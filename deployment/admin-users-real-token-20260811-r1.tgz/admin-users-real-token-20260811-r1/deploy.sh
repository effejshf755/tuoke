#!/usr/bin/env bash
set -Eeuo pipefail

CONTAINER="tuoke-prod-freellmapi-1"
COMPOSE_FILE="/srv/tuoke-prod/docker-compose.yml"
COMPOSE_PROJECT="tuoke-prod"
COMPOSE_SERVICE="freellmapi"
DATA_VOLUME="tuoke-prod_freellmapi-data"
PUBLIC_ORIGIN="https://tuokeapi.com"
EXPECTED_COMPOSE_HASH="5ffef3822d4f267dbaf96a2bd79ef53f03f16875099840074b7369ced18e41f5"
EXPECTED_BASE_IMAGE="migration-japan/tuokeapi:20260810-admin-users-total-io-r1"
EXPECTED_BASE_IMAGE_ID="sha256:47d9f56e986e60895d414f5754c805a062c6bf3084445ce3c6cc13dedfcec2df"
EXPECTED_BASE_RELEASE="admin-users-total-io-20260810-r1"
RELEASE_LABEL="admin-users-real-token-20260811-r1"
NEW_IMAGE="migration-japan/tuokeapi:20260811-admin-users-real-token-r1"
CLIENT_JS="index-admin-users-total-io-r1.js"
CLIENT_CSS="index-O2MQsLsm.css"
OLD_ROUTE_SHA256="7af222fd88265528dc7fe8620af4ef3dc73c6a13d061c40dd4dd73cd4c16dbc7"
NEW_ROUTE_SHA256="098b83fd284c8ae59a72340d5d3b34a856257f8fa471823db13d2ae874ba49df"

RELEASE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="/root/deploy-backups/${RELEASE_LABEL}-${STAMP}"

stage() { printf 'deployment_stage=%s\n' "$1"; }

stage lock
exec 9>/var/lock/tuoke-api-deploy.lock
flock -n 9 || { echo "deployment_lock=busy" >&2; exit 75; }

stage release_validation
test "$(id -u)" -eq 0
test -f "$COMPOSE_FILE"
test -f "$RELEASE_DIR/Dockerfile"
test -f "$RELEASE_DIR/MANIFEST.sha256"
test -s "$RELEASE_DIR/server-dist/routes/admin-users.js"
(cd "$RELEASE_DIR" && sha256sum -c MANIFEST.sha256)
node --check "$RELEASE_DIR/server-dist/routes/admin-users.js"

docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config -q
mapfile -t COMPOSE_IMAGES < <(docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config --images)
test "${#COMPOSE_IMAGES[@]}" -eq 1
test "${COMPOSE_IMAGES[0]}" = "$EXPECTED_BASE_IMAGE"
COMPOSE_HASH="$(sha256sum "$COMPOSE_FILE" | awk '{print $1}')"
test "$COMPOSE_HASH" = "$EXPECTED_COMPOSE_HASH"

docker inspect "$CONTAINER" >/dev/null
test "$(docker inspect --format '{{.State.Status}}' "$CONTAINER")" = "running"
test "$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER")" = "healthy"
OLD_IMAGE="$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")"
OLD_IMAGE_ID="$(docker inspect --format '{{.Image}}' "$CONTAINER")"
OLD_RELEASE="$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$OLD_IMAGE")"
test "$OLD_IMAGE" = "$EXPECTED_BASE_IMAGE"
test "$OLD_IMAGE_ID" = "$EXPECTED_BASE_IMAGE_ID"
test "$OLD_RELEASE" = "$EXPECTED_BASE_RELEASE"
test "$(docker image inspect --format '{{.Id}}' "$OLD_IMAGE")" = "$OLD_IMAGE_ID"
test "$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project"}}' "$CONTAINER")" = "$COMPOSE_PROJECT"
test "$(docker inspect --format '{{index .Config.Labels "com.docker.compose.service"}}' "$CONTAINER")" = "$COMPOSE_SERVICE"
test "$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project.config_files"}}' "$CONTAINER")" = "$COMPOSE_FILE"
test "$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project.working_dir"}}' "$CONTAINER")" = "/srv/tuoke-prod"
test "$(docker inspect --format '{{range .Mounts}}{{if eq .Destination "/app/server/data"}}{{.Name}}{{end}}{{end}}' "$CONTAINER")" = "$DATA_VOLUME"

assert_live_baseline() {
  test "$(sha256sum "$COMPOSE_FILE" | awk '{print $1}')" = "$COMPOSE_HASH"
  mapfile -t current_compose_images < <(docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config --images)
  test "${#current_compose_images[@]}" -eq 1
  test "${current_compose_images[0]}" = "$OLD_IMAGE"
  test "$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")" = "$OLD_IMAGE"
  test "$(docker inspect --format '{{.Image}}' "$CONTAINER")" = "$OLD_IMAGE_ID"
  test "$(docker image inspect --format '{{.Id}}' "$OLD_IMAGE")" = "$OLD_IMAGE_ID"
  test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$OLD_IMAGE")" = "$EXPECTED_BASE_RELEASE"
}

assert_live_baseline
docker exec "$CONTAINER" sh -lc "
  set -eu
  echo '$OLD_ROUTE_SHA256  /app/server/dist/routes/admin-users.js' | sha256sum -c -
  echo '4812648ac42d141b1e15b063041cf2e923497497506c4a991c9bdc17fb617440  /app/client/dist/index.html' | sha256sum -c -
  echo 'e05e94c15b32ba71de122caf67704ce2c73038f143781099be4b5bf3010c8b00  /app/client/dist/assets/$CLIENT_JS' | sha256sum -c -
  echo '73de455c265aa18654a1d974220cee44b1688870c5e5cd9a2bc4b6794a0de0a0  /app/client/dist/assets/$CLIENT_CSS' | sha256sum -c -
"

stage backup
install -d -m 0700 "$BACKUP_DIR"
cp -a "$COMPOSE_FILE" "$BACKUP_DIR/docker-compose.yml.before"
chmod 0600 "$BACKUP_DIR/docker-compose.yml.before"
docker inspect "$CONTAINER" > "$BACKUP_DIR/container-inspect.before.json"
docker volume inspect "$DATA_VOLUME" > "$BACKUP_DIR/data-volume.before.json"
printf '%s\n' "$OLD_IMAGE" > "$BACKUP_DIR/previous-image.txt"
printf '%s\n' "$OLD_IMAGE_ID" > "$BACKUP_DIR/previous-image-id.txt"
sha256sum "$COMPOSE_FILE" > "$BACKUP_DIR/docker-compose.yml.before.sha256"

CONTAINER_DB_BACKUP="/app/server/data/.deploy-backup-${STAMP}.db"
docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  const target = process.argv[1];
  const source = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  await source.backup(target);
  source.close();
  const copy = new Database(target, { readonly: true, fileMustExist: true });
  const result = copy.pragma("quick_check", { simple: true });
  copy.close();
  if (result !== "ok") throw new Error(`backup quick_check failed: ${result}`);
' "$CONTAINER_DB_BACKUP"
docker cp "$CONTAINER:$CONTAINER_DB_BACKUP" "$BACKUP_DIR/freeapi-before.db"
docker exec "$CONTAINER" rm -f -- "$CONTAINER_DB_BACKUP"
test -s "$BACKUP_DIR/freeapi-before.db"
sha256sum "$BACKUP_DIR/freeapi-before.db" > "$BACKUP_DIR/freeapi-before.db.sha256"

stage candidate_build
docker build \
  --pull=false \
  --build-arg "BASE_IMAGE=$OLD_IMAGE" \
  --build-arg "BASE_IMAGE_ID=$OLD_IMAGE_ID" \
  --build-arg "BASE_RELEASE=$OLD_RELEASE" \
  --tag "$NEW_IMAGE" \
  "$RELEASE_DIR"

test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$NEW_IMAGE")" = "$RELEASE_LABEL"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.expected-base"}}' "$NEW_IMAGE")" = "$OLD_IMAGE"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.expected-base-id"}}' "$NEW_IMAGE")" = "$OLD_IMAGE_ID"
NEW_IMAGE_ID="$(docker image inspect --format '{{.Id}}' "$NEW_IMAGE")"
test -n "$NEW_IMAGE_ID"

stage isolated_route_test
docker run --rm -i \
  --env ENCRYPTION_KEY=0000000000000000000000000000000000000000000000000000000000000000 \
  --entrypoint node \
  "$NEW_IMAGE" \
  --input-type=module - <<'NODE'
import { initDb, getDb } from "/app/server/dist/db/index.js";
import { createUser, createSession } from "/app/server/dist/services/auth.js";
import { createConsumerApiKey } from "/app/server/dist/services/consumer-api-keys.js";
import { createApp } from "/app/server/dist/app.js";

initDb(":memory:");
const admin = createUser("real-token-admin@example.test", "password123");
const target = createUser("real-token-target@example.test", "password123");
const db = getDb();
const key = createConsumerApiKey(db, target.userId, "usage-stats");

db.prepare(`
  INSERT INTO requests (
    platform, model_id, status, input_tokens, output_tokens,
    input_compute_points, output_compute_points,
    compute_points_per_million_tokens, consumer_user_id,
    consumer_api_key_id, created_at
  ) VALUES (
    'openai-codex', 'gpt-usage-current', 'success', 100, 20,
    150, 30, 1500000, ?, ?, datetime('now')
  )
`).run(target.userId, key.record.id);

db.prepare(`
  INSERT INTO requests (
    platform, model_id, status, input_tokens, output_tokens,
    input_compute_points, output_compute_points,
    compute_points_per_million_tokens, consumer_user_id,
    consumer_api_key_id, created_at
  ) VALUES (
    'openai-codex', 'gpt-usage-history', 'success', 40, 10,
    400, 100, 10000000, NULL, ?, datetime('now', '-2 months')
  )
`).run(key.record.id);

const app = createApp();
const server = await new Promise((resolve) => {
  const running = app.listen(0, "127.0.0.1", () => resolve(running));
});
try {
  const port = server.address().port;
  const response = await fetch(`http://127.0.0.1:${port}/api/admin/users`, {
    headers: { Authorization: `Bearer ${createSession(admin.userId)}` },
  });
  const body = await response.json();
  const row = body.users?.find((entry) => entry.id === target.userId);
  if (response.status !== 200 ||
      row?.monthly_used_tokens !== 120 ||
      row?.total_used_tokens !== 170 ||
      row?.total_compute_points !== 680) {
    throw new Error(`admin user usage contract failed: ${JSON.stringify({ status: response.status, row })}`);
  }
  console.log("isolated_admin_user_usage_contract=ok");
} finally {
  await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
}
NODE

stage live_read_only_query
docker run --rm \
  --volume "$DATA_VOLUME:/app/server/data:ro" \
  --entrypoint node \
  "$NEW_IMAGE" \
  --input-type=module -e '
    import Database from "better-sqlite3";
    const db = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
    const result = db.pragma("quick_check", { simple: true });
    if (result !== "ok") throw new Error(`live quick_check failed: ${result}`);
    const columns = new Set(db.prepare("PRAGMA table_info(requests)").all().map((row) => row.name));
    for (const name of ["input_tokens", "output_tokens", "input_compute_points", "output_compute_points"]) {
      if (!columns.has(name)) throw new Error(`missing requests column: ${name}`);
    }
    db.close();
    console.log("candidate_live_usage_schema=ok");
  '

# Refuse to switch if another deployment changed production during the build.
assert_live_baseline

SWITCH_STARTED=0
rollback() {
  local code="${1:-$?}"
  local rollback_ok=0
  trap - ERR HUP INT TERM
  set +e
  if [ "$SWITCH_STARTED" -eq 1 ]; then
    cp -a "$BACKUP_DIR/docker-compose.yml.before" "$COMPOSE_FILE"
    chmod 0600 "$COMPOSE_FILE"
    docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"
    for _ in $(seq 1 30); do
      if test "$(docker inspect --format '{{.Config.Image}}' "$CONTAINER" 2>/dev/null)" = "$OLD_IMAGE" \
        && test "$(docker inspect --format '{{.Image}}' "$CONTAINER" 2>/dev/null)" = "$OLD_IMAGE_ID" \
        && docker exec "$CONTAINER" node -e '
          fetch("http://127.0.0.1:3001/api/ping")
            .then(async response => {
              const body = await response.json();
              if (!response.ok || body.status !== "ok") process.exit(1);
            })
            .catch(() => process.exit(1));
        ' >/dev/null 2>&1; then
        rollback_ok=1
        break
      fi
      sleep 2
    done
    if [ "$rollback_ok" -eq 1 ]; then
      echo "deployment_result=rolled_back" >&2
    else
      echo "deployment_result=rollback_failed" >&2
    fi
  fi
  exit "$code"
}
trap 'rollback $?' ERR
trap 'rollback 129' HUP
trap 'rollback 130' INT
trap 'rollback 143' TERM

stage switch
SWITCH_STARTED=1
python3 - "$COMPOSE_FILE" "$NEW_IMAGE" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
image = sys.argv[2]
lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
inside = False
replaced = False
for index, line in enumerate(lines):
    if line.startswith("  freellmapi:"):
        inside = True
        continue
    if inside and line.startswith("  ") and not line.startswith("    ") and line.strip():
        break
    if inside and line.startswith("    image:"):
        newline = "\n" if line.endswith("\n") else ""
        lines[index] = f"    image: {image}{newline}"
        replaced = True
        break
if not replaced:
    raise SystemExit("freellmapi image entry not found")
temporary = path.with_suffix(path.suffix + ".codex-new")
temporary.write_text("".join(lines), encoding="utf-8")
temporary.chmod(0o600)
temporary.replace(path)
PY

docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config -q
docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"

stage health_check
HEALTH_OK=0
for _ in $(seq 1 60); do
  STATUS="$(docker inspect --format '{{.State.Status}}' "$CONTAINER" 2>/dev/null || true)"
  HEALTH="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER" 2>/dev/null || true)"
  if [ "$STATUS" = "running" ] && { [ "$HEALTH" = "healthy" ] || [ "$HEALTH" = "none" ]; }; then
    if docker exec "$CONTAINER" node -e '
      fetch("http://127.0.0.1:3001/api/ping")
        .then(async response => {
          const body = await response.json();
          if (!response.ok || body.status !== "ok") process.exit(1);
        })
        .catch(() => process.exit(1));
    ' >/dev/null 2>&1; then
      HEALTH_OK=1
      break
    fi
  fi
  if [ "$STATUS" = "exited" ] || [ "$STATUS" = "dead" ]; then
    break
  fi
  sleep 2
done
test "$HEALTH_OK" -eq 1

test "$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")" = "$NEW_IMAGE"
test "$(docker inspect --format '{{.Image}}' "$CONTAINER")" = "$NEW_IMAGE_ID"
test "$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER")" != "unhealthy"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$NEW_IMAGE")" = "$RELEASE_LABEL"

docker exec "$CONTAINER" sh -lc "
  set -eu
  echo '$NEW_ROUTE_SHA256  /app/server/dist/routes/admin-users.js' | sha256sum -c -
  test ! -e /app/server/dist/routes/admin-users.js.map
  echo '4812648ac42d141b1e15b063041cf2e923497497506c4a991c9bdc17fb617440  /app/client/dist/index.html' | sha256sum -c -
  echo 'e05e94c15b32ba71de122caf67704ce2c73038f143781099be4b5bf3010c8b00  /app/client/dist/assets/$CLIENT_JS' | sha256sum -c -
  echo '73de455c265aa18654a1d974220cee44b1688870c5e5cd9a2bc4b6794a0de0a0  /app/client/dist/assets/$CLIENT_CSS' | sha256sum -c -
"

docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  const db = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  const result = db.pragma("quick_check", { simple: true });
  db.close();
  if (result !== "ok") throw new Error(`live quick_check failed: ${result}`);
  console.log("live_database_quick_check=ok");
'

PUBLIC_OK=0
for _ in $(seq 1 30); do
  if docker exec "$CONTAINER" node -e "
    Promise.all([
      fetch('$PUBLIC_ORIGIN/api/ping', { cache: 'no-store' }).then(async response => {
        const body = await response.json();
        if (!response.ok || body.status !== 'ok') throw new Error('public ping failed');
      }),
      fetch('$PUBLIC_ORIGIN/', { cache: 'no-store' }).then(async response => {
        const html = await response.text();
        if (!response.ok || !html.includes('/assets/$CLIENT_JS') || !html.includes('/assets/$CLIENT_CSS')) {
          throw new Error('public client assets are stale');
        }
      }),
    ]).catch(() => process.exit(1));
  " >/dev/null 2>&1; then
    PUBLIC_OK=1
    break
  fi
  sleep 2
done
test "$PUBLIC_OK" -eq 1
test "$(docker inspect --format '{{.RestartCount}}' "$CONTAINER")" = "0"

SWITCH_STARTED=0
trap - ERR HUP INT TERM
echo "deployment_result=ok"
echo "deployment_mode=verified_admin_users_real_token_overlay"
echo "backup_dir=$BACKUP_DIR"
echo "previous_image=$OLD_IMAGE"
echo "previous_image_id=$OLD_IMAGE_ID"
echo "new_image=$NEW_IMAGE"
echo "new_image_id=$NEW_IMAGE_ID"
