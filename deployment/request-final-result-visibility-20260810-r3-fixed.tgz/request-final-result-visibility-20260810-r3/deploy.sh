#!/usr/bin/env bash
set -Eeuo pipefail

CONTAINER="tuoke-prod-freellmapi-1"
COMPOSE_FILE="/srv/tuoke-prod/docker-compose.yml"
COMPOSE_PROJECT="tuoke-prod"
COMPOSE_SERVICE="freellmapi"
PUBLIC_ORIGIN="https://tuokeapi.com"
RELEASE_LABEL="request-final-result-visibility-20260810-r3"
NEW_IMAGE="migration-japan/tuokeapi:20260810-request-final-result-visibility-r3"

RELEASE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="/root/deploy-backups/${RELEASE_LABEL}-${STAMP}"

stage() { printf 'deployment_stage=%s\n' "$1"; }

stage lock
exec 9>/var/lock/tuoke-api-deploy.lock
flock -n 9 || { echo "deployment_lock=busy" >&2; exit 75; }

stage release_validation
test "$(id -u)" -eq 0
test -f "$COMPOSE_FILE"
test -f "$RELEASE_DIR/Dockerfile"
test -f "$RELEASE_DIR/MANIFEST.sha256"
(cd "$RELEASE_DIR" && sha256sum -c MANIFEST.sha256)
for path in \
  server-dist/lib/request-log.js \
  server-dist/lib/fallback-loop.js \
  server-dist/services/fusion.js \
  server-dist/routes/user.js \
  server-dist/routes/user-analytics.js \
  server-dist/db/migrations/20260810_000083_request_visibility_chain.js \
  client-dist/index.html; do
  test -s "$RELEASE_DIR/$path"
done
CLIENT_JS="$(grep -oE '/assets/[^\" ]+\.js' "$RELEASE_DIR/client-dist/index.html" | head -n 1 | sed 's#^/assets/##')"
CLIENT_CSS="$(grep -oE '/assets/[^\" ]+\.css' "$RELEASE_DIR/client-dist/index.html" | head -n 1 | sed 's#^/assets/##')"
test -n "$CLIENT_JS"
test -n "$CLIENT_CSS"
test -s "$RELEASE_DIR/client-dist/assets/$CLIENT_JS"
test -s "$RELEASE_DIR/client-dist/assets/$CLIENT_CSS"
echo "client_entrypoints=$CLIENT_JS,$CLIENT_CSS"

stage live_baseline
docker inspect "$CONTAINER" >/dev/null
test "$(docker inspect --format '{{.State.Status}}' "$CONTAINER")" = "running"
OLD_IMAGE="$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")"
OLD_IMAGE_ID="$(docker inspect --format '{{.Image}}' "$CONTAINER")"
test -n "$OLD_IMAGE"
test -n "$OLD_IMAGE_ID"
test "$(docker image inspect --format '{{.Id}}' "$OLD_IMAGE")" = "$OLD_IMAGE_ID"
echo "baseline_image=$OLD_IMAGE"
echo "baseline_image_id=$OLD_IMAGE_ID"

assert_live_baseline() {
  local actual_image actual_id tagged_id
  actual_image="$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")"
  actual_id="$(docker inspect --format '{{.Image}}' "$CONTAINER")"
  tagged_id="$(docker image inspect --format '{{.Id}}' "$OLD_IMAGE")"
  test "$actual_image" = "$OLD_IMAGE"
  test "$actual_id" = "$OLD_IMAGE_ID"
  test "$tagged_id" = "$OLD_IMAGE_ID"
}
assert_live_baseline

stage backup
install -d -m 0700 "$BACKUP_DIR"
cp -a "$COMPOSE_FILE" "$BACKUP_DIR/docker-compose.yml.before"
docker inspect "$CONTAINER" > "$BACKUP_DIR/container-inspect.before.json"
docker volume inspect tuoke-prod_freellmapi-data > "$BACKUP_DIR/data-volume.before.json"
sha256sum "$COMPOSE_FILE" > "$BACKUP_DIR/docker-compose.yml.before.sha256"
printf '%s\n' "$OLD_IMAGE" > "$BACKUP_DIR/previous-image.txt"
printf '%s\n' "$OLD_IMAGE_ID" > "$BACKUP_DIR/previous-image-id.txt"
CONTAINER_DB_BACKUP="/app/server/data/.deploy-backup-${STAMP}.db"
docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  const target = process.argv[1];
  const source = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  await source.backup(target);
  source.close();
  const copy = new Database(target, { readonly: true, fileMustExist: true });
  const result = copy.pragma("quick_check", { simple: true });
  copy.close();
  if (result !== "ok") throw new Error(`backup quick_check failed: ${result}`);
  console.log("database_backup_quick_check=ok");
' "$CONTAINER_DB_BACKUP"
docker cp "$CONTAINER:$CONTAINER_DB_BACKUP" "$BACKUP_DIR/freeapi-before.db"
docker exec "$CONTAINER" rm -f -- "$CONTAINER_DB_BACKUP"
test -s "$BACKUP_DIR/freeapi-before.db"
sha256sum "$BACKUP_DIR/freeapi-before.db" > "$BACKUP_DIR/freeapi-before.db.sha256"
echo "backup_dir=$BACKUP_DIR"

stage image_build
docker build --pull=false --build-arg "BASE_IMAGE=$OLD_IMAGE" --tag "$NEW_IMAGE" "$RELEASE_DIR"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$NEW_IMAGE")" = "$RELEASE_LABEL"
NEW_IMAGE_ID="$(docker image inspect --format '{{.Id}}' "$NEW_IMAGE")"
test -n "$NEW_IMAGE_ID"
for file in \
  /app/server/dist/index.js \
  /app/server/dist/lib/request-log.js \
  /app/server/dist/lib/fallback-loop.js \
  /app/server/dist/services/fusion.js \
  /app/server/dist/routes/user.js \
  /app/server/dist/routes/user-analytics.js \
  /app/server/dist/db/migrations/20260810_000083_request_visibility_chain.js; do
  docker run --rm --entrypoint node "$NEW_IMAGE" --check "$file"
done
docker run --rm --entrypoint sh "$NEW_IMAGE" -lc "
  set -eu
  test -s /app/client/dist/assets/$CLIENT_JS
  test -s /app/client/dist/assets/$CLIENT_CSS
  grep -q 'user_visible' /app/server/dist/lib/request-log.js
  grep -q 'request_chain_id' /app/server/dist/lib/request-log.js
  grep -q 'userVisible' /app/server/dist/services/fusion.js
  grep -q 'USER_VISIBLE_REQUEST_RESULT_SQL' /app/server/dist/routes/user.js
  grep -q 'USER_VISIBLE_REQUEST_RESULT_SQL' /app/server/dist/routes/user-analytics.js
"
assert_live_baseline

SWITCH_STARTED=0
rollback() {
  local code=$?
  set +e
  if [ "$SWITCH_STARTED" -eq 1 ]; then
    cp -a "$BACKUP_DIR/docker-compose.yml.before" "$COMPOSE_FILE"
    chmod 0600 "$COMPOSE_FILE"
    docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"
    echo "deployment_result=rolled_back" >&2
  fi
  exit "$code"
}
trap rollback ERR

stage switch
SWITCH_STARTED=1
python3 - "$COMPOSE_FILE" "$NEW_IMAGE" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
image = sys.argv[2]
lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
inside = False
replaced = False
for index, line in enumerate(lines):
    if line.startswith("  freellmapi:"):
        inside = True
        continue
    if inside and line.startswith("  ") and not line.startswith("    ") and line.strip():
        break
    if inside and line.startswith("    image:"):
        newline = "\n" if line.endswith("\n") else ""
        lines[index] = f"    image: {image}{newline}"
        replaced = True
        break
if not replaced:
    raise SystemExit("freellmapi image entry not found")
temporary = path.with_suffix(path.suffix + ".codex-new")
temporary.write_text("".join(lines), encoding="utf-8")
temporary.chmod(0o600)
temporary.replace(path)
PY
docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config -q
docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"

stage health_check
HEALTH_OK=0
for _ in $(seq 1 60); do
  STATUS="$(docker inspect --format '{{.State.Status}}' "$CONTAINER" 2>/dev/null || true)"
  HEALTH="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER" 2>/dev/null || true)"
  if [ "$STATUS" = "running" ] && { [ "$HEALTH" = "healthy" ] || [ "$HEALTH" = "none" ]; }; then
    if docker exec "$CONTAINER" node -e 'fetch("http://127.0.0.1:3001/api/ping").then(async response => { const body = await response.json(); if (!response.ok || body.status !== "ok") process.exit(1); }).catch(() => process.exit(1));' >/dev/null 2>&1; then
      HEALTH_OK=1
      break
    fi
  fi
  if [ "$STATUS" = "exited" ] || [ "$STATUS" = "dead" ]; then break; fi
  sleep 2
done
test "$HEALTH_OK" -eq 1
test "$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")" = "$NEW_IMAGE"
test "$(docker inspect --format '{{.Image}}' "$CONTAINER")" = "$NEW_IMAGE_ID"
docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  const db = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  const quickCheck = db.pragma("quick_check", { simple: true });
  const columns = new Set(db.prepare("PRAGMA table_info(requests)").all().map(row => row.name));
  db.close();
  if (quickCheck !== "ok") throw new Error(`live quick_check failed: ${quickCheck}`);
  for (const column of ["user_visible", "request_chain_id"]) if (!columns.has(column)) throw new Error(`migration missing requests.${column}`);
  console.log("live_database_and_migration_check=ok");
'

PUBLIC_OK=0
for _ in $(seq 1 30); do
  if docker exec "$CONTAINER" node -e "Promise.all([fetch('$PUBLIC_ORIGIN/api/ping',{cache:'no-store'}).then(async r=>{const b=await r.json();if(!r.ok||b.status!=='ok')throw new Error('ping')}),fetch('$PUBLIC_ORIGIN/',{cache:'no-store'}).then(async r=>{const h=await r.text();if(!r.ok||!h.includes('/assets/$CLIENT_JS')||!h.includes('/assets/$CLIENT_CSS'))throw new Error('assets')})]).catch(()=>process.exit(1));" >/dev/null 2>&1; then
    PUBLIC_OK=1
    break
  fi
  sleep 2
done
test "$PUBLIC_OK" -eq 1

SWITCH_STARTED=0
trap - ERR
stage complete
echo "deployment_result=ok"
echo "backup_dir=$BACKUP_DIR"
echo "previous_image=$OLD_IMAGE"
echo "previous_image_id=$OLD_IMAGE_ID"
echo "new_image=$NEW_IMAGE"
echo "new_image_id=$NEW_IMAGE_ID"
