param(
  [string]$RepositoryRoot = (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
)

$ErrorActionPreference = 'Stop'

$releaseRoot = $PSScriptRoot
$serverDist = Join-Path $RepositoryRoot 'server\dist'
$clientDist = Join-Path $RepositoryRoot 'client\dist'
$releaseServerDist = Join-Path $releaseRoot 'server-dist'
$releaseClientDist = Join-Path $releaseRoot 'client-dist'
$requiredServerFiles = @(
  'lib\request-log.js',
  'lib\fallback-loop.js',
  'services\fusion.js',
  'routes\user.js',
  'routes\user-analytics.js',
  'db\migrations\20260810_000083_request_visibility_chain.js'
)

foreach ($path in @($serverDist, $clientDist)) {
  if (-not (Test-Path -LiteralPath $path -PathType Container)) {
    throw "Expected built artifact directory is missing: $path"
  }
}
foreach ($relativePath in $requiredServerFiles) {
  $path = Join-Path $serverDist $relativePath
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
    throw "Required server artifact is missing: $path"
  }
}
foreach ($relativePath in @('index.html', 'assets')) {
  $path = Join-Path $clientDist $relativePath
  if (-not (Test-Path -LiteralPath $path)) {
    throw "Required client artifact is missing: $path"
  }
}

foreach ($target in @($releaseServerDist, $releaseClientDist)) {
  if (Test-Path -LiteralPath $target) {
    Remove-Item -LiteralPath $target -Recurse -Force
  }
}

New-Item -ItemType Directory -Path $releaseServerDist | Out-Null
New-Item -ItemType Directory -Path $releaseClientDist | Out-Null
Copy-Item -Path (Join-Path $serverDist '*') -Destination $releaseServerDist -Recurse -Force
Copy-Item -Path (Join-Path $clientDist '*') -Destination $releaseClientDist -Recurse -Force -Exclude 'media'

$indexHtml = Get-Content -LiteralPath (Join-Path $releaseClientDist 'index.html') -Raw
$clientJs = [regex]::Match($indexHtml, '/assets/([^" ]+\.js)').Groups[1].Value
$clientCss = [regex]::Match($indexHtml, '/assets/([^" ]+\.css)').Groups[1].Value
foreach ($relativePath in @("assets\$clientJs", "assets\$clientCss")) {
  if (-not (Test-Path -LiteralPath (Join-Path $releaseClientDist $relativePath) -PathType Leaf)) {
    throw "Client entrypoint references a missing artifact: $relativePath"
  }
}
if (Test-Path -LiteralPath (Join-Path $releaseClientDist 'media')) {
  throw 'The release archive must not include the large immutable media directory.'
}

$manifestPath = Join-Path $releaseRoot 'MANIFEST.sha256'
$files = Get-ChildItem -LiteralPath $releaseRoot -File -Recurse |
  Where-Object { $_.FullName -ne $manifestPath } |
  Sort-Object FullName
$lines = foreach ($file in $files) {
  $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
  $relative = $file.FullName.Substring($releaseRoot.Length + 1).Replace('\', '/')
  "$hash  $relative"
}
$manifestText = ($lines -join "`n") + "`n"
[System.IO.File]::WriteAllText($manifestPath, $manifestText, [System.Text.UTF8Encoding]::new($false))

Write-Output "release_payload_ready=$releaseRoot"
Write-Output "client_js=$clientJs"
Write-Output "client_css=$clientCss"
Write-Output "manifest_entries=$($lines.Count)"
