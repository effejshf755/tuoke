import { PUBLIC_UPSTREAM_FAILURE_MESSAGE } from '../lib/error-redaction.js';
export function errorHandler(err, _req, res, next) {
    console.error('[Error]', err.message);
    if (res.headersSent)
        return next(err);
    // Route handlers send their own client-validation failures. Anything that
    // reaches this last-resort handler may contain an upstream response body,
    // including 400/422 relay errors, so never expose `err.message` here.
    res.status(502).json({
        error: {
            message: PUBLIC_UPSTREAM_FAILURE_MESSAGE,
            type: 'server_error',
        },
    });
}
//# sourceMappingURL=errorHandler.js.map