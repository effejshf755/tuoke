import crypto from 'crypto';
import { Router } from 'express';
import { z } from 'zod';
import multer from 'multer';
import { routeRequest, resolveRoutingChain, resolveModelGroupCandidates, hasEnabledVisionModel, hasEnabledToolsModel, requiresCodexMultiTurnCapability, routingReserveTokens } from '../services/router.js';
import { runEmbeddings, EmbeddingsError } from '../services/embeddings.js';
import { runImageEdit, runImageGeneration, runSpeech, MediaError } from '../services/media.js';
import { getDb, getUnifiedApiKey } from '../db/index.js';
import { contentToString, messageHasImage, normalizeOutboundContent, sanitizeResponse } from '../lib/content.js';
import { repairToolArguments, toolSchemaMap } from '../lib/tool-args.js';
import { PUBLIC_UPSTREAM_FAILURE_MESSAGE, PUBLIC_UPSTREAM_STREAM_FAILURE_MESSAGE, sanitizeProviderErrorMessage, } from '../lib/error-redaction.js';
import { rescueInlineToolCalls, startsWithDialectMarker, couldBecomeDialectMarker, containsDialectMarker } from '../lib/tool-call-rescue.js';
import { getContextHandoffMode, recordIncomingMessages, maybeInjectContextHandoff, recordSuccessfulModel, hasPriorModel, HANDOFF_MAX_TOKENS } from '../services/context-handoff.js';
import { isFusionModel, runFusion, fusionConfigSchema, FusionError, FUSION_MODEL_ID } from '../services/fusion.js';
import { isRetryableError, isPaymentRequiredError, isModelNotFoundError, isModelAccessForbiddenError, providerStreamErrorFromChunk } from '../lib/error-classify.js';
import { logRequest } from '../lib/request-log.js';
import { parseCacheDirective, cacheActive, isCacheableTemperature, computeCacheKey, getCachedResponse, storeCachedResponse, resolveResponseCachePolicyNamespace, isResponseCacheLookupAuthorized } from '../services/cache.js';
import { runFallbackLoop, newFallbackState, recordCommittedUpstreamFailure, recordUpstreamSuccess, exhaustedRetryError, setFallbackHeaders, } from '../lib/fallback-loop.js';
import { applyTokenBudget, tokenBudgetMessage } from '../lib/guardrails.js';
import { samplingParamSchemaFields, pickSamplingParams, supportedParametersForPlatforms } from '../lib/sampling-params.js';
import { enforceJsonContent } from '../lib/structured-output.js';
import { inferQuotaPoolKey } from '../services/provider-quota.js';
import { isUnifyEnabled, getModelGroups, resolveRequestedIdToMembers } from '../services/model-groups.js';
import { buildModelListing, filterModelListingForCodexConsumer, filterModelListingForConsumer, getCodexConsumerModelDbId } from '../services/model-listing.js';
import { validateConsumerApiKey } from '../services/consumer-api-keys.js';
import { getClientContext, setConsumerIdentity } from '../lib/client-context.js';
import { codexCachedInputTokensFromUsage, codexCacheWriteTokensFromUsage, normalizeCodexPromptCacheUsage, } from '../lib/codex-cache-usage.js';
import { assertWalletStreamBudget, isWalletSafetyBalanceReachedError, WALLET_SAFETY_STOP_MESSAGE, } from '../services/wallet-stream-budget.js';
export const proxyRouter = Router();
// Virtual "auto" model. Clients like Hermes require a non-empty `model` field
// on every request, but freellmapi's whole point is to pick the model itself.
// Requesting this id means "let the router decide" — identical to omitting
// `model` entirely.
const AUTO_MODEL_ID = 'auto';
function isAutoModel(modelId) {
    if (!modelId)
        return true;
    const lower = modelId.toLowerCase();
    return lower === AUTO_MODEL_ID || lower.startsWith(`${AUTO_MODEL_ID}:`);
}
// Constant-time string comparison for the unified API key. Plain `===` leaks
// length and per-character timing, which a network attacker could in principle
// use to recover the key one byte at a time.
export function timingSafeStringEqual(provided, expected) {
    if (provided.startsWith('tuoke-')) {
        const consumerKey = validateConsumerApiKey(getDb(), provided);
        if (consumerKey) {
            setConsumerIdentity(consumerKey.userId, consumerKey.id, consumerKey.keyType, consumerKey.codexGroupId);
        }
        return consumerKey !== null;
    }
    // Use HMAC to produce fixed-length digests so timingSafeEqual always
    // receives same-length buffers regardless of input length. This eliminates
    // both the per-character timing leak and the length-branch timing leak that
    // the Buffer.alloc-on-mismatch approach had.
    const key = Buffer.alloc(32);
    const a = crypto.createHmac('sha256', key).update(provided).digest();
    const b = crypto.createHmac('sha256', key).update(expected).digest();
    return crypto.timingSafeEqual(a, b);
}
// Extract the unified API key from an incoming request. Accepts both the
// OpenAI-style `Authorization: Bearer <key>` header and the Anthropic-style
// `x-api-key` header. Clients that speak the Anthropic wire format — notably
// Claude Code routed through CC Switch (#103) — send the key in `x-api-key`
// rather than a bearer token, and were getting a spurious "Invalid API key"
// 401 before this fallback existed.
export function extractApiToken(req) {
    const bearer = req.headers.authorization?.replace(/^Bearer\s+/i, '').trim();
    if (bearer)
        return bearer;
    const apiKeyHeader = req.headers['x-api-key'];
    const xApiKey = Array.isArray(apiKeyHeader) ? apiKeyHeader[0] : apiKeyHeader;
    const trimmed = xApiKey?.trim();
    return trimmed || undefined;
}
function quotaContextForRoute(route, endpoint) {
    return {
        platform: route.platform,
        keyId: route.keyId,
        modelId: route.modelId,
        quotaPoolKey: inferQuotaPoolKey(route.platform, route.modelId),
        endpoint,
        origin: 'proxy',
    };
}
export function getRequestGroupId(req) {
    const raw = req.headers['x-request-id'];
    const value = Array.isArray(raw) ? raw[0] : raw;
    const trimmed = value?.trim();
    return trimmed || crypto.randomUUID();
}
function shortRequestId(requestId) {
    return requestId.replace(/-/g, '').slice(0, 6);
}
export function traceRouteEvent(scope, opts) {
    const parts = [
        `[${scope}]`,
        new Date().toISOString().slice(11, 19),
        opts.event,
        shortRequestId(opts.requestId),
        `a${opts.attempt}`,
        opts.platform,
        '-',
        opts.model,
    ];
    if (opts.requestedModel)
        parts.push(`req=${opts.requestedModel}`);
    if (opts.latencyMs != null)
        parts.push(`lat=${opts.latencyMs}ms`);
    if (opts.inputTokens != null)
        parts.push(`in=${opts.inputTokens}`);
    if (opts.outputTokens != null)
        parts.push(`out=${opts.outputTokens}`);
    if (opts.error)
        parts.push(`err=${JSON.stringify(opts.error)}`);
    console.log(parts.join(' '));
}
// exhaustedRetryError moved to lib/fallback-loop.ts (the shared retry loop needs
// it and importing it back from a route would be a cycle). Re-exported here for
// existing importers (routes/responses.ts, proxy-retry.test.ts historically).
export { exhaustedRetryError };
// Sticky sessions: track which model served each "session"
// Key: hash of first user message → model_db_id
// This prevents model switching mid-conversation which causes hallucination
const stickySessionMap = new Map();
const STICKY_TTL_MS = 30 * 60 * 1000; // 30 min session TTL
function getSessionKey(messages, sessionIdHeader, strategyKey) {
    const consumerKeyId = getClientContext().consumerApiKeyId;
    const policyNamespace = consumerKeyId === null
        ? 'operator'
        : `consumer-key:${consumerKeyId}`;
    if (sessionIdHeader) {
        const identity = strategyKey
            ? `hdr:${sessionIdHeader}::${strategyKey}`
            : `hdr:${sessionIdHeader}`;
        return crypto.createHash('sha256').update(`${policyNamespace}::${identity}`).digest('hex');
    }
    const firstUser = messages.find(m => m.role === 'user');
    if (!firstUser)
        return '';
    const text = contentToString(firstUser.content ?? '');
    if (!text)
        return '';
    const payload = strategyKey ? `${text}::${strategyKey}` : text;
    return crypto.createHash('sha256').update(`${policyNamespace}::msg:${payload}`).digest('hex');
}
function resolveChatUsageForAccounting(usage, fallbackInputTokens, fallbackOutputTokens, trustCacheUsage = true) {
    const record = usage && typeof usage === 'object' && !Array.isArray(usage)
        ? usage
        : {};
    const token = (value, fallback) => {
        const parsed = Number(value);
        return Number.isFinite(parsed) && parsed >= 0
            ? Math.trunc(parsed)
            : Math.max(0, Math.trunc(fallback));
    };
    const inputTokens = token(record.prompt_tokens ?? record.input_tokens, fallbackInputTokens);
    const outputTokens = token(record.completion_tokens ?? record.output_tokens, fallbackOutputTokens);
    const cachedInputTokens = trustCacheUsage
        ? Math.min(inputTokens, codexCachedInputTokensFromUsage(record) ?? 0)
        : 0;
    const cacheWriteTokens = trustCacheUsage
        ? Math.min(inputTokens - cachedInputTokens, codexCacheWriteTokensFromUsage(record) ?? 0)
        : 0;
    const computedTotalTokens = inputTokens + outputTokens;
    const reportedTotalTokens = Number(record.total_tokens);
    const totalTokens = Number.isFinite(reportedTotalTokens) && reportedTotalTokens >= 0
        ? Math.max(Math.trunc(reportedTotalTokens), computedTotalTokens)
        : computedTotalTokens;
    return {
        inputTokens,
        cachedInputTokens,
        cacheWriteTokens,
        outputTokens,
        totalTokens,
    };
}
/**
 * Build the raw-token usage block that backs both the internal request row and
 * the consumer-facing compute-point response. Providers are allowed to omit
 * usage, so consumer responses get the same fallback estimate used for
 * accounting instead of silently returning no usage at all.
 */
function usageForConsumerResponse(usage, accounted, includeFallback) {
    const raw = usage && typeof usage === 'object' && !Array.isArray(usage)
        ? normalizeCodexPromptCacheUsage(usage, 'prompt_tokens_details')
        : null;
    if (!raw && !includeFallback)
        return undefined;
    const result = raw ? { ...raw } : {};
    result.prompt_tokens = accounted.inputTokens;
    result.completion_tokens = accounted.outputTokens;
    result.total_tokens = accounted.inputTokens + accounted.outputTokens;
    const details = result.prompt_tokens_details && typeof result.prompt_tokens_details === 'object'
        && !Array.isArray(result.prompt_tokens_details)
        ? { ...result.prompt_tokens_details }
        : {};
    details.cached_tokens = accounted.cachedInputTokens;
    details.cache_write_tokens = accounted.cacheWriteTokens;
    result.prompt_tokens_details = details;
    return result;
}
export function getStickyModel(messages, sessionIdHeader, strategyKey) {
    const hasAssistant = messages.some(m => m.role === 'assistant');
    if (!hasAssistant)
        return undefined;
    const key = getSessionKey(messages, sessionIdHeader, strategyKey);
    if (!key)
        return undefined;
    const entry = stickySessionMap.get(key);
    if (!entry)
        return undefined;
    if (Date.now() - entry.lastUsed > STICKY_TTL_MS) {
        stickySessionMap.delete(key);
        return undefined;
    }
    return entry.modelDbId;
}
export function setStickyModel(messages, modelDbId, sessionIdHeader, strategyKey) {
    const key = getSessionKey(messages, sessionIdHeader, strategyKey);
    if (!key)
        return;
    stickySessionMap.set(key, { modelDbId, lastUsed: Date.now() });
    // Cleanup old entries
    if (stickySessionMap.size > 500) {
        const now = Date.now();
        for (const [k, v] of stickySessionMap) {
            if (now - v.lastUsed > STICKY_TTL_MS)
                stickySessionMap.delete(k);
        }
        // Hard cap: if still over 1000 after pruning expired entries, evict oldest by lastUsed
        if (stickySessionMap.size > 1000) {
            const entries = [...stickySessionMap.entries()].sort((a, b) => a[1].lastUsed - b[1].lastUsed);
            const toEvict = stickySessionMap.size - 1000;
            for (let i = 0; i < toEvict; i++) {
                stickySessionMap.delete(entries[i][0]);
            }
        }
    }
}
// OpenAI-compatible /models endpoint (used by Hermes for metadata) 
// shows API models which is linked by the user
proxyRouter.get('/models', (req, res) => {
    const token = extractApiToken(req);
    const unifiedKey = getUnifiedApiKey();
    if (!token || !timingSafeStringEqual(token, unifiedKey)) {
        res.status(401).json({ error: { message: 'Invalid API key', type: 'authentication_error' } });
        return;
    }
    // By default we return the WHOLE catalog (one row per model id), each tagged
    // with whether it is currently usable, so a client can see everything and know
    // what's connected vs. disabled/keyless (#242). `?available=true` (alias
    // `?connected=true`) narrows the list to only models that can serve a request
    // right now — the previous default behavior. `available` is computed as
    // "enabled AND an enabled key can serve it"; dedup prefers an available
    // instance of a model id over a disabled/keyless one.
    // Shared catalog listing (one source of truth for the OpenAI and Anthropic
    // /v1/models endpoints — see services/model-listing.ts). `autoContextWindow`
    // is the honest ceiling for the virtual "auto" model: the largest context
    // window among models that can serve a request right now. Advertising null
    // makes OpenAI-compatible clients (opencode, Continue) fall back to their own
    // conservative default and truncate long inputs before they reach us (#282).
    // A consumer key must only discover models that the administrator has made
    // usable for billed users. Determine this from the validated key record,
    // rather than from a string prefix alone, so every third-party model picker
    // receives the same user-visible catalog policy.
    const consumerKey = validateConsumerApiKey(getDb(), token);
    const consumerRequest = consumerKey !== null;
    const fullCatalog = buildModelListing();
    // Codex consumer keys route through OAuth account pools, whose health is
    // independent from ordinary provider API keys. Keep the generic health and
    // billing filter for universal keys, then enforce the key-specific catalog
    // boundary below.
    const baseCatalog = consumerKey?.keyType === 'universal'
        ? filterModelListingForConsumer(fullCatalog)
        : consumerKey
            ? filterModelListingForCodexConsumer(fullCatalog, consumerKey.keyType, consumerKey.id)
            : fullCatalog;
    const catalog = consumerKey
        ? {
            ...baseCatalog,
            models: baseCatalog.models,
        }
        : baseCatalog;
    const { models: allListed, autoContextWindow } = catalog;
    const q = String(req.query.available ?? req.query.connected ?? '').toLowerCase();
    const onlyAvailable = q === '1' || q === 'true' || q === 'yes';
    const listed = consumerRequest
        ? allListed
        : onlyAvailable
            ? allListed.filter(m => m.available === 1)
            : allListed;
    res.json({
        object: 'list',
        data: [
            ...(consumerKey && consumerKey.keyType !== 'universal' ? [] : [
                {
                    id: AUTO_MODEL_ID,
                    object: 'model',
                    created: 0,
                    owned_by: 'freellmapi',
                    name: 'Auto (router picks the best available model)',
                    context_window: autoContextWindow,
                    // `context_length` is OpenRouter's field name and the one most
                    // OpenAI-compatible clients read; emit both so whichever a client
                    // looks for is populated. Additive — clients ignore unknown fields.
                    context_length: autoContextWindow,
                    available: autoContextWindow != null,
                    unavailable_reason: autoContextWindow != null ? null : 'no_models',
                },
                {
                    id: FUSION_MODEL_ID,
                    object: 'model',
                    created: 0,
                    owned_by: 'freellmapi',
                    name: 'Fusion (panel of models answer in parallel, a judge synthesizes one answer)',
                    context_window: autoContextWindow,
                    context_length: autoContextWindow,
                    // Available whenever auto is — fusion needs at least one routable model.
                    available: autoContextWindow != null,
                    unavailable_reason: autoContextWindow != null ? null : 'no_models',
                },
            ]),
            ...listed.map(m => ({
                id: m.id,
                object: 'model',
                created: 0,
                owned_by: m.ownedBy,
                name: m.name,
                context_window: m.contextWindow,
                context_length: m.contextWindow,
                // Non-standard but additive: OpenAI clients ignore unknown fields.
                available: m.available === 1,
                unavailable_reason: m.available === 1 ? null : (m.enabled === 1 ? 'no_key' : 'disabled'),
                // OpenRouter's field name; agents use it to pick knobs per model. For
                // a unify group this is the intersection over member platforms — a
                // param is only advertised when every platform the router might pick
                // honors it.
                supported_parameters: supportedParametersForPlatforms(m.platforms, { tools: m.supportsTools }),
            })),
        ],
    });
});
const MAX_RETRIES = 20;
// Echo-tolerant tool calls: agents replay OUR responses back as history, and
// not all of them preserve the strict OpenAI shape. `type` may be dropped
// (re-added on forward), Gemini-lineage agents (Qwen Code, AionUI) often
// send `arguments` as a parsed object instead of a JSON string, and `id` may
// be missing or empty (ids aren't a Gemini concept) — all get normalized
// below rather than 400-ing the whole session. Missing ids are synthesized
// and paired with their tool-result messages by order. (#200)
const toolCallSchema = z.object({
    id: z.string().optional(),
    type: z.literal('function').optional(),
    function: z.object({
        name: z.string().min(1),
        arguments: z.union([z.string(), z.record(z.string(), z.unknown())]),
    }),
    thought_signature: z.string().optional(),
});
const toolCallArgsToString = (args) => typeof args === 'string' ? args : JSON.stringify(args);
// OpenAI multimodal envelope. Clients like opencode / continue.dev send
// content as an array of typed blocks even when only text is present, and
// Gemini-lineage agents send part-style blocks like `{ "text": "..." }` with
// no `type` at all. Accept any object (or bare string) as a block; flatten to
// string for providers that don't support arrays (Cohere, Cloudflare).
// Non-text blocks pass z validation but get dropped by contentToString —
// vision/audio still isn't supported. (#200)
const contentBlockSchema = z.union([z.string(), z.record(z.string(), z.unknown())]);
const contentSchema = z.union([z.string(), z.array(contentBlockSchema)]);
const systemMessageSchema = z.object({
    role: z.literal('system'),
    content: contentSchema,
    name: z.string().optional(),
});
// OpenAI's newer SDKs send the system prompt as role:"developer"; accept it
// and forward as "system" — none of the routed providers know the developer
// role. (#200)
const developerMessageSchema = z.object({
    role: z.literal('developer'),
    content: contentSchema,
    name: z.string().optional(),
});
const userMessageSchema = z.object({
    role: z.literal('user'),
    content: contentSchema,
    name: z.string().optional(),
});
// Assistant turns may carry empty/null content and no tool_calls — OpenAI
// accepts these in conversation history (a turn that produced no visible text,
// a placeholder, a tool turn whose content was emptied), and clients replay
// them verbatim. We accept them too and coerce empty/null content to "" before
// forwarding (see message build below) rather than 400-ing a payload OpenAI
// would take. (#165)
const assistantMessageSchema = z.object({
    role: z.literal('assistant'),
    content: z.union([contentSchema, z.null()]).optional(),
    name: z.string().optional(),
    // tool_calls: null (not just missing) is what several agents replay for
    // no-tool assistant turns — aionrs (AionUI's engine) writes it into every
    // session-resumed assistant echo. Treated as absent. (#200)
    tool_calls: z.array(toolCallSchema).nullable().optional(),
    // Thinking trace echoed back by a client. DeepSeek thinking models on
    // OpenCode Zen 400 ("reasoning_content in thinking mode must be passed back")
    // unless the prior turn's reasoning_content is replayed, so keep it through
    // validation instead of stripping it. See issue #255.
    reasoning_content: z.string().nullable().optional(),
});
// Tool results may arrive with null/missing content (a tool that returned
// nothing) and a missing/empty tool_call_id (Gemini-lineage agents) — coerced
// to "" and paired by order with the preceding tool_calls respectively. (#200)
const toolMessageSchema = z.object({
    role: z.literal('tool'),
    content: z.union([contentSchema, z.null()]).optional(),
    tool_call_id: z.string().optional(),
    name: z.string().optional(),
});
// Legacy function-calling shape (pre-tools OpenAI API). Old clients still
// replay these in history; forwarded as a tool message. (#200)
const functionMessageSchema = z.object({
    role: z.literal('function'),
    name: z.string().min(1),
    content: z.union([contentSchema, z.null()]).optional(),
});
const toolDefinitionSchema = z.object({
    // Some agents omit `type` on tool definitions; re-defaulted to 'function'
    // on forward. (#200)
    type: z.literal('function').optional(),
    function: z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        parameters: z.record(z.string(), z.unknown()).optional(),
        strict: z.boolean().optional(),
    }),
});
const toolChoiceSchema = z.union([
    // 'any' is the Mistral/Gemini wording for OpenAI's 'required'; mapped on
    // forward. (#200)
    z.enum(['none', 'auto', 'required', 'any']),
    z.object({
        type: z.literal('function'),
        function: z.object({
            name: z.string().min(1),
        }),
    }),
]);
const stopSchema = z.union([z.string(), z.array(z.string()).min(1).max(64)]);
function providerSafeStop(stop) {
    if (!Array.isArray(stop))
        return stop;
    return stop.slice(0, 4);
}
function hasExplicitPromptCacheBreakpoint(messages) {
    return messages.some((message) => Array.isArray(message.content)
        && message.content.some((part) => {
            if (!part || typeof part !== 'object')
                return false;
            const breakpoint = part.prompt_cache_breakpoint;
            return !!breakpoint
                && typeof breakpoint === 'object'
                && !Array.isArray(breakpoint)
                && breakpoint.mode === 'explicit';
        }));
}
const chatCompletionSchema = z.object({
    messages: z.array(z.union([
        systemMessageSchema,
        developerMessageSchema,
        userMessageSchema,
        assistantMessageSchema,
        toolMessageSchema,
        functionMessageSchema,
    ])).min(1),
    model: z.string().optional(),
    temperature: z.number().min(0).max(2).optional(),
    // Some clients send max_tokens <= 0 (or -1) to mean "no limit"; accepted and
    // treated as unset on forward. (#200)
    max_tokens: z.number().int().optional(),
    top_p: z.number().min(0).max(1).optional(),
    stop: stopSchema.optional(),
    stream: z.boolean().optional(),
    stream_options: z.object({
        include_usage: z.boolean().nullable().optional(),
    }).nullable().optional(),
    // GPT-5.6 prompt-cache controls. They are forwarded only to the native
    // Codex OAuth Responses adapter and are capability-gated again there.
    prompt_cache_key: z.string().trim().min(1).max(1024).nullable().optional(),
    prompt_cache_options: z.object({
        mode: z.enum(['implicit', 'explicit']).optional(),
        ttl: z.literal('30m').optional(),
    }).nullable().optional(),
    // Top-level tool knobs may arrive as explicit nulls from clients that
    // serialize every field of their request struct; all treated as absent
    // and never forwarded as null. (#200)
    tools: z.array(toolDefinitionSchema).nullable().optional(),
    tool_choice: toolChoiceSchema.nullable().optional(),
    parallel_tool_calls: z.boolean().nullable().optional(),
    // Fusion config — only meaningful when `model` is the virtual "fusion" id.
    // Ignored for every other model. See services/fusion.ts.
    fusion: fusionConfigSchema.optional(),
    // Extended sampling + structured-output params (top_k, seed, penalties,
    // logit_bias, logprobs, response_format, max_completion_tokens…), forwarded
    // per the platform policy in lib/sampling-params.ts.
    ...samplingParamSchemaFields,
});
// Upstream-error classifiers live in lib/error-classify.ts so the fusion
// service can share them without an import cycle; imported above for internal
// use and re-exported here for existing importers (routes/responses.ts,
// proxy-retry.test.ts) that pull them from this module.
export { isRetryableError, isPaymentRequiredError, isModelNotFoundError, isModelAccessForbiddenError };
// Pull the incremental text out of a streaming chunk for token counting.
// Must tolerate chunks that carry no `choices` array at all: some providers
// (e.g. Groq) emit usage/keepalive frames shaped like `{usage:{...}}` with no
// `choices`. Indexing `chunk.choices[0]` on those throws "Cannot read
// properties of undefined (reading '0')", which — once the SSE stream has
// started — aborts the response mid-flight with no chance to fall back.
export function streamChunkText(chunk) {
    return chunk?.choices?.[0]?.delta?.content ?? '';
}
// OpenAI-compatible embeddings endpoint, routed through the embeddings family
// catalog: `model: "auto"` (or omitted) → the configured default family; a
// family name or provider model id → that family's provider chain. Failover
// only happens WITHIN a family (same model on another provider) — never across
// models, since vectors from different models are incompatible.
const EmbeddingsBody = z.object({
    model: z.string().optional(),
    input: z.union([z.string(), z.array(z.string())]),
    // Optional output-dimension override forwarded to providers that support MRL
    // truncation (NVIDIA NeMo NIM, Google Gemini Embedding, OpenAI v3). Validation
    // only — bounds checking happens upstream (the provider rejects out-of-range
    // values with a clear 400).
    dimensions: z.number().int().positive().optional(),
});
proxyRouter.post('/embeddings', async (req, res) => {
    if (getClientContext().consumerUserId !== null) {
        res.status(403).json({ error: { message: 'Consumer billing is not available for embeddings.', type: 'billing_not_supported' } });
        return;
    }
    const token = extractApiToken(req);
    const unifiedKey = getUnifiedApiKey();
    if (!token || !timingSafeStringEqual(token, unifiedKey)) {
        res.status(401).json({ error: { message: 'Invalid API key', type: 'authentication_error' } });
        return;
    }
    const parsed = EmbeddingsBody.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: 'Invalid request: `input` is required', type: 'invalid_request_error' } });
        return;
    }
    const inputs = Array.isArray(parsed.data.input) ? parsed.data.input : [parsed.data.input];
    try {
        const result = await runEmbeddings(parsed.data.model, inputs, parsed.data.dimensions);
        res.json({
            object: 'list',
            data: result.vectors.map((values, i) => ({ object: 'embedding', index: i, embedding: values })),
            model: result.family,
            provider: result.platform,
            usage: { prompt_tokens: result.inputTokens, total_tokens: result.inputTokens },
        });
    }
    catch (err) {
        const status = err instanceof EmbeddingsError ? err.status : 502;
        const type = status === 400 ? 'invalid_request_error' : status === 429 ? 'rate_limit_error' : 'server_error';
        res.status(status).json({ error: { message: PUBLIC_UPSTREAM_FAILURE_MESSAGE, type } });
    }
});
// OpenAI-compatible image generation. Routed through the media catalog (its own
// table, never the chat router): `model: "auto"` (or omitted) tries every enabled
// image provider in order; a provider model id pins to that one. Failover is
// across providers, never across modalities. See services/media.ts.
const ImageBody = z.object({
    model: z.string().optional(),
    prompt: z.string().min(1),
    n: z.number().int().positive().max(4).optional(),
    size: z.string().optional(),
    response_format: z.enum(['url', 'b64_json']).optional(),
});
function normalizeCodexImageModel(model) {
    return model === 'gpt-image-2' || model === 'gpt-image-1' ? undefined : model;
}
function mediaErrorType(status) {
    if (status === 400)
        return 'invalid_request_error';
    if (status === 401)
        return 'authentication_error';
    if (status === 429)
        return 'rate_limit_error';
    return 'server_error';
}
// The consumer billing/settlement path currently covers chat, Responses and
// Anthropic requests.  Do not let a consumer key spend the platform's media
// credentials until image pricing and settlement are implemented end-to-end.
// Keep this middleware before multer so a rejected key cannot make the server
// buffer a large multipart upload either.
function rejectConsumerMedia(req, res, next) {
    if (getClientContext().consumerUserId !== null) {
        res.status(403).json({
            error: {
                message: 'Consumer billing is not available for image generation.',
                type: 'billing_not_supported',
            },
        });
        return;
    }
    next();
}
proxyRouter.post('/images/generations', rejectConsumerMedia, async (req, res) => {
    const token = extractApiToken(req);
    const unifiedKey = getUnifiedApiKey();
    const consumerContext = getClientContext();
    if (!token || (!timingSafeStringEqual(token, unifiedKey) && consumerContext.consumerUserId === null)) {
        res.status(401).json({ error: { message: 'Invalid API key', type: 'authentication_error' } });
        return;
    }
    const parsed = ImageBody.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: 'Invalid request: `prompt` is required', type: 'invalid_request_error' } });
        return;
    }
    try {
        const result = await runImageGeneration(normalizeCodexImageModel(parsed.data.model), {
            prompt: parsed.data.prompt, n: parsed.data.n, size: parsed.data.size,
        });
        res.json({
            created: Math.floor(Date.now() / 1000),
            data: result.images,
            model: result.modelId,
            provider: result.platform,
        });
    }
    catch (err) {
        const status = err instanceof MediaError ? err.status : 502;
        const httpStatus = status >= 400 && status < 600 ? status : 502;
        res.status(httpStatus).json({ error: { message: PUBLIC_UPSTREAM_FAILURE_MESSAGE, type: mediaErrorType(status) } });
    }
});
const imageEditUpload = multer({
    storage: multer.memoryStorage(),
    limits: { files: 5, fileSize: 20 * 1024 * 1024, fields: 20 },
});
proxyRouter.post('/images/edits', rejectConsumerMedia, imageEditUpload.any(), async (req, res) => {
    const token = extractApiToken(req);
    const unifiedKey = getUnifiedApiKey();
    const consumerContext = getClientContext();
    if (!token || (!timingSafeStringEqual(token, unifiedKey) && consumerContext.consumerUserId === null)) {
        res.status(401).json({ error: { message: 'Invalid API key', type: 'authentication_error' } });
        return;
    }
    const prompt = typeof req.body?.prompt === 'string' ? req.body.prompt.trim() : '';
    const files = (req.files ?? []);
    if (!prompt || files.length === 0) {
        res.status(400).json({ error: { message: 'Invalid request: `prompt` and at least one `image` are required', type: 'invalid_request_error' } });
        return;
    }
    try {
        const result = await runImageEdit(normalizeCodexImageModel(req.body?.model), {
            prompt,
            n: req.body?.n ? Number(req.body.n) : undefined,
            size: typeof req.body?.size === 'string' ? req.body.size : undefined,
            images: files.map(file => ({
                data: file.buffer,
                filename: file.originalname || 'image.png',
                contentType: file.mimetype || 'image/png',
            })),
        });
        res.json({
            created: Math.floor(Date.now() / 1000),
            data: result.images,
            model: result.modelId,
            provider: result.platform,
        });
    }
    catch (err) {
        const status = err instanceof MediaError ? err.status : 502;
        const httpStatus = status >= 400 && status < 600 ? status : 502;
        res.status(httpStatus).json({ error: { message: PUBLIC_UPSTREAM_FAILURE_MESSAGE, type: mediaErrorType(status) } });
    }
});
// OpenAI-compatible text-to-speech. Returns raw audio bytes (OpenAI's /audio/speech
// shape). Same media-catalog routing as images.
const SpeechBody = z.object({
    model: z.string().optional(),
    input: z.string().min(1),
    voice: z.string().optional(),
    response_format: z.string().optional(),
});
proxyRouter.post('/audio/speech', async (req, res) => {
    if (getClientContext().consumerUserId !== null) {
        res.status(403).json({ error: { message: 'Consumer billing is not available for speech generation.', type: 'billing_not_supported' } });
        return;
    }
    const token = extractApiToken(req);
    const unifiedKey = getUnifiedApiKey();
    if (!token || !timingSafeStringEqual(token, unifiedKey)) {
        res.status(401).json({ error: { message: 'Invalid API key', type: 'authentication_error' } });
        return;
    }
    const parsed = SpeechBody.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: 'Invalid request: `input` is required', type: 'invalid_request_error' } });
        return;
    }
    try {
        const result = await runSpeech(parsed.data.model, {
            input: parsed.data.input, voice: parsed.data.voice, format: parsed.data.response_format,
        });
        res.setHeader('Content-Type', result.contentType);
        res.setHeader('X-Provider', result.platform);
        res.send(result.audio);
    }
    catch (err) {
        const status = err instanceof MediaError ? err.status : 502;
        const httpStatus = status >= 400 && status < 600 ? status : 502;
        res.status(httpStatus).json({ error: { message: PUBLIC_UPSTREAM_FAILURE_MESSAGE, type: mediaErrorType(status) } });
    }
});
const CompletionBody = z.object({
    model: z.string().optional(),
    prompt: z.string(),
    suffix: z.string().optional(),
    temperature: z.number().min(0).max(2).optional(),
    max_tokens: z.number().int().optional(),
    top_p: z.number().min(0).max(1).optional(),
    stop: stopSchema.optional(),
    stream: z.boolean().optional(),
});
function completionPromptToMessages(prompt, suffix) {
    const hasSuffix = suffix !== undefined && suffix.length > 0;
    return [
        {
            role: 'system',
            content: [
                'You are a code autocomplete engine.',
                'Complete at the cursor and return only the text to insert.',
                'Do not include markdown fences, explanations, or repeat surrounding code.',
            ].join(' '),
        },
        {
            role: 'user',
            content: hasSuffix
                ? `Prefix before cursor:\n${prompt}\n\nSuffix after cursor:\n${suffix}\n\nCompletion to insert:`
                : `Prefix before cursor:\n${prompt}\n\nCompletion to insert:`,
        },
    ];
}
function completionTextFromChat(result) {
    return contentToString(result?.choices?.[0]?.message?.content ?? '');
}
function completionIdFromChat(id) {
    if (!id)
        return `cmpl-${Date.now()}`;
    return id.startsWith('cmpl-') ? id : `cmpl-${id}`;
}
function clientVisibleRouteModel(route) {
    return route.billingModelId ?? route.modelId;
}
function legacyCompletionChunk(route, chunk, text) {
    return {
        id: completionIdFromChat(chunk?.id),
        object: 'text_completion',
        created: chunk?.created ?? Math.floor(Date.now() / 1000),
        model: clientVisibleRouteModel(route),
        choices: [{
                text,
                index: chunk?.choices?.[0]?.index ?? 0,
                logprobs: null,
                finish_reason: chunk?.choices?.[0]?.finish_reason ?? null,
            }],
    };
}
// OpenAI-compatible legacy completions endpoint. Editor ghost-text clients
// (notably Continue autocomplete) still send prompt/suffix requests here; route
// those through chat models while preserving the legacy text_completion shape.
proxyRouter.post('/completions', async (req, res) => {
    const start = Date.now();
    const requestGroupId = getRequestGroupId(req);
    res.setHeader('X-Request-ID', requestGroupId);
    const token = extractApiToken(req);
    const unifiedKey = getUnifiedApiKey();
    if (!token || !timingSafeStringEqual(token, unifiedKey)) {
        res.status(401).json({
            error: { message: 'Invalid API key', type: 'authentication_error' },
        });
        return;
    }
    const parsed = CompletionBody.safeParse(req.body);
    if (!parsed.success) {
        const detail = parsed.error.errors
            .map(e => (e.path.length ? `${e.path.join('.')}: ${e.message}` : e.message))
            .slice(0, 5)
            .join(', ');
        res.status(400).json({
            error: { message: `Invalid request: ${detail}`, type: 'invalid_request_error' },
        });
        return;
    }
    const { model: requestedModel, prompt, suffix, temperature, top_p, stream } = parsed.data;
    const requestedModelLabel = requestedModel ?? 'auto';
    const max_tokens = parsed.data.max_tokens != null && parsed.data.max_tokens > 0
        ? parsed.data.max_tokens : 128;
    const stop = providerSafeStop(parsed.data.stop);
    const messages = completionPromptToMessages(prompt, suffix);
    const estimatedInputTokens = messages.reduce((sum, m) => sum + Math.ceil(contentToString(m.content).length / 4), 0);
    // Cap the reserved output so a huge client-set max_tokens doesn't falsely
    // exclude the whole model pool (#470); input is still counted in full.
    const estimatedTotal = estimatedInputTokens + routingReserveTokens(max_tokens);
    // Guardrail: per-request token budget (request_max_tokens_budget, default
    // off). max_tokens always has a value on this surface (default 128), so a
    // violation can only reject — no capping branch.
    const budgetCheck = applyTokenBudget(estimatedInputTokens, max_tokens);
    if (budgetCheck.rejection) {
        res.status(413).json({
            error: { message: tokenBudgetMessage(budgetCheck.rejection), type: 'invalid_request_error', code: 'request_token_budget' },
        });
        return;
    }
    let resolvedChain;
    if (isAutoModel(requestedModel)) {
        resolvedChain = resolveRoutingChain(requestedModel);
    }
    let preferredModel;
    let groupChain;
    const codexPin = resolveCodexConsumerPin(requestedModel, res);
    if (codexPin === null)
        return;
    if (codexPin) {
        preferredModel = codexPin.modelDbId;
        groupChain = codexPin.strictChain;
    }
    else if (!isAutoModel(requestedModel) && requestedModel) {
        const db = getDb();
        const members = isUnifyEnabled() ? resolveRequestedIdToMembers(requestedModel, getModelGroups()) : null;
        if (members && members.length > 0) {
            groupChain = resolveModelGroupCandidates(members);
            if (groupChain.length === 0) {
                const placeholders = members.map(() => '?').join(',');
                const anyEnabled = db.prepare(`SELECT 1 FROM models WHERE id IN (${placeholders}) AND enabled = 1 LIMIT 1`).get(...members);
                const reason = anyEnabled ? 'has no providers with an enabled key' : 'is disabled';
                res.status(400).json({
                    error: {
                        message: `Model '${requestedModel}' ${reason}. Use 'auto' (or omit the 'model' field) to auto-route, or call /v1/models for the available list.`,
                        type: 'invalid_request_error',
                        code: 'model_not_found',
                    },
                });
                return;
            }
        }
        else {
            const enabled = db.prepare('SELECT id FROM models WHERE model_id = ? AND enabled = 1').get(requestedModel);
            if (enabled) {
                preferredModel = enabled.id;
            }
            else {
                const disabled = db.prepare('SELECT id FROM models WHERE model_id = ?').get(requestedModel);
                const reason = disabled ? 'is disabled' : 'is not in the catalog';
                res.status(400).json({
                    error: {
                        message: `Model '${requestedModel}' ${reason}. Use 'auto' (or omit the 'model' field) to auto-route, or call /v1/models for the available list.`,
                        type: 'invalid_request_error',
                        code: 'model_not_found',
                    },
                });
                return;
            }
        }
    }
    const pinnedModelId = requestedModel && !isAutoModel(requestedModel) ? requestedModel : null;
    const state = newFallbackState();
    const attemptLog = [];
    let clientGone = false;
    res.on('close', () => { if (!res.writableEnded)
        clientGone = true; });
    // Legacy /completions is a thin adapter over the shared fallback loop
    // (lib/fallback-loop.ts): the cooldown/skip/penalty/exhaustion machinery is
    // shared; only the text_completion request/stream translation lives here.
    await runFallbackLoop({
        maxRetries: MAX_RETRIES,
        state,
        attemptLog,
        clientGone: () => clientGone,
        route: () => routeRequest(estimatedTotal, state.skipKeys.size > 0 ? state.skipKeys : undefined, preferredModel, false, false, state.skipModels.size > 0 ? state.skipModels : undefined, groupChain ?? resolvedChain?.chain, false, 'chat_completions', undefined, undefined, false, state.skipRelaySources.size > 0 ? state.skipRelaySources : undefined, stream, false),
        dispatch: async (route, attempt) => {
            traceRouteEvent('Proxy', {
                event: attempt === 0 ? 'start' : 'next',
                requestId: requestGroupId,
                attempt,
                platform: route.platform,
                model: route.modelId,
                requestedModel: attempt === 0 ? requestedModelLabel : undefined,
            });
            if (stream) {
                let totalOutputTokens = 0;
                let headerSent = false;
                let ttfbMs = null;
                let sawText = false;
                let upstreamFinish = null;
                const buffered = [];
                const flushHeaders = () => {
                    if (headerSent)
                        return;
                    ttfbMs = Date.now() - start;
                    res.setHeader('Content-Type', 'text/event-stream');
                    res.setHeader('Cache-Control', 'no-cache');
                    res.setHeader('Connection', 'keep-alive');
                    res.setHeader('X-Routed-Via', `${route.platform}/${clientVisibleRouteModel(route)}`);
                    setFallbackHeaders(res, attempt, undefined);
                    headerSent = true;
                    for (const frame of buffered)
                        res.write(`data: ${JSON.stringify(frame)}\n\n`);
                    buffered.length = 0;
                };
                try {
                    const gen = route.provider.streamChatCompletion(route.apiKey, messages, route.modelId, { temperature, max_tokens, top_p, stop }, quotaContextForRoute(route, 'chat/completions'));
                    for await (const chunk of gen) {
                        if (clientGone)
                            break; // client hung up: stop pulling; reader.cancel() aborts upstream
                        const inBandError = providerStreamErrorFromChunk(chunk, route.displayName);
                        if (inBandError)
                            throw inBandError;
                        const text = streamChunkText(chunk);
                        if (text.length > 0)
                            sawText = true;
                        const finish = chunk?.choices?.[0]?.finish_reason;
                        if (finish)
                            upstreamFinish = finish;
                        totalOutputTokens += Math.ceil(text.length / 4);
                        if (text.length > 0) {
                            assertWalletStreamBudget(getDb(), {
                                platform: route.platform,
                                modelId: route.billingModelId ?? route.modelId,
                                inputTokens: estimatedInputTokens,
                                outputTokens: totalOutputTokens,
                            });
                        }
                        const frame = legacyCompletionChunk(route, chunk, text);
                        // Commit point: hold headers until the first real text, so a stream
                        // that dies before producing any fails over invisibly.
                        if (!headerSent && !sawText) {
                            buffered.push(frame);
                            continue;
                        }
                        flushHeaders();
                        res.write(`data: ${JSON.stringify(frame)}\n\n`);
                    }
                    // Disconnect before the commit point: the break above fired with no
                    // text seen, which is indistinguishable from an empty completion
                    // below — but it is CLIENT behavior, not a provider failure. Without
                    // this check every Ctrl-C during a reasoning model's TTFB window
                    // benched the healthy model+key for 90s and logged a provider error.
                    if (clientGone && !headerSent && !sawText) {
                        console.log(`[Proxy] client disconnected before first token from ${route.displayName} — dropping attempt without benching`);
                        return 'committed';
                    }
                    if (!sawText) {
                        // finish_reason 'length' means the model spent the whole output
                        // budget before any visible text (hidden reasoning) — fail over,
                        // but skip the cooldown/penalty: not a provider-health signal.
                        throw Object.assign(new Error(`empty completion from ${route.displayName} (legacy stream produced no text)`), upstreamFinish === 'length' ? { skipBench: true } : {});
                    }
                    flushHeaders();
                    if (getClientContext().consumerUserId !== null) {
                        const usage = usageForConsumerResponse(undefined, {
                            inputTokens: estimatedInputTokens,
                            cachedInputTokens: 0,
                            cacheWriteTokens: 0,
                            outputTokens: totalOutputTokens,
                            totalTokens: estimatedInputTokens + totalOutputTokens,
                        }, true);
                        if (usage) {
                            res.write(`data: ${JSON.stringify({
                                id: `cmpl-${Date.now()}`,
                                object: 'text_completion',
                                created: Math.floor(Date.now() / 1000),
                                model: clientVisibleRouteModel(route),
                                choices: [],
                                usage,
                            })}\n\n`);
                        }
                    }
                    res.write('data: [DONE]\n\n');
                    res.end();
                    recordUpstreamSuccess(route, estimatedInputTokens + totalOutputTokens);
                    traceRouteEvent('Proxy', {
                        event: 'ok',
                        requestId: requestGroupId,
                        attempt,
                        platform: route.platform,
                        model: route.modelId,
                        latencyMs: Date.now() - start,
                        inputTokens: estimatedInputTokens,
                        outputTokens: totalOutputTokens,
                    });
                    logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'success', estimatedInputTokens, totalOutputTokens, Date.now() - start, null, ttfbMs, pinnedModelId);
                    return 'done';
                }
                catch (streamErr) {
                    if (isWalletSafetyBalanceReachedError(streamErr)) {
                        if (headerSent) {
                            const payload = {
                                error: {
                                    message: WALLET_SAFETY_STOP_MESSAGE,
                                    type: 'insufficient_balance',
                                    code: 'wallet_safety_balance_reached',
                                },
                            };
                            try {
                                res.write(`data: ${JSON.stringify(payload)}\n\n`);
                            }
                            catch { /* socket gone */ }
                            try {
                                res.write('data: [DONE]\n\n');
                                res.end();
                            }
                            catch { /* socket gone */ }
                        }
                        else {
                            res.status(402).json({
                                error: {
                                    message: WALLET_SAFETY_STOP_MESSAGE,
                                    type: 'insufficient_balance',
                                    code: 'wallet_safety_balance_reached',
                                },
                            });
                        }
                        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', estimatedInputTokens, totalOutputTokens, Date.now() - start, WALLET_SAFETY_STOP_MESSAGE, ttfbMs, pinnedModelId);
                        return 'committed';
                    }
                    if (headerSent) {
                        if (!clientGone)
                            recordCommittedUpstreamFailure(route, streamErr);
                        console.error(`[Proxy] Mid-stream legacy completion error from ${route.displayName}:`, streamErr.message);
                        const payload = { error: { message: PUBLIC_UPSTREAM_STREAM_FAILURE_MESSAGE, type: 'stream_error' } };
                        try {
                            res.write(`data: ${JSON.stringify(payload)}\n\n`);
                        }
                        catch { /* socket gone */ }
                        try {
                            res.write('data: [DONE]\n\n');
                            res.end();
                        }
                        catch { /* socket gone */ }
                        traceRouteEvent('Proxy', {
                            event: 'fail',
                            requestId: requestGroupId,
                            attempt,
                            platform: route.platform,
                            model: route.modelId,
                            latencyMs: Date.now() - start,
                            error: sanitizeProviderErrorMessage(streamErr.message),
                        });
                        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', estimatedInputTokens, totalOutputTokens, Date.now() - start, sanitizeProviderErrorMessage(streamErr.message), ttfbMs, pinnedModelId);
                        return 'committed';
                    }
                    throw streamErr;
                }
            }
            const result = await route.provider.chatCompletion(route.apiKey, messages, route.modelId, { temperature, max_tokens, top_p, stop }, quotaContextForRoute(route, 'chat/completions'));
            const text = completionTextFromChat(result);
            if (!text) {
                // finish_reason 'length' = output budget consumed by hidden reasoning
                // before any visible text: fail over without a cooldown/penalty.
                throw Object.assign(new Error(`empty completion from ${route.displayName}`), result.choices?.[0]?.finish_reason === 'length' ? { skipBench: true } : {});
            }
            // Usage fallback: providers that omit `usage` used to be logged as 0
            // tokens, silently undercounting analytics and the rate-limit ledger.
            // Fall back to the same chars/4 estimate the streaming path uses.
            const promptTokens = result.usage?.prompt_tokens ?? estimatedInputTokens;
            const completionTokens = result.usage?.completion_tokens ?? Math.ceil(text.length / 4);
            const totalTokens = result.usage?.total_tokens ?? (promptTokens + completionTokens);
            const legacyUsage = getClientContext().consumerUserId !== null
                ? usageForConsumerResponse(result.usage, {
                    inputTokens: promptTokens,
                    cachedInputTokens: 0,
                    cacheWriteTokens: 0,
                    outputTokens: completionTokens,
                    totalTokens: promptTokens + completionTokens,
                }, true)
                : result.usage;
            recordUpstreamSuccess(route, totalTokens);
            res.setHeader('X-Routed-Via', `${route.platform}/${clientVisibleRouteModel(route)}`);
            setFallbackHeaders(res, attempt, undefined);
            res.json({
                id: completionIdFromChat(result.id),
                object: 'text_completion',
                created: result.created ?? Math.floor(Date.now() / 1000),
                model: clientVisibleRouteModel(route),
                choices: [{
                        text,
                        index: result.choices?.[0]?.index ?? 0,
                        logprobs: null,
                        finish_reason: result.choices?.[0]?.finish_reason ?? 'stop',
                    }],
                usage: legacyUsage,
            });
            traceRouteEvent('Proxy', {
                event: 'ok',
                requestId: requestGroupId,
                attempt,
                platform: route.platform,
                model: route.modelId,
                latencyMs: Date.now() - start,
                inputTokens: promptTokens,
                outputTokens: completionTokens,
            });
            logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'success', promptTokens, completionTokens, Date.now() - start, null, null, pinnedModelId);
            return 'done';
        },
        logFailure: (route, err, attempt) => {
            const latency = Date.now() - start;
            const safeError = sanitizeProviderErrorMessage(err.message);
            traceRouteEvent('Proxy', {
                event: 'fail',
                requestId: requestGroupId,
                attempt,
                platform: route.platform,
                model: route.modelId,
                latencyMs: latency,
                error: safeError,
            });
            logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'error', estimatedInputTokens, 0, latency, safeError, null, pinnedModelId);
        },
        onFatal: (route, err, attempt) => {
            setFallbackHeaders(res, attempt, attemptLog);
            const upstreamStatus = Number(err.status);
            const invalidRelayRequest = route.codexSource === 'relay' && [400, 422].includes(upstreamStatus);
            res.status(invalidRelayRequest ? upstreamStatus : 502).json({
                error: {
                    message: PUBLIC_UPSTREAM_FAILURE_MESSAGE,
                    type: invalidRelayRequest ? 'invalid_request_error' : 'provider_error',
                },
            });
        },
        onRoutingExhausted: (lastError, routeErr, exhaustion, info) => {
            if (exhaustion) {
                setFallbackHeaders(res, info.attempts.length, info.attempts, exhaustion.retryAfterMs);
                res.status(exhaustion.status).json({ error: { message: exhaustion.message, type: exhaustion.type } });
            }
            else {
                const disposition = Array.isArray(routeErr.diagnostics) ? routeErr.diagnostics : [];
                console.warn(`[Proxy] legacy completions routing exhausted (no upstream tried) req=${shortRequestId(requestGroupId)} ` +
                    `requested=${requestedModelLabel} candidates=${disposition.length}` +
                    (disposition.length ? `:\n  ${disposition.join('\n  ')}` : ''));
                res.status(routeErr.status ?? 503).json({ error: { message: PUBLIC_UPSTREAM_FAILURE_MESSAGE, type: 'routing_error' } });
            }
        },
        onExhausted: (exhaustion, info) => {
            setFallbackHeaders(res, info.attempts.length, info.attempts, exhaustion.retryAfterMs);
            res.status(exhaustion.status).json({ error: { message: exhaustion.message, type: exhaustion.type } });
        },
    });
});
export async function chatCompletionHandler(req, res) {
    const start = Date.now();
    const requestGroupId = getRequestGroupId(req);
    res.setHeader('X-Request-ID', requestGroupId);
    // Authenticate with the unified API key for every proxy request, including
    // loopback callers. Browser pages can reach localhost, so socket locality is
    // not a reliable authorization boundary.
    const token = extractApiToken(req);
    const unifiedKey = getUnifiedApiKey();
    const dashboardUser = req.user?.userId;
    if (!dashboardUser && (!token || !timingSafeStringEqual(token, unifiedKey))) {
        res.status(401).json({
            error: { message: 'Invalid API key', type: 'authentication_error' },
        });
        return;
    }
    // Validate request
    const parsed = chatCompletionSchema.safeParse(req.body);
    if (!parsed.success) {
        // Path-qualified issues ("messages.1.content: Invalid input" beats a bare
        // "Invalid input") and a server-side breadcrumb — these rejections never
        // reach the request log, which made #200 nearly undebuggable.
        const detail = parsed.error.errors
            .map(e => (e.path.length ? `${e.path.join('.')}: ${e.message}` : e.message))
            .slice(0, 5)
            .join(', ');
        console.warn(`[proxy] 400 invalid /chat/completions request: ${detail}`);
        res.status(400).json({
            error: {
                message: `Invalid request: ${detail}`,
                type: 'invalid_request_error',
            },
        });
        return;
    }
    const { model: requestedModel, temperature, top_p, stream } = parsed.data;
    const includeUsage = parsed.data.stream_options?.include_usage === true;
    const requestedModelLabel = requestedModel ?? 'auto';
    // Agent-tolerant knob normalization (#200): max_tokens <= 0 means "no
    // limit" in several clients → unset; tool_choice 'any' is OpenAI's
    // 'required'; tool definitions get their 'function' type re-defaulted.
    // `max_completion_tokens` is OpenAI's newer alias — honored when max_tokens
    // itself is absent. `let`: the token-budget guardrail below may cap an
    // absent max_tokens to the budget remainder before the options objects are
    // built from it.
    const requestedMaxTokens = parsed.data.max_tokens ?? parsed.data.max_completion_tokens;
    let max_tokens = requestedMaxTokens != null && requestedMaxTokens > 0
        ? requestedMaxTokens : undefined;
    // Extended sampling/output params (seed, penalties, response_format…),
    // spread into every options object below — including fusion fan-out.
    const samplingParams = pickSamplingParams(parsed.data);
    const stop = providerSafeStop(parsed.data.stop);
    const tool_choice = parsed.data.tool_choice === 'any' ? 'required' : parsed.data.tool_choice ?? undefined;
    const tools = parsed.data.tools?.map(t => ({ ...t, type: 'function' }));
    const parallel_tool_calls = parsed.data.parallel_tool_calls ?? undefined;
    // Pairing state for id-less tool calls (#200): every tool_call id (given or
    // synthesized) queues up here; a tool message without a tool_call_id takes
    // the oldest unanswered one, which matches the single-call-per-turn flow
    // Gemini-lineage agents produce.
    const pendingToolCallIds = [];
    let syntheticIdCounter = 0;
    const takeToolCallId = (given) => {
        if (given && given.length > 0) {
            const qi = pendingToolCallIds.indexOf(given);
            if (qi !== -1)
                pendingToolCallIds.splice(qi, 1);
            return given;
        }
        return pendingToolCallIds.shift() ?? `call_auto_${++syntheticIdCounter}`;
    };
    const messages = parsed.data.messages.map((m) => {
        if (m.role === 'assistant') {
            const hasToolCalls = (m.tool_calls?.length ?? 0) > 0;
            // With tool_calls, content: null is the correct OpenAI shape — keep it.
            // Without tool_calls, coerce empty/null content to "" so strict upstreams
            // don't choke on a null-content assistant turn we just accepted. (#165)
            const isEmptyContent = m.content == null
                || (typeof m.content === 'string' && m.content.length === 0)
                || (Array.isArray(m.content) && m.content.length === 0);
            const assistantContent = hasToolCalls
                ? (m.content ?? null)
                : (isEmptyContent ? '' : m.content);
            return {
                role: 'assistant',
                content: assistantContent,
                ...(m.name ? { name: m.name } : {}),
                // Replay the thinking trace verbatim. DeepSeek thinking models on
                // OpenCode Zen reject a follow-up turn that drops it; other providers
                // ignore the unknown field. Same round-trip rationale as
                // thought_signature below. (#255)
                ...(typeof m.reasoning_content === 'string' && m.reasoning_content.length > 0
                    ? { reasoning_content: m.reasoning_content }
                    : {}),
                // hasToolCalls (not a bare truthiness check) so null AND empty-array
                // tool_calls are dropped rather than forwarded — strict upstreams
                // reject both shapes. (#200)
                ...(hasToolCalls ? { tool_calls: m.tool_calls.map(tc => {
                        // Normalize echo-tolerant inputs back to the strict OpenAI shape
                        // before forwarding (see toolCallSchema); synthesize missing ids
                        // and queue every id for order-based tool-result pairing. (#200)
                        const id = tc.id && tc.id.length > 0 ? tc.id : `call_auto_${++syntheticIdCounter}`;
                        pendingToolCallIds.push(id);
                        return {
                            id,
                            type: 'function',
                            function: { name: tc.function.name, arguments: toolCallArgsToString(tc.function.arguments) },
                            thought_signature: tc.thought_signature,
                        };
                    }) } : {}),
            };
        }
        if (m.role === 'tool') {
            return {
                role: 'tool',
                // Null/missing content (a tool that returned nothing) → "". (#200)
                content: m.content ?? '',
                tool_call_id: takeToolCallId(m.tool_call_id),
                ...(m.name ? { name: m.name } : {}),
            };
        }
        // Legacy function-calling result → forward as a tool message, paired by
        // order like an id-less tool message. (#200)
        if (m.role === 'function') {
            return {
                role: 'tool',
                content: m.content ?? '',
                tool_call_id: takeToolCallId(undefined),
                name: m.name,
            };
        }
        return {
            // 'developer' is OpenAI's newer name for the system role — providers
            // downstream only know 'system'. (#200)
            role: m.role === 'developer' ? 'system' : m.role,
            content: m.content,
            ...(m.name ? { name: m.name } : {}),
        };
    });
    // Token estimation is intentionally a heuristic (~4 chars per token). Used
    // for routing decisions (skip a model whose budget is too small) and for
    // streaming bookkeeping where the provider doesn't echo a final usage count.
    // Non-streaming requests reconcile against the provider's real `usage` block
    // (see line ~340). Streaming will drift from real consumption — accepted
    // tradeoff because per-request usage isn't always returned mid-stream.
    const estimatedInputTokens = messages.reduce((sum, m) => {
        const text = contentToString(m.content);
        return sum + Math.ceil(text.length / 4);
    }, 0);
    // Image requests must route to a vision-capable model. Reject up front with a
    // clear message when none is enabled, rather than silently dropping the image
    // or surfacing the generic "all models exhausted" error (#118, #125). Add a
    // rough per-image token cost so budget routing isn't skewed by content the
    // heuristic above (text-only) can't see.
    const hasImage = messageHasImage(messages);
    if (hasImage && !hasEnabledVisionModel()) {
        res.status(422).json({
            error: {
                message: 'This request includes an image, but no vision-capable model is enabled. Enable a vision model (e.g. Gemini 2.5 Flash, Llama 4 Scout) in the Fallback Chain.',
                type: 'invalid_request_error',
                code: 'no_vision_model',
            },
        });
        return;
    }
    const IMAGE_TOKEN_ESTIMATE = 1000;
    const imageCount = messages.reduce((n, m) => n + (Array.isArray(m.content) ? m.content.filter(b => b?.type === 'image_url' || b?.type === 'image').length : 0), 0);
    // The reserved output is capped (routingReserveTokens, #470) so an oversized
    // client max_tokens can't starve routing; input + images count in full.
    const estimatedTotal = estimatedInputTokens + imageCount * IMAGE_TOKEN_ESTIMATE + routingReserveTokens(max_tokens);
    // Tool-bearing requests must route to a model that emits STRUCTURED
    // tool_calls. A model without real function-calling support serializes the
    // call into its text answer — the request "succeeds" but the client's tool
    // loop sees nothing, which is strictly worse than an error. Same up-front
    // gate pattern as vision above.
    const wantsTools = (tools?.length ?? 0) > 0;
    // `required` (and the object form that names one function) promises the
    // caller a structured tool call.  A plain-text answer is valid for `auto`,
    // but for a required choice it is a pre-commit route failure: hold streaming
    // text until the turn is validated, then let the shared loop try the next
    // candidate without leaking the rejected answer to the client.
    const requiredToolName = typeof tool_choice === 'object'
        ? tool_choice.function.name
        : undefined;
    const requiresToolCall = wantsTools
        && (tool_choice === 'required' || requiredToolName !== undefined);
    if (wantsTools && !hasEnabledToolsModel()) {
        res.status(422).json({
            error: {
                message: 'This request includes tools, but no tool-capable model is enabled. Enable a tool-calling model (e.g. GPT-OSS 120B, Gemini 3.5 Flash, GLM-4.7) in the Fallback Chain.',
                type: 'invalid_request_error',
                code: 'no_tools_model',
            },
        });
        return;
    }
    // Guardrail: per-request token budget (request_max_tokens_budget, default
    // off). Estimated input (incl. images) + requested output must fit the
    // ceiling; a request with no max_tokens gets its output capped to the
    // remainder instead. Sits before the Fusion branch so fan-out inherits the
    // capped max_tokens too.
    const budgetCheck = applyTokenBudget(estimatedInputTokens + imageCount * IMAGE_TOKEN_ESTIMATE, max_tokens);
    if (budgetCheck.rejection) {
        res.status(413).json({
            error: { message: tokenBudgetMessage(budgetCheck.rejection), type: 'invalid_request_error', code: 'request_token_budget' },
        });
        return;
    }
    max_tokens = budgetCheck.maxTokens;
    // ── Fusion: multi-model synthesis ──────────────────────────────────────────
    // The virtual "fusion" model fans the prompt out to a panel of diverse models
    // in parallel, then a judge synthesizes one answer. It routes each panel/judge
    // sub-call through the normal path (cooldowns, quotas, analytics), so it
    // behaves like a normal model from the client's side — just K+1x the tokens.
    // Vision is still rejected up front; tool requests run on tool-capable panel
    // members and return the first structured tool call directly.
    if (isFusionModel(requestedModel)) {
        if (hasImage) {
            res.status(422).json({ error: { message: 'Fusion does not support image input yet. Use a vision model directly.', type: 'invalid_request_error', code: 'fusion_no_vision' } });
            return;
        }
        const fusionOptions = { temperature, max_tokens, top_p, stop, tools, tool_choice, parallel_tool_calls, ...samplingParams };
        const fusionConfig = parsed.data.fusion ?? {};
        if (stream) {
            // Streaming fusion: open the SSE response immediately and emit additive
            // `_fusion` frames (no `choices`, so standard OpenAI clients skip them) as
            // each panel model settles and when the judge runs — the Playground shows
            // these arriving in a collapsible trace. The final synthesized answer is
            // then streamed as normal content deltas, so plain clients still get it.
            res.setHeader('Content-Type', 'text/event-stream');
            res.setHeader('Cache-Control', 'no-cache');
            res.setHeader('Connection', 'keep-alive');
            const writeFrame = (o) => { try {
                res.write(`data: ${JSON.stringify(o)}\n\n`);
            }
            catch { /* socket gone */ } };
            const streamId = `fusion-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
            const base = { id: streamId, object: 'chat.completion.chunk', created: Math.floor(Date.now() / 1000), model: FUSION_MODEL_ID };
            // Track whether the judge already streamed content so we don't re-emit it.
            let answerStarted = false;
            try {
                const { response } = await runFusion({
                    messages,
                    config: fusionConfig,
                    options: fusionOptions,
                    estimatedTokens: estimatedTotal,
                    hooks: {
                        // `a` already carries a sanitized error for failed slots; content is
                        // the model's own answer and is forwarded as-is.
                        onPanel: (a) => {
                            // Panel failures are internal retries.  They must never become
                            // client-visible events while another panel route can still
                            // produce the final Codex response.
                            if (a.status !== 'ok')
                                return;
                            writeFrame({
                                ...base,
                                choices: [{ index: 0, delta: {}, finish_reason: null }],
                                _fusion: {
                                    event: 'panel',
                                    platform: a.platform,
                                    model: a.model,
                                    status: a.status,
                                },
                            });
                        },
                        onJudge: (j) => writeFrame({
                            ...base,
                            choices: [{ index: 0, delta: {}, finish_reason: null }],
                            _fusion: { event: 'judge', ...j },
                        }),
                        // Stream the judge's synthesis live as standard content deltas, so
                        // the final answer appears as it's written instead of after the wait.
                        onJudgeDelta: (delta) => {
                            if (!answerStarted) {
                                writeFrame({ ...base, choices: [{ index: 0, delta: { role: 'assistant' }, finish_reason: null }] });
                                answerStarted = true;
                            }
                            writeFrame({ ...base, choices: [{ index: 0, delta: { content: delta }, finish_reason: null }] });
                        },
                    },
                });
                // best_of / single-survivor / judge-fell-back-to-best-of never streamed
                // a delta — emit the final answer as one chunk in that case.
                const finalMsg = response.choices[0]?.message;
                const finalToolCalls = finalMsg?.tool_calls;
                const hasFinalToolCalls = Array.isArray(finalToolCalls) && finalToolCalls.length > 0;
                if (hasFinalToolCalls) {
                    writeFrame({ ...base, choices: [{ index: 0, delta: { role: 'assistant' }, finish_reason: null }] });
                    writeFrame({ ...base, choices: [{ index: 0, delta: { tool_calls: finalToolCalls }, finish_reason: null }] });
                    writeFrame({ ...base, choices: [{ index: 0, delta: {}, finish_reason: 'tool_calls' }], usage: response.usage });
                }
                else {
                    if (!answerStarted) {
                        const finalText = contentToString(finalMsg?.content ?? '');
                        writeFrame({ ...base, choices: [{ index: 0, delta: { role: 'assistant' }, finish_reason: null }] });
                        writeFrame({ ...base, choices: [{ index: 0, delta: { content: finalText }, finish_reason: null }] });
                    }
                    writeFrame({ ...base, choices: [{ index: 0, delta: {}, finish_reason: 'stop' }], usage: response.usage });
                }
            }
            catch (err) {
                const message = PUBLIC_UPSTREAM_FAILURE_MESSAGE;
                const type = err instanceof FusionError && err.status === 429 ? 'rate_limit_error' : 'server_error';
                writeFrame({ error: { message, type } });
            }
            try {
                res.write('data: [DONE]\n\n');
                res.end();
            }
            catch { /* socket gone */ }
            return;
        }
        try {
            const { response, routedVia } = await runFusion({
                messages,
                config: fusionConfig,
                options: fusionOptions,
                estimatedTokens: estimatedTotal,
            });
            // Structured-output enforcement for fusion (#516 scope gap): the panel/
            // judge output got no format check, so model:"fusion" could hand back
            // prose as a "success" for a json_schema request. Fusion has no failover
            // machinery to hand this to — heal what's healable, otherwise answer
            // honestly instead of pretending. (Streaming fusion stays unenforced,
            // same boundary as every other streamed response.)
            const fusionMsg = response?.choices?.[0]?.message;
            if (samplingParams.response_format && fusionMsg && !fusionMsg.tool_calls?.length) {
                const fusionText = contentToString(fusionMsg.content ?? '');
                if (fusionText) {
                    const enforced = enforceJsonContent(fusionText);
                    if (!enforced.ok) {
                        res.status(502).json({ error: { message: `fusion produced non-JSON output despite response_format=${samplingParams.response_format.type} — retry, or pin a structured-output-capable model instead of "fusion"`, type: 'server_error' } });
                        return;
                    }
                    if (enforced.healed)
                        fusionMsg.content = enforced.content;
                }
            }
            res.setHeader('X-Routed-Via', routedVia);
            res.json(response);
        }
        catch (err) {
            if (err instanceof FusionError) {
                res.status(err.status).json({ error: { message: PUBLIC_UPSTREAM_FAILURE_MESSAGE, type: err.status === 429 ? 'rate_limit_error' : 'invalid_request_error' } });
            }
            else {
                res.status(502).json({ error: { message: PUBLIC_UPSTREAM_FAILURE_MESSAGE, type: 'server_error' } });
            }
        }
        return;
    }
    // ── Response cache (services/cache.ts) ──
    // Opt-in exact-match cache. An identical earlier request is replayed from an
    // in-memory LRU without spending any provider quota. Computed here, after
    // message + sampling-param normalization but before any routing/session work,
    // so a hit short-circuits the whole pipeline. Only NON-streaming requests at a
    // cacheable temperature are eligible (v1 scope: streaming always bypasses); a
    // per-request `X-FreeLLM-Cache` header can force or bypass. Off unless enabled
    // via the RESPONSE_CACHE env var or the response_cache_enabled setting.
    const cacheDirective = parseCacheDirective(req.headers['x-freellm-cache'], req.headers['cache-control']);
    const cacheEligible = !stream && cacheActive(cacheDirective) && isCacheableTemperature(temperature);
    const cachePolicyNamespace = cacheEligible
        ? resolveResponseCachePolicyNamespace()
        : null;
    const cacheKey = cachePolicyNamespace
        ? computeCacheKey({
            policyNamespace: cachePolicyNamespace,
            model: requestedModel, messages, temperature, top_p, max_tokens, tools, tool_choice,
            // Normalized stop (providerSafeStop), i.e. what is actually forwarded.
            stop,
            // The knobs below are NOT in chatCompletionSchema, so zod strips them
            // from parsed.data; read them from the raw body. They still change what
            // answer the client is asking for, so requests differing only in one of
            // them must never collide on a cached entry. Explicit null is coerced
            // to undefined (dropped from the key) to match how the proxy treats
            // null-valued optional knobs as absent.
            response_format: req.body?.response_format ?? undefined,
            n: req.body?.n ?? undefined,
            seed: req.body?.seed ?? undefined,
            presence_penalty: req.body?.presence_penalty ?? undefined,
            frequency_penalty: req.body?.frequency_penalty ?? undefined,
            logit_bias: req.body?.logit_bias ?? undefined,
            logprobs: req.body?.logprobs ?? undefined,
            top_logprobs: req.body?.top_logprobs ?? undefined,
        })
        : null;
    if (cacheKey && isResponseCacheLookupAuthorized(requestedModel)) {
        const hit = getCachedResponse(cacheKey);
        if (hit) {
            // A hit consumes NO provider quota, so recordRequest/recordTokens are
            // deliberately skipped and the reply is not re-logged as provider usage.
            // The savings are reported separately by GET /api/cache/stats.
            res.setHeader('X-Routed-Via', 'cache');
            res.setHeader('X-FreeLLM-Cache', 'HIT');
            res.json(hit.body);
            return;
        }
    }
    // Optional client-managed session affinity (see getSessionKey). Express
    // lower-cases header names; a repeated header arrives as an array — take
    // the first value.
    const rawSessionId = req.headers['x-session-id'];
    const sessionIdHeader = Array.isArray(rawSessionId) ? rawSessionId[0] : rawSessionId;
    const consumerContext = getClientContext();
    const codexPromptCacheOptions = {
        prompt_cache_key: parsed.data.prompt_cache_key ?? undefined,
        prompt_cache_options: parsed.data.prompt_cache_options ?? undefined,
        promptCacheNamespace: consumerContext.consumerApiKeyId === null
            ? 'operator'
            : `consumer-key:${consumerContext.consumerApiKeyId}`,
        promptCacheSessionId: sessionIdHeader,
        // When the client did not define its own breakpoint policy, add one at
        // every user turn. A previous turn then becomes a read-only cache prefix
        // while the newly appended turn writes only its incremental suffix.
        autoPromptCacheBreakpoints: parsed.data.prompt_cache_options == null
            && !hasExplicitPromptCacheBreakpoint(messages),
    };
    let resolvedChain;
    let strategyKey;
    if (isAutoModel(requestedModel)) {
        resolvedChain = resolveRoutingChain(requestedModel);
        strategyKey = resolvedChain.strategyKey;
    }
    // Context handoff only applies to auto-routed requests. Pinned-model requests
    // are deliberate client choices; injecting "you are taking over" there would
    // be semantically wrong.
    const isAutoRouted = !requestedModel || isAutoModel(requestedModel);
    const handoffMode = isAutoRouted ? getContextHandoffMode() : 'off';
    const sessionKey = handoffMode !== 'off' ? getSessionKey(messages, sessionIdHeader, strategyKey) : '';
    if (handoffMode !== 'off' && sessionKey) {
        recordIncomingMessages(sessionKey, messages);
    }
    // A handoff can only fire when a prior model is on record for this session.
    // Check after recordIncomingMessages, which clears the prior model on a
    // fresh conversation. Stable across the retry loop (the prior model only
    // changes on a success, which returns), so compute it once here.
    const handoffPossible = handoffMode !== 'off' && !!sessionKey && hasPriorModel(sessionKey);
    // Explicit `model` field pins routing. If the catalog has no enabled row
    // matching the requested id, return 400 — silently auto-routing to a
    // different model would be surprising to OpenAI-compatible clients.
    // Sticky-session is the fallback when no `model` field was sent at all.
    let preferredModel;
    // When the pinned model is a unified group, this holds the group's ordered
    // members and is passed to routeRequest as the STRICT chain (no other model
    // is ever reached). Undefined for auto and legacy single-row pins.
    let groupChain;
    // Sticky scope: auto requests bucket by routing strategy; a unified group pin
    // buckets by the canonical id the client sent, so the group prefers its last
    // successful provider without leaking stickiness across groups.
    let stickyStrategyKey = strategyKey;
    const codexPin = resolveCodexConsumerPin(requestedModel, res);
    if (codexPin === null)
        return;
    if (codexPin) {
        preferredModel = codexPin.modelDbId;
        groupChain = codexPin.strictChain;
    }
    else if (isAutoModel(requestedModel)) {
        preferredModel = getStickyModel(messages, sessionIdHeader, strategyKey);
    }
    else if (requestedModel) {
        const db = getDb();
        // Unify ON: a requested id (canonical slug OR any provider's model_id) maps
        // to the whole logical-model group, and we route STRICTLY across only its
        // providers — failing over between them, never to a different model (#335).
        const members = isUnifyEnabled() ? resolveRequestedIdToMembers(requestedModel, getModelGroups()) : null;
        if (members && members.length > 0) {
            groupChain = resolveModelGroupCandidates(members);
            if (groupChain.length === 0) {
                // Distinguish a catalog-disabled model from one whose providers are
                // present but unusable (chain-disabled / no key), so the 400 stays
                // actionable and matches the legacy single-row "is disabled" wording.
                const placeholders = members.map(() => '?').join(',');
                const anyEnabled = db.prepare(`SELECT 1 FROM models WHERE id IN (${placeholders}) AND enabled = 1 LIMIT 1`).get(...members);
                const reason = anyEnabled ? 'has no providers with an enabled key' : 'is disabled';
                res.status(400).json({
                    error: {
                        message: `Model '${requestedModel}' ${reason}. Use 'auto' (or omit the 'model' field) to auto-route, or call /v1/models for the available list.`,
                        type: 'invalid_request_error',
                        code: 'model_not_found',
                    },
                });
                return;
            }
            stickyStrategyKey = requestedModel;
            const sticky = getStickyModel(messages, sessionIdHeader, stickyStrategyKey);
            // Only prefer the sticky member if it's actually IN this group — passing a
            // non-member as preferredModelDbId would make routeRequest inject an
            // off-group model and break strict pinning.
            preferredModel = (sticky != null && groupChain.some(r => r.model_db_id === sticky)) ? sticky : undefined;
        }
        else {
            // Unify OFF, or an id that isn't in the catalog: legacy single-row pin.
            const enabled = db.prepare('SELECT id FROM models WHERE model_id = ? AND enabled = 1').get(requestedModel);
            if (enabled) {
                preferredModel = enabled.id;
            }
            else {
                const disabled = db.prepare('SELECT id FROM models WHERE model_id = ?').get(requestedModel);
                const reason = disabled ? 'is disabled' : 'is not in the catalog';
                res.status(400).json({
                    error: {
                        message: `Model '${requestedModel}' ${reason}. Use 'auto' (or omit the 'model' field) to auto-route, or call /v1/models for the available list.`,
                        type: 'invalid_request_error',
                        code: 'model_not_found',
                    },
                });
                return;
            }
        }
    }
    else {
        preferredModel = getStickyModel(messages, sessionIdHeader, strategyKey);
    }
    // For analytics: the model id the client pinned, null when auto-routed
    // ('auto' or omitted). Logged with every request row so pinned vs auto
    // traffic and failover overrides are visible.
    const pinnedModelId = requestedModel && !isAutoModel(requestedModel) ? requestedModel : null;
    // Retry loop: on 429/rate limit, skip that model+key and try the next one.
    // The attempt iteration, cooldown/skip/penalty bookkeeping, and exhaustion
    // rendering are the shared fallback loop (lib/fallback-loop.ts). What stays
    // here is /chat/completions-specific: the response-cache MISS store, the
    // context-handoff injection, group/unified-chain routing, and the OpenAI
    // stream turn-integrity framing.
    const state = newFallbackState();
    const attemptLog = [];
    let clientGone = false;
    res.on('close', () => { if (!res.writableEnded)
        clientGone = true; });
    await runFallbackLoop({
        maxRetries: MAX_RETRIES,
        state,
        attemptLog,
        clientGone: () => clientGone,
        route: () => {
            // When a handoff could fire this turn, pad the token estimate so the router's
            // context-window and TPM checks account for the extra system message overhead.
            // We don't know the selected model key until after routeRequest() returns, so
            // the padding is conservative on turns where injection is *possible* (a prior
            // model is on record). Turns where injection can't happen — every turn 1, and
            // sessions that never switched — pay no headroom tax.
            const routingEstimate = handoffPossible ? estimatedTotal + HANDOFF_MAX_TOKENS : estimatedTotal;
            const codexRelayAffinityKey = parsed.data.prompt_cache_key
                ?? sessionIdHeader
                ?? JSON.stringify(messages.slice(0, Math.max(1, messages.findIndex((message) => message.role === 'user') + 1)));
            return routeRequest(routingEstimate, state.skipKeys.size > 0 ? state.skipKeys : undefined, preferredModel, hasImage, wantsTools, state.skipModels.size > 0 ? state.skipModels : undefined, groupChain ?? resolvedChain?.chain, samplingParams.response_format !== undefined, 'chat_completions', codexRelayAffinityKey, undefined, false, state.skipRelaySources.size > 0 ? state.skipRelaySources : undefined, stream, requiresCodexMultiTurnCapability(messages));
        },
        dispatch: async (route, attempt) => {
            const modelKey = `${route.platform}:${route.modelId}`;
            traceRouteEvent('Proxy', {
                event: attempt === 0 ? 'start' : 'next',
                requestId: requestGroupId,
                attempt,
                platform: route.platform,
                model: route.modelId,
                requestedModel: attempt === 0 ? requestedModelLabel : undefined,
            });
            let outboundMessages = messages;
            // Extra input tokens the injected handoff adds on this turn (0 when not
            // injected). Folded into the streaming success accounting, where token
            // counts are estimated; the non-stream path uses the provider's usage,
            // which already counts the injected message.
            let injectedHandoffTokens = 0;
            if (handoffMode !== 'off' && sessionKey) {
                const handoff = maybeInjectContextHandoff({ mode: handoffMode, sessionKey, messages, selectedModelKey: modelKey });
                if (handoff.injected)
                    console.log(`[Proxy] Context handoff injected (session ${sessionKey.slice(0, 8)}…, model switch detected)`);
                outboundMessages = handoff.messages;
                injectedHandoffTokens = handoff.injectedTokens;
            }
            if (stream) {
                // — Stream turn-integrity (#231 audit) —
                // The old loop forwarded upstream chunks verbatim and called any
                // stream that produced bytes a success. Live failure modes that
                // slipped through: in-band `{"error":...}` frames delivered as dead
                // turns, tool calls with no terminal finish_reason, inline tool-call
                // dialect emitted as text, truncations logged as success. This loop
                // validates the TURN, not the transport:
                //  - headers are held until the first real payload, so anything that
                //    dies before producing one fails over invisibly;
                //  - text that starts with an inline tool-call dialect marker is held
                //    and rescued into structured tool_calls (or failed over);
                //  - tool_call deltas are buffered, argument-repaired, and emitted as
                //    one complete chunk, always followed by finish_reason
                //    "tool_calls" — agents never see calls without a terminal reason;
                //  - a stream that ends with neither content nor calls is an empty
                //    completion and fails over like the non-stream path.
                let totalOutputTokens = 0;
                let headerSent = false;
                let ttfbMs = null;
                // Hold-window state: 'undecided' until the first text either matches
                // a dialect marker (→ 'dialect': buffer everything, rescue at end) or
                // provably cannot (→ 'passthrough': flush and stream normally).
                let mode = 'undecided';
                let heldText = '';
                const preamble = []; // role-only chunks held until flush
                const toolCallAcc = new Map();
                let upstreamFinish = null;
                let usageChunk = null;
                let lastMeta = {};
                const flushHeaders = () => {
                    if (headerSent)
                        return;
                    ttfbMs = Date.now() - start;
                    res.setHeader('Content-Type', 'text/event-stream');
                    res.setHeader('Cache-Control', 'no-cache');
                    res.setHeader('Connection', 'keep-alive');
                    res.setHeader('X-Routed-Via', `${route.platform}/${clientVisibleRouteModel(route)}`);
                    setFallbackHeaders(res, attempt, undefined);
                    headerSent = true;
                    for (const p of preamble)
                        res.write(`data: ${JSON.stringify(p)}\n\n`);
                    preamble.length = 0;
                };
                const mkChunk = (delta, finish) => ({
                    id: lastMeta.id ?? `chatcmpl-${Date.now()}`,
                    object: 'chat.completion.chunk',
                    created: lastMeta.created ?? Math.floor(Date.now() / 1000),
                    model: clientVisibleRouteModel(route),
                    choices: [{ index: 0, delta, finish_reason: finish }],
                });
                const writeChunk = (c) => res.write(`data: ${JSON.stringify(c)}\n\n`);
                try {
                    const nativeResponsesRelay = route.platform === 'openai-codex'
                        && route.codexSource === 'relay'
                        && route.codexRelayProtocol === 'responses';
                    const chatProtocolRelay = route.codexSource === 'relay'
                        && route.codexRelayProtocol === 'chat_completions';
                    const gen = route.provider.streamChatCompletion(route.apiKey, outboundMessages, route.modelId, {
                        temperature, max_tokens, top_p, stop, tools, tool_choice, parallel_tool_calls,
                        // Always collect the native relay's terminal usage for the
                        // internal ledger. It is only forwarded to the caller when the
                        // caller requested stream_options.include_usage.
                        includeUsage: nativeResponsesRelay || chatProtocolRelay || (includeUsage
                            && route.platform === 'openai-codex'
                            && route.codexSource !== 'relay'),
                        ...(route.platform === 'openai-codex'
                            && (route.codexSource !== 'relay' || nativeResponsesRelay)
                            ? codexPromptCacheOptions
                            : {}),
                        ...samplingParams,
                    }, quotaContextForRoute(route, 'chat/completions'));
                    for await (const chunk of gen) {
                        if (clientGone)
                            break; // client hung up: stop pulling; reader.cancel() aborts upstream
                        const anyChunk = chunk;
                        if (route.billingModelId)
                            anyChunk.model = route.billingModelId;
                        // In-band upstream error frame (observed live: Groq emits
                        // {"error":{...,"code":"tool_use_failed"}} inside a 200 SSE
                        // stream). Before headers: retryable, the next model gets the
                        // request. After: surface an error frame instead of pretending
                        // the turn succeeded.
                        const inBandError = providerStreamErrorFromChunk(anyChunk, route.displayName);
                        if (inBandError) {
                            const safeMessage = sanitizeProviderErrorMessage(inBandError.message);
                            if (!headerSent)
                                throw inBandError;
                            console.error(`[Proxy] In-band error frame from ${route.displayName} mid-stream:`, safeMessage);
                            writeChunk({ error: { message: PUBLIC_UPSTREAM_STREAM_FAILURE_MESSAGE, type: 'stream_error' } });
                            try {
                                res.write('data: [DONE]\n\n');
                                res.end();
                            }
                            catch { /* socket gone */ }
                            traceRouteEvent('Proxy', {
                                event: 'fail',
                                requestId: requestGroupId,
                                attempt,
                                platform: route.platform,
                                model: route.modelId,
                                latencyMs: Date.now() - start,
                                error: safeMessage,
                            });
                            if (!clientGone)
                                recordCommittedUpstreamFailure(route, inBandError);
                            logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'error', estimatedInputTokens, totalOutputTokens, Date.now() - start, safeMessage, ttfbMs, pinnedModelId);
                            return 'committed';
                        }
                        if (anyChunk.id)
                            lastMeta = { id: anyChunk.id, model: anyChunk.model, created: anyChunk.created };
                        // Some OpenAI-compatible relays attach terminal `usage` to the
                        // same frame as the final choice instead of emitting a separate
                        // `choices: []` usage-only frame. Capture it before processing the
                        // choice so cache counters are not discarded.
                        if (anyChunk.usage && typeof anyChunk.usage === 'object') {
                            usageChunk = {
                                ...anyChunk,
                                usage: normalizeCodexPromptCacheUsage(anyChunk.usage, 'prompt_tokens_details'),
                            };
                        }
                        const choice = anyChunk.choices?.[0];
                        if (!choice) {
                            // Usage-only frame (stream_options.include_usage) — held and
                            // re-emitted after our finish chunk to preserve OpenAI ordering.
                            continue;
                        }
                        if (choice.finish_reason)
                            upstreamFinish = choice.finish_reason;
                        // Buffer tool_call deltas — emitted complete + repaired at end.
                        for (const tc of choice.delta?.tool_calls ?? []) {
                            const idx = tc.index ?? 0;
                            if (!toolCallAcc.has(idx))
                                toolCallAcc.set(idx, { id: undefined, name: '', args: '' });
                            const acc = toolCallAcc.get(idx);
                            if (tc.id && !acc.id)
                                acc.id = tc.id;
                            if (tc.function?.name)
                                acc.name += tc.function.name;
                            if (tc.function?.arguments)
                                acc.args += tc.function.arguments;
                        }
                        normalizeOutboundContent(chunk);
                        sanitizeResponse(chunk);
                        const text = typeof choice.delta?.content === 'string' ? choice.delta.content : '';
                        if (text.length === 0) {
                            // Role preamble / keep-alive: hold until first payload decides
                            // the mode, forward afterwards. tool_calls and finish_reason are
                            // stripped — both are re-emitted complete at the end (OpenRouter
                            // attaches tool_call deltas to chunks that also carry role/
                            // reasoning keys; forwarding them raw would duplicate the call).
                            if (choice.delta && Object.keys(choice.delta).some(k => k !== 'content' && k !== 'tool_calls' && choice.delta[k] != null)) {
                                const cleaned = { ...anyChunk, choices: [{ ...choice, delta: { ...choice.delta, tool_calls: undefined }, finish_reason: null }] };
                                if (headerSent)
                                    writeChunk(cleaned);
                                else
                                    preamble.push(cleaned);
                            }
                            continue;
                        }
                        totalOutputTokens += Math.ceil(text.length / 4);
                        assertWalletStreamBudget(getDb(), {
                            platform: route.platform,
                            modelId: route.billingModelId ?? route.modelId,
                            inputTokens: estimatedInputTokens + injectedHandoffTokens,
                            outputTokens: totalOutputTokens,
                        });
                        if (mode === 'passthrough' && !requiresToolCall) {
                            writeChunk({ ...anyChunk, choices: [{ ...choice, delta: { ...choice.delta, tool_calls: undefined }, finish_reason: null }] });
                            continue;
                        }
                        heldText += text;
                        if (mode === 'dialect' || mode === 'passthrough')
                            continue;
                        const probe = heldText.trimStart();
                        if (startsWithDialectMarker(probe)) {
                            mode = 'dialect';
                        }
                        else if (!couldBecomeDialectMarker(probe) || probe.length > 256) {
                            mode = 'passthrough';
                            if (!requiresToolCall) {
                                flushHeaders();
                                writeChunk(mkChunk({ content: heldText }, null));
                                heldText = '';
                            }
                        }
                        // else: still a strict prefix of a marker — keep holding.
                    }
                    // — Stream ended cleanly (provider saw [DONE] or a finish_reason) —
                    // Assemble buffered tool calls: synthesize missing ids, repair
                    // double-encoded arguments against the request's schemas, drop
                    // calls whose args still aren't valid JSON.
                    const schemas = toolSchemaMap(tools);
                    let syntheticStreamIds = 0;
                    const completedCalls = [...toolCallAcc.entries()]
                        .sort((a, b) => a[0] - b[0])
                        .map(([, acc]) => ({
                        id: acc.id && acc.id.length > 0 ? acc.id : `call_stream_${++syntheticStreamIds}`,
                        type: 'function',
                        function: { name: acc.name, arguments: repairToolArguments(acc.args || '{}', schemas.get(acc.name)) },
                    }))
                        .filter(c => { try {
                        JSON.parse(c.function.arguments);
                        return c.function.name.length > 0;
                    }
                    catch {
                        return false;
                    } });
                    // Dialect rescue: the held text is an inline tool call in some
                    // model's private syntax. Parse it into structured calls or treat
                    // the turn as dead (headers were never sent in dialect mode, so
                    // failing over is free).
                    if (mode === 'dialect' || (mode === 'undecided' && heldText.length > 0 && containsDialectMarker(heldText))) {
                        const rescue = rescueInlineToolCalls(heldText, new Set((tools ?? []).map(t => t.function.name)));
                        if (rescue.detected) {
                            if (!rescue.calls)
                                throw new Error(`unparseable inline tool-call dialect from ${route.displayName}: ${heldText.slice(0, 120)}`);
                            let rescuedIds = 0;
                            for (const c of rescue.calls) {
                                completedCalls.push({ id: `call_rescued_${++rescuedIds}`, type: 'function', function: { name: c.name, arguments: repairToolArguments(c.arguments, schemas.get(c.name)) } });
                            }
                            heldText = rescue.cleanText;
                            console.log(`[Proxy] Rescued ${rescuedIds} inline tool call(s) from ${route.displayName} into structured tool_calls`);
                        }
                    }
                    if (requiresToolCall
                        && !completedCalls.some(call => (requiredToolName === undefined || call.function.name === requiredToolName))) {
                        throw Object.assign(new Error(requiredToolName
                            ? `${route.displayName} did not return the required tool call ${requiredToolName}`
                            : `${route.displayName} did not return a required tool call`), {
                            status: 422,
                            code: 'required_tool_call_missing',
                            skipBench: true,
                            skipRelaySourceForRequest: true,
                        });
                    }
                    // Disconnect before the commit point: nothing usable was (or will
                    // be) delivered, and that is CLIENT behavior, not a provider
                    // failure — do not let it fall through to the empty-completion
                    // throw below, which would bench a healthy model+key for 90s and
                    // log a provider error for every Ctrl-C during a reasoning model's
                    // TTFB window.
                    if (clientGone && !headerSent && heldText.trim().length === 0 && completedCalls.length === 0) {
                        console.log(`[Proxy] client disconnected before first token from ${route.displayName} — dropping attempt without benching`);
                        return 'committed';
                    }
                    const hasText = headerSent || heldText.trim().length > 0;
                    if (!hasText && completedCalls.length === 0) {
                        // Nothing usable came out — same failover semantics as the
                        // non-stream empty-completion path. Headers can't have been sent
                        // (header flush requires payload), so the client never notices.
                        // finish_reason 'length' = the model spent the whole output budget
                        // on hidden reasoning before any visible text: fail over, but skip
                        // the cooldown/penalty (not a provider-health signal).
                        throw Object.assign(new Error(`empty completion from ${route.displayName} (stream produced no content and no tool calls)`), upstreamFinish === 'length' ? { skipBench: true } : {});
                    }
                    if (clientGone) {
                        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', estimatedInputTokens + injectedHandoffTokens, totalOutputTokens, Date.now() - start, 'client disconnected after stream usage', ttfbMs, pinnedModelId);
                        return 'committed';
                    }
                    flushHeaders();
                    if (heldText.length > 0) {
                        writeChunk(mkChunk({ content: heldText }, null));
                    }
                    if (completedCalls.length > 0) {
                        writeChunk(mkChunk({ tool_calls: completedCalls.map((c, i) => ({ index: i, ...c })) }, null));
                        totalOutputTokens += Math.ceil(completedCalls.reduce((n, c) => n + c.function.arguments.length, 0) / 4);
                    }
                    // Terminal finish_reason, ALWAYS present: calls win over a sloppy
                    // upstream 'stop'; 'length'/'content_filter' survive for pure-text
                    // turns; missing upstream reason is synthesized.
                    const finish = completedCalls.length > 0
                        ? 'tool_calls'
                        : (upstreamFinish && upstreamFinish !== 'tool_calls' ? upstreamFinish : 'stop');
                    writeChunk(mkChunk({}, finish));
                    const accountedUsage = resolveChatUsageForAccounting(usageChunk && typeof usageChunk === 'object'
                        ? usageChunk.usage
                        : undefined, estimatedInputTokens + injectedHandoffTokens, totalOutputTokens, route.codexSource !== 'relay' || route.codexRelayCacheUsageTrusted !== false);
                    const consumerUsage = getClientContext().consumerUserId !== null;
                    const publicUsage = consumerUsage
                        ? usageForConsumerResponse(usageChunk && typeof usageChunk === 'object'
                            ? usageChunk.usage
                            : undefined, accountedUsage, true)
                        : usageChunk && typeof usageChunk === 'object'
                            ? usageChunk.usage
                            : undefined;
                    if (publicUsage && (includeUsage || consumerUsage)) {
                        const usageFrame = usageChunk && typeof usageChunk === 'object'
                            ? { ...usageChunk, usage: publicUsage }
                            : {
                                id: lastMeta.id ?? `chatcmpl-${Date.now()}`,
                                object: 'chat.completion.chunk',
                                created: lastMeta.created ?? Math.floor(Date.now() / 1000),
                                model: clientVisibleRouteModel(route),
                                choices: [],
                                usage: publicUsage,
                            };
                        writeChunk(usageFrame);
                    }
                    res.write('data: [DONE]\n\n');
                    res.end();
                    recordUpstreamSuccess(route, accountedUsage.totalTokens);
                    setStickyModel(messages, route.modelDbId, sessionIdHeader, stickyStrategyKey);
                    if (handoffMode !== 'off' && sessionKey)
                        recordSuccessfulModel({ sessionKey, modelKey });
                    traceRouteEvent('Proxy', {
                        event: 'ok',
                        requestId: requestGroupId,
                        attempt,
                        platform: route.platform,
                        model: route.modelId,
                        latencyMs: Date.now() - start,
                        inputTokens: accountedUsage.inputTokens,
                        outputTokens: accountedUsage.outputTokens,
                    });
                    logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'success', accountedUsage.inputTokens, accountedUsage.outputTokens, Date.now() - start, null, ttfbMs, pinnedModelId, accountedUsage.cachedInputTokens, accountedUsage.cacheWriteTokens);
                    return 'done';
                }
                catch (streamErr) {
                    if (isWalletSafetyBalanceReachedError(streamErr)) {
                        if (headerSent) {
                            const payload = {
                                error: {
                                    message: WALLET_SAFETY_STOP_MESSAGE,
                                    type: 'insufficient_balance',
                                    code: 'wallet_safety_balance_reached',
                                },
                            };
                            try {
                                res.write(`data: ${JSON.stringify(payload)}\n\n`);
                            }
                            catch { /* socket gone */ }
                            try {
                                res.write('data: [DONE]\n\n');
                                res.end();
                            }
                            catch { /* socket gone */ }
                        }
                        else {
                            res.status(402).json({
                                error: {
                                    message: WALLET_SAFETY_STOP_MESSAGE,
                                    type: 'insufficient_balance',
                                    code: 'wallet_safety_balance_reached',
                                },
                            });
                        }
                        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', estimatedInputTokens + injectedHandoffTokens, totalOutputTokens, Date.now() - start, WALLET_SAFETY_STOP_MESSAGE, ttfbMs, pinnedModelId);
                        return 'committed';
                    }
                    if (headerSent) {
                        // Mid-stream error after real payload reached the client — finish
                        // the SSE response honestly instead of leaving the client hanging.
                        if (!clientGone)
                            recordCommittedUpstreamFailure(route, streamErr);
                        console.error(`[Proxy] Mid-stream error from ${route.displayName}:`, streamErr.message);
                        const payload = { error: { message: PUBLIC_UPSTREAM_STREAM_FAILURE_MESSAGE, type: 'stream_error' } };
                        try {
                            res.write(`data: ${JSON.stringify(payload)}\n\n`);
                        }
                        catch { /* socket gone */ }
                        try {
                            res.write('data: [DONE]\n\n');
                            res.end();
                        }
                        catch { /* socket gone */ }
                        traceRouteEvent('Proxy', {
                            event: 'fail',
                            requestId: requestGroupId,
                            attempt,
                            platform: route.platform,
                            model: route.modelId,
                            latencyMs: Date.now() - start,
                            error: sanitizeProviderErrorMessage(streamErr.message),
                        });
                        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', estimatedInputTokens, totalOutputTokens, Date.now() - start, sanitizeProviderErrorMessage(streamErr.message), ttfbMs, pinnedModelId);
                        return 'committed';
                    }
                    // Headers never sent — bubble to the shared loop, which cooldowns this
                    // model+key and tries the next one. Covers upstream HTTP errors, in-band
                    // error frames, abrupt EOF, stalls, empty completions, and unparseable
                    // dialect turns alike.
                    throw streamErr;
                }
            }
            else {
                const nativeResponsesRelay = route.platform === 'openai-codex'
                    && route.codexSource === 'relay'
                    && route.codexRelayProtocol === 'responses';
                const result = await route.provider.chatCompletion(route.apiKey, outboundMessages, route.modelId, {
                    temperature, max_tokens, top_p, stop, tools, tool_choice, parallel_tool_calls,
                    ...(route.platform === 'openai-codex'
                        && (route.codexSource !== 'relay' || nativeResponsesRelay)
                        ? codexPromptCacheOptions
                        : {}),
                    ...samplingParams,
                }, quotaContextForRoute(route, 'chat/completions'));
                // Empty completion (no text, no tool calls) → fail over rather than
                // return a transport-level "success" the caller can't act on. Mirrors
                // the zero-chunk streaming case above. Throwing hands it to the shared
                // loop, which classifies "empty completion" as retryable and applies the
                // same cooldown/skip/penalty bookkeeping as every other failure.
                const respMsg = result.choices?.[0]?.message;
                const respText = contentToString(respMsg?.content ?? '');
                if (!respText && (respMsg?.tool_calls?.length ?? 0) === 0) {
                    // finish_reason 'length' = the model spent the whole output budget on
                    // hidden reasoning before any visible text (observed live: 5 of 11
                    // hops in one chain). Still fail over, but skipBench tells the shared
                    // loop not to cooldown/penalize a healthy model for a truncated turn.
                    throw Object.assign(new Error(`empty completion from ${route.displayName}`), result.choices?.[0]?.finish_reason === 'length' ? { skipBench: true } : {});
                }
                // Inline tool-call dialect rescue (#231 audit): a tool-bearing
                // request answered with the call serialized as TEXT (a mid-
                // conversation model switch makes the new model imitate the previous
                // model's private syntax). Re-parse it into structured tool_calls so
                // the client's agent loop keeps working; a detected-but-unparseable
                // dialect is a dead turn and fails over like an empty completion.
                if (wantsTools && respMsg && (respMsg.tool_calls?.length ?? 0) === 0 && respText) {
                    const rescue = rescueInlineToolCalls(respText, new Set((tools ?? []).map(t => t.function.name)));
                    if (rescue.detected) {
                        if (!rescue.calls) {
                            throw new Error(`unparseable inline tool-call dialect from ${route.displayName}: ${respText.slice(0, 120)}`);
                        }
                        const schemas = toolSchemaMap(tools);
                        respMsg.tool_calls = rescue.calls.map((c, i) => ({
                            id: `call_rescued_${i + 1}`,
                            type: 'function',
                            function: { name: c.name, arguments: repairToolArguments(c.arguments, schemas.get(c.name)) },
                        }));
                        respMsg.content = rescue.cleanText.length > 0 ? rescue.cleanText : null;
                        if (result.choices?.[0])
                            result.choices[0].finish_reason = 'tool_calls';
                        console.log(`[Proxy] Rescued ${rescue.calls.length} inline tool call(s) from ${route.displayName} into structured tool_calls`);
                    }
                }
                if (requiresToolCall
                    && !(respMsg?.tool_calls ?? []).some(call => (requiredToolName === undefined || call.function.name === requiredToolName))) {
                    throw Object.assign(new Error(requiredToolName
                        ? `${route.displayName} did not return the required tool call ${requiredToolName}`
                        : `${route.displayName} did not return a required tool call`), {
                        status: 422,
                        code: 'required_tool_call_missing',
                        skipBench: true,
                        skipRelaySourceForRequest: true,
                    });
                }
                // Structured-output enforcement (#514 follow-up): the client asked for
                // JSON; a model that answered in prose despite the forwarded
                // response_format must not be returned as a "success". Heal the common
                // almost-right shapes (fenced block, prose-wrapped JSON) in place;
                // otherwise fail over. Deliberately AFTER the dialect rescue (matching
                // responses.ts): an inline tool-call turn isn't JSON either, and
                // gating it first burned a failover hop on turns the rescue converts.
                // skipBench: the provider is healthy — the MODEL misbehaved — so no
                // cooldown/penalty; skipModelForRequest: a sibling key would misbehave
                // identically, so rule out the whole model for this request.
                if (samplingParams.response_format && respText && (respMsg?.tool_calls?.length ?? 0) === 0) {
                    const enforced = enforceJsonContent(respText);
                    if (!enforced.ok) {
                        // finish_reason 'length' = the JSON was CUT OFF by max_tokens, not
                        // ignored — same failover (a terser model may fit the budget), but
                        // an honest error class/trail instead of "ignored response_format".
                        const truncated = result.choices?.[0]?.finish_reason === 'length';
                        throw Object.assign(new Error(truncated
                            ? `truncated JSON from ${route.displayName} (finish_reason=length — raise max_tokens for this ${samplingParams.response_format.type} request)`
                            : `${route.displayName} ignored response_format (returned non-JSON despite ${samplingParams.response_format.type})`), { skipBench: true, skipModelForRequest: true });
                    }
                    if (enforced.healed && respMsg) {
                        respMsg.content = enforced.content;
                    }
                }
                // Usage fallback: providers that omit `usage` used to be logged as 0
                // tokens, silently undercounting analytics and the rate-limit ledger.
                // Fall back to the same chars/4 estimate the streaming path uses (tool
                // arguments included, mirroring the stream accounting).
                const respToolArgChars = (respMsg?.tool_calls ?? []).reduce((n, tc) => n + (tc?.function?.arguments?.length ?? 0), 0);
                const accountedUsage = resolveChatUsageForAccounting(result.usage, estimatedInputTokens, Math.ceil((contentToString(respMsg?.content ?? '').length + respToolArgChars) / 4), route.codexSource !== 'relay' || route.codexRelayCacheUsageTrusted !== false);
                const promptTokens = accountedUsage.inputTokens;
                const completionTokens = accountedUsage.outputTokens;
                const totalTokens = accountedUsage.totalTokens;
                if (result.usage) {
                    result.usage = normalizeCodexPromptCacheUsage(result.usage, 'prompt_tokens_details');
                }
                try {
                    assertWalletStreamBudget(getDb(), {
                        platform: route.platform,
                        modelId: route.billingModelId ?? route.modelId,
                        inputTokens: promptTokens,
                        outputTokens: completionTokens,
                        cachedInputTokens: accountedUsage.cachedInputTokens,
                        cacheWriteTokens: accountedUsage.cacheWriteTokens,
                    });
                }
                catch (error) {
                    if (!isWalletSafetyBalanceReachedError(error))
                        throw error;
                    logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', promptTokens, completionTokens, Date.now() - start, WALLET_SAFETY_STOP_MESSAGE, null, pinnedModelId, accountedUsage.cachedInputTokens, accountedUsage.cacheWriteTokens);
                    res.status(402).json({
                        error: {
                            message: WALLET_SAFETY_STOP_MESSAGE,
                            type: 'insufficient_balance',
                            code: 'wallet_safety_balance_reached',
                        },
                    });
                    return 'committed';
                }
                recordUpstreamSuccess(route, totalTokens);
                // Use stickyStrategyKey (not the global strategyKey) so a group-pinned
                // request writes its sticky entry under the SAME key the next turn reads
                // from (set to the requested model id at the top of the loop). Matches the
                // streaming success path; without it, "prefer last successful provider"
                // is lost for non-streaming group-pinned sessions. (#341 review)
                setStickyModel(messages, route.modelDbId, sessionIdHeader, stickyStrategyKey);
                if (handoffMode !== 'off' && sessionKey)
                    recordSuccessfulModel({ sessionKey, modelKey });
                res.setHeader('X-Routed-Via', `${route.platform}/${clientVisibleRouteModel(route)}`);
                setFallbackHeaders(res, attempt, undefined);
                // Repair double-encoded tool arguments against the request's tool
                // schemas (e.g. GLM emitting an array parameter as a JSON string),
                // so strict clients don't reject the call. Schema-gated — a true
                // string parameter is never touched. See lib/tool-args.ts.
                if (respMsg?.tool_calls?.length) {
                    const schemas = toolSchemaMap(tools);
                    for (const tc of respMsg.tool_calls) {
                        if (tc?.function?.arguments != null) {
                            tc.function.arguments = repairToolArguments(tc.function.arguments, schemas.get(tc.function.name));
                        }
                    }
                }
                // Normalize array-shaped message.content to a string on the way out (#166).
                const outboundBody = sanitizeResponse(normalizeOutboundContent(result));
                if (route.billingModelId
                    && outboundBody
                    && typeof outboundBody === 'object'
                    && !Array.isArray(outboundBody)) {
                    outboundBody.model = route.billingModelId;
                }
                if (getClientContext().consumerUserId !== null
                    && outboundBody
                    && typeof outboundBody === 'object'
                    && !Array.isArray(outboundBody)) {
                    const consumerUsage = usageForConsumerResponse(outboundBody.usage, accountedUsage, true);
                    if (consumerUsage) {
                        outboundBody.usage = consumerUsage;
                    }
                }
                res.setHeader('X-FreeLLM-Cache', cacheKey ? 'MISS' : 'OFF');
                res.json(outboundBody);
                // Cache the freshly-generated answer so an identical later request is
                // served from memory without spending another free-tier slot. A
                // truncated turn (finish_reason 'length') is NOT cached: replaying a
                // cut-off answer forever would be worse than regenerating.
                if (cacheKey
                    && cachePolicyNamespace === resolveResponseCachePolicyNamespace()
                    && isResponseCacheLookupAuthorized(requestedModel)
                    && result.choices?.[0]?.finish_reason !== 'length') {
                    storeCachedResponse(cacheKey, {
                        body: outboundBody,
                        platform: route.platform,
                        modelId: route.modelId,
                        keyId: route.keyId,
                        promptTokens,
                        completionTokens,
                    });
                }
                traceRouteEvent('Proxy', {
                    event: 'ok',
                    requestId: requestGroupId,
                    attempt,
                    platform: route.platform,
                    model: route.modelId,
                    latencyMs: Date.now() - start,
                    inputTokens: promptTokens,
                    outputTokens: completionTokens,
                });
                logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'success', promptTokens, completionTokens, Date.now() - start, null, null, pinnedModelId, accountedUsage.cachedInputTokens, accountedUsage.cacheWriteTokens);
                return 'done';
            }
        },
        logFailure: (route, err, attempt) => {
            const latency = Date.now() - start;
            const safeError = sanitizeProviderErrorMessage(err.message);
            traceRouteEvent('Proxy', {
                event: 'fail',
                requestId: requestGroupId,
                attempt,
                platform: route.platform,
                model: route.modelId,
                latencyMs: latency,
                error: safeError,
            });
            logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'error', estimatedInputTokens, 0, latency, safeError, null, pinnedModelId);
        },
        onFatal: (route, err, attempt) => {
            // Non-retryable error (bare 4xx, etc.): don't retry.
            setFallbackHeaders(res, attempt, attemptLog);
            const upstreamStatus = Number(err.status);
            const invalidRelayRequest = route.codexSource === 'relay' && [400, 422].includes(upstreamStatus);
            res.status(invalidRelayRequest ? upstreamStatus : 502).json({
                error: {
                    message: PUBLIC_UPSTREAM_FAILURE_MESSAGE,
                    type: invalidRelayRequest ? 'invalid_request_error' : 'provider_error',
                },
            });
        },
        onRoutingExhausted: (lastError, routeErr, exhaustion, info) => {
            // No more models available.
            if (exhaustion) {
                setFallbackHeaders(res, info.attempts.length, info.attempts, exhaustion.retryAfterMs);
                res.status(exhaustion.status).json({ error: { message: exhaustion.message, type: exhaustion.type } });
            }
            else {
                // Synchronous exhaustion: the router rejected every candidate before any
                // upstream was tried, so this is the ONLY place the per-model disposition
                // is recorded. Without it a routing_error 429 is opaque — you can't tell a
                // genuinely dry pool from cooldowns/quota/context narrowing (issue _1).
                const disposition = Array.isArray(routeErr.diagnostics) ? routeErr.diagnostics : [];
                console.warn(`[Proxy] routing exhausted (no upstream tried) req=${shortRequestId(requestGroupId)} ` +
                    `requested=${requestedModelLabel} candidates=${disposition.length}` +
                    (disposition.length ? `:\n  ${disposition.join('\n  ')}` : ''));
                res.status(routeErr.status ?? 503).json({ error: { message: PUBLIC_UPSTREAM_FAILURE_MESSAGE, type: 'routing_error' } });
            }
        },
        onExhausted: (exhaustion, info) => {
            setFallbackHeaders(res, info.attempts.length, info.attempts, exhaustion.retryAfterMs);
            res.status(exhaustion.status).json({ error: { message: exhaustion.message, type: exhaustion.type } });
        },
    });
}
/**
 * Resolve an explicit model for a scoped Codex consumer key. Returning null
 * means an error response has already been sent; undefined means the request
 * uses the ordinary/unified routing path.
 */
function resolveCodexConsumerPin(requestedModel, res) {
    const context = getClientContext();
    const keyType = context.consumerApiKeyType;
    if ((keyType !== 'codex_pool' && keyType !== 'resource_subpool')
        || context.consumerApiKeyId === null
        || !requestedModel
        || isAutoModel(requestedModel)) {
        return undefined;
    }
    const modelDbId = getCodexConsumerModelDbId(keyType, context.consumerApiKeyId, requestedModel);
    const strictChain = modelDbId === null ? [] : resolveModelGroupCandidates([modelDbId]);
    if (modelDbId === null || strictChain.length === 0) {
        res.status(400).json({
            error: {
                message: `Codex model '${requestedModel}' is not available for this API key. Refresh /v1/models and select one of the returned models.`,
                type: 'invalid_request_error',
                code: 'model_not_available_for_key',
            },
        });
        return null;
    }
    return { modelDbId, strictChain };
}
proxyRouter.post('/chat/completions', chatCompletionHandler);
// logRequest moved to lib/request-log.ts (shared with the fusion service to
// avoid an import cycle); imported above for internal use and re-exported here
// for routes/responses.ts which imports it from this module.
export { logRequest };
//# sourceMappingURL=proxy.js.map