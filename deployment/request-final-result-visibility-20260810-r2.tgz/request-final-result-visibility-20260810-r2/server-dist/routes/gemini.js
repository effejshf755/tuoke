import { Router } from 'express';
import { routeRequest, requiresCodexMultiTurnCapability, resolveModelGroupCandidates, routingReserveTokens, } from '../services/router.js';
import { getDb, getUnifiedApiKey } from '../db/index.js';
import { contentToString } from '../lib/content.js';
import { PUBLIC_UPSTREAM_FAILURE_MESSAGE, PUBLIC_UPSTREAM_STREAM_FAILURE_MESSAGE, sanitizeProviderErrorMessage, } from '../lib/error-redaction.js';
import { logRequest } from '../lib/request-log.js';
import { extractApiToken, getStickyModel, setStickyModel, timingSafeStringEqual } from './proxy.js';
import { newFallbackState, recordCommittedUpstreamFailure, recordUpstreamSuccess, runFallbackLoop, setFallbackHeaders, } from '../lib/fallback-loop.js';
import { applyTokenBudget, tokenBudgetMessage } from '../lib/guardrails.js';
import { buildModelListing, filterModelListingForCodexConsumer, filterModelListingForConsumer, getCodexConsumerModelDbId, } from '../services/model-listing.js';
import { validateConsumerApiKey } from '../services/consumer-api-keys.js';
import { getClientContext } from '../lib/client-context.js';
import { getModelGroups, resolveRequestedIdToMembers } from '../services/model-groups.js';
import { inferQuotaPoolKey } from '../services/provider-quota.js';
// Native Gemini REST compatibility surface.  This intentionally translates at
// the edge rather than calling Google's API directly: every request still uses
// the gateway's router, fallback loop, provider health accounting, consumer
// billing settlement, and request analytics.
export const geminiRouter = Router();
const MAX_RETRIES = 20;
const DEFAULT_MAX_TOKENS = 1024;
const IMAGE_TOKEN_ESTIMATE = 1000;
function isRecord(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function record(value) {
    return isRecord(value) ? value : undefined;
}
function stringValue(value) {
    return typeof value === 'string' ? value : undefined;
}
function finiteNumber(value) {
    return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}
function positiveInteger(value) {
    const n = finiteNumber(value);
    if (n === undefined || n <= 0)
        return undefined;
    return Math.max(1, Math.min(262_144, Math.trunc(n)));
}
function toJsonString(value) {
    if (typeof value === 'string')
        return value;
    try {
        return JSON.stringify(value ?? {});
    }
    catch {
        return '{}';
    }
}
function toObject(value) {
    if (isRecord(value))
        return value;
    if (typeof value === 'string') {
        try {
            const parsed = JSON.parse(value);
            if (isRecord(parsed))
                return parsed;
            return { value: parsed };
        }
        catch {
            return { value };
        }
    }
    return { value: value ?? null };
}
function isAutoModel(modelId) {
    const normalized = modelId.trim().toLowerCase();
    return normalized === 'auto' || normalized.startsWith('auto:');
}
function normalizeModelId(value) {
    return value.trim().replace(/^models\//i, '');
}
function decodeGeminiModelId(value) {
    try {
        const modelId = normalizeModelId(decodeURIComponent(value));
        return modelId || null;
    }
    catch {
        return null;
    }
}
function geminiModelPath(req) {
    const match = /^\/models\/(.+)$/.exec(req.path);
    return match ? decodeGeminiModelId(match[1]) : null;
}
function geminiOperationPath(req) {
    // Logical catalog ids are not restricted to one URL segment: provider-style
    // names can contain `/` and `:free`. The known operation is always the last
    // colon suffix, so this remains unambiguous for both raw and URL-encoded ids.
    const match = /^\/models\/(.+):(generateContent|streamGenerateContent|countTokens)$/.exec(req.path);
    const modelId = match ? decodeGeminiModelId(match[1]) : null;
    return modelId && match
        ? { modelId, operation: match[2] }
        : null;
}
function extractGeminiApiToken(req) {
    // Keep the existing bearer/x-api-key precedence for callers that send more
    // than one credential, then accept Gemini's native header and `?key=` form.
    const shared = extractApiToken(req);
    if (shared)
        return shared;
    const raw = req.headers['x-goog-api-key'];
    const value = Array.isArray(raw) ? raw[0] : raw;
    if (value?.trim())
        return value.trim();
    const queryKey = req.query?.key;
    const queryValue = Array.isArray(queryKey) ? queryKey[0] : queryKey;
    return typeof queryValue === 'string' && queryValue.trim() ? queryValue.trim() : undefined;
}
function googleStatusForHttp(status) {
    if (status === 400 || status === 413)
        return 'INVALID_ARGUMENT';
    if (status === 401)
        return 'UNAUTHENTICATED';
    if (status === 402)
        return 'FAILED_PRECONDITION';
    if (status === 403)
        return 'PERMISSION_DENIED';
    if (status === 404)
        return 'NOT_FOUND';
    if (status === 409)
        return 'ABORTED';
    if (status === 429)
        return 'RESOURCE_EXHAUSTED';
    if (status === 503)
        return 'UNAVAILABLE';
    return 'INTERNAL';
}
function sendGoogleError(res, status, message) {
    res.status(status).json({
        error: {
            code: status,
            message,
            status: googleStatusForHttp(status),
        },
    });
}
function authenticate(req, res) {
    const token = extractGeminiApiToken(req);
    if (!token || !timingSafeStringEqual(token, getUnifiedApiKey())) {
        sendGoogleError(res, 401, 'Invalid API key');
        return null;
    }
    return token;
}
function inlineImagePart(part) {
    const inline = record(part.inlineData);
    const mimeType = stringValue(inline?.mimeType);
    const data = stringValue(inline?.data);
    if (mimeType?.startsWith('image/') && data) {
        return {
            type: 'image_url',
            image_url: { url: `data:${mimeType};base64,${data}` },
        };
    }
    const file = record(part.fileData);
    const fileMimeType = stringValue(file?.mimeType);
    const fileUri = stringValue(file?.fileUri);
    if (fileMimeType?.startsWith('image/') && fileUri && /^https?:\/\//i.test(fileUri)) {
        return {
            type: 'image_url',
            image_url: { url: fileUri },
        };
    }
    return null;
}
function textFromPart(part) {
    const text = stringValue(part.text);
    if (text !== undefined)
        return text;
    const inline = record(part.inlineData);
    if (inline && stringValue(inline.mimeType) && stringValue(inline.data)) {
        return `[inline data: ${stringValue(inline.mimeType)}]`;
    }
    const file = record(part.fileData);
    if (file && stringValue(file.fileUri))
        return `[file: ${stringValue(file.fileUri)}]`;
    return null;
}
function convertTools(body) {
    const tools = [];
    const seenNames = new Set();
    const addTool = (name, description, parameters) => {
        if (!name || seenNames.has(name))
            return;
        seenNames.add(name);
        tools.push({
            type: 'function',
            function: {
                name,
                ...(description ? { description } : {}),
                parameters: isRecord(parameters) ? parameters : { type: 'object', properties: {} },
            },
        });
    };
    const rawTools = Array.isArray(body.tools) ? body.tools : [];
    for (const rawTool of rawTools) {
        const tool = record(rawTool);
        if (!tool)
            continue;
        const declarations = Array.isArray(tool.functionDeclarations) ? tool.functionDeclarations : [];
        for (const rawDeclaration of declarations) {
            const declaration = record(rawDeclaration);
            const name = stringValue(declaration?.name)?.trim();
            if (!name)
                continue;
            addTool(name, stringValue(declaration?.description), declaration?.parameters ?? declaration?.parametersJsonSchema);
        }
        // Existing Google provider support maps this pseudo function back to
        // Gemini's native grounding block when a Google route is selected.
        if (record(tool.googleSearch) || record(tool.googleSearchRetrieval)) {
            addTool('google_search', 'Use Google Search grounding when available.', { type: 'object', properties: {} });
        }
    }
    const functionCallingConfig = record(record(body.toolConfig)?.functionCallingConfig);
    const mode = stringValue(functionCallingConfig?.mode)?.toUpperCase();
    const allowedNames = Array.isArray(functionCallingConfig?.allowedFunctionNames)
        ? functionCallingConfig.allowedFunctionNames.filter((name) => typeof name === 'string' && name.length > 0)
        : [];
    let toolChoice;
    if (mode === 'NONE')
        toolChoice = 'none';
    else if (mode === 'ANY') {
        toolChoice = allowedNames.length === 1
            ? { type: 'function', function: { name: allowedNames[0] } }
            : 'required';
    }
    else if (mode === 'AUTO' || mode === 'VALIDATED') {
        toolChoice = 'auto';
    }
    return { tools: tools.length > 0 ? tools : undefined, toolChoice };
}
function convertGeminiRequest(body) {
    if (!isRecord(body))
        return { error: 'Request body must be a JSON object.' };
    if (!Array.isArray(body.contents) || body.contents.length === 0) {
        return { error: '`contents` must be a non-empty array.' };
    }
    const messages = [];
    let hasImage = false;
    const systemInstruction = record(body.systemInstruction);
    if (systemInstruction) {
        const systemParts = Array.isArray(systemInstruction.parts) ? systemInstruction.parts : [];
        const text = systemParts
            .map(record)
            .filter((part) => Boolean(part))
            .map(textFromPart)
            .filter((value) => value !== null && value.length > 0)
            .join('\n\n');
        if (text)
            messages.push({ role: 'system', content: text });
    }
    for (let contentIndex = 0; contentIndex < body.contents.length; contentIndex += 1) {
        const entry = record(body.contents[contentIndex]);
        if (!entry || !Array.isArray(entry.parts)) {
            return { error: `contents.${contentIndex}.parts must be an array.` };
        }
        const role = stringValue(entry.role) === 'model' ? 'model' : 'user';
        const textParts = [];
        const contentBlocks = [];
        const toolCalls = [];
        const toolResponses = [];
        for (let partIndex = 0; partIndex < entry.parts.length; partIndex += 1) {
            const part = record(entry.parts[partIndex]);
            if (!part)
                continue;
            const image = inlineImagePart(part);
            if (image) {
                hasImage = true;
                contentBlocks.push(image);
            }
            const text = textFromPart(part);
            if (text !== null)
                textParts.push(text);
            const functionCall = record(part.functionCall);
            if (functionCall && role === 'model') {
                const name = stringValue(functionCall.name)?.trim();
                if (name) {
                    const id = stringValue(functionCall.id)?.trim() || `call_gemini_${contentIndex}_${partIndex}`;
                    const thoughtSignature = stringValue(part.thoughtSignature) ?? stringValue(part.thought_signature);
                    toolCalls.push({
                        id,
                        type: 'function',
                        function: { name, arguments: toJsonString(functionCall.args) },
                        ...(thoughtSignature ? { thought_signature: thoughtSignature } : {}),
                    });
                }
            }
            const functionResponse = record(part.functionResponse);
            if (functionResponse && role === 'user') {
                const name = stringValue(functionResponse.name)?.trim() || 'tool';
                const id = stringValue(functionResponse.id)?.trim() || `call_gemini_${contentIndex}_${partIndex}`;
                toolResponses.push({
                    role: 'tool',
                    tool_call_id: id,
                    name,
                    content: toJsonString(functionResponse.response),
                });
            }
        }
        const joinedText = textParts.join('\n');
        if (role === 'model') {
            if (joinedText.length > 0 || contentBlocks.length > 0 || toolCalls.length > 0) {
                messages.push({
                    role: 'assistant',
                    content: contentBlocks.length > 0
                        ? [
                            ...(joinedText ? [{ type: 'text', text: joinedText }] : []),
                            ...contentBlocks,
                        ]
                        : (joinedText || null),
                    ...(toolCalls.length > 0 ? { tool_calls: toolCalls } : {}),
                });
            }
        }
        else {
            messages.push(...toolResponses);
            if (joinedText.length > 0 || contentBlocks.length > 0) {
                messages.push({
                    role: 'user',
                    content: contentBlocks.length > 0
                        ? [
                            ...(joinedText ? [{ type: 'text', text: joinedText }] : []),
                            ...contentBlocks,
                        ]
                        : joinedText,
                });
            }
        }
    }
    if (messages.length === 0)
        return { error: '`contents` must contain at least one supported part.' };
    const toolConversion = convertTools(body);
    return {
        value: {
            messages,
            tools: toolConversion.tools,
            toolChoice: toolConversion.toolChoice,
            hasImage,
            wantsTools: (toolConversion.tools?.length ?? 0) > 0,
            generationConfig: record(body.generationConfig) ?? {},
        },
    };
}
function estimateInputTokens(messages) {
    return Math.max(1, messages.reduce((total, message) => total + Math.ceil(contentToString(message.content).length / 4), 0));
}
function countImages(messages) {
    return messages.reduce((total, message) => total + (Array.isArray(message.content)
        ? message.content.filter((part) => part?.type === 'image_url').length
        : 0), 0);
}
function geminiFinishReason(finishReason, hasToolCalls = false) {
    if (hasToolCalls || finishReason === 'tool_calls')
        return 'STOP';
    switch ((finishReason ?? '').toLowerCase()) {
        case 'length': return 'MAX_TOKENS';
        case 'content_filter': return 'SAFETY';
        case 'stop':
        case 'function_call':
        case 'function_calls': return 'STOP';
        default: return 'STOP';
    }
}
function toGeminiToolParts(calls) {
    const parts = [];
    for (const call of calls ?? []) {
        const functionCall = {
            id: call.id,
            name: call.function.name,
            args: toObject(call.function.arguments),
        };
        parts.push({
            functionCall,
            ...(call.thought_signature ? { thoughtSignature: call.thought_signature } : {}),
        });
    }
    return parts;
}
function toGeminiResponse(route, requestedModel, result, estimatedInputTokens) {
    const choice = result.choices?.[0];
    const message = choice?.message;
    const text = contentToString(message?.content ?? '');
    const toolParts = toGeminiToolParts(message?.tool_calls);
    const parts = [
        ...(text ? [{ text }] : []),
        ...toolParts,
    ];
    const promptTokenCount = result.usage?.prompt_tokens ?? estimatedInputTokens;
    const candidatesTokenCount = result.usage?.completion_tokens
        ?? Math.ceil((text.length + toolParts.reduce((sum, part) => sum + JSON.stringify(part).length, 0)) / 4);
    return {
        responseId: result.id,
        modelVersion: route.billingModelId ?? route.modelId,
        candidates: [{
                index: 0,
                content: { role: 'model', parts },
                finishReason: geminiFinishReason(choice?.finish_reason, toolParts.length > 0),
            }],
        usageMetadata: {
            promptTokenCount,
            candidatesTokenCount,
            totalTokenCount: result.usage?.total_tokens ?? promptTokenCount + candidatesTokenCount,
        },
        // Helpful for clients that keep the requested virtual id in their own
        // telemetry while still exposing the actually selected upstream model.
        requestedModel,
    };
}
function quotaContextForRoute(route, endpoint) {
    return {
        platform: route.platform,
        keyId: route.keyId,
        modelId: route.modelId,
        quotaPoolKey: inferQuotaPoolKey(route.platform, route.modelId),
        endpoint,
        origin: 'proxy',
    };
}
function resolveRoutingTarget(requestedModel, res) {
    const client = getClientContext();
    const scopedKeyType = client.consumerApiKeyType === 'codex_pool' || client.consumerApiKeyType === 'resource_subpool'
        ? client.consumerApiKeyType
        : null;
    if (scopedKeyType && client.consumerApiKeyId !== null && !isAutoModel(requestedModel)) {
        const modelDbId = getCodexConsumerModelDbId(scopedKeyType, client.consumerApiKeyId, requestedModel);
        const strictChain = modelDbId === null ? [] : resolveModelGroupCandidates([modelDbId]);
        if (modelDbId === null || strictChain.length === 0) {
            sendGoogleError(res, 404, `Model '${requestedModel}' is not available for this API key.`);
            return null;
        }
        return { preferredModel: modelDbId, strictChain, pinned: true, pinnedModelId: requestedModel };
    }
    if (isAutoModel(requestedModel))
        return { pinned: false, pinnedModelId: null };
    const members = resolveRequestedIdToMembers(requestedModel, getModelGroups());
    if (members && members.length > 0) {
        const strictChain = resolveModelGroupCandidates(members);
        if (strictChain.length > 0)
            return { strictChain, pinned: true, pinnedModelId: requestedModel };
    }
    const db = getDb();
    const enabled = db.prepare('SELECT id FROM models WHERE model_id = ? AND enabled = 1 LIMIT 1').get(requestedModel);
    if (enabled) {
        const strictChain = resolveModelGroupCandidates([enabled.id]);
        if (strictChain.length > 0)
            return { preferredModel: enabled.id, strictChain, pinned: true, pinnedModelId: requestedModel };
    }
    sendGoogleError(res, 404, `Model '${requestedModel}' was not found or is not currently available.`);
    return null;
}
function modelCatalog(token) {
    const consumerKey = validateConsumerApiKey(getDb(), token);
    const fullCatalog = buildModelListing();
    const catalog = consumerKey?.keyType === 'universal'
        ? filterModelListingForConsumer(fullCatalog)
        : consumerKey
            ? filterModelListingForCodexConsumer(fullCatalog, consumerKey.keyType, consumerKey.id)
            : fullCatalog;
    return {
        models: catalog.models.filter((model) => model.available === 1),
        autoContextWindow: catalog.autoContextWindow,
        scoped: Boolean(consumerKey && consumerKey.keyType !== 'universal'),
    };
}
function toGeminiModel(model) {
    return {
        name: `models/${model.id}`,
        baseModelId: model.id,
        version: 'freellmapi',
        displayName: model.name,
        description: `FreeLLMAPI routed model (${model.platforms.join(', ')})`,
        inputTokenLimit: model.contextWindow ?? 32_768,
        outputTokenLimit: DEFAULT_MAX_TOKENS,
        supportedGenerationMethods: ['generateContent', 'streamGenerateContent', 'countTokens'],
    };
}
function autoGeminiModel(contextWindow) {
    return {
        name: 'models/auto',
        baseModelId: 'auto',
        version: 'freellmapi',
        displayName: 'Auto (router picks the best available model)',
        description: 'Routes through FreeLLMAPI using the configured fallback chain.',
        inputTokenLimit: contextWindow ?? 32_768,
        outputTokenLimit: DEFAULT_MAX_TOKENS,
        supportedGenerationMethods: ['generateContent', 'streamGenerateContent', 'countTokens'],
    };
}
function writeGeminiSse(res, payload) {
    res.write(`data: ${JSON.stringify(payload)}\n\n`);
}
class StreamCommitted extends Error {
}
async function streamGeminiCompletion(res, route, messages, options, ctx) {
    let started = false;
    let outputChars = 0;
    let sawOutput = false;
    let upstreamFinish = null;
    let latestUsage;
    const toolCalls = new Map();
    const ensureStarted = () => {
        if (started)
            return;
        res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');
        res.setHeader('X-Routed-Via', `${route.platform}/${route.billingModelId ?? route.modelId}`);
        setFallbackHeaders(res, ctx.attempt, undefined);
        started = true;
    };
    try {
        const stream = route.provider.streamChatCompletion(route.apiKey, messages, route.modelId, options, quotaContextForRoute(route, 'gemini/streamGenerateContent'));
        for await (const chunk of stream) {
            if (ctx.clientGone())
                break;
            const anyChunk = chunk;
            if (anyChunk.error) {
                const upstreamError = anyChunk.error;
                const msg = upstreamError.message ?? JSON.stringify(upstreamError).slice(0, 200);
                const status = typeof upstreamError.status_code === 'number'
                    ? upstreamError.status_code
                    : typeof upstreamError.status === 'number'
                        ? upstreamError.status
                        : typeof upstreamError.code === 'number'
                            ? upstreamError.code
                            : undefined;
                throw Object.assign(new Error(`in-band provider error from ${route.displayName}: ${String(msg)}`), {
                    ...(status !== undefined ? { status } : {}),
                    ...(typeof upstreamError.code === 'string' ? { upstreamCode: upstreamError.code } : {}),
                    ...(typeof upstreamError.type === 'string'
                        ? { upstreamType: upstreamError.type }
                        : typeof upstreamError.status === 'string'
                            ? { upstreamType: upstreamError.status }
                            : {}),
                });
            }
            const usage = anyChunk.usage;
            if (usage) {
                latestUsage = {
                    prompt: finiteNumber(usage.prompt_tokens),
                    completion: finiteNumber(usage.completion_tokens),
                    total: finiteNumber(usage.total_tokens),
                };
            }
            const choice = anyChunk.choices?.[0];
            if (!choice)
                continue;
            if (choice.finish_reason)
                upstreamFinish = choice.finish_reason;
            const delta = choice.delta ?? {};
            const parts = [];
            if (typeof delta.content === 'string' && delta.content.length > 0) {
                parts.push({ text: delta.content });
                outputChars += delta.content.length;
            }
            if (typeof delta.reasoning_content === 'string' && delta.reasoning_content.length > 0) {
                parts.push({ text: delta.reasoning_content, thought: true });
                outputChars += delta.reasoning_content.length;
            }
            for (const rawCall of delta.tool_calls ?? []) {
                const call = rawCall;
                const index = Number.isInteger(call.index) ? call.index : toolCalls.size;
                if (!toolCalls.has(index))
                    toolCalls.set(index, { name: '', arguments: '' });
                const accumulated = toolCalls.get(index);
                if (call.id && !accumulated.id)
                    accumulated.id = String(call.id);
                if (call.function?.name)
                    accumulated.name += String(call.function.name);
                if (call.function?.arguments)
                    accumulated.arguments += String(call.function.arguments);
                if (call.thought_signature && !accumulated.thoughtSignature)
                    accumulated.thoughtSignature = String(call.thought_signature);
            }
            if (parts.length > 0) {
                sawOutput = true;
                ensureStarted();
                writeGeminiSse(res, {
                    modelVersion: route.billingModelId ?? route.modelId,
                    candidates: [{ index: 0, content: { role: 'model', parts } }],
                });
            }
        }
        if (ctx.clientGone())
            throw new StreamCommitted();
        const functionParts = [...toolCalls.values()]
            .filter((call) => call.name.length > 0)
            .map((call, index) => ({
            functionCall: {
                id: call.id ?? `call_gemini_stream_${index}`,
                name: call.name,
                args: toObject(call.arguments),
            },
            ...(call.thoughtSignature ? { thoughtSignature: call.thoughtSignature } : {}),
        }));
        if (functionParts.length > 0) {
            sawOutput = true;
            outputChars += functionParts.reduce((total, part) => total + JSON.stringify(part).length, 0);
        }
        if (!sawOutput) {
            throw Object.assign(new Error(`empty completion from ${route.displayName}`), upstreamFinish === 'length' ? { skipBench: true } : {});
        }
        const promptTokens = latestUsage?.prompt ?? ctx.estimatedInputTokens;
        const completionTokens = latestUsage?.completion ?? Math.max(1, Math.ceil(outputChars / 4));
        const totalTokens = latestUsage?.total ?? promptTokens + completionTokens;
        ensureStarted();
        writeGeminiSse(res, {
            modelVersion: route.billingModelId ?? route.modelId,
            candidates: [{
                    index: 0,
                    ...(functionParts.length > 0 ? { content: { role: 'model', parts: functionParts } } : {}),
                    finishReason: geminiFinishReason(upstreamFinish, functionParts.length > 0),
                }],
            usageMetadata: {
                promptTokenCount: promptTokens,
                candidatesTokenCount: completionTokens,
                totalTokenCount: totalTokens,
            },
        });
        res.end();
        recordUpstreamSuccess(route, totalTokens);
        if (!ctx.pinned)
            setStickyModel(messages, route.modelDbId, ctx.sessionId);
        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'success', promptTokens, completionTokens, Date.now() - ctx.start, null, null, ctx.pinnedModelId);
    }
    catch (error) {
        if (error instanceof StreamCommitted)
            throw error;
        if (ctx.clientGone())
            throw new StreamCommitted();
        if (started) {
            recordCommittedUpstreamFailure(route, error);
            if (!ctx.clientGone() && !res.writableEnded) {
                writeGeminiSse(res, {
                    error: {
                        code: 502,
                        message: PUBLIC_UPSTREAM_STREAM_FAILURE_MESSAGE,
                        status: 'UNAVAILABLE',
                    },
                });
                try {
                    res.end();
                }
                catch { /* client socket already closed */ }
            }
            logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', ctx.estimatedInputTokens, Math.ceil(outputChars / 4), Date.now() - ctx.start, sanitizeProviderErrorMessage(error?.message), null, ctx.pinnedModelId);
            throw new StreamCommitted();
        }
        throw error;
    }
}
function requestOptions(converted, maxTokens) {
    const config = converted.generationConfig;
    const responseMimeType = stringValue(config.responseMimeType);
    const responseSchema = config.responseJsonSchema ?? config.responseSchema;
    const responseFormat = responseMimeType === 'application/json'
        ? isRecord(responseSchema)
            ? { type: 'json_schema', json_schema: { name: 'gemini_response', schema: responseSchema } }
            : { type: 'json_object' }
        : undefined;
    const stop = Array.isArray(config.stopSequences)
        ? config.stopSequences.filter((value) => typeof value === 'string').slice(0, 4)
        : undefined;
    return {
        temperature: finiteNumber(config.temperature),
        top_p: finiteNumber(config.topP),
        top_k: finiteNumber(config.topK),
        max_tokens: maxTokens,
        stop,
        tools: converted.tools,
        tool_choice: converted.toolChoice,
        ...(responseFormat ? { response_format: responseFormat } : {}),
    };
}
async function generateContent(req, res, streaming, modelIdFromPath) {
    const start = Date.now();
    const token = authenticate(req, res);
    if (!token)
        return;
    const requestedModel = normalizeModelId(modelIdFromPath ?? String(req.params.model ?? ''));
    if (!requestedModel) {
        sendGoogleError(res, 400, 'A model name is required.');
        return;
    }
    const convertedResult = convertGeminiRequest(req.body);
    if (!convertedResult.value) {
        sendGoogleError(res, 400, convertedResult.error ?? 'Invalid GenerateContent request.');
        return;
    }
    const converted = convertedResult.value;
    const candidateCount = positiveInteger(converted.generationConfig.candidateCount);
    if (candidateCount && candidateCount > 1) {
        sendGoogleError(res, 400, 'candidateCount greater than 1 is not supported by this routed compatibility endpoint.');
        return;
    }
    const estimatedInputTokens = estimateInputTokens(converted.messages);
    const budgetCheck = applyTokenBudget(estimatedInputTokens + countImages(converted.messages) * IMAGE_TOKEN_ESTIMATE, positiveInteger(converted.generationConfig.maxOutputTokens));
    if (budgetCheck.rejection) {
        sendGoogleError(res, 400, tokenBudgetMessage(budgetCheck.rejection));
        return;
    }
    const maxTokens = positiveInteger(converted.generationConfig.maxOutputTokens)
        ?? (budgetCheck.maxTokens != null ? Math.min(DEFAULT_MAX_TOKENS, budgetCheck.maxTokens) : DEFAULT_MAX_TOKENS);
    const options = requestOptions(converted, maxTokens);
    const target = resolveRoutingTarget(requestedModel, res);
    if (!target)
        return;
    const estimatedTotal = estimatedInputTokens
        + countImages(converted.messages) * IMAGE_TOKEN_ESTIMATE
        + routingReserveTokens(maxTokens);
    const sessionHeader = req.headers['x-session-id'];
    const sessionId = Array.isArray(sessionHeader) ? sessionHeader[0] : sessionHeader;
    const preferredModel = target.preferredModel ?? (!target.pinned ? getStickyModel(converted.messages, sessionId) : undefined);
    const state = newFallbackState();
    const attempts = [];
    let clientGone = false;
    res.on('close', () => { if (!res.writableEnded)
        clientGone = true; });
    await runFallbackLoop({
        maxRetries: MAX_RETRIES,
        state,
        attemptLog: attempts,
        clientGone: () => clientGone,
        route: () => routeRequest(estimatedTotal, state.skipKeys.size > 0 ? state.skipKeys : undefined, preferredModel, converted.hasImage, converted.wantsTools, state.skipModels.size > 0 ? state.skipModels : undefined, target.strictChain, options.response_format !== undefined, 'chat_completions', undefined, undefined, false, state.skipRelaySources.size > 0 ? state.skipRelaySources : undefined, streaming, requiresCodexMultiTurnCapability(converted.messages)),
        dispatch: async (route, attempt) => {
            if (streaming) {
                try {
                    await streamGeminiCompletion(res, route, converted.messages, options, {
                        start,
                        attempt,
                        attempts,
                        clientGone: () => clientGone,
                        estimatedInputTokens,
                        requestedModel,
                        pinnedModelId: target.pinnedModelId,
                        sessionId,
                        pinned: target.pinned,
                    });
                    return 'done';
                }
                catch (error) {
                    if (error instanceof StreamCommitted)
                        return 'committed';
                    throw error;
                }
            }
            const result = await route.provider.chatCompletion(route.apiKey, converted.messages, route.modelId, options, quotaContextForRoute(route, 'gemini/generateContent'));
            const message = result.choices?.[0]?.message;
            const text = contentToString(message?.content ?? '');
            const toolCalls = message?.tool_calls ?? [];
            if (!text && toolCalls.length === 0) {
                throw Object.assign(new Error(`empty completion from ${route.displayName}`), result.choices?.[0]?.finish_reason === 'length' ? { skipBench: true } : {});
            }
            const promptTokens = result.usage?.prompt_tokens ?? estimatedInputTokens;
            const completionTokens = result.usage?.completion_tokens
                ?? Math.max(1, Math.ceil((text.length + toolCalls.reduce((sum, call) => sum + call.function.arguments.length, 0)) / 4));
            const totalTokens = result.usage?.total_tokens ?? promptTokens + completionTokens;
            recordUpstreamSuccess(route, totalTokens);
            if (!target.pinned)
                setStickyModel(converted.messages, route.modelDbId, sessionId);
            res.setHeader('X-Routed-Via', `${route.platform}/${route.billingModelId ?? route.modelId}`);
            setFallbackHeaders(res, attempt, undefined);
            logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'success', promptTokens, completionTokens, Date.now() - start, null, null, target.pinnedModelId);
            res.json(toGeminiResponse(route, requestedModel, result, estimatedInputTokens));
            return 'done';
        },
        logFailure: (route, error) => {
            logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'error', estimatedInputTokens, 0, Date.now() - start, sanitizeProviderErrorMessage(error?.message), null, target.pinnedModelId);
        },
        onFatal: (route, error, attempt) => {
            setFallbackHeaders(res, attempt, attempts);
            const upstreamStatus = Number(error?.status);
            const invalidRelayRequest = route.codexSource === 'relay' && [400, 422].includes(upstreamStatus);
            sendGoogleError(res, invalidRelayRequest ? upstreamStatus : 502, PUBLIC_UPSTREAM_FAILURE_MESSAGE);
        },
        onRoutingExhausted: (_lastError, routeError, exhaustion, info) => {
            if (exhaustion) {
                setFallbackHeaders(res, info.attempts.length, info.attempts, exhaustion.retryAfterMs);
                sendGoogleError(res, exhaustion.status, exhaustion.message);
            }
            else {
                sendGoogleError(res, routeError?.status ?? 503, PUBLIC_UPSTREAM_FAILURE_MESSAGE);
            }
        },
        onExhausted: (exhaustion, info) => {
            setFallbackHeaders(res, info.attempts.length, info.attempts, exhaustion.retryAfterMs);
            sendGoogleError(res, exhaustion.status, exhaustion.message);
        },
    });
}
geminiRouter.get('/models', (req, res) => {
    const token = authenticate(req, res);
    if (!token)
        return;
    const catalog = modelCatalog(token);
    const models = [
        ...(catalog.scoped ? [] : [autoGeminiModel(catalog.autoContextWindow)]),
        ...catalog.models.map(toGeminiModel),
    ];
    res.json({ models });
});
geminiRouter.get(/^\/models\/(.+)$/, (req, res) => {
    const token = authenticate(req, res);
    if (!token)
        return;
    const requestedModel = geminiModelPath(req);
    if (!requestedModel) {
        sendGoogleError(res, 400, 'A model name is required.');
        return;
    }
    const catalog = modelCatalog(token);
    if (!catalog.scoped && isAutoModel(requestedModel)) {
        res.json(autoGeminiModel(catalog.autoContextWindow));
        return;
    }
    const model = catalog.models.find((entry) => entry.id === requestedModel);
    if (!model) {
        sendGoogleError(res, 404, `Model '${requestedModel}' was not found.`);
        return;
    }
    res.json(toGeminiModel(model));
});
geminiRouter.post(/^\/models\/(.+):(generateContent|streamGenerateContent|countTokens)$/, (req, res) => {
    const operation = geminiOperationPath(req);
    if (!operation) {
        sendGoogleError(res, 400, 'A model name and supported operation are required.');
        return;
    }
    if (operation.operation === 'generateContent') {
        void generateContent(req, res, false, operation.modelId);
        return;
    }
    if (operation.operation === 'streamGenerateContent') {
        void generateContent(req, res, true, operation.modelId);
        return;
    }
    if (!authenticate(req, res))
        return;
    const body = isRecord(req.body) && isRecord(req.body.generateContentRequest)
        ? req.body.generateContentRequest
        : req.body;
    const converted = convertGeminiRequest(body);
    if (!converted.value) {
        sendGoogleError(res, 400, converted.error ?? 'Invalid CountTokens request.');
        return;
    }
    const inputTokens = estimateInputTokens(converted.value.messages)
        + countImages(converted.value.messages) * IMAGE_TOKEN_ESTIMATE;
    res.json({ totalTokens: inputTokens });
});
//# sourceMappingURL=gemini.js.map