import type { Db } from '../db/types.js';
export declare const RELAY_DETECTION_MIN_SAMPLES = 20;
export type RelayDetectionWindow = '24h' | '7d';
export type RelayDetectionLevel = 'insufficient' | 'low' | 'medium' | 'high';
export interface RelayDetectionMetrics {
    requestCount: number;
    successCount: number;
    errorOrPartialCount: number;
    requestsWithIp: number;
    distinctIpCount: number;
    dominantIpShare: number;
    requestsWithUserAgent: number;
    distinctUserAgentCount: number;
    dominantUserAgentShare: number;
    knownRelayUserAgentRequests: number;
    knownRelayUserAgentShare: number;
    distinctApiKeyCount: number;
    distinctModelCount: number;
    activeHourCount: number;
    activeDayCount: number;
    activeHourOfDayCount: number;
    peakRequestsPerMinute: number;
    peakRequestsPerSecond: number;
    firstSeenAt: string;
    lastSeenAt: string;
}
export interface RelayDetectionReason {
    code: 'insufficient_samples' | 'known_relay_user_agent' | 'stable_network_origin' | 'stable_client_signature' | 'automated_request_burst' | 'sustained_activity' | 'model_diversity';
    points: number;
    detail: string;
}
export interface RelayDetectionSignal {
    userId: number;
    score: number;
    level: RelayDetectionLevel;
    reasons: RelayDetectionReason[];
    metrics: RelayDetectionMetrics;
}
export declare function relayDetectionSince(window: RelayDetectionWindow, now?: Date): string;
/**
 * Produce an explainable heuristic score. This is deliberately a triage aid,
 * not proof that an account is reselling the API: ordinary automated clients
 * can have the same network and traffic shape.
 */
export declare function scoreRelayDetectionMetrics(metrics: RelayDetectionMetrics, window: RelayDetectionWindow): Pick<RelayDetectionSignal, 'score' | 'level' | 'reasons'>;
/** Aggregate recent, final request outcomes by their authoritative owner. */
export declare function listRelayDetectionSignals(db: Db, window: RelayDetectionWindow, now?: Date): RelayDetectionSignal[];
//# sourceMappingURL=relay-detection.d.ts.map