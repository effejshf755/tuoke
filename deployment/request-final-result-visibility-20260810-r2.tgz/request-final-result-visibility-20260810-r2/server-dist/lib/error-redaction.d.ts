/**
 * External API clients must not receive an upstream provider's text, model
 * name, or routing details. Keep the response gateway-owned while the
 * redacted original remains available to administrators in request logs.
 */
export declare const PUBLIC_UPSTREAM_FAILURE_MESSAGE = "The request could not be completed. Please try again.";
export declare const PUBLIC_UPSTREAM_STREAM_FAILURE_MESSAGE = "The response was interrupted. Please try again.";
export declare function sanitizeProviderErrorMessage(message: unknown): string;
//# sourceMappingURL=error-redaction.d.ts.map