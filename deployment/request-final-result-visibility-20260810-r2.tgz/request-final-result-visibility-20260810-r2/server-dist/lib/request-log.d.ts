import { type RequestRoutingDiagnostics } from "./client-context.js";
/**
 * Request rows shown as user-facing outcomes. A retry attempt that was later
 * recovered by a normal successful dispatch must not appear as a separate
 * failure, while committed streams, terminal failures, and partial responses
 * remain visible. A committed stream can contain an in-band provider error
 * after bytes were sent, so it is a real final failure rather than a hidden
 * pre-fallback attempt. SQL users must alias the requests table as `r`.
 */
export declare const RECOVERED_FALLBACK_ATTEMPT_SQL = "(\n  r.status = 'error'\n  AND COALESCE(\n    CASE\n      WHEN json_valid(r.routing_diagnostics) = 1\n        THEN json_extract(r.routing_diagnostics, '$.outcome')\n    END,\n    ''\n  ) = 'succeeded'\n)";
/**
 * Rows that belong to an internal fallback attempt rather than the final
 * outcome sent to the API client. Once a fallback chain ends, its diagnostic
 * snapshot identifies exactly one user-visible row; every sibling stays in
 * administrator-only analytics. Older rows without that marker retain the
 * compatibility rule below.
 */
export declare const NON_FINAL_FALLBACK_ATTEMPT_SQL = "(\n  (\n    json_valid(r.routing_diagnostics) = 1\n    AND (\n      COALESCE(json_extract(r.routing_diagnostics, '$.hideFromUserHistory'), 0) = 1\n      OR (\n        json_extract(r.routing_diagnostics, '$.userVisibleRequestId') IS NOT NULL\n        AND r.id != CAST(json_extract(r.routing_diagnostics, '$.userVisibleRequestId') AS INTEGER)\n      )\n    )\n  )\n  OR (\n    r.status = 'error'\n    AND COALESCE(\n      CASE\n        WHEN json_valid(r.routing_diagnostics) = 1\n          THEN json_extract(r.routing_diagnostics, '$.outcome')\n      END,\n      ''\n    ) IN ('in_progress', 'succeeded')\n  )\n)";
/** Rows whose durable attempt counters have not yet been corrected. */
export declare const UNADJUSTED_RECOVERED_FALLBACK_ATTEMPT_SQL = "(\n  (\n  r.status = 'error'\n  AND COALESCE(\n    CASE\n      WHEN json_valid(r.routing_diagnostics) = 1\n        THEN json_extract(r.routing_diagnostics, '$.outcome')\n    END,\n    ''\n  ) = 'succeeded'\n)\n  AND COALESCE(\n    CASE\n      WHEN json_valid(r.routing_diagnostics) = 1\n        THEN json_extract(r.routing_diagnostics, '$.aggregateAdjusted')\n    END,\n    0\n  ) <> 1\n)";
/** Non-final attempts that still contribute to durable aggregate counters. */
export declare const UNADJUSTED_NON_FINAL_FALLBACK_ATTEMPT_SQL = "(\n  (\n  (\n    json_valid(r.routing_diagnostics) = 1\n    AND (\n      COALESCE(json_extract(r.routing_diagnostics, '$.hideFromUserHistory'), 0) = 1\n      OR (\n        json_extract(r.routing_diagnostics, '$.userVisibleRequestId') IS NOT NULL\n        AND r.id != CAST(json_extract(r.routing_diagnostics, '$.userVisibleRequestId') AS INTEGER)\n      )\n    )\n  )\n  OR (\n    r.status = 'error'\n    AND COALESCE(\n      CASE\n        WHEN json_valid(r.routing_diagnostics) = 1\n          THEN json_extract(r.routing_diagnostics, '$.outcome')\n      END,\n      ''\n    ) IN ('in_progress', 'succeeded')\n  )\n)\n  AND COALESCE(\n    CASE\n      WHEN json_valid(r.routing_diagnostics) = 1\n        THEN json_extract(r.routing_diagnostics, '$.aggregateAdjusted')\n    END,\n    0\n  ) <> 1\n)";
export declare const FINAL_REQUEST_RESULT_SQL = "NOT (\n  (\n    json_valid(r.routing_diagnostics) = 1\n    AND (\n      COALESCE(json_extract(r.routing_diagnostics, '$.hideFromUserHistory'), 0) = 1\n      OR (\n        json_extract(r.routing_diagnostics, '$.userVisibleRequestId') IS NOT NULL\n        AND r.id != CAST(json_extract(r.routing_diagnostics, '$.userVisibleRequestId') AS INTEGER)\n      )\n    )\n  )\n  OR (\n    r.status = 'error'\n    AND COALESCE(\n      CASE\n        WHEN json_valid(r.routing_diagnostics) = 1\n          THEN json_extract(r.routing_diagnostics, '$.outcome')\n      END,\n      ''\n    ) IN ('in_progress', 'succeeded')\n  )\n)";
/**
 * Ordinary users get a stricter view than operator analytics.  A failed
 * attempt is private by default: it becomes user-visible only after the
 * fallback loop has explicitly marked the row that was actually returned to
 * the API client.  This also keeps historical pre-marker provider failures
 * out of user history instead of guessing whether they were terminal.
 *
 * SQL users must alias the requests table as `r`.
 */
export declare const USER_VISIBLE_REQUEST_RESULT_SQL = "(\n  COALESCE(r.user_visible, 0) = 1\n)";
/** Start an isolated routing trace for one fallback loop in this HTTP call. */
export declare function resetRequestRoutingDiagnostics(): void;
/**
 * Publish the newest bounded snapshot and refresh rows already written by
 * earlier failed attempts.  This makes every row in the same fallback chain
 * answer what happened eventually, including a later successful source.
 */
export declare function publishRequestRoutingDiagnostics(diagnostics: RequestRoutingDiagnostics): void;
/**
 * A surface may recover an exhausted upstream chain with a local response
 * after the fallback loop has already persisted its failed attempts.  Treat
 * that local result as the final outcome before replying, so those attempts
 * remain available to administrators in routing diagnostics but are removed
 * from user-facing history and aggregate error counts.
 */
export declare function markExhaustedRequestRoutingRecovered(): void;
export interface RequestLogOptions {
    /** Internal upstream attempts are retained for operators but never users. */
    userVisible?: boolean;
}
export declare function logRequest(platform: string, modelId: string, keyId: number, status: string, inputTokens: number, outputTokens: number, latencyMs: number, error: string | null, ttfbMs?: number | null, requestedModel?: string | null, explicitCachedInputTokens?: number | null, explicitCacheWriteTokens?: number | null, options?: RequestLogOptions): number | undefined;
//# sourceMappingURL=request-log.d.ts.map