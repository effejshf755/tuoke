import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/index.js';
import { listRelayDetectionSignals, RELAY_DETECTION_MIN_SAMPLES, } from '../services/relay-detection.js';
export const adminUsersRouter = Router();
const relaySignalsQuerySchema = z.object({
    window: z.enum(['24h', '7d']).default('24h'),
});
adminUsersRouter.get('/relay-signals', (req, res) => {
    const parsed = relaySignalsQuerySchema.safeParse(req.query);
    if (!parsed.success) {
        res.status(400).json({
            error: {
                message: 'Invalid relay detection window. Use 24h or 7d.',
                type: 'validation_error',
            },
        });
        return;
    }
    res.json({
        window: parsed.data.window,
        minimumSamples: RELAY_DETECTION_MIN_SAMPLES,
        signals: listRelayDetectionSignals(getDb(), parsed.data.window),
    });
});
const updateUserSchema = z.object({
    status: z
        .enum(['active', 'disabled'])
        .optional(),
    monthly_token_limit: z
        .number()
        .int()
        .min(0)
        .optional(),
});
const rpmSchema = z.object({ rate_limit_rpm: z.number().int().min(0).max(100000).nullable() });
adminUsersRouter.patch('/:userId/keys/:keyId/rpm', (req, res) => {
    const userId = Number(req.params.userId), keyId = Number(req.params.keyId);
    const parsed = rpmSchema.safeParse(req.body);
    if (!Number.isInteger(userId) || !Number.isInteger(keyId) || !parsed.success) {
        res.status(400).json({ error: { message: 'Invalid RPM', type: 'validation_error' } });
        return;
    }
    const result = getDb().prepare('UPDATE consumer_api_keys SET rate_limit_rpm = ? WHERE id = ? AND user_id = ?').run(parsed.data.rate_limit_rpm, keyId, userId);
    if (result.changes !== 1) {
        res.status(404).json({ error: { message: 'API key not found', type: 'not_found' } });
        return;
    }
    res.json({ success: true, rate_limit_rpm: parsed.data.rate_limit_rpm });
});
/**
 * 管理员获取用户列表
 *
 * GET /api/admin/users
 * GET /api/admin/users?q=test@example.com
 */
adminUsersRouter.get('/', (req, res) => {
    const db = getDb();
    const search = typeof req.query.q === 'string'
        ? req.query.q.trim().toLowerCase()
        : '';
    const now = Date.now();
    const rows = db
        .prepare(`
        SELECT
          u.id,
          u.email,
          u.role,
          u.status,
          u.created_at,
          u.monthly_token_limit,

          COALESCE(
            (
              SELECT SUM(
                COALESCE(r.input_tokens, 0) +
                COALESCE(r.output_tokens, 0)
              )
              FROM requests r
              WHERE (
                r.consumer_user_id = u.id
                OR (
                  r.consumer_user_id IS NULL
                  AND EXISTS (
                    SELECT 1 FROM consumer_api_keys owner_key
                    WHERE owner_key.id = r.consumer_api_key_id
                      AND owner_key.user_id = u.id
                  )
                )
              )
              AND r.created_at >=
                strftime(
                  '%Y-%m-01 00:00:00',
                    'now'
                  )
            ),
            0
          ) AS monthly_used_tokens,

          (
            SELECT COUNT(*)
            FROM requests r
            WHERE r.consumer_user_id = u.id
          ) AS total_request_count,

          COALESCE(
            (
              SELECT SUM(
                COALESCE(r.input_tokens, 0) +
                COALESCE(r.output_tokens, 0)
              )
              FROM requests r
              WHERE (
                r.consumer_user_id = u.id
                OR (
                  r.consumer_user_id IS NULL
                  AND EXISTS (
                    SELECT 1 FROM consumer_api_keys owner_key
                    WHERE owner_key.id = r.consumer_api_key_id
                      AND owner_key.user_id = u.id
                  )
                )
              )
            ),
            0
          ) AS total_used_tokens,

          COALESCE(
            (
              SELECT SUM(
                CASE
                  WHEN COALESCE(r.compute_points_per_million_tokens, 0) > 0
                    THEN COALESCE(r.input_compute_points, 0)
                  ELSE COALESCE(r.input_tokens, 0)
                END
                +
                CASE
                  WHEN COALESCE(r.compute_points_per_million_tokens, 0) > 0
                    THEN COALESCE(r.output_compute_points, 0)
                  ELSE COALESCE(r.output_tokens, 0)
                END
              )
              FROM requests r
              WHERE (
                r.consumer_user_id = u.id
                OR (
                  r.consumer_user_id IS NULL
                  AND EXISTS (
                    SELECT 1 FROM consumer_api_keys owner_key
                    WHERE owner_key.id = r.consumer_api_key_id
                      AND owner_key.user_id = u.id
                  )
                )
              )
            ),
            0
          ) AS total_compute_points,

          (
            SELECT COUNT(*)
            FROM consumer_api_keys k
            WHERE k.user_id = u.id
          ) AS api_key_count,

          (
            SELECT COUNT(*)
            FROM consumer_api_keys k
            WHERE k.user_id = u.id
              AND k.status = 'active'
          ) AS active_api_key_count,

          (
            SELECT MAX(r.created_at)
            FROM requests r
            WHERE r.consumer_user_id = u.id
          ) AS last_request_at,

          (
            SELECT COUNT(*)
            FROM sessions s
            WHERE s.user_id = u.id
              AND s.expires_at_ms > ?
          ) AS active_session_count

          ,(
            SELECT json_group_array(json_object(
              'id', k.id,
              'name', k.name,
              'key_prefix', k.key_prefix,
              'key_scope', k.key_scope,
              'codex_group_name', (
                SELECT g.name
                FROM codex_groups g
                WHERE g.id = k.codex_group_id
              ),
              'status', k.status,
              'enabled', k.enabled,
              'created_at', k.created_at,
              'last_used_at', k.last_used_at,
              'expires_at', k.expires_at,
              'rate_limit_rpm', k.rate_limit_rpm,
              'request_count', (SELECT COUNT(*) FROM requests r2 WHERE r2.consumer_api_key_id = k.id),
              'input_tokens', (SELECT COALESCE(SUM(CASE WHEN COALESCE(r3.compute_points_per_million_tokens, 0) > 0 THEN COALESCE(r3.input_compute_points, 0) ELSE COALESCE(r3.input_tokens, 0) END), 0) FROM requests r3 WHERE r3.consumer_api_key_id = k.id),
              'output_tokens', (SELECT COALESCE(SUM(CASE WHEN COALESCE(r4.compute_points_per_million_tokens, 0) > 0 THEN COALESCE(r4.output_compute_points, 0) ELSE COALESCE(r4.output_tokens, 0) END), 0) FROM requests r4 WHERE r4.consumer_api_key_id = k.id)
            ))
            FROM consumer_api_keys k
            WHERE k.user_id = u.id
              AND k.status <> 'revoked'
          ) AS api_keys

        FROM users u

        WHERE
          u.deleted_at IS NULL
          AND (
            ? = ''
            OR LOWER(u.email)
               LIKE '%' || ? || '%'
          )

        ORDER BY
          u.id DESC
      `)
        .all(now, search, search);
    res.json({
        users: rows,
    });
});
/**
 * 管理员修改用户
 *
 * PATCH /api/admin/users/:id
 *
 * 支持：
 * - monthly_token_limit
 * - status
 */
adminUsersRouter.patch('/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) ||
        id <= 0) {
        res.status(400).json({
            error: {
                message: 'Invalid user id',
                type: 'validation_error',
            },
        });
        return;
    }
    const parsed = updateUserSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({
            error: {
                message: parsed.error.errors
                    .map((error) => error.message)
                    .join(', '),
                type: 'validation_error',
            },
        });
        return;
    }
    const actor = req.user;
    const db = getDb();
    const current = db
        .prepare(`
        SELECT
          id,
          email,
          role,
          status
         FROM users
         WHERE id = ?
           AND deleted_at IS NULL
      `)
        .get(id);
    if (!current) {
        res.status(404).json({
            error: {
                message: 'User not found',
                type: 'not_found',
            },
        });
        return;
    }
    const { status, monthly_token_limit, } = parsed.data;
    /**
     * 管理员不能禁用自己。
     */
    if (status === 'disabled' &&
        actor.userId === id) {
        res.status(400).json({
            error: {
                message: 'You cannot disable yourself',
                type: 'invalid_operation',
            },
        });
        return;
    }
    /**
     * 现阶段不允许禁用管理员账号。
     */
    if (status === 'disabled' &&
        current.role === 'admin') {
        res.status(400).json({
            error: {
                message: 'Administrators cannot be disabled',
                type: 'invalid_operation',
            },
        });
        return;
    }
    const transaction = db.transaction(() => {
        if (monthly_token_limit !==
            undefined) {
            db.prepare(`
            UPDATE users
            SET monthly_token_limit = ?
            WHERE id = ?
          `).run(monthly_token_limit, id);
        }
        if (status) {
            db.prepare(`
            UPDATE users
            SET status = ?
            WHERE id = ?
          `).run(status, id);
            /**
             * 用户被禁用时，
             * 立即删除所有 Dashboard Session。
             */
            if (status === 'disabled') {
                db.prepare(`
              DELETE FROM sessions
              WHERE user_id = ?
            `).run(id);
            }
        }
    });
    transaction();
    res.json({
        success: true,
    });
});
/**
 * 管理员强制注销用户所有登录设备
 *
 * POST /api/admin/users/:id/logout-all
 */
adminUsersRouter.post('/:id/logout-all', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) ||
        id <= 0) {
        res.status(400).json({
            error: {
                message: 'Invalid user id',
                type: 'validation_error',
            },
        });
        return;
    }
    const actor = req.user;
    /**
     * 防止管理员误操作把自己踢下线。
     */
    if (actor.userId === id) {
        res.status(400).json({
            error: {
                message: 'You cannot force logout yourself',
                type: 'invalid_operation',
            },
        });
        return;
    }
    const db = getDb();
    const user = db
        .prepare(`
        SELECT id
        FROM users
        WHERE id = ?
      `)
        .get(id);
    if (!user) {
        res.status(404).json({
            error: {
                message: 'User not found',
                type: 'not_found',
            },
        });
        return;
    }
    const result = db
        .prepare(`
        DELETE FROM sessions
        WHERE user_id = ?
      `)
        .run(id);
    res.json({
        success: true,
        logged_out_sessions: result.changes,
    });
});
/**
 * 删除用户的登录身份和调用权限，同时保留匿名化后的财务与订单审计记录。
 *
 * DELETE /api/admin/users/:id
 */
adminUsersRouter.delete('/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
        res.status(400).json({ error: { message: 'Invalid user id', type: 'validation_error' } });
        return;
    }
    const actor = req.user;
    if (actor.userId === id) {
        res.status(400).json({ error: { message: '不能删除当前登录的管理员账号', type: 'invalid_operation' } });
        return;
    }
    const db = getDb();
    const user = db.prepare(`
    SELECT id, email, role, deleted_at
    FROM users
    WHERE id = ?
  `).get(id);
    if (!user || user.deleted_at) {
        res.status(404).json({ error: { message: '用户不存在', type: 'not_found' } });
        return;
    }
    if (user.role === 'admin') {
        res.status(400).json({ error: { message: '不能删除管理员账号', type: 'invalid_operation' } });
        return;
    }
    const deletedAt = new Date().toISOString();
    db.transaction(() => {
        // Email-bound authentication artifacts must be destroyed before the email
        // address is released for a future registration. Otherwise, a reset code
        // issued for the deleted account could be replayed against a new account
        // that later registers the same address.
        db.prepare('DELETE FROM email_verification_codes WHERE email = ?').run(user.email);
        db.prepare('DELETE FROM password_reset_codes WHERE email = ?').run(user.email);
        db.prepare('DELETE FROM sessions WHERE user_id = ?').run(id);
        // Support messages and playground conversations contain user-authored
        // content rather than financial audit evidence. Remove both the owned
        // records and any message the user authored in another support thread.
        db.prepare('DELETE FROM support_messages WHERE sender_id = ?').run(id);
        db.prepare('DELETE FROM support_tickets WHERE user_id = ?').run(id);
        db.prepare('DELETE FROM playground_conversations WHERE user_id = ?').run(id);
        db.prepare('DELETE FROM site_notification_reads WHERE user_id = ?').run(id);
        db.prepare('DELETE FROM free_model_daily_usage WHERE user_id = ?').run(id);
        // Clear request metadata before mutating credentials. The key-side branch
        // also covers an in-flight request whose consumer_user_id was not written
        // yet but whose API-key foreign key already exists.
        db.prepare(`
      UPDATE requests
      SET client_ip = NULL, client_user_agent = NULL
      WHERE consumer_user_id = ?
         OR consumer_api_key_id IN (
           SELECT id FROM consumer_api_keys WHERE user_id = ?
         )
    `).run(id, id);
        // Dedicated-resource membership is retained as anonymous order/quota
        // history, but it must stop granting access immediately.
        db.prepare(`
      UPDATE resource_subpool_members
      SET status = 'expired', expires_at = ?, consumer_api_key_id = NULL
      WHERE user_id = ?
    `).run(deletedAt, id);
        db.prepare(`
      DELETE FROM resource_member_api_keys
      WHERE consumer_api_key_id IN (
        SELECT id FROM consumer_api_keys WHERE user_id = ?
      )
    `).run(id);
        // Keep the non-personal key row so requests already in flight can still
        // write logs and settle against its foreign key. Destroy every credential
        // component irreversibly and revoke it, so the old raw key can never be
        // authenticated again. Keep codex_group_id and billing configuration until
        // in-flight settlement finishes, otherwise deletion could change its price.
        db.prepare(`
      UPDATE consumer_api_keys
      SET name = '已注销密钥',
          key_prefix = 'deleted-' || id,
          key_hash = 'deleted:' || id || ':' || ?,
          key_encrypted = NULL,
          key_iv = NULL,
          key_auth_tag = NULL,
          status = 'revoked',
          enabled = 0,
          expires_at = ?
      WHERE user_id = ?
    `).run(deletedAt, deletedAt, id);
        db.prepare(`
      UPDATE users
      SET email = ?,
          password_hash = ?,
          status = 'disabled',
          deleted_at = ?
      WHERE id = ?
    `).run(`deleted-user-${id}@deleted.local`, `deleted:${id}:${deletedAt}`, deletedAt, id);
    })();
    res.json({ success: true });
});
