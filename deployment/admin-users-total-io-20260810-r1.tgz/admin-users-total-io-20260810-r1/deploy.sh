#!/usr/bin/env bash
set -Eeuo pipefail

CONTAINER="tuoke-prod-freellmapi-1"
COMPOSE_FILE="/srv/tuoke-prod/docker-compose.yml"
COMPOSE_PROJECT="tuoke-prod"
COMPOSE_SERVICE="freellmapi"
DATA_VOLUME="tuoke-prod_freellmapi-data"
PUBLIC_ORIGIN="https://tuokeapi.com"
EXPECTED_BASE_RELEASE="key-payload-fix-20260810-r1"
RELEASE_LABEL="admin-users-total-io-20260810-r1"
NEW_IMAGE="migration-japan/tuokeapi:20260810-admin-users-total-io-r1"
CLIENT_JS="index-admin-users-total-io-r1.js"
CLIENT_CSS="index-O2MQsLsm.css"

RELEASE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="/root/deploy-backups/${RELEASE_LABEL}-${STAMP}"

stage() { printf 'deployment_stage=%s\n' "$1"; }

stage lock
exec 9>/var/lock/tuoke-api-deploy.lock
flock -n 9 || { echo "deployment_lock=busy" >&2; exit 75; }

stage release_validation
test "$(id -u)" -eq 0
test -f "$COMPOSE_FILE"
test -f "$RELEASE_DIR/Dockerfile"
test -f "$RELEASE_DIR/MANIFEST.sha256"
(cd "$RELEASE_DIR" && sha256sum -c MANIFEST.sha256)

for path in \
  client-dist/index.html \
  "client-dist/assets/$CLIENT_JS"; do
  test -s "$RELEASE_DIR/$path"
done

docker inspect "$CONTAINER" >/dev/null
test "$(docker inspect --format '{{.State.Status}}' "$CONTAINER")" = "running"
OLD_IMAGE="$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")"
OLD_IMAGE_ID="$(docker inspect --format '{{.Image}}' "$CONTAINER")"
OLD_RELEASE="$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$OLD_IMAGE")"
test "$OLD_RELEASE" = "$EXPECTED_BASE_RELEASE"
test "$(docker image inspect --format '{{.Id}}' "$OLD_IMAGE")" = "$OLD_IMAGE_ID"

assert_live_baseline() {
  test "$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")" = "$OLD_IMAGE"
  test "$(docker inspect --format '{{.Image}}' "$CONTAINER")" = "$OLD_IMAGE_ID"
  test "$(docker image inspect --format '{{.Id}}' "$OLD_IMAGE")" = "$OLD_IMAGE_ID"
  test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$OLD_IMAGE")" = "$EXPECTED_BASE_RELEASE"
}

assert_live_baseline
docker exec "$CONTAINER" sh -lc "
  set -eu
  echo 'b60f70d997e9ba9ae7410c007e6fc3ff2c2b900f605edc65ca3a72562a79f31a  /app/server/dist/routes/admin-wallet.js' | sha256sum -c -
  echo '601fc909c03e709a745d97973ab3335cce56d3e3030341e7d1f5685ed002b8e0  /app/client/dist/index.html' | sha256sum -c -
  echo '7306186003955145fd2136c21ccf38f14add6e95bae9a28927387557e4ac2526  /app/client/dist/assets/index-key-payload-fix-r1.js' | sha256sum -c -
  echo '73de455c265aa18654a1d974220cee44b1688870c5e5cd9a2bc4b6794a0de0a0  /app/client/dist/assets/$CLIENT_CSS' | sha256sum -c -
"

stage backup
install -d -m 0700 "$BACKUP_DIR"
cp -a "$COMPOSE_FILE" "$BACKUP_DIR/docker-compose.yml.before"
chmod 0600 "$BACKUP_DIR/docker-compose.yml.before"
docker inspect "$CONTAINER" > "$BACKUP_DIR/container-inspect.before.json"
docker volume inspect "$DATA_VOLUME" > "$BACKUP_DIR/data-volume.before.json"
printf '%s\n' "$OLD_IMAGE" > "$BACKUP_DIR/previous-image.txt"
printf '%s\n' "$OLD_IMAGE_ID" > "$BACKUP_DIR/previous-image-id.txt"
sha256sum "$COMPOSE_FILE" > "$BACKUP_DIR/docker-compose.yml.before.sha256"

CONTAINER_DB_BACKUP="/app/server/data/.deploy-backup-${STAMP}.db"
docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  const target = process.argv[1];
  const source = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  await source.backup(target);
  source.close();
  const copy = new Database(target, { readonly: true, fileMustExist: true });
  const result = copy.pragma("quick_check", { simple: true });
  copy.close();
  if (result !== "ok") throw new Error(`backup quick_check failed: ${result}`);
' "$CONTAINER_DB_BACKUP"
docker cp "$CONTAINER:$CONTAINER_DB_BACKUP" "$BACKUP_DIR/freeapi-before.db"
docker exec "$CONTAINER" rm -f -- "$CONTAINER_DB_BACKUP"
test -s "$BACKUP_DIR/freeapi-before.db"
sha256sum "$BACKUP_DIR/freeapi-before.db" > "$BACKUP_DIR/freeapi-before.db.sha256"

stage candidate_build
docker build \
  --pull=false \
  --build-arg "BASE_IMAGE=$OLD_IMAGE" \
  --build-arg "BASE_IMAGE_ID=$OLD_IMAGE_ID" \
  --build-arg "BASE_RELEASE=$OLD_RELEASE" \
  --tag "$NEW_IMAGE" \
  "$RELEASE_DIR"

test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$NEW_IMAGE")" = "$RELEASE_LABEL"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.expected-base"}}' "$NEW_IMAGE")" = "$OLD_IMAGE"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.expected-base-id"}}' "$NEW_IMAGE")" = "$OLD_IMAGE_ID"
NEW_IMAGE_ID="$(docker image inspect --format '{{.Id}}' "$NEW_IMAGE")"
test -n "$NEW_IMAGE_ID"

stage isolated_route_test
docker run --rm -i --entrypoint node "$NEW_IMAGE" --input-type=module - <<'NODE'
import { initDb, getDb } from "/app/server/dist/db/index.js";
import { createUser, createSession } from "/app/server/dist/services/auth.js";
import { createApp } from "/app/server/dist/app.js";

process.env.ENCRYPTION_KEY = "0000000000000000000000000000000000000000000000000000000000000000";
initDb(":memory:");
const admin = createUser("wallet-ip-admin@example.test", "password123");
const target = createUser("wallet-ip-target@example.test", "password123");
const db = getDb();
const request = db.prepare(`
  INSERT INTO requests (
    platform, model_id, status, input_tokens, output_tokens,
    client_ip, consumer_user_id
  ) VALUES ('openai-codex', 'gpt-5.6-sol', 'success', 123, 45, '203.0.113.27', ?)
`).run(target.userId);
const requestId = Number(request.lastInsertRowid);
db.prepare(`
  INSERT INTO wallet_transactions (
    user_id, type, delta_micro, balance_after_micro, request_id,
    platform, model_id, input_tokens, output_tokens, note
  ) VALUES (?, 'usage', -100, 0, ?, 'openai-codex', 'gpt-5.6-sol', 123, 45, 'must stay hidden')
`).run(target.userId, requestId);

const app = createApp();
const server = await new Promise((resolve) => {
  const running = app.listen(0, "127.0.0.1", () => resolve(running));
});
try {
  const port = server.address().port;
  const response = await fetch(`http://127.0.0.1:${port}/api/admin/wallet/users/${target.userId}/transactions`, {
    headers: { Authorization: `Bearer ${createSession(admin.userId)}` },
  });
  const body = await response.json();
  const row = body.transactions?.find((entry) => entry.request_id === requestId);
  if (response.status !== 200 || row?.request_ip !== "203.0.113.27" || row?.note !== "must stay hidden") {
    throw new Error(`wallet request IP contract failed: ${JSON.stringify(body)}`);
  }
  console.log("isolated_wallet_request_ip_route=ok");
} finally {
  await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
}
NODE

stage live_read_only_query
docker run --rm \
  --volume "$DATA_VOLUME:/app/server/data:ro" \
  --entrypoint node \
  "$NEW_IMAGE" \
  --input-type=module -e '
    import Database from "better-sqlite3";
    const db = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
    const result = db.pragma("quick_check", { simple: true });
    if (result !== "ok") throw new Error(`live quick_check failed: ${result}`);
    const sample = db.prepare(`
      SELECT wt.id, wt.request_id AS requestId, req.client_ip AS requestIp
      FROM wallet_transactions wt
      LEFT JOIN requests req ON req.id = wt.request_id
      WHERE wt.type = ?
      ORDER BY wt.id DESC
      LIMIT 20
    `).all("usage");
    if (!Array.isArray(sample)) throw new Error("live wallet/IP query failed");
    db.close();
    console.log(`candidate_live_wallet_ip_query=ok rows=${sample.length}`);
  '

# Refuse to switch if production changed while the candidate image built.
assert_live_baseline

SWITCH_STARTED=0
rollback() {
  local code=$?
  set +e
  if [ "$SWITCH_STARTED" -eq 1 ]; then
    cp -a "$BACKUP_DIR/docker-compose.yml.before" "$COMPOSE_FILE"
    chmod 0600 "$COMPOSE_FILE"
    docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"
    for _ in $(seq 1 30); do
      if docker exec "$CONTAINER" node -e '
        fetch("http://127.0.0.1:3001/api/ping")
          .then(async response => {
            const body = await response.json();
            if (!response.ok || body.status !== "ok") process.exit(1);
          })
          .catch(() => process.exit(1));
      ' >/dev/null 2>&1; then
        break
      fi
      sleep 2
    done
    echo "deployment_result=rolled_back" >&2
  fi
  exit "$code"
}
trap rollback ERR

stage switch
SWITCH_STARTED=1
python3 - "$COMPOSE_FILE" "$NEW_IMAGE" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
image = sys.argv[2]
lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
inside = False
replaced = False
for index, line in enumerate(lines):
    if line.startswith("  freellmapi:"):
        inside = True
        continue
    if inside and line.startswith("  ") and not line.startswith("    ") and line.strip():
        break
    if inside and line.startswith("    image:"):
        newline = "\n" if line.endswith("\n") else ""
        lines[index] = f"    image: {image}{newline}"
        replaced = True
        break
if not replaced:
    raise SystemExit("freellmapi image entry not found")
temporary = path.with_suffix(path.suffix + ".codex-new")
temporary.write_text("".join(lines), encoding="utf-8")
temporary.chmod(0o600)
temporary.replace(path)
PY

docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config -q
docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"

stage health_check
HEALTH_OK=0
for _ in $(seq 1 60); do
  STATUS="$(docker inspect --format '{{.State.Status}}' "$CONTAINER" 2>/dev/null || true)"
  HEALTH="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER" 2>/dev/null || true)"
  if [ "$STATUS" = "running" ] && { [ "$HEALTH" = "healthy" ] || [ "$HEALTH" = "none" ]; }; then
    if docker exec "$CONTAINER" node -e '
      fetch("http://127.0.0.1:3001/api/ping")
        .then(async response => {
          const body = await response.json();
          if (!response.ok || body.status !== "ok") process.exit(1);
        })
        .catch(() => process.exit(1));
    ' >/dev/null 2>&1; then
      HEALTH_OK=1
      break
    fi
  fi
  if [ "$STATUS" = "exited" ] || [ "$STATUS" = "dead" ]; then
    break
  fi
  sleep 2
done
test "$HEALTH_OK" -eq 1

test "$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")" = "$NEW_IMAGE"
test "$(docker inspect --format '{{.Image}}' "$CONTAINER")" = "$NEW_IMAGE_ID"
test "$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER")" != "unhealthy"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$NEW_IMAGE")" = "$RELEASE_LABEL"

docker exec "$CONTAINER" sh -lc "
  set -eu
  echo 'b60f70d997e9ba9ae7410c007e6fc3ff2c2b900f605edc65ca3a72562a79f31a  /app/server/dist/routes/admin-wallet.js' | sha256sum -c -
  echo '4812648ac42d141b1e15b063041cf2e923497497506c4a991c9bdc17fb617440  /app/client/dist/index.html' | sha256sum -c -
  echo '4147b4f2117dda005335a969940b0165a2f6b12b8b25225fbc6dfb496c443799  /app/client/dist/assets/$CLIENT_JS' | sha256sum -c -
  echo '73de455c265aa18654a1d974220cee44b1688870c5e5cd9a2bc4b6794a0de0a0  /app/client/dist/assets/$CLIENT_CSS' | sha256sum -c -
  grep -q 'LEFT JOIN requests req' /app/server/dist/routes/admin-wallet.js
  grep -q 'request_ip' /app/server/dist/routes/admin-wallet.js
"

docker exec "$CONTAINER" node -e '
  const fs = require("node:fs");
  const source = fs.readFileSync("/app/client/dist/assets/index-admin-users-total-io-r1.js", "utf8");
  if (!source.includes("\u603b\u8f93\u5165\u8f93\u51fa")) throw new Error("new admin user label is missing");
  if (!source.includes("total_compute_points")) throw new Error("compute-point source field is missing");
  if (source.includes("\u603b\u7b97\u529b\u70b9")) throw new Error("old admin user label is still present");
'

docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  const db = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  const result = db.pragma("quick_check", { simple: true });
  db.close();
  if (result !== "ok") throw new Error(`live quick_check failed: ${result}`);
  console.log("live_database_quick_check=ok");
'

PUBLIC_OK=0
for _ in $(seq 1 30); do
  if docker exec "$CONTAINER" node -e "
    Promise.all([
      fetch('$PUBLIC_ORIGIN/api/ping', { cache: 'no-store' }).then(async response => {
        const body = await response.json();
        if (!response.ok || body.status !== 'ok') throw new Error('public ping failed');
      }),
      fetch('$PUBLIC_ORIGIN/', { cache: 'no-store' }).then(async response => {
        const html = await response.text();
        if (!response.ok || !html.includes('/assets/$CLIENT_JS') || !html.includes('/assets/$CLIENT_CSS')) {
          throw new Error('public client assets are stale');
        }
      }),
      fetch('$PUBLIC_ORIGIN/assets/$CLIENT_JS', { cache: 'no-store' }).then(async response => {
        const source = await response.text();
        if (!response.ok ||
            !source.includes('\u603b\u8f93\u5165\u8f93\u51fa') ||
            !source.includes('total_compute_points') ||
            source.includes('\u603b\u7b97\u529b\u70b9')) {
          throw new Error('public client JavaScript is stale');
        }
      }),
    ]).catch(() => process.exit(1));
  " >/dev/null 2>&1; then
    PUBLIC_OK=1
    break
  fi
  sleep 2
done
test "$PUBLIC_OK" -eq 1
test "$(docker inspect --format '{{.RestartCount}}' "$CONTAINER")" = "0"

SWITCH_STARTED=0
trap - ERR
echo "deployment_result=ok"
echo "deployment_mode=verified_admin_users_total_io_client_overlay"
echo "backup_dir=$BACKUP_DIR"
echo "previous_image=$OLD_IMAGE"
echo "previous_image_id=$OLD_IMAGE_ID"
echo "new_image=$NEW_IMAGE"
echo "new_image_id=$NEW_IMAGE_ID"
