import type { Db } from '../db/types.js';
import { type CodexPromptCacheStatus } from '../lib/codex-prompt-cache.js';
import type { CodexRelayCompatibilityReport, CodexRelayCompatibilityStatus } from './codex-relay-compatibility.js';
export declare const CODEX_RELAY_PROTOCOLS: readonly ["chat_completions", "responses"];
export type CodexRelayProtocol = typeof CODEX_RELAY_PROTOCOLS[number];
export type CodexPromptCacheReport = Record<string, unknown>;
export declare const CODEX_RELAY_MODEL_OUT_OF_CREDITS_COOLDOWN_MS: number;
export type CodexRelayModelRuntimeStatus = 'unknown' | 'healthy' | 'cooldown' | 'unsupported' | 'error';
export type CodexRelayModelFailureKind = 'unsupported_model' | 'access_forbidden' | 'out_of_credits' | 'temporary_unavailable' | 'no_channel' | 'policy_rejected' | 'other';
export interface CodexRelaySourceModelInput {
    publicModelId: string;
    upstreamModelId: string;
    enabled: boolean;
    supportsTools: boolean;
    supportsVision: boolean;
}
export interface CodexRelaySourceModel extends CodexRelaySourceModelInput {
    sourceId: number;
    promptCacheStatus: CodexPromptCacheStatus;
    promptCacheCheckedAt: string | null;
    promptCacheReport: CodexPromptCacheReport | null;
    runtimeStatus: CodexRelayModelRuntimeStatus;
    runtimeConsecutiveFailures: number;
    runtimeCooldownUntil: string | null;
    runtimeLastError: string | null;
    runtimeLastFailureAt: string | null;
    runtimeLastSuccessAt: string | null;
}
export interface CodexRelaySourceKey {
    sourceId: number;
    apiKeyId: number;
    label: string;
    maskedKey: string;
    priority: number;
    enabled: boolean;
    status: string;
    lastUsedAt: string | null;
    lastCheckedAt: string | null;
    lastError: string | null;
    failureCount: number;
    cooldownUntil: string | null;
    balance: number | null;
    balanceCurrency: string | null;
    balanceSyncedAt: string | null;
    credentialRevision: number;
    compatibilityStatus: CodexRelayCompatibilityStatus;
    compatibilityCheckedAt: string | null;
    compatibilityReport: CodexRelayCompatibilityReport | null;
    compatibilityCurrent: boolean;
    compatibilityStaleReason: 'test_suite_updated' | 'tested_key_changed' | null;
    createdAt: string;
    updatedAt: string;
}
export interface CodexRelaySource {
    id: number;
    kind: 'codex_relay';
    apiKeyId: number;
    name: string;
    baseUrl: string;
    maskedKey: string;
    codexGroupId: number | null;
    codexGroupName: string | null;
    protocol: CodexRelayProtocol;
    enabled: boolean;
    priority: number;
    status: string;
    lastUsedAt: string | null;
    lastCheckedAt: string | null;
    lastError: string | null;
    failureCount: number;
    cooldownUntil: string | null;
    balance: number | null;
    balanceCurrency: string | null;
    balanceSyncedAt: string | null;
    compatibilityStatus: CodexRelayCompatibilityStatus;
    compatibilityCheckedAt: string | null;
    compatibilityReport: CodexRelayCompatibilityReport | null;
    compatibilityCurrent: boolean;
    compatibilityStaleReason: 'test_suite_updated' | 'tested_key_changed' | null;
    createdAt: string;
    updatedAt: string;
    modelMappings: CodexRelaySourceModel[];
    keys: CodexRelaySourceKey[];
    keySummary: {
        total: number;
        enabled: number;
        healthy: number;
        available: number;
    };
}
/**
 * Internal-only credential carried with a routing candidate.  It is never
 * passed through an HTTP response; `decryptCodexRelaySourceApiKey` is the only
 * intended way routing code should read the secret.
 */
export interface CodexRelaySourceCredential {
    sourceId: number;
    apiKeyId: number;
    baseUrl: string;
    encryptedKey: string;
    iv: string;
    authTag: string;
}
export interface CodexRelayCandidate {
    sourceId: number;
    apiKeyId: number;
    baseUrl: string;
    publicModelId: string;
    upstreamModelId: string;
    supportsTools: boolean;
    supportsVision: boolean;
    protocol: CodexRelayProtocol;
    priority: number;
    keyPriority: number;
    keyLastUsedAt: string | null;
    promptCacheStatus: CodexPromptCacheStatus;
    promptCacheCheckedAt: string | null;
    promptCacheReport: CodexPromptCacheReport | null;
    runtimeStatus: CodexRelayModelRuntimeStatus;
    runtimeConsecutiveFailures: number;
    runtimeCooldownUntil: string | null;
    runtimeLastError: string | null;
    runtimeLastFailureAt: string | null;
    runtimeLastSuccessAt: string | null;
    source: CodexRelaySourceCredential;
}
export interface CreateCodexRelaySourceInput {
    name: string;
    baseUrl: string;
    apiKey: string;
    codexGroupId: number;
    protocol: CodexRelayProtocol;
    enabled: boolean;
    priority: number;
    modelMappings: CodexRelaySourceModelInput[];
}
export interface UpdateCodexRelaySourceInput {
    name?: string;
    baseUrl?: string;
    apiKey?: string;
    codexGroupId?: number;
    protocol?: CodexRelayProtocol;
    enabled?: boolean;
    priority?: number;
    modelMappings?: CodexRelaySourceModelInput[];
}
export interface CreateCodexRelaySourceKeyInput {
    apiKey: string;
    label?: string;
    priority?: number;
}
export interface UpdateCodexRelaySourceKeyInput {
    label?: string;
    enabled?: boolean;
    priority?: number;
}
export interface CodexRelayHealthCheckResult {
    source: CodexRelaySource;
    discoveredModels: string[];
}
export interface CodexRelayKeyHealthCheckOptions {
    /**
     * Manual Chat health checks may retry one aborted GET /models request. The
     * create-source path disables this so saving a supplier can never fan out
     * into more than one upstream request.
     */
    retryAbort?: boolean;
}
export interface CodexRelayModelHealthCheckResult {
    source: CodexRelaySource;
    model: CodexRelaySourceModel;
    apiKeyId: number;
    success: boolean;
    message: string;
}
export interface CodexRelayModelDiscoveryResult {
    models: string[];
    apiKeyId: number | null;
}
export declare function listCodexRelaySources(db: Db): CodexRelaySource[];
export declare function getCodexRelaySource(db: Db, id: number): CodexRelaySource | null;
export declare function createCodexRelaySource(db: Db, input: CreateCodexRelaySourceInput): CodexRelaySource;
export declare function updateCodexRelaySource(db: Db, id: number, input: UpdateCodexRelaySourceInput): CodexRelaySource | null;
export declare function deleteCodexRelaySource(db: Db, id: number): boolean;
export declare function createCodexRelaySourceKey(db: Db, sourceId: number, input: CreateCodexRelaySourceKeyInput): CodexRelaySource | null;
export declare function updateCodexRelaySourceKey(db: Db, sourceId: number, apiKeyId: number, input: UpdateCodexRelaySourceKeyInput): CodexRelaySource | null;
export declare function rotateCodexRelaySourceKey(db: Db, sourceId: number, apiKeyId: number, apiKey: string): CodexRelaySource | null;
export declare function deleteCodexRelaySourceKey(db: Db, sourceId: number, apiKeyId: number): CodexRelaySource | null;
/**
 * Finds relay candidates for a Codex-pool consumer only. Supplying a resource
 * subpool key intentionally yields no rows, so this remains safe even if a
 * future caller accidentally invokes it from a resource flow.
 */
export declare function listEligibleCodexRelayCandidates(db: Db, options: {
    consumerApiKeyId?: number | null;
    modelId: string;
    protocol?: CodexRelayProtocol;
    requireCompaction?: boolean;
    requireTools?: boolean;
    requireStreaming?: boolean;
    requireMultiTurn?: boolean;
}): CodexRelayCandidate[];
export declare function decryptCodexRelaySourceApiKey(source: CodexRelaySourceCredential): string;
export declare function classifyCodexRelayModelFailure(error: unknown): CodexRelayModelFailureKind;
export declare function recordCodexRelaySourceModelSuccess(db: Db, sourceId: number, publicModelId: string, nowMs?: number): boolean;
export declare function recordCodexRelaySourceUsed(db: Db, sourceId: number, apiKeyId: number): void;
/**
 * Persist a credential-wide Relay protection. Callers must reserve this for
 * authentication failure or confirmed balance exhaustion; transient/model
 * failures belong to the current request's fallback state and diagnostics.
 */
export declare function recordCodexRelaySourceFailure(db: Db, sourceId: number, apiKeyId: number, options?: {
    error?: unknown;
    authenticationFailure?: boolean;
    cooldownUntil?: string | null;
}): void;
export declare function discoveredModelsFromListPayload(payload: unknown): string[];
/**
 * Read an OpenAI-compatible model catalog without changing relay health or
 * routing state. This is deliberately separate from the health probe: model
 * discovery only proves that GET /models is readable, not that /responses or
 * /chat/completions works.
 */
export declare function discoverCodexRelayModelsWithCredentials(baseUrl: string, apiKey: string): Promise<string[]>;
/** Use the first saved credential that can read the supplier's model list. */
export declare function discoverCodexRelaySourceModels(db: Db, sourceId: number): Promise<CodexRelayModelDiscoveryResult>;
/**
 * Probe one credential without changing any sibling credential. Native
 * Responses suppliers issue a deliberately tiny non-streaming /responses
 * request because a successful model listing does not prove the Responses
 * wire protocol. The credential revision comparison prevents a slow probe
 * from overwriting the result of a Key rotation that completed meanwhile.
 */
export declare function checkCodexRelaySourceKeyHealth(db: Db, sourceId: number, apiKeyId: number, options?: CodexRelayKeyHealthCheckOptions): Promise<CodexRelayHealthCheckResult>;
/** Probe every credential belonging to the supplier and aggregate discovery. */
export declare function checkCodexRelaySourceHealth(db: Db, sourceId: number): Promise<CodexRelayHealthCheckResult>;
/**
 * Probe one exact public-to-upstream model mapping. A successful GET /models
 * or source-level health check does not prove that this particular model is
 * accepted by the relay, so this probe supplies mapping-level diagnostics.
 * Administrator enablement remains the routing gate: a failed probe does not
 * bench the mapping for later user requests. The credential is isolated only
 * when the response identifies a key-wide authentication or balance problem.
 */
export declare function checkCodexRelaySourceModelHealth(db: Db, sourceId: number, publicModelId: string): Promise<CodexRelayModelHealthCheckResult>;
//# sourceMappingURL=codex-relay-sources.d.ts.map