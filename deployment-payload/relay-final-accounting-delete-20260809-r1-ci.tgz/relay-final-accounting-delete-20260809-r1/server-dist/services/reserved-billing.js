import { calculateBillingAmountMicro, DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI, getEffectiveModelBillingRule, applyCodexGroupMultiplier, applyUserBillingMultiplier, } from './billing.js';
import { PAID_MODEL_SAFETY_BALANCE_MICRO } from './free-model-access.js';
import { ensurePromotionCreditReservation, getPromotionCreditReservationExpiryBreakdown, releasePromotionCreditReservation, settlePromotionCreditReservation, } from './promotion-credits.js';
function markRequestExempt(db, requestId) {
    db.prepare(`
    UPDATE requests
    SET
      billing_status = 'exempt',
      billing_amount_micro = 0
    WHERE id = ?
      AND billing_status = 'unbilled'
  `).run(requestId);
}
export function chargeReservedRequest(db, requestId, reservationId) {
    const transaction = db.transaction(() => {
        const request = db.prepare(`
            SELECT
              id,
              platform,
              model_id AS modelId,
              status,
              input_tokens AS inputTokens,
              cached_input_tokens AS cachedInputTokens,
              cache_write_tokens AS cacheWriteTokens,
              output_tokens AS outputTokens,
              consumer_user_id AS consumerUserId,
              consumer_api_key_id AS consumerApiKeyId,
              billing_status AS billingStatus
            FROM requests
            WHERE id = ?
          `).get(requestId);
        if (!request) {
            return {
                status: 'request_not_found',
            };
        }
        if (request.billingStatus !==
            'unbilled') {
            return {
                status: 'already_processed',
            };
        }
        // Failed routing attempts are not charged. A partial stream has
        // delivered billable output and must settle its observed usage.
        // Do not release the reservation here because
        // failover may still succeed on another route.
        if (request.status !== 'success' &&
            request.status !== 'partial') {
            markRequestExempt(db, request.id);
            return {
                status: 'not_billable',
            };
        }
        if (request.consumerUserId ===
            null) {
            markRequestExempt(db, request.id);
            return {
                status: 'not_billable',
            };
        }
        const reservation = db.prepare(`
            SELECT
              id,
              user_id AS userId,
              reserved_micro AS reservedMicro,
              status
            FROM wallet_reservations
            WHERE id = ?
          `).get(reservationId);
        if (!reservation) {
            return {
                status: 'reservation_not_found',
            };
        }
        if (reservation.status !==
            'reserved') {
            return {
                status: 'reservation_already_finalized',
            };
        }
        if (reservation.userId !==
            request.consumerUserId) {
            throw new Error('Wallet reservation user does not match request user');
        }
        const rule = getEffectiveModelBillingRule(db, request.platform, request.modelId, request.consumerApiKeyId);
        if (!rule ||
            !rule.billingEnabled) {
            return {
                status: 'no_billing_rule',
            };
        }
        const effectiveMultiplierMilli = applyUserBillingMultiplier(db, request.consumerUserId, applyCodexGroupMultiplier(db, request.platform, request.consumerApiKeyId, rule.multiplierMilli));
        const amountMicro = calculateBillingAmountMicro(request.inputTokens, request.outputTokens, rule.inputPriceMicroPerMillion, rule.outputPriceMicroPerMillion, effectiveMultiplierMilli, request.cachedInputTokens, rule.cachedInputMultiplierMilli, request.cacheWriteTokens, DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI);
        const wallet = db.prepare(`
            SELECT
              balance_micro AS balanceMicro,
              reserved_balance_micro
                AS reservedBalanceMicro
            FROM users
            WHERE id = ?
          `).get(request.consumerUserId);
        if (!wallet) {
            return {
                status: 'insufficient_balance',
                amountMicro,
                balanceAfterMicro: 0,
            };
        }
        // Explicit free model.
        if (amountMicro === 0) {
            releasePromotionCreditReservation(db, reservation.id);
            const released = db.prepare(`
              UPDATE users
              SET
                reserved_balance_micro =
                  reserved_balance_micro - ?
              WHERE id = ?
                AND reserved_balance_micro >= ?
            `).run(reservation.reservedMicro, request.consumerUserId, reservation.reservedMicro);
            if (released.changes !== 1) {
                throw new Error('Failed to release free request reservation');
            }
            const reservationUpdated = db.prepare(`
              UPDATE wallet_reservations
              SET
                request_id = ?,
                actual_micro = 0,
                status = 'settled',
                settled_at = datetime('now')
              WHERE id = ?
                AND status = 'reserved'
            `).run(request.id, reservation.id);
            if (reservationUpdated.changes !==
                1) {
                throw new Error('Failed to settle free reservation');
            }
            const requestUpdated = db.prepare(`
              UPDATE requests
              SET
                billing_amount_micro = 0,
                billing_status = 'free'
              WHERE id = ?
                AND billing_status = 'unbilled'
            `).run(request.id);
            if (requestUpdated.changes !==
                1) {
                throw new Error('Failed to mark free request');
            }
            return {
                status: 'free',
                amountMicro: 0,
                balanceAfterMicro: wallet.balanceMicro,
            };
        }
        // Top up this request from currently-valid FEFO batches before
        // settlement. Credit attached at admission remains settleable even if
        // its batch expired while the provider was running.
        const promotionReservation = ensurePromotionCreditReservation(db, {
            userId: request.consumerUserId,
            walletReservationId: reservation.id,
            targetMicro: amountMicro,
        });
        const promotionExpiry = getPromotionCreditReservationExpiryBreakdown(db, reservation.id);
        // Money reserved for other simultaneous wallet requests must not be
        // spent by this request.
        const otherReservedMicro = Math.max(0, wallet.reservedBalanceMicro -
            reservation.reservedMicro);
        const spendableForThisRequest = Math.max(0, wallet.balanceMicro -
            otherReservedMicro);
        // The 0.10 yuan floor is based on the user's combined API credit, not
        // the permanent wallet alone. Unallocated active promotion credit may
        // satisfy the floor, while another request's allocation is excluded.
        // Credit allocated before its batch expired is already committed to
        // this in-flight request and remains fully spendable. The 0.10 floor
        // applies only to still-active/unallocated credit plus the permanent
        // wallet; otherwise an expiry during generation would erase the final
        // 0.10 of a request that had already been admitted.
        const maximumCombinedChargeMicro = promotionExpiry.expiredReservedMicro
            + Math.max(0, promotionExpiry.activeReservedMicro
                + promotionReservation.availableAfterMicro
                + spendableForThisRequest
                - PAID_MODEL_SAFETY_BALANCE_MICRO);
        const chargeTargetMicro = Math.min(amountMicro, promotionReservation.totalReservedMicro + spendableForThisRequest, maximumCombinedChargeMicro);
        const promotionSettlement = settlePromotionCreditReservation(db, {
            userId: request.consumerUserId,
            walletReservationId: reservation.id,
            requestId: request.id,
            chargeMicro: chargeTargetMicro,
        });
        const walletChargedMicro = promotionSettlement.uncoveredMicro;
        const chargedMicro = promotionSettlement.consumedMicro + walletChargedMicro;
        if (chargedMicro !== chargeTargetMicro || walletChargedMicro > spendableForThisRequest) {
            throw new Error('Combined promotion and wallet settlement changed during charge');
        }
        const safetyCapped = chargedMicro < amountMicro;
        const balanceAfterMicro = wallet.balanceMicro -
            walletChargedMicro;
        // Deduct actual usage and release this
        // reservation atomically.
        const updated = db.prepare(`
            UPDATE users
            SET
              balance_micro =
                balance_micro - ?,
              reserved_balance_micro =
                reserved_balance_micro - ?
            WHERE id = ?
              AND reserved_balance_micro >= ?
              AND balance_micro >= ?
          `).run(walletChargedMicro, reservation.reservedMicro, request.consumerUserId, reservation.reservedMicro, walletChargedMicro);
        if (updated.changes !== 1) {
            // Promotion allocations were settled earlier in this same SQLite
            // transaction. Returning here would commit that consumption while
            // leaving the request and reservation unfinished. Throw so every
            // promotion + wallet side effect is rolled back atomically.
            throw new Error('Wallet balance changed during combined settlement');
        }
        if (walletChargedMicro > 0) {
            db.prepare(`
            INSERT INTO wallet_transactions (
              user_id,
              type,
              delta_micro,
              balance_after_micro,
              request_id,
              platform,
              model_id,
              input_tokens,
              cached_input_tokens,
              cache_write_tokens,
              output_tokens,
              multiplier_milli,
              cached_input_multiplier_milli,
              cache_write_multiplier_milli,
              input_price_micro_per_million,
              output_price_micro_per_million,
              note
            )
            VALUES (
              ?,
              'usage',
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?
            )
          `).run(request.consumerUserId, -walletChargedMicro, balanceAfterMicro, request.id, request.platform, request.modelId, request.inputTokens, request.cachedInputTokens, request.cacheWriteTokens, request.outputTokens, effectiveMultiplierMilli, rule.cachedInputMultiplierMilli, DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI, rule.inputPriceMicroPerMillion, rule.outputPriceMicroPerMillion, safetyCapped
                ? 'API usage wallet remainder (combined credit safety cap applied)'
                : 'API usage wallet remainder after promotion credit');
        }
        const markedRequest = db.prepare(`
            UPDATE requests
            SET
              billing_amount_micro = ?,
              billing_status = 'charged'
            WHERE id = ?
              AND billing_status = 'unbilled'
          `).run(chargedMicro, request.id);
        if (markedRequest.changes !==
            1) {
            throw new Error('Request billing state changed during reservation settlement');
        }
        const markedReservation = db.prepare(`
            UPDATE wallet_reservations
            SET
              request_id = ?,
              actual_micro = ?,
              status = 'settled',
              settled_at = datetime('now')
            WHERE id = ?
              AND status = 'reserved'
          `).run(request.id, chargedMicro, reservation.id);
        if (markedReservation.changes !==
            1) {
            throw new Error('Reservation state changed during settlement');
        }
        return {
            status: 'charged',
            amountMicro: chargedMicro,
            balanceAfterMicro,
        };
    });
    return transaction();
}
//# sourceMappingURL=reserved-billing.js.map