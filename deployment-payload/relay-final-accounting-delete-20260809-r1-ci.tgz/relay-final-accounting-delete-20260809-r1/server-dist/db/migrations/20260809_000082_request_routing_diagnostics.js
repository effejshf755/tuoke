const COLUMN = 'routing_diagnostics';
function hasColumn(db) {
    return db.prepare('PRAGMA table_info(requests)').all()
        .some((column) => column.name === COLUMN);
}
/**
 * Store one bounded, administrator-only routing snapshot beside the existing
 * raw request row.  A nullable column keeps the common no-fallback path small
 * and follows the same retention policy as request analytics; no second log
 * table or independent cleanup job is required.
 */
export function up(db) {
    if (!hasColumn(db)) {
        db.exec(`ALTER TABLE requests ADD COLUMN ${COLUMN} TEXT`);
    }
}
export function down(db) {
    if (hasColumn(db)) {
        db.exec(`ALTER TABLE requests DROP COLUMN ${COLUMN}`);
    }
}
//# sourceMappingURL=20260809_000082_request_routing_diagnostics.js.map