import { FINAL_REQUEST_RESULT_SQL } from '../lib/request-log.js';
export const RELAY_DETECTION_MIN_SAMPLES = 20;
const KNOWN_RELAY_USER_AGENT_SQL = `(
  INSTR(LOWER(COALESCE(r.client_user_agent, '')), 'new-api') > 0
  OR INSTR(LOWER(COALESCE(r.client_user_agent, '')), 'newapi') > 0
  OR INSTR(LOWER(COALESCE(r.client_user_agent, '')), 'one-api') > 0
  OR INSTR(LOWER(COALESCE(r.client_user_agent, '')), 'oneapi') > 0
  OR INSTR(LOWER(COALESCE(r.client_user_agent, '')), 'uni-api') > 0
  OR INSTR(LOWER(COALESCE(r.client_user_agent, '')), 'litellm') > 0
  OR INSTR(LOWER(COALESCE(r.client_user_agent, '')), 'openai-forward') > 0
  OR INSTR(LOWER(COALESCE(r.client_user_agent, '')), 'openai-proxy') > 0
)`;
function sqliteTimestamp(date) {
    return date.toISOString().slice(0, 19).replace('T', ' ');
}
function isoTimestamp(value) {
    return `${value.slice(0, 10)}T${value.slice(11, 19)}Z`;
}
function nonNegativeInteger(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? Math.max(0, Math.trunc(parsed)) : 0;
}
function share(part, total) {
    if (total <= 0)
        return 0;
    return Math.round((part / total) * 10_000) / 10_000;
}
export function relayDetectionSince(window, now = new Date()) {
    const durationMs = window === '24h'
        ? 24 * 60 * 60 * 1000
        : 7 * 24 * 60 * 60 * 1000;
    return sqliteTimestamp(new Date(now.getTime() - durationMs));
}
/**
 * Produce an explainable heuristic score. This is deliberately a triage aid,
 * not proof that an account is reselling the API: ordinary automated clients
 * can have the same network and traffic shape.
 */
export function scoreRelayDetectionMetrics(metrics, window) {
    if (metrics.requestCount < RELAY_DETECTION_MIN_SAMPLES) {
        return {
            score: 0,
            level: 'insufficient',
            reasons: [{
                    code: 'insufficient_samples',
                    points: 0,
                    detail: `${metrics.requestCount}/${RELAY_DETECTION_MIN_SAMPLES} requests in the selected window`,
                }],
        };
    }
    const reasons = [];
    const ipCoverage = share(metrics.requestsWithIp, metrics.requestCount);
    const userAgentCoverage = share(metrics.requestsWithUserAgent, metrics.requestCount);
    if (metrics.knownRelayUserAgentRequests >= 5
        && metrics.knownRelayUserAgentShare >= 0.5) {
        reasons.push({
            code: 'known_relay_user_agent',
            points: 45,
            detail: `${Math.round(metrics.knownRelayUserAgentShare * 100)}% of requests identify a known relay`,
        });
    }
    else if (metrics.knownRelayUserAgentRequests >= 5
        && metrics.knownRelayUserAgentShare >= 0.2) {
        reasons.push({
            code: 'known_relay_user_agent',
            points: 30,
            detail: `${Math.round(metrics.knownRelayUserAgentShare * 100)}% of requests identify a known relay`,
        });
    }
    const stableNetworkOrigin = ipCoverage >= 0.8
        && metrics.distinctIpCount <= 2
        && metrics.dominantIpShare >= 0.9;
    if (stableNetworkOrigin) {
        reasons.push({
            code: 'stable_network_origin',
            points: 15,
            detail: `${Math.round(metrics.dominantIpShare * 100)}% of identified requests use one IP`,
        });
    }
    const requestBurstPoints = metrics.peakRequestsPerSecond >= 4
        || metrics.peakRequestsPerMinute >= 30
        ? 25
        : metrics.peakRequestsPerSecond >= 2 || metrics.peakRequestsPerMinute >= 10
            ? 15
            : 0;
    if (requestBurstPoints > 0) {
        reasons.push({
            code: 'automated_request_burst',
            points: requestBurstPoints,
            detail: `peak ${metrics.peakRequestsPerSecond}/second and ${metrics.peakRequestsPerMinute}/minute`,
        });
    }
    if (stableNetworkOrigin
        && userAgentCoverage >= 0.8
        && metrics.distinctUserAgentCount <= 2
        && metrics.dominantUserAgentShare >= 0.9
        && requestBurstPoints > 0) {
        reasons.push({
            code: 'stable_client_signature',
            points: 10,
            detail: `${Math.round(metrics.dominantUserAgentShare * 100)}% of identified requests use one client signature`,
        });
    }
    const sustainedPoints = window === '24h'
        ? metrics.activeHourCount >= 12
            ? 20
            : metrics.activeHourCount >= 8
                ? 12
                : 0
        : metrics.activeDayCount >= 4 && metrics.activeHourOfDayCount >= 16
            ? 20
            : metrics.activeDayCount >= 3 && metrics.activeHourOfDayCount >= 10
                ? 12
                : 0;
    if (sustainedPoints > 0) {
        reasons.push({
            code: 'sustained_activity',
            points: sustainedPoints,
            detail: `${metrics.activeHourCount} active hours across ${metrics.activeDayCount} days`,
        });
    }
    const modelDiversityPoints = metrics.distinctModelCount >= 4
        ? 10
        : metrics.distinctModelCount >= 2
            ? 5
            : 0;
    if (modelDiversityPoints > 0) {
        reasons.push({
            code: 'model_diversity',
            points: modelDiversityPoints,
            detail: `${metrics.distinctModelCount} distinct models`,
        });
    }
    const score = Math.min(100, reasons.reduce((sum, reason) => sum + reason.points, 0));
    const level = score >= 60
        ? 'high'
        : score >= 35
            ? 'medium'
            : 'low';
    return { score, level, reasons };
}
function metricsFromRow(row) {
    const requestCount = nonNegativeInteger(row.request_count);
    const requestsWithIp = nonNegativeInteger(row.requests_with_ip);
    const requestsWithUserAgent = nonNegativeInteger(row.requests_with_user_agent);
    const knownRelayUserAgentRequests = nonNegativeInteger(row.known_relay_user_agent_requests);
    return {
        requestCount,
        successCount: nonNegativeInteger(row.success_count),
        errorOrPartialCount: nonNegativeInteger(row.error_or_partial_count),
        requestsWithIp,
        distinctIpCount: nonNegativeInteger(row.distinct_ip_count),
        dominantIpShare: share(nonNegativeInteger(row.dominant_ip_requests), requestsWithIp),
        requestsWithUserAgent,
        distinctUserAgentCount: nonNegativeInteger(row.distinct_user_agent_count),
        dominantUserAgentShare: share(nonNegativeInteger(row.dominant_user_agent_requests), requestsWithUserAgent),
        knownRelayUserAgentRequests,
        knownRelayUserAgentShare: share(knownRelayUserAgentRequests, requestCount),
        distinctApiKeyCount: nonNegativeInteger(row.distinct_api_key_count),
        distinctModelCount: nonNegativeInteger(row.distinct_model_count),
        activeHourCount: nonNegativeInteger(row.active_hour_count),
        activeDayCount: nonNegativeInteger(row.active_day_count),
        activeHourOfDayCount: nonNegativeInteger(row.active_hour_of_day_count),
        peakRequestsPerMinute: nonNegativeInteger(row.peak_requests_per_minute),
        peakRequestsPerSecond: nonNegativeInteger(row.peak_requests_per_second),
        firstSeenAt: isoTimestamp(row.first_seen_at),
        lastSeenAt: isoTimestamp(row.last_seen_at),
    };
}
/** Aggregate recent, final request outcomes by their authoritative owner. */
export function listRelayDetectionSignals(db, window, now = new Date()) {
    const rows = db.prepare(`
    WITH owned_requests AS (
      SELECT
        r.id,
        CASE
          WHEN r.consumer_user_id IS NOT NULL THEN r.consumer_user_id
          ELSE consumer_key.user_id
        END AS user_id,
        r.consumer_api_key_id,
        r.model_id,
        r.status,
        NULLIF(TRIM(r.client_ip), '') AS client_ip,
        NULLIF(TRIM(r.client_user_agent), '') AS client_user_agent,
        CASE WHEN ${KNOWN_RELAY_USER_AGENT_SQL} THEN 1 ELSE 0 END AS known_relay_user_agent,
        r.created_at
      FROM requests r
      LEFT JOIN consumer_api_keys consumer_key
        ON r.consumer_user_id IS NULL
       AND consumer_key.id = r.consumer_api_key_id
      WHERE r.created_at >= ?
        AND ${FINAL_REQUEST_RESULT_SQL}
    ),
    scoped_requests AS (
      SELECT owned.*
      FROM owned_requests owned
      JOIN users owner
        ON owner.id = owned.user_id
       AND owner.deleted_at IS NULL
      WHERE owned.user_id IS NOT NULL
    ),
    base AS (
      SELECT
        user_id,
        COUNT(*) AS request_count,
        SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS success_count,
        SUM(CASE WHEN status IN ('error', 'partial') THEN 1 ELSE 0 END) AS error_or_partial_count,
        SUM(CASE WHEN client_ip IS NOT NULL THEN 1 ELSE 0 END) AS requests_with_ip,
        COUNT(DISTINCT client_ip) AS distinct_ip_count,
        SUM(CASE WHEN client_user_agent IS NOT NULL THEN 1 ELSE 0 END) AS requests_with_user_agent,
        COUNT(DISTINCT client_user_agent) AS distinct_user_agent_count,
        SUM(known_relay_user_agent) AS known_relay_user_agent_requests,
        COUNT(DISTINCT consumer_api_key_id) AS distinct_api_key_count,
        COUNT(DISTINCT model_id) AS distinct_model_count,
        COUNT(DISTINCT STRFTIME('%Y-%m-%d %H', created_at)) AS active_hour_count,
        COUNT(DISTINCT DATE(created_at)) AS active_day_count,
        COUNT(DISTINCT STRFTIME('%H', created_at)) AS active_hour_of_day_count,
        MIN(created_at) AS first_seen_at,
        MAX(created_at) AS last_seen_at
      FROM scoped_requests
      GROUP BY user_id
    ),
    ip_counts AS (
      SELECT user_id, client_ip, COUNT(*) AS request_count
      FROM scoped_requests
      WHERE client_ip IS NOT NULL
      GROUP BY user_id, client_ip
    ),
    ip_peaks AS (
      SELECT user_id, MAX(request_count) AS dominant_ip_requests
      FROM ip_counts
      GROUP BY user_id
    ),
    user_agent_counts AS (
      SELECT user_id, client_user_agent, COUNT(*) AS request_count
      FROM scoped_requests
      WHERE client_user_agent IS NOT NULL
      GROUP BY user_id, client_user_agent
    ),
    user_agent_peaks AS (
      SELECT user_id, MAX(request_count) AS dominant_user_agent_requests
      FROM user_agent_counts
      GROUP BY user_id
    ),
    minute_counts AS (
      SELECT user_id, STRFTIME('%Y-%m-%d %H:%M', created_at) AS minute, COUNT(*) AS request_count
      FROM scoped_requests
      GROUP BY user_id, minute
    ),
    minute_peaks AS (
      SELECT user_id, MAX(request_count) AS peak_requests_per_minute
      FROM minute_counts
      GROUP BY user_id
    ),
    second_counts AS (
      SELECT user_id, created_at AS second, COUNT(*) AS request_count
      FROM scoped_requests
      GROUP BY user_id, second
    ),
    second_peaks AS (
      SELECT user_id, MAX(request_count) AS peak_requests_per_second
      FROM second_counts
      GROUP BY user_id
    )
    SELECT
      base.*,
      COALESCE(ip_peaks.dominant_ip_requests, 0) AS dominant_ip_requests,
      COALESCE(user_agent_peaks.dominant_user_agent_requests, 0) AS dominant_user_agent_requests,
      COALESCE(minute_peaks.peak_requests_per_minute, 0) AS peak_requests_per_minute,
      COALESCE(second_peaks.peak_requests_per_second, 0) AS peak_requests_per_second
    FROM base
    LEFT JOIN ip_peaks USING (user_id)
    LEFT JOIN user_agent_peaks USING (user_id)
    LEFT JOIN minute_peaks USING (user_id)
    LEFT JOIN second_peaks USING (user_id)
    ORDER BY base.request_count DESC, base.user_id ASC
  `).all(relayDetectionSince(window, now));
    return rows.map((row) => {
        const metrics = metricsFromRow(row);
        return {
            userId: nonNegativeInteger(row.user_id),
            ...scoreRelayDetectionMetrics(metrics, window),
            metrics,
        };
    });
}
//# sourceMappingURL=relay-detection.js.map