#!/usr/bin/env bash
set -Eeuo pipefail

CONTAINER="tuoke-prod-freellmapi-1"
COMPOSE_FILE="/srv/tuoke-prod/docker-compose.yml"
COMPOSE_PROJECT="tuoke-prod"
COMPOSE_SERVICE="freellmapi"
DATA_VOLUME="tuoke-prod_freellmapi-data"
PUBLIC_ORIGIN="https://tuokeapi.com"
EXPECTED_BASE_IMAGE="migration-japan/tuokeapi:20260810-relay-balance-request-local-r1"
EXPECTED_BASE_ID="sha256:b6fe8f66b244932a191bbf90c1b47da4abc14d0ae8de2cb5c7403bc4449f41b4"
EXPECTED_BASE_RELEASE="relay-balance-request-local-20260810-r1"
NEW_IMAGE="migration-japan/tuokeapi:20260810-relay-detection-r1"
RELEASE_LABEL="relay-detection-20260810-r1"
CLIENT_JS="index-Bjoy-hS2.js"
CLIENT_CSS="index-O2MQsLsm.css"

RELEASE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="/root/deploy-backups/${RELEASE_LABEL}-${STAMP}"

exec 9>/var/lock/tuoke-api-deploy.lock
flock -n 9 || { echo "deployment_lock=busy" >&2; exit 75; }

test "$(id -u)" -eq 0
test -f "$COMPOSE_FILE"
test -f "$RELEASE_DIR/Dockerfile"
test -f "$RELEASE_DIR/MANIFEST.sha256"
(
  cd "$RELEASE_DIR"
  sha256sum -c MANIFEST.sha256
)

for path in \
  server-dist/lib/compute-points-response.js \
  server-dist/lib/request-log.js \
  server-dist/routes/admin-users.js \
  server-dist/routes/responses.js \
  server-dist/services/relay-detection.js \
  client-dist/index.html \
  "client-dist/assets/$CLIENT_JS" \
  "client-dist/assets/$CLIENT_CSS"; do
  test -s "$RELEASE_DIR/$path"
done

docker inspect "$CONTAINER" >/dev/null
test "$(docker inspect --format '{{.State.Status}}' "$CONTAINER")" = "running"
OLD_IMAGE="$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")"
OLD_IMAGE_ID="$(docker inspect --format '{{.Image}}' "$CONTAINER")"
test "$OLD_IMAGE" = "$EXPECTED_BASE_IMAGE"
test "$OLD_IMAGE_ID" = "$EXPECTED_BASE_ID"
test "$(docker image inspect --format '{{.Id}}' "$OLD_IMAGE")" = "$EXPECTED_BASE_ID"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$OLD_IMAGE")" = "$EXPECTED_BASE_RELEASE"

assert_live_baseline() {
  local actual_image actual_id tagged_id actual_release
  actual_image="$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")"
  actual_id="$(docker inspect --format '{{.Image}}' "$CONTAINER")"
  tagged_id="$(docker image inspect --format '{{.Id}}' "$EXPECTED_BASE_IMAGE")"
  actual_release="$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$EXPECTED_BASE_IMAGE")"
  test "$actual_image" = "$EXPECTED_BASE_IMAGE"
  test "$actual_id" = "$EXPECTED_BASE_ID"
  test "$tagged_id" = "$EXPECTED_BASE_ID"
  test "$actual_release" = "$EXPECTED_BASE_RELEASE"
}

assert_live_baseline

docker exec "$CONTAINER" sh -lc "
  set -eu
  echo '24d050725cd5bde0a56dc5827579de418a4c51b549a9dadfac486a03ccd9175f  /app/server/dist/lib/compute-points-response.js' | sha256sum -c -
  echo '764010ca67ba22a529a42d01a03decc161bb4d718c8428d12ecc49fa0e6ece47  /app/server/dist/lib/request-log.js' | sha256sum -c -
  echo 'c852ad7117221bf0af14750aebec7a4f9dc78f35d76cc15e46d1f2f5a70e990c  /app/server/dist/routes/admin-users.js' | sha256sum -c -
  echo 'f7c175d4da2ee917874ce98dfab4674a2197ebd3b60d7235349bf1802aa1ec50  /app/server/dist/routes/responses.js' | sha256sum -c -
  echo 'ece022d1ef4e1dcd530475f47e3fa0d86e1336d192ec8c7ba21bdd4e4e98c727  /app/client/dist/index.html' | sha256sum -c -
  echo '9953ee41357a5ecb2e0fc8bc304866042a088e498778d644585428d41b6679d2  /app/client/dist/assets/index-DQLlbmOq.js' | sha256sum -c -
  echo '1c7b534847859aa2ba2ee70e26b58a1fe8b032c1c493b8253ebd39f6a4e85260  /app/client/dist/assets/index-Bu5ANiKc.css' | sha256sum -c -
  echo 'ae4b17dd586f82ea99b53f9e30c7eca5f2337abd28cf1035aa66e030739c4279  /app/server/dist/services/billing.js' | sha256sum -c -
  test ! -e /app/server/dist/services/relay-detection.js
  grep -q 'A balance error is request-local too' /app/server/dist/lib/fallback-loop.js
  grep -q 'installComputePointUsageResponse' /app/server/dist/middleware/consumerQuota.js
"

docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  const db = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  const requestColumns = new Set(db.pragma("table_info(requests)").map((row) => row.name));
  const userColumns = new Set(db.pragma("table_info(users)").map((row) => row.name));
  const migrations = new Set(db.prepare("SELECT filename FROM migrations").all().map((row) => row.filename));
  if (!requestColumns.has("routing_diagnostics")) throw new Error("routing_diagnostics column missing");
  if (!userColumns.has("deleted_at")) throw new Error("users.deleted_at column missing");
  if (!migrations.has("20260809_000082_request_routing_diagnostics.ts")) throw new Error("migration 82 missing");
  db.close();
  console.log("production_schema_preflight=ok");
'

install -d -m 0700 "$BACKUP_DIR"
cp -a "$COMPOSE_FILE" "$BACKUP_DIR/docker-compose.yml.before"
docker inspect "$CONTAINER" > "$BACKUP_DIR/container-inspect.before.json"
docker volume inspect "$DATA_VOLUME" > "$BACKUP_DIR/data-volume.before.json"
sha256sum "$COMPOSE_FILE" > "$BACKUP_DIR/docker-compose.yml.before.sha256"
printf '%s\n' "$OLD_IMAGE" > "$BACKUP_DIR/previous-image.txt"
printf '%s\n' "$OLD_IMAGE_ID" > "$BACKUP_DIR/previous-image-id.txt"

CONTAINER_DB_BACKUP="/app/server/data/.deploy-backup-${STAMP}.db"
docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  const target = process.argv[1];
  const source = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  await source.backup(target);
  source.close();
  const copy = new Database(target, { readonly: true, fileMustExist: true });
  const result = copy.pragma("quick_check", { simple: true });
  copy.close();
  if (result !== "ok") throw new Error(`backup quick_check failed: ${result}`);
  console.log("database_backup_quick_check=ok");
' "$CONTAINER_DB_BACKUP"
docker cp "$CONTAINER:$CONTAINER_DB_BACKUP" "$BACKUP_DIR/freeapi-before.db"
docker exec "$CONTAINER" rm -f -- "$CONTAINER_DB_BACKUP"
test -s "$BACKUP_DIR/freeapi-before.db"
sha256sum "$BACKUP_DIR/freeapi-before.db" > "$BACKUP_DIR/freeapi-before.db.sha256"

docker build \
  --pull=false \
  --build-arg "BASE_IMAGE=$OLD_IMAGE" \
  --tag "$NEW_IMAGE" \
  "$RELEASE_DIR"

test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$NEW_IMAGE")" = "$RELEASE_LABEL"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.expected-base"}}' "$NEW_IMAGE")" = "$EXPECTED_BASE_IMAGE"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.expected-base-id"}}' "$NEW_IMAGE")" = "$EXPECTED_BASE_ID"
NEW_IMAGE_ID="$(docker image inspect --format '{{.Id}}' "$NEW_IMAGE")"
test -n "$NEW_IMAGE_ID"

for file in \
  /app/server/dist/lib/compute-points-response.js \
  /app/server/dist/lib/request-log.js \
  /app/server/dist/routes/admin-users.js \
  /app/server/dist/routes/responses.js \
  /app/server/dist/services/relay-detection.js; do
  docker run --rm --entrypoint node "$NEW_IMAGE" --check "$file"
done

docker run --rm --entrypoint node "$NEW_IMAGE" --input-type=module -e '
  import { convertUsageToComputePoints } from "/app/server/dist/lib/compute-points-response.js";
  import { calculateComputePointBillingAmountMicro } from "/app/server/dist/services/billing.js";
  import { scoreRelayDetectionMetrics } from "/app/server/dist/services/relay-detection.js";
  const converted = convertUsageToComputePoints({
    input_tokens: 100,
    output_tokens: 20,
    total_tokens: 120,
    input_tokens_details: { cached_tokens: 40, cache_write_tokens: 10 },
  }, 1_500_000);
  const expected = JSON.stringify({
    input_tokens: 150,
    output_tokens: 30,
    total_tokens: 180,
    input_tokens_details: { cached_tokens: 60, cache_write_tokens: 15 },
  });
  if (JSON.stringify(converted) !== expected) throw new Error("account usage conversion check failed");
  const charge = calculateComputePointBillingAmountMicro({
    inputTokens: 1_000_000,
    cachedInputTokens: 0,
    cacheWriteTokens: 0,
    outputTokens: 0,
    inputComputePoints: 1_500_000,
    outputComputePoints: 0,
    computePointsPerMillionTokens: 1_500_000,
  }, 1_000_000, 0, 1_000);
  if (charge !== 1_500_000) throw new Error(`unexpected compute-point charge: ${charge}`);
  const signal = scoreRelayDetectionMetrics({
    requestCount: 20,
    successCount: 20,
    errorOrPartialCount: 0,
    requestsWithIp: 20,
    distinctIpCount: 1,
    dominantIpShare: 1,
    requestsWithUserAgent: 20,
    distinctUserAgentCount: 1,
    dominantUserAgentShare: 1,
    knownRelayUserAgentRequests: 20,
    knownRelayUserAgentShare: 1,
    distinctApiKeyCount: 1,
    distinctModelCount: 4,
    activeHourCount: 1,
    activeDayCount: 1,
    activeHourOfDayCount: 1,
    peakRequestsPerMinute: 20,
    peakRequestsPerSecond: 20,
    firstSeenAt: "2026-08-10T00:00:00Z",
    lastSeenAt: "2026-08-10T00:00:01Z",
  }, "24h");
  if (signal.level !== "high" || signal.score !== 100) throw new Error("relay scoring contract failed");
  console.log("combined_behavior_check=ok");
'

# Exercise the real authenticated route on an isolated in-memory database.
docker run --rm --entrypoint node "$NEW_IMAGE" --input-type=module -e '
  import { initDb, getDb } from "/app/server/dist/db/index.js";
  import { createUser, createSession } from "/app/server/dist/services/auth.js";
  import { createConsumerApiKey } from "/app/server/dist/services/consumer-api-keys.js";
  import { clientContextMiddleware, getClientContext } from "/app/server/dist/lib/client-context.js";
  import { markExhaustedRequestRoutingRecovered } from "/app/server/dist/lib/request-log.js";
  import { createApp } from "/app/server/dist/app.js";
  process.env.ENCRYPTION_KEY = "0000000000000000000000000000000000000000000000000000000000000000";
  initDb(":memory:");
  const recoveryRow = getDb().prepare(`
    INSERT INTO requests (platform, model_id, status, input_tokens, output_tokens, latency_ms)
    VALUES (?, ?, ?, ?, ?, ?) RETURNING id
  `).get("openai-codex", "gpt-recovery", "error", 12, 0, 5);
  await new Promise((resolve, reject) => {
    clientContextMiddleware({ headers: {}, socket: { remoteAddress: "127.0.0.1" } }, {}, () => {
      try {
        const context = getClientContext();
        context.routingDiagnosticsRequestIds = [recoveryRow.id];
        context.routingDiagnostics = {
          version: 1,
          attempts: [{
            platform: "openai-codex",
            modelId: "gpt-recovery",
            relaySourceId: null,
            relaySourceName: null,
            relayApiKeyId: null,
            relayKeyLabel: null,
            errorClass: "upstream_error",
          }],
          finalRoute: null,
          fallbackOccurred: true,
          outcome: "exhausted",
          switchBlockedReason: null,
        };
        markExhaustedRequestRoutingRecovered();
        const stored = JSON.parse(getDb().prepare(
          "SELECT routing_diagnostics FROM requests WHERE id = ?",
        ).get(recoveryRow.id).routing_diagnostics);
        if (stored.outcome !== "succeeded" || stored.fallbackOccurred !== true) {
          throw new Error(`local compaction recovery failed: ${JSON.stringify(stored)}`);
        }
        if ("hideFromUserHistory" in stored || "userVisibleRequestId" in stored) {
          throw new Error("pending request visibility fields leaked into release");
        }
        resolve();
      } catch (error) {
        reject(error);
      }
    });
  });
  const admin = createUser("relay-deploy-admin@example.test", "password123");
  const target = createUser("relay-deploy-target@example.test", "password123");
  const key = createConsumerApiKey(getDb(), target.userId, "relay deploy test").record;
  const insert = getDb().prepare(`
    INSERT INTO requests (
      platform, model_id, status, consumer_user_id, consumer_api_key_id,
      client_ip, client_user_agent, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const timestamp = new Date().toISOString().slice(0, 19).replace("T", " ");
  for (let index = 0; index < 20; index += 1) {
    insert.run(
      "openai-codex",
      `gpt-relay-${index % 4}`,
      "success",
      target.userId,
      key.id,
      "203.0.113.10",
      "New-API/0.9",
      timestamp,
    );
  }
  const app = createApp();
  const server = await new Promise((resolve) => {
    const running = app.listen(0, "127.0.0.1", () => resolve(running));
  });
  const port = server.address().port;
  const call = (path, token) => fetch(`http://127.0.0.1:${port}${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const adminToken = createSession(admin.userId);
  for (const window of ["24h", "7d"]) {
    const response = await call(`/api/admin/users/relay-signals?window=${window}`, adminToken);
    const body = await response.json();
    const relay = body.signals?.find((entry) => entry.userId === target.userId);
    if (response.status !== 200 || body.window !== window || body.minimumSamples !== 20 || relay?.level !== "high") {
      throw new Error(`admin relay route failed for ${window}`);
    }
  }
  const forbidden = await call("/api/admin/users/relay-signals?window=24h", createSession(target.userId));
  if (forbidden.status !== 403) throw new Error(`non-admin status ${forbidden.status}`);
  await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  console.log("isolated_admin_route_check=ok");
'

# Query the live schema read-only through the candidate image before switching.
docker run --rm \
  --volume "$DATA_VOLUME:/app/server/data:ro" \
  --entrypoint node \
  "$NEW_IMAGE" \
  --input-type=module -e '
    import Database from "better-sqlite3";
    import { listRelayDetectionSignals } from "/app/server/dist/services/relay-detection.js";
    const db = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
    const signals24h = listRelayDetectionSignals(db, "24h");
    const signals7d = listRelayDetectionSignals(db, "7d");
    if (!Array.isArray(signals24h) || !Array.isArray(signals7d)) throw new Error("live relay query failed");
    if (signals24h.some((entry) => !Number.isSafeInteger(entry.userId))) throw new Error("invalid relay owner");
    db.close();
    console.log(`candidate_live_query=ok 24h=${signals24h.length} 7d=${signals7d.length}`);
  '

# Refuse to switch if another release changed production while this image built.
assert_live_baseline

SWITCH_STARTED=0
rollback() {
  local code=$?
  set +e
  if [ "$SWITCH_STARTED" -eq 1 ]; then
    cp -a "$BACKUP_DIR/docker-compose.yml.before" "$COMPOSE_FILE"
    chmod 0600 "$COMPOSE_FILE"
    docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"
    for _ in $(seq 1 30); do
      if docker exec "$CONTAINER" node -e '
        fetch("http://127.0.0.1:3001/api/ping")
          .then(async response => {
            const body = await response.json();
            if (!response.ok || body.status !== "ok") process.exit(1);
          })
          .catch(() => process.exit(1));
      ' >/dev/null 2>&1; then
        break
      fi
      sleep 2
    done
    echo "deployment_result=rolled_back" >&2
  fi
  exit "$code"
}
trap rollback ERR

SWITCH_STARTED=1
python3 - "$COMPOSE_FILE" "$NEW_IMAGE" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
image = sys.argv[2]
lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
inside = False
replaced = False
for index, line in enumerate(lines):
    if line.startswith("  freellmapi:"):
        inside = True
        continue
    if inside and line.startswith("  ") and not line.startswith("    ") and line.strip():
        break
    if inside and line.startswith("    image:"):
        newline = "\n" if line.endswith("\n") else ""
        lines[index] = f"    image: {image}{newline}"
        replaced = True
        break
if not replaced:
    raise SystemExit("freellmapi image entry not found")
temporary = path.with_suffix(path.suffix + ".codex-new")
temporary.write_text("".join(lines), encoding="utf-8")
temporary.chmod(0o600)
temporary.replace(path)
PY

docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config -q
docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"

HEALTH_OK=0
for _ in $(seq 1 60); do
  STATUS="$(docker inspect --format '{{.State.Status}}' "$CONTAINER" 2>/dev/null || true)"
  HEALTH="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER" 2>/dev/null || true)"
  if [ "$STATUS" = "running" ] && { [ "$HEALTH" = "healthy" ] || [ "$HEALTH" = "none" ]; }; then
    if docker exec "$CONTAINER" node -e '
      fetch("http://127.0.0.1:3001/api/ping")
        .then(async response => {
          const body = await response.json();
          if (!response.ok || body.status !== "ok") process.exit(1);
        })
        .catch(() => process.exit(1));
    ' >/dev/null 2>&1; then
      HEALTH_OK=1
      break
    fi
  fi
  if [ "$STATUS" = "exited" ] || [ "$STATUS" = "dead" ]; then
    break
  fi
  sleep 2
done
test "$HEALTH_OK" -eq 1

test "$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")" = "$NEW_IMAGE"
test "$(docker inspect --format '{{.Image}}' "$CONTAINER")" = "$NEW_IMAGE_ID"
test "$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER")" != "unhealthy"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$NEW_IMAGE")" = "$RELEASE_LABEL"

docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  import { listRelayDetectionSignals } from "/app/server/dist/services/relay-detection.js";
  const db = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  const quickCheck = db.pragma("quick_check", { simple: true });
  if (quickCheck !== "ok") throw new Error(`live quick_check failed: ${quickCheck}`);
  const signals24h = listRelayDetectionSignals(db, "24h");
  const signals7d = listRelayDetectionSignals(db, "7d");
  db.close();
  if (!Array.isArray(signals24h) || !Array.isArray(signals7d)) throw new Error("live relay query failed");
  console.log(`live_database_and_relay_query=ok 24h=${signals24h.length} 7d=${signals7d.length}`);
'

docker exec "$CONTAINER" sh -lc "
  set -eu
  echo '93e69abf282187df90522d3e12b0e61f67300a145f6949713bc72e51b0fffeed  /app/server/dist/lib/compute-points-response.js' | sha256sum -c -
  echo 'e00086ca728afbfb58964678ec18dfaaa7793617d651a097fdc3e19bdf65b1c1  /app/server/dist/lib/request-log.js' | sha256sum -c -
  echo '7af222fd88265528dc7fe8620af4ef3dc73c6a13d061c40dd4dd73cd4c16dbc7  /app/server/dist/routes/admin-users.js' | sha256sum -c -
  echo '70f179854dd3fe6987b7b501743c8495a1bc1163bdb33d642c440d138a9e209e  /app/server/dist/routes/responses.js' | sha256sum -c -
  echo '3e7181ff57c624411d94411a6848ad3b1e5766390ed9ad86b583d6f1b5c09f48  /app/server/dist/services/relay-detection.js' | sha256sum -c -
  echo '4a8a6f4d9fbcde88ed62bfac6127c10750b30029ccff0f7cdc8d134693c15734  /app/client/dist/index.html' | sha256sum -c -
  echo 'b96a89be4aa95a6d8fe85d08568725b4d3c9e7aa04fe010492ae8574c0bd6503  /app/client/dist/assets/$CLIENT_JS' | sha256sum -c -
  echo '73de455c265aa18654a1d974220cee44b1688870c5e5cd9a2bc4b6794a0de0a0  /app/client/dist/assets/$CLIENT_CSS' | sha256sum -c -
  grep -q 'A balance error is request-local too' /app/server/dist/lib/fallback-loop.js
  grep -q 'installComputePointUsageResponse' /app/server/dist/middleware/consumerQuota.js
  grep -q 'ensureConsumerNativeUsage' /app/server/dist/routes/responses.js
  grep -q 'markExhaustedRequestRoutingRecovered' /app/server/dist/lib/request-log.js
  grep -q 'markExhaustedRequestRoutingRecovered();' /app/server/dist/routes/responses.js
  grep -q 'listRelayDetectionSignals' /app/server/dist/routes/admin-users.js
  ! grep -q 'X-Tuoke-Usage-Unit' /app/server/dist/lib/compute-points-response.js
  ! grep -q 'CODEX_RELAY_MODEL_OUT_OF_CREDITS_COOLDOWN_MS' /app/server/dist/services/codex-relay-sources.js
"

PUBLIC_OK=0
for _ in $(seq 1 30); do
  if docker exec "$CONTAINER" node -e "
    Promise.all([
      fetch('$PUBLIC_ORIGIN/api/ping', { cache: 'no-store' }).then(async response => {
        const body = await response.json();
        if (!response.ok || body.status !== 'ok') throw new Error('public ping failed');
      }),
      fetch('$PUBLIC_ORIGIN/', { cache: 'no-store' }).then(async response => {
        const html = await response.text();
        if (!response.ok || !html.includes('/assets/$CLIENT_JS') || !html.includes('/assets/$CLIENT_CSS')) {
          throw new Error('public client assets are stale');
        }
      }),
      fetch('$PUBLIC_ORIGIN/assets/$CLIENT_JS', { cache: 'no-store' }).then(response => {
        if (!response.ok) throw new Error('public client JavaScript failed');
      }),
      fetch('$PUBLIC_ORIGIN/assets/$CLIENT_CSS', { cache: 'no-store' }).then(response => {
        if (!response.ok) throw new Error('public client CSS failed');
      }),
    ]).catch(() => process.exit(1));
  " >/dev/null 2>&1; then
    PUBLIC_OK=1
    break
  fi
  sleep 2
done
test "$PUBLIC_OK" -eq 1

test "$(docker inspect --format '{{.RestartCount}}' "$CONTAINER")" = "0"

SWITCH_STARTED=0
trap - ERR
echo "deployment_result=ok"
echo "deployment_mode=verified_relay_detection_combined_overlay"
echo "backup_dir=$BACKUP_DIR"
echo "previous_image=$OLD_IMAGE"
echo "previous_image_id=$OLD_IMAGE_ID"
echo "new_image=$NEW_IMAGE"
echo "new_image_id=$NEW_IMAGE_ID"
