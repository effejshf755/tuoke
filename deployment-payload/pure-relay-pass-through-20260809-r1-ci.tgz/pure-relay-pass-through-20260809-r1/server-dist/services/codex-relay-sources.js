import { decrypt, encrypt, maskKey } from '../lib/crypto.js';
import { sanitizeProviderErrorMessage } from '../lib/error-redaction.js';
import { isKeyAuthError } from '../lib/error-classify.js';
import { proxyFetch } from '../lib/proxy.js';
import { providerHttpError, UPSTREAM_HEADER_TIMEOUT_CODE } from '../providers/base.js';
import { CODEX_RELAY_COMPATIBILITY_SUITE_VERSION } from './codex-relay-compatibility.js';
export const CODEX_RELAY_PROTOCOLS = ['chat_completions', 'responses'];
export const CODEX_RELAY_MODEL_OUT_OF_CREDITS_COOLDOWN_MS = 24 * 60 * 60 * 1000;
const CODEX_RELAY_HEALTH_TIMEOUT_MS = 60_000;
const CODEX_RELAY_RETRY_TIMEOUT_MS = 30_000;
const CODEX_RELAY_ABORT_RETRIES = 1;
const SOURCE_SELECT = `
  SELECT
    s.id,
    s.api_key_id,
    s.name,
    COALESCE(NULLIF(TRIM(s.base_url), ''), k.base_url) AS base_url,
    s.codex_group_id,
    (SELECT name FROM codex_groups g WHERE g.id = s.codex_group_id) AS codex_group_name,
    s.protocol,
    s.enabled,
    s.priority,
    s.status,
    s.last_used_at,
    s.last_checked_at,
    s.last_error,
    s.failure_count,
    s.cooldown_until,
    s.balance,
    s.balance_currency,
    s.balance_synced_at,
    s.compatibility_status,
    s.compatibility_needs_retest,
    s.compatibility_checked_at,
    s.compatibility_report,
    s.created_at,
    s.updated_at,
    k.encrypted_key,
    k.iv,
    k.auth_tag
  FROM codex_relay_sources s
  JOIN api_keys k ON k.id = s.api_key_id
  WHERE k.role = 'codex_relay'
`;
function sourceModelsById(db) {
    const rows = db.prepare(`
    SELECT source_id, public_model_id, upstream_model_id, enabled, supports_tools, supports_vision,
           prompt_cache_status, prompt_cache_checked_at, prompt_cache_report,
           runtime_status, runtime_consecutive_failures, runtime_cooldown_until,
           runtime_last_error, runtime_last_failure_at, runtime_last_success_at
    FROM codex_relay_source_models
    ORDER BY source_id ASC, public_model_id ASC
  `).all();
    const models = new Map();
    for (const row of rows) {
        const mapped = models.get(row.source_id) ?? [];
        mapped.push({
            sourceId: row.source_id,
            publicModelId: row.public_model_id,
            upstreamModelId: row.upstream_model_id,
            enabled: row.enabled === 1,
            supportsTools: row.supports_tools === 1,
            supportsVision: row.supports_vision === 1,
            promptCacheStatus: row.prompt_cache_status,
            promptCacheCheckedAt: row.prompt_cache_checked_at,
            promptCacheReport: parsePromptCacheReport(row.prompt_cache_report),
            runtimeStatus: row.runtime_status,
            runtimeConsecutiveFailures: row.runtime_consecutive_failures,
            runtimeCooldownUntil: row.runtime_cooldown_until,
            runtimeLastError: row.runtime_last_error,
            runtimeLastFailureAt: row.runtime_last_failure_at,
            runtimeLastSuccessAt: row.runtime_last_success_at,
        });
        models.set(row.source_id, mapped);
    }
    return models;
}
function sourceKeysById(db) {
    const rows = db.prepare(`
    SELECT
      sk.source_id, sk.api_key_id, sk.label, sk.priority, sk.enabled,
      k.enabled AS vault_enabled, sk.status,
      sk.last_used_at, sk.last_checked_at, sk.last_error, sk.failure_count,
      sk.cooldown_until, sk.balance, sk.balance_currency, sk.balance_synced_at,
      sk.credential_revision, sk.compatibility_status, sk.compatibility_needs_retest,
      sk.compatibility_checked_at, sk.compatibility_report,
      sk.created_at, sk.updated_at,
      k.encrypted_key, k.iv, k.auth_tag
    FROM codex_relay_source_keys sk
    JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
    ORDER BY sk.source_id ASC, sk.priority ASC,
             COALESCE(sk.last_used_at, '1970-01-01') ASC, sk.api_key_id ASC
  `).all();
    const keys = new Map();
    for (const row of rows) {
        const sourceKeys = keys.get(row.source_id) ?? [];
        const compatibility = keyCompatibilityPresentation(row);
        sourceKeys.push({
            sourceId: row.source_id,
            apiKeyId: row.api_key_id,
            label: row.label,
            maskedKey: safelyMaskKey(row),
            priority: row.priority,
            enabled: row.enabled === 1 && row.vault_enabled === 1,
            status: row.status,
            lastUsedAt: row.last_used_at,
            lastCheckedAt: row.last_checked_at,
            lastError: row.last_error,
            failureCount: row.failure_count,
            cooldownUntil: row.cooldown_until,
            balance: row.balance == null ? null : Number(row.balance),
            balanceCurrency: row.balance_currency,
            balanceSyncedAt: row.balance_synced_at,
            credentialRevision: row.credential_revision,
            compatibilityStatus: compatibility.status,
            compatibilityCheckedAt: row.compatibility_checked_at,
            compatibilityReport: compatibility.report,
            compatibilityCurrent: compatibility.current,
            compatibilityStaleReason: compatibility.staleReason,
            createdAt: row.created_at,
            updatedAt: row.updated_at,
        });
        keys.set(row.source_id, sourceKeys);
    }
    return keys;
}
function parsePromptCacheReport(value) {
    if (!value)
        return null;
    try {
        const parsed = JSON.parse(value);
        return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
            ? parsed
            : null;
    }
    catch {
        return null;
    }
}
function safelyMaskKey(row) {
    try {
        return maskKey(decrypt(row.encrypted_key, row.iv, row.auth_tag));
    }
    catch {
        return '[decrypt failed]';
    }
}
function parseCompatibilityReport(value) {
    if (!value)
        return null;
    try {
        const parsed = JSON.parse(value);
        if (parsed.version !== 2
            || parsed.suite_version !== CODEX_RELAY_COMPATIBILITY_SUITE_VERSION
            || parsed.protocol !== 'responses'
            || !Number.isSafeInteger(parsed.api_key_id)
            || Number(parsed.api_key_id) <= 0
            || !Number.isSafeInteger(parsed.api_key_credential_revision)
            || Number(parsed.api_key_credential_revision) < 0
            || typeof parsed.masked_key !== 'string'
            || !Array.isArray(parsed.stages)
            || !['needs_retest', 'compatible', 'partial', 'incompatible'].includes(String(parsed.overall_status))) {
            return null;
        }
        return parsed;
    }
    catch {
        return null;
    }
}
function compatibilityPresentation(row, keys) {
    if (!row.compatibility_report) {
        return {
            status: 'untested',
            report: null,
            current: false,
            staleReason: null,
        };
    }
    const report = parseCompatibilityReport(row.compatibility_report);
    if (!report) {
        return {
            status: 'untested',
            report: null,
            current: false,
            staleReason: 'test_suite_updated',
        };
    }
    const testedKey = keys.find((key) => key.apiKeyId === report.api_key_id);
    if (!testedKey || testedKey.credentialRevision !== report.api_key_credential_revision) {
        return {
            status: 'untested',
            report: null,
            current: false,
            staleReason: 'tested_key_changed',
        };
    }
    return {
        status: row.compatibility_needs_retest === 1 || report.overall_status === 'needs_retest'
            ? 'needs_retest'
            : row.compatibility_status,
        report,
        current: true,
        staleReason: null,
    };
}
function keyCompatibilityPresentation(row) {
    if (!row.compatibility_report) {
        return { status: 'untested', report: null, current: false, staleReason: null };
    }
    const report = parseCompatibilityReport(row.compatibility_report);
    if (!report) {
        return {
            status: 'untested',
            report: null,
            current: false,
            staleReason: 'test_suite_updated',
        };
    }
    if (report.api_key_id !== row.api_key_id
        || report.api_key_credential_revision !== row.credential_revision) {
        return {
            status: 'untested',
            report: null,
            current: false,
            staleReason: 'tested_key_changed',
        };
    }
    return {
        status: row.compatibility_needs_retest === 1 || report.overall_status === 'needs_retest'
            ? 'needs_retest'
            : row.compatibility_status,
        report,
        current: true,
        staleReason: null,
    };
}
function toPublicSource(row, models, keys) {
    const now = Date.now();
    const availableKeys = keys.filter((key) => {
        if (!key.enabled || !['healthy', 'unknown'].includes(key.status))
            return false;
        if (!key.cooldownUntil)
            return true;
        const cooldown = Date.parse(key.cooldownUntil);
        return !Number.isFinite(cooldown) || cooldown <= now;
    });
    const compatibility = compatibilityPresentation(row, keys);
    return {
        id: row.id,
        kind: 'codex_relay',
        apiKeyId: row.api_key_id,
        name: row.name,
        baseUrl: row.base_url,
        maskedKey: safelyMaskKey(row),
        codexGroupId: row.codex_group_id,
        codexGroupName: row.codex_group_name,
        protocol: row.protocol,
        enabled: row.enabled === 1,
        priority: row.priority,
        status: row.status,
        lastUsedAt: row.last_used_at,
        lastCheckedAt: row.last_checked_at,
        lastError: row.last_error,
        failureCount: row.failure_count,
        cooldownUntil: row.cooldown_until,
        balance: row.balance == null ? null : Number(row.balance),
        balanceCurrency: row.balance_currency,
        balanceSyncedAt: row.balance_synced_at,
        compatibilityStatus: compatibility.status,
        compatibilityCheckedAt: row.compatibility_checked_at,
        compatibilityReport: compatibility.report,
        compatibilityCurrent: compatibility.current,
        compatibilityStaleReason: compatibility.staleReason,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
        modelMappings: models,
        keys,
        keySummary: {
            total: keys.length,
            enabled: keys.filter((key) => key.enabled).length,
            healthy: keys.filter((key) => key.status === 'healthy').length,
            available: availableKeys.length,
        },
    };
}
export function listCodexRelaySources(db) {
    const rows = db.prepare(`${SOURCE_SELECT} ORDER BY s.priority ASC, s.id ASC`).all();
    const models = sourceModelsById(db);
    const keys = sourceKeysById(db);
    return rows.map((row) => toPublicSource(row, models.get(row.id) ?? [], keys.get(row.id) ?? []));
}
export function getCodexRelaySource(db, id) {
    const row = db.prepare(`${SOURCE_SELECT} AND s.id = ?`).get(id);
    if (!row)
        return null;
    return toPublicSource(row, sourceModelsById(db).get(row.id) ?? [], sourceKeysById(db).get(row.id) ?? []);
}
function assertEnabledCodexGroup(db, groupId) {
    if (groupId == null)
        throw new Error('A Codex relay source must be bound to an enabled Codex group');
    const group = db.prepare('SELECT 1 FROM codex_groups WHERE id = ? AND enabled = 1').get(groupId);
    if (!group)
        throw new Error('Codex group not found or disabled');
}
function assertDispatchableProtocol(protocol) {
    if (!CODEX_RELAY_PROTOCOLS.includes(protocol)) {
        throw new Error(`Unsupported Codex relay protocol: ${protocol}`);
    }
}
function assertModelMappings(mappings, allowEmpty = false) {
    if (!allowEmpty && mappings.length === 0)
        throw new Error('At least one relay model mapping is required');
    const seen = new Set();
    for (const mapping of mappings) {
        if (!mapping.publicModelId || !mapping.upstreamModelId) {
            throw new Error('Relay model mapping ids are required');
        }
        if (seen.has(mapping.publicModelId)) {
            throw new Error(`Duplicate public model mapping: ${mapping.publicModelId}`);
        }
        seen.add(mapping.publicModelId);
    }
}
function sameModelMappings(existing, requested) {
    if (existing.length !== requested.length)
        return false;
    const signature = (mapping) => JSON.stringify({
        publicModelId: mapping.publicModelId,
        upstreamModelId: mapping.upstreamModelId,
        enabled: mapping.enabled,
        supportsTools: mapping.supportsTools,
        supportsVision: mapping.supportsVision,
    });
    const existingSignatures = existing.map(signature).sort();
    const requestedSignatures = requested.map(signature).sort();
    return existingSignatures.every((value, index) => value === requestedSignatures[index]);
}
function assertLiveModelMappings(db, codexGroupId, mappings) {
    if (codexGroupId == null) {
        throw new Error('A live Codex relay mapping must be bound to an enabled Codex group');
    }
    db.transaction(() => {
        const liveMappings = mappings.filter((candidate) => candidate.enabled);
        for (const mapping of liveMappings) {
            // A relay can be the first upstream that introduces a Codex model. Treat
            // the administrator-confirmed public mapping as a catalog declaration,
            // just like OAuth model discovery does, instead of requiring an OAuth
            // account to have discovered the model first.
            db.prepare(`
        INSERT OR IGNORE INTO models (
          platform, model_id, display_name, intelligence_rank, speed_rank,
          size_label, monthly_token_budget, enabled, supports_vision, supports_tools
        ) VALUES ('openai-codex', ?, ?, 50, 50, '', '', 1, ?, ?)
      `).run(mapping.publicModelId, mapping.publicModelId, mapping.supportsVision ? 1 : 0, mapping.supportsTools ? 1 : 0);
            // Catalog capabilities are an aggregate gate: if any confirmed live
            // relay mapping can serve tools or vision, the public model must not be
            // filtered out before per-source routing runs. Keep this monotonic so an
            // edit cannot erase capabilities supplied by OAuth or a sibling relay.
            db.prepare(`
        UPDATE models
        SET supports_vision = MAX(supports_vision, ?),
            supports_tools = MAX(supports_tools, ?)
        WHERE platform = 'openai-codex'
          AND model_id = ?
      `).run(mapping.supportsVision ? 1 : 0, mapping.supportsTools ? 1 : 0, mapping.publicModelId);
            db.prepare(`
        INSERT OR IGNORE INTO model_billing_rules (
          platform, model_id, input_price_micro_per_million,
          output_price_micro_per_million, multiplier_milli, billing_enabled
        ) VALUES ('openai-codex', ?, 0, 0, 1000, 1)
      `).run(mapping.publicModelId);
            const catalogModel = db.prepare(`
        SELECT 1
        FROM models m
        JOIN model_billing_rules b
          ON b.platform = m.platform
         AND b.model_id = m.model_id
        WHERE m.platform = 'openai-codex'
          AND m.model_id = ?
          AND m.enabled = 1
          AND b.billing_enabled = 1
        LIMIT 1
      `).get(mapping.publicModelId);
            if (!catalogModel) {
                throw new Error(`Relay public model is disabled in the Codex catalog or billing table: ${mapping.publicModelId}`);
            }
            // Selecting the group while confirming a live mapping is the explicit
            // binding action. It also lets a fresh installation create an empty
            // group and introduce its first Codex capability without OAuth.
            db.prepare(`
        INSERT INTO codex_group_models (
          group_id, model_id, multiplier_milli_override
        )
        SELECT id, ?, multiplier_milli
        FROM codex_groups
        WHERE id = ?
        ON CONFLICT(group_id, model_id) DO NOTHING
      `).run(mapping.publicModelId, codexGroupId);
        }
    })();
}
function replaceCodexRelaySourceModels(db, sourceId, mappings, allowEmpty = false) {
    assertModelMappings(mappings, allowEmpty);
    const existingByPublicModel = new Map((sourceModelsById(db).get(sourceId) ?? []).map((mapping) => [mapping.publicModelId, mapping]));
    db.prepare('DELETE FROM codex_relay_source_models WHERE source_id = ?').run(sourceId);
    const insert = db.prepare(`
    INSERT INTO codex_relay_source_models (
      source_id, public_model_id, upstream_model_id, enabled, supports_tools, supports_vision,
      prompt_cache_status, prompt_cache_checked_at, prompt_cache_report,
      runtime_status, runtime_consecutive_failures, runtime_cooldown_until,
      runtime_last_error, runtime_last_failure_at, runtime_last_success_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
    for (const mapping of mappings) {
        const existing = existingByPublicModel.get(mapping.publicModelId);
        const preserveCertification = existing?.upstreamModelId === mapping.upstreamModelId;
        const preserveRuntime = preserveCertification && existing?.enabled === mapping.enabled;
        insert.run(sourceId, mapping.publicModelId, mapping.upstreamModelId, mapping.enabled ? 1 : 0, mapping.supportsTools ? 1 : 0, mapping.supportsVision ? 1 : 0, preserveCertification ? existing.promptCacheStatus : 'untested', preserveCertification ? existing.promptCacheCheckedAt : null, preserveCertification && existing.promptCacheReport != null
            ? JSON.stringify(existing.promptCacheReport)
            : null, preserveRuntime ? existing.runtimeStatus : 'unknown', preserveRuntime ? existing.runtimeConsecutiveFailures : 0, preserveRuntime ? existing.runtimeCooldownUntil : null, preserveRuntime ? existing.runtimeLastError : null, preserveRuntime ? existing.runtimeLastFailureAt : null, preserveRuntime ? existing.runtimeLastSuccessAt : null);
    }
}
function recomputeCodexRelaySourceStatus(db, sourceId) {
    const keys = db.prepare(`
    SELECT sk.enabled, k.enabled AS vault_enabled, sk.status, sk.last_used_at, sk.last_checked_at, sk.last_error,
           sk.failure_count, sk.cooldown_until, sk.balance, sk.balance_currency, sk.balance_synced_at
    FROM codex_relay_source_keys sk
    JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
    WHERE sk.source_id = ?
    ORDER BY sk.updated_at DESC, sk.api_key_id ASC
  `).all(sourceId);
    if (keys.length === 0)
        return;
    const enabled = keys.filter((key) => key.enabled === 1 && key.vault_enabled === 1);
    const status = enabled.some((key) => key.status === 'healthy')
        ? 'healthy'
        : enabled.some((key) => key.status === 'unknown')
            ? 'unknown'
            : enabled.length > 0 && enabled.every((key) => key.status === 'invalid')
                ? 'invalid'
                : enabled.length > 0
                    ? 'unhealthy'
                    : 'unknown';
    const latest = (values) => {
        const present = values.filter((value) => Boolean(value)).sort();
        return present.at(-1) ?? null;
    };
    const now = Date.now();
    const anyAvailable = enabled.some((key) => {
        if (!['healthy', 'unknown'].includes(key.status))
            return false;
        if (!key.cooldown_until)
            return true;
        const parsed = Date.parse(key.cooldown_until);
        return !Number.isFinite(parsed) || parsed <= now;
    });
    const futureCooldowns = enabled
        .map((key) => key.cooldown_until)
        .filter((value) => Boolean(value))
        .sort();
    const primary = keys[0];
    db.prepare(`
    UPDATE codex_relay_sources
    SET status = ?,
        last_used_at = ?,
        last_checked_at = ?,
        last_error = ?,
        failure_count = ?,
        cooldown_until = ?,
        balance = ?,
        balance_currency = ?,
        balance_synced_at = ?,
        updated_at = datetime('now')
    WHERE id = ?
  `).run(status, latest(keys.map((key) => key.last_used_at)), latest(keys.map((key) => key.last_checked_at)), keys.find((key) => key.last_error)?.last_error ?? null, keys.reduce((sum, key) => sum + Math.max(0, key.failure_count), 0), anyAvailable ? null : futureCooldowns[0] ?? null, primary.balance, primary.balance_currency, primary.balance_synced_at, sourceId);
}
export function createCodexRelaySource(db, input) {
    assertEnabledCodexGroup(db, input.codexGroupId);
    assertDispatchableProtocol(input.protocol);
    assertModelMappings(input.modelMappings, !input.enabled);
    if (input.enabled && !input.modelMappings.some((mapping) => mapping.enabled)) {
        throw new Error('An enabled Codex relay source requires an enabled model mapping');
    }
    if (input.enabled) {
        assertLiveModelMappings(db, input.codexGroupId, input.modelMappings);
    }
    const sourceId = db.transaction(() => {
        const secret = encrypt(input.apiKey);
        const apiKeyId = Number(db.prepare(`
      INSERT INTO api_keys (
        platform, role, label, encrypted_key, iv, auth_tag, status, enabled, base_url
      ) VALUES ('custom', 'codex_relay', ?, ?, ?, ?, 'unknown', ?, ?)
    `).run(input.name, secret.encrypted, secret.iv, secret.authTag, 1, input.baseUrl).lastInsertRowid);
        const result = db.prepare(`
      INSERT INTO codex_relay_sources (
        api_key_id, name, base_url, codex_group_id, protocol, enabled, priority,
        statistics_started_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, CASE WHEN ? = 1 THEN datetime('now') ELSE NULL END)
    `).run(apiKeyId, input.name, input.baseUrl, input.codexGroupId, input.protocol, input.enabled ? 1 : 0, input.priority, input.enabled ? 1 : 0);
        const id = Number(result.lastInsertRowid);
        db.prepare(`
      INSERT INTO codex_relay_source_keys (
        source_id, api_key_id, label, priority, enabled, status
      ) VALUES (?, ?, ?, 100, 1, 'unknown')
    `).run(id, apiKeyId, `${input.name} Key 1`);
        replaceCodexRelaySourceModels(db, id, input.modelMappings, !input.enabled);
        return id;
    })();
    const source = getCodexRelaySource(db, sourceId);
    if (!source)
        throw new Error('Failed to create Codex relay source');
    return source;
}
export function updateCodexRelaySource(db, id, input) {
    const existing = db.prepare(`${SOURCE_SELECT} AND s.id = ?`).get(id);
    if (!existing)
        return null;
    if (input.codexGroupId !== undefined)
        assertEnabledCodexGroup(db, input.codexGroupId);
    const existingMappings = sourceModelsById(db).get(id) ?? [];
    const mappingsChanged = input.modelMappings !== undefined
        && !sameModelMappings(existingMappings, input.modelMappings);
    const sourceConnectionChanged = (input.protocol !== undefined && input.protocol !== existing.protocol)
        || (input.baseUrl !== undefined && input.baseUrl !== existing.base_url);
    const resetHealth = sourceConnectionChanged || mappingsChanged;
    // Health and compatibility results are diagnostics only. Configuration or
    // credential changes invalidate those snapshots, but must not silently take
    // an administrator-enabled relay out of the routing pool.
    const nextEnabled = input.enabled ?? existing.enabled === 1;
    const nextProtocol = input.protocol ?? existing.protocol;
    const nextGroupId = input.codexGroupId === undefined
        ? existing.codex_group_id
        : input.codexGroupId;
    assertDispatchableProtocol(nextProtocol);
    if (input.modelMappings !== undefined) {
        assertModelMappings(input.modelMappings, !nextEnabled);
        if (nextEnabled && !input.modelMappings.some((mapping) => mapping.enabled)) {
            throw new Error('An enabled Codex relay source requires an enabled model mapping');
        }
    }
    else if (nextEnabled) {
        const enabledMapping = db.prepare(`
      SELECT 1 FROM codex_relay_source_models
      WHERE source_id = ? AND enabled = 1
      LIMIT 1
    `).get(id);
        if (!enabledMapping)
            throw new Error('An enabled Codex relay source requires an enabled model mapping');
    }
    if (nextEnabled) {
        assertEnabledCodexGroup(db, nextGroupId);
        const nextMappings = input.modelMappings
            ?? existingMappings;
        assertLiveModelMappings(db, nextGroupId, nextMappings);
    }
    db.transaction(() => {
        const sourceUpdates = [];
        const sourceValues = [];
        const apiKeyUpdates = [];
        const apiKeyValues = [];
        if (input.name !== undefined) {
            sourceUpdates.push('name = ?');
            sourceValues.push(input.name);
        }
        if (input.codexGroupId !== undefined) {
            sourceUpdates.push('codex_group_id = ?');
            sourceValues.push(input.codexGroupId);
        }
        if (input.protocol !== undefined) {
            sourceUpdates.push('protocol = ?');
            sourceValues.push(input.protocol);
        }
        if (input.enabled !== undefined) {
            sourceUpdates.push('enabled = ?');
            sourceValues.push(nextEnabled ? 1 : 0);
            if (nextEnabled && existing.enabled !== 1) {
                sourceUpdates.push("statistics_started_at = COALESCE(statistics_started_at, datetime('now'))");
            }
        }
        if (input.priority !== undefined) {
            sourceUpdates.push('priority = ?');
            sourceValues.push(input.priority);
        }
        if (input.baseUrl !== undefined) {
            sourceUpdates.push('base_url = ?');
            sourceValues.push(input.baseUrl);
        }
        if (input.apiKey !== undefined) {
            const secret = encrypt(input.apiKey);
            apiKeyUpdates.push('encrypted_key = ?', 'iv = ?', 'auth_tag = ?');
            apiKeyValues.push(secret.encrypted, secret.iv, secret.authTag);
            apiKeyUpdates.push("status = 'unknown'", 'last_checked_at = NULL');
            // Keep the previous report as a historical snapshot, but make an
            // in-flight result lose its lease. The credential revision below makes
            // the old report present as stale until an administrator explicitly
            // runs (and pays for) another compatibility test.
            if (!resetHealth) {
                sourceUpdates.push('compatibility_config_revision = compatibility_config_revision + 1');
            }
        }
        if (resetHealth) {
            sourceUpdates.push("status = 'unknown'", 'last_error = NULL', 'last_checked_at = NULL', 'failure_count = 0', 'cooldown_until = NULL', "compatibility_status = 'untested'", 'compatibility_needs_retest = 0', 'compatibility_checked_at = NULL', 'compatibility_report = NULL', 'compatibility_config_revision = compatibility_config_revision + 1');
        }
        if (sourceUpdates.length > 0) {
            sourceUpdates.push("updated_at = datetime('now')");
            db.prepare(`UPDATE codex_relay_sources SET ${sourceUpdates.join(', ')} WHERE id = ?`)
                .run(...sourceValues, id);
        }
        if (apiKeyUpdates.length > 0) {
            db.prepare(`UPDATE api_keys SET ${apiKeyUpdates.join(', ')} WHERE id = ? AND role = 'codex_relay'`)
                .run(...apiKeyValues, existing.api_key_id);
        }
        if (input.baseUrl !== undefined) {
            db.prepare(`
        UPDATE api_keys
        SET base_url = ?
        WHERE role = 'codex_relay'
          AND id IN (
            SELECT api_key_id FROM codex_relay_source_keys WHERE source_id = ?
          )
      `).run(input.baseUrl, id);
        }
        if (input.apiKey !== undefined) {
            db.prepare(`
        UPDATE codex_relay_source_keys
        SET status = 'unknown',
            last_error = NULL,
            last_checked_at = NULL,
            failure_count = 0,
            cooldown_until = NULL,
            credential_revision = credential_revision + 1,
            updated_at = datetime('now')
        WHERE source_id = ? AND api_key_id = ?
      `).run(id, existing.api_key_id);
        }
        if (resetHealth) {
            db.prepare(`
        UPDATE codex_relay_source_keys
        SET status = 'unknown',
            last_error = NULL,
            last_checked_at = NULL,
            failure_count = 0,
            cooldown_until = NULL,
            compatibility_status = 'untested',
            compatibility_needs_retest = 0,
            compatibility_checked_at = NULL,
            compatibility_report = NULL,
            updated_at = datetime('now')
        WHERE source_id = ?
      `).run(id);
            db.prepare(`
        UPDATE api_keys
        SET status = 'unknown', last_checked_at = NULL
        WHERE role = 'codex_relay'
          AND id IN (
            SELECT api_key_id FROM codex_relay_source_keys WHERE source_id = ?
          )
      `).run(id);
        }
        if (input.modelMappings !== undefined) {
            replaceCodexRelaySourceModels(db, id, input.modelMappings, !nextEnabled);
        }
        if (sourceConnectionChanged) {
            db.prepare(`
        UPDATE codex_relay_source_models
        SET prompt_cache_status = 'untested',
            prompt_cache_checked_at = NULL,
            prompt_cache_report = NULL,
            runtime_status = 'unknown',
            runtime_consecutive_failures = 0,
            runtime_cooldown_until = NULL,
            runtime_last_error = NULL,
            runtime_last_failure_at = NULL,
            runtime_last_success_at = NULL,
            updated_at = datetime('now')
        WHERE source_id = ?
      `).run(id);
        }
    })();
    recomputeCodexRelaySourceStatus(db, id);
    return getCodexRelaySource(db, id);
}
export function deleteCodexRelaySource(db, id) {
    return db.transaction(() => {
        const source = db.prepare(`${SOURCE_SELECT} AND s.id = ?`).get(id);
        if (!source)
            return false;
        const keyIds = db.prepare(`
      SELECT api_key_id FROM codex_relay_source_keys WHERE source_id = ?
    `).all(id).map((row) => row.api_key_id);
        db.prepare('DELETE FROM codex_relay_sources WHERE id = ?').run(id);
        const removeKey = db.prepare("DELETE FROM api_keys WHERE id = ? AND role = 'codex_relay'");
        for (const keyId of keyIds)
            removeKey.run(keyId);
        return true;
    })();
}
export function createCodexRelaySourceKey(db, sourceId, input) {
    const source = db.prepare(`${SOURCE_SELECT} AND s.id = ?`).get(sourceId);
    if (!source)
        return null;
    const count = db.prepare(`
    SELECT COUNT(*) AS count FROM codex_relay_source_keys WHERE source_id = ?
  `).get(sourceId);
    db.transaction(() => {
        const secret = encrypt(input.apiKey);
        const label = input.label?.trim() || `${source.name} Key ${count.count + 1}`;
        const apiKeyId = Number(db.prepare(`
      INSERT INTO api_keys (
        platform, role, label, encrypted_key, iv, auth_tag, status, enabled, base_url
      ) VALUES ('custom', 'codex_relay', ?, ?, ?, ?, 'unknown', 1, ?)
    `).run(label, secret.encrypted, secret.iv, secret.authTag, source.base_url).lastInsertRowid);
        db.prepare(`
      INSERT INTO codex_relay_source_keys (
        source_id, api_key_id, label, priority, enabled, status
      ) VALUES (?, ?, ?, ?, 1, 'unknown')
    `).run(sourceId, apiKeyId, label, input.priority ?? 100);
    })();
    recomputeCodexRelaySourceStatus(db, sourceId);
    return getCodexRelaySource(db, sourceId);
}
export function updateCodexRelaySourceKey(db, sourceId, apiKeyId, input) {
    const existing = db.prepare(`
    SELECT sk.status
    FROM codex_relay_source_keys sk
    JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
    WHERE sk.source_id = ? AND sk.api_key_id = ?
  `).get(sourceId, apiKeyId);
    if (!existing)
        return null;
    db.transaction(() => {
        const updates = [];
        const values = [];
        if (input.label !== undefined) {
            updates.push('label = ?');
            values.push(input.label);
            db.prepare(`UPDATE api_keys SET label = ? WHERE id = ? AND role = 'codex_relay'`)
                .run(input.label, apiKeyId);
        }
        if (input.enabled !== undefined) {
            updates.push('enabled = ?');
            values.push(input.enabled ? 1 : 0);
            db.prepare(`UPDATE api_keys SET enabled = ? WHERE id = ? AND role = 'codex_relay'`)
                .run(input.enabled ? 1 : 0, apiKeyId);
        }
        if (input.priority !== undefined) {
            updates.push('priority = ?');
            values.push(input.priority);
        }
        if (updates.length > 0) {
            updates.push("updated_at = datetime('now')");
            db.prepare(`
        UPDATE codex_relay_source_keys
        SET ${updates.join(', ')}
        WHERE source_id = ? AND api_key_id = ?
      `).run(...values, sourceId, apiKeyId);
        }
    })();
    recomputeCodexRelaySourceStatus(db, sourceId);
    return getCodexRelaySource(db, sourceId);
}
export function rotateCodexRelaySourceKey(db, sourceId, apiKeyId, apiKey) {
    const linked = db.prepare(`
    SELECT 1 FROM codex_relay_source_keys
    WHERE source_id = ? AND api_key_id = ?
  `).get(sourceId, apiKeyId);
    if (!linked)
        return null;
    const secret = encrypt(apiKey);
    db.transaction(() => {
        db.prepare(`
      UPDATE codex_relay_sources
      SET compatibility_config_revision = compatibility_config_revision + 1,
          updated_at = datetime('now')
      WHERE id = ?
    `).run(sourceId);
        db.prepare(`
      UPDATE api_keys
      SET encrypted_key = ?, iv = ?, auth_tag = ?,
          status = 'unknown', last_checked_at = NULL
      WHERE id = ? AND role = 'codex_relay'
    `).run(secret.encrypted, secret.iv, secret.authTag, apiKeyId);
        db.prepare(`
      UPDATE codex_relay_source_keys
      SET status = 'unknown', last_used_at = NULL,
          last_checked_at = NULL, last_error = NULL, failure_count = 0,
          cooldown_until = NULL, credential_revision = credential_revision + 1,
          updated_at = datetime('now')
      WHERE source_id = ? AND api_key_id = ?
    `).run(sourceId, apiKeyId);
    })();
    recomputeCodexRelaySourceStatus(db, sourceId);
    return getCodexRelaySource(db, sourceId);
}
export function deleteCodexRelaySourceKey(db, sourceId, apiKeyId) {
    const source = db.prepare(`
    SELECT api_key_id FROM codex_relay_sources WHERE id = ?
  `).get(sourceId);
    if (!source)
        return null;
    const keys = db.prepare(`
    SELECT api_key_id FROM codex_relay_source_keys
    WHERE source_id = ? ORDER BY priority ASC, api_key_id ASC
  `).all(sourceId);
    if (!keys.some((key) => key.api_key_id === apiKeyId))
        return null;
    if (keys.length <= 1)
        throw new Error('The last relay API key cannot be deleted; delete the supplier instead');
    const replacement = keys.find((key) => key.api_key_id !== apiKeyId);
    db.transaction(() => {
        if (source.api_key_id === apiKeyId) {
            db.prepare(`
        UPDATE codex_relay_sources SET api_key_id = ?, updated_at = datetime('now') WHERE id = ?
      `).run(replacement.api_key_id, sourceId);
        }
        db.prepare(`
      UPDATE codex_relay_sources
      SET compatibility_config_revision = compatibility_config_revision + 1,
          updated_at = datetime('now')
      WHERE id = ?
    `).run(sourceId);
        db.prepare(`
      DELETE FROM codex_relay_source_keys WHERE source_id = ? AND api_key_id = ?
    `).run(sourceId, apiKeyId);
        db.prepare(`DELETE FROM api_keys WHERE id = ? AND role = 'codex_relay'`).run(apiKeyId);
    })();
    recomputeCodexRelaySourceStatus(db, sourceId);
    return getCodexRelaySource(db, sourceId);
}
/**
 * Finds relay candidates for a Codex-pool consumer only. Supplying a resource
 * subpool key intentionally yields no rows, so this remains safe even if a
 * future caller accidentally invokes it from a resource flow.
 */
export function listEligibleCodexRelayCandidates(db, options) {
    const where = [
        "k.role = 'codex_relay'",
        "k.platform = 'custom'",
        'k.enabled = 1',
        'sk.enabled = 1',
        "sk.status IN ('healthy', 'unknown')",
        "(sk.cooldown_until IS NULL OR datetime(sk.cooldown_until) <= datetime('now'))",
        's.enabled = 1',
        'sm.enabled = 1',
        // Model runtime failures deliberately do not gate later requests. A failed
        // attempt is skipped only inside that request's fallback loop; the next
        // request may try the administrator-enabled mapping again. Credential-wide
        // 401/402 protection remains enforced above through `sk.status` and
        // `sk.cooldown_until`.
        'sm.public_model_id = ?',
        's.codex_group_id IS NOT NULL',
        `EXISTS (
      SELECT 1 FROM codex_groups enabled_group
      WHERE enabled_group.id = s.codex_group_id AND enabled_group.enabled = 1
    )`,
    ];
    const params = [options.modelId];
    if (options.protocol !== undefined) {
        where.push('s.protocol = ?');
        params.push(options.protocol);
    }
    if (options.consumerApiKeyId != null) {
        where.push(`EXISTS (
      SELECT 1
      FROM consumer_api_keys consumer
      WHERE consumer.id = ?
        AND consumer.key_scope = 'codex_pool'
        AND consumer.status = 'active'
        AND consumer.codex_group_id IS NOT NULL
        AND consumer.codex_group_id = s.codex_group_id
        AND EXISTS (
          SELECT 1 FROM codex_group_models group_model
          WHERE group_model.group_id = s.codex_group_id
            AND group_model.model_id = sm.public_model_id
        )
    )`);
        params.push(options.consumerApiKeyId);
    }
    else {
        // Relay capacity is always group-owned and can never act as a global
        // fallback without a scoped consumer key.
        where.push('1 = 0');
    }
    const rows = db.prepare(`
    SELECT
      s.id AS source_id,
      sk.api_key_id,
      s.protocol,
      s.priority,
      sk.priority AS key_priority,
      sk.last_used_at AS key_last_used_at,
      COALESCE(NULLIF(TRIM(s.base_url), ''), k.base_url) AS base_url,
      k.encrypted_key,
      k.iv,
      k.auth_tag,
      sm.public_model_id,
      sm.upstream_model_id,
      sm.supports_tools,
      sm.supports_vision,
      sm.prompt_cache_status,
      sm.prompt_cache_checked_at,
      sm.prompt_cache_report,
      sm.runtime_status,
      sm.runtime_consecutive_failures,
      sm.runtime_cooldown_until,
      sm.runtime_last_error,
      sm.runtime_last_failure_at,
      sm.runtime_last_success_at
    FROM codex_relay_sources s
    JOIN codex_relay_source_keys sk ON sk.source_id = s.id
    JOIN api_keys k ON k.id = sk.api_key_id
    JOIN codex_relay_source_models sm ON sm.source_id = s.id
    WHERE ${where.join('\n      AND ')}
    ORDER BY s.priority ASC, s.id ASC, sk.priority ASC,
             COALESCE(sk.last_used_at, '1970-01-01') ASC, sk.api_key_id ASC,
             sm.public_model_id ASC
  `).all(...params);
    return rows.flatMap((row) => {
        // Compatibility reports and declared feature flags are administrator
        // diagnostics, not dispatch gates. Enabled mappings are tried as configured;
        // the real request determines whether this candidate succeeds, and the
        // request-local fallback loop can then move to another Relay or OAuth.
        // Protocol, group, credential health and affinity constraints remain in the
        // SQL above and in the shared router.
        const source = {
            sourceId: row.source_id,
            apiKeyId: row.api_key_id,
            baseUrl: row.base_url,
            encryptedKey: row.encrypted_key,
            iv: row.iv,
            authTag: row.auth_tag,
        };
        return [{
                sourceId: row.source_id,
                apiKeyId: row.api_key_id,
                baseUrl: row.base_url,
                publicModelId: row.public_model_id,
                upstreamModelId: row.upstream_model_id,
                supportsTools: row.supports_tools === 1,
                supportsVision: row.supports_vision === 1,
                protocol: row.protocol,
                priority: row.priority,
                keyPriority: row.key_priority,
                keyLastUsedAt: row.key_last_used_at,
                promptCacheStatus: row.prompt_cache_status,
                promptCacheCheckedAt: row.prompt_cache_checked_at,
                promptCacheReport: parsePromptCacheReport(row.prompt_cache_report),
                runtimeStatus: row.runtime_status,
                runtimeConsecutiveFailures: row.runtime_consecutive_failures,
                runtimeCooldownUntil: row.runtime_cooldown_until,
                runtimeLastError: row.runtime_last_error,
                runtimeLastFailureAt: row.runtime_last_failure_at,
                runtimeLastSuccessAt: row.runtime_last_success_at,
                source,
            }];
    });
}
export function decryptCodexRelaySourceApiKey(source) {
    return decrypt(source.encryptedKey, source.iv, source.authTag);
}
function relayModelErrorStatus(error) {
    if (!error || typeof error !== 'object')
        return null;
    const candidate = error;
    for (const value of [candidate.status, candidate.statusCode, candidate.response?.status]) {
        const status = Number(value);
        if (Number.isInteger(status) && status >= 100 && status <= 599)
            return status;
    }
    return null;
}
function relayModelErrorSignals(error) {
    const signals = {
        codes: new Set(),
        names: new Set(),
        types: new Set(),
        skipBench: false,
    };
    const seen = new Set();
    let current = error;
    for (let depth = 0; current && typeof current === 'object' && depth < 6; depth += 1) {
        if (seen.has(current))
            break;
        seen.add(current);
        const candidate = current;
        if (typeof candidate.code === 'string')
            signals.codes.add(candidate.code.toLowerCase());
        if (typeof candidate.upstreamCode === 'string')
            signals.codes.add(candidate.upstreamCode.toLowerCase());
        if (typeof candidate.name === 'string')
            signals.names.add(candidate.name.toLowerCase());
        if (typeof candidate.type === 'string')
            signals.types.add(candidate.type.toLowerCase());
        if (typeof candidate.upstreamType === 'string')
            signals.types.add(candidate.upstreamType.toLowerCase());
        if (candidate.skipBench === true)
            signals.skipBench = true;
        current = candidate.cause;
    }
    return signals;
}
export function classifyCodexRelayModelFailure(error) {
    const message = sanitizeProviderErrorMessage(error ?? '').toLowerCase();
    const signals = relayModelErrorSignals(error);
    if (signals.skipBench
        || signals.codes.has('wallet_safety_balance_reached')
        || signals.codes.has('codex_relay_client_abort')
        || signals.names.has('walletsafetybalancereachederror')
        || /(?:client|downstream|user).{0,32}(?:abort|cancel|disconnect|closed|gone)/.test(message)
        || /(?:abort|cancel)(?:led|ed)?.{0,24}(?:by|from) (?:the )?(?:client|user)/.test(message)
        || /client disconnected after stream usage/.test(message)) {
        return 'other';
    }
    if (signals.codes.has('codex_relay_header_timeout')
        || signals.codes.has(UPSTREAM_HEADER_TIMEOUT_CODE)) {
        return 'temporary_unavailable';
    }
    const status = relayModelErrorStatus(error);
    // Runtime HTTP status is authoritative. In particular, several compatible
    // gateways put `insufficient_quota` prose/codes in a 429 or 5xx response.
    // Those are request-local capacity failures; only an actual HTTP 402 is a
    // credential-wide balance signal that may be protected across requests.
    if (status === 402) {
        return 'out_of_credits';
    }
    if (status === 408
        || status === 409
        || status === 429
        || (status != null && status >= 500)) {
        return 'temporary_unavailable';
    }
    // These are deterministic supplier policy outcomes, not capacity or
    // credential failures. Keep the marker narrow: a generic 400/403 can still
    // be a key-tier or request-shape issue, while these codes specifically mean
    // that retrying another key on this same source cannot help.
    if ([
        'sensitive_words_detected',
        'content_policy_violation',
        'content_filter',
        'safety_violation',
        'prompt_blocked',
        'input_blocked',
        'moderation_blocked',
    ].some((code) => signals.codes.has(code) || signals.types.has(code))
        || /\b(?:sensitive_words_detected|content_policy_violation|content_filter|safety_violation|prompt_blocked|input_blocked|moderation_blocked)\b/.test(message)) {
        return 'policy_rejected';
    }
    if (status === 403
        && ([
            'model_access_denied',
            'model_forbidden',
            'model_not_allowed',
            'model_permission_denied',
            'model_not_in_plan',
            'plan_restricted',
            'tier_restricted',
            'subscription_required',
            'entitlement_required',
        ].some((code) => signals.codes.has(code) || signals.types.has(code))
            || /\b(?:model_access_denied|model_forbidden|model_not_allowed|model_permission_denied|model_not_in_plan|plan_restricted|tier_restricted|subscription_required|entitlement_required)\b/.test(message)
            || /\bmodel\b.{0,80}\b(?:not available|not accessible|not allowed|forbidden|permission denied|access denied)\b.{0,80}\b(?:plan|tier|subscription|package|entitlement)\b/.test(message)
            || /\b(?:plan|tier|subscription|package|entitlement)\b.{0,80}\b(?:does not (?:include|allow)|not entitled|permission denied|access denied|upgrade|required)\b.{0,80}\bmodel\b/.test(message)
            || /\b(?:do not|does not|don't|cannot|can't)\s+have\s+access\s+to\s+(?:this\s+)?model\b/.test(message))) {
        return 'access_forbidden';
    }
    if ([
        'unsupported_model',
        'model_not_found',
        'model_not_supported',
        'deployment_not_found',
    ].some((code) => signals.codes.has(code) || signals.types.has(code))
        ||
            /\bunsupported[_ -]?model\b/.test(message)
        || /\bmodel[_ -]?not[_ -]?found\b/.test(message)
        || /\b(?:model|deployment)\b.{0,80}\b(?:is\s+)?not\s+supported\b/.test(message)
        || /\b(?:model|deployment)\b.{0,80}\b(?:does\s+not\s+exist|not\s+found|unknown)\b/.test(message)
        || /(?:\u6a21\u578b|\u90e8\u7f72).{0,40}(?:\u4e0d\u652f\u6301|\u4e0d\u5b58\u5728|\u672a\u627e\u5230)/.test(message)) {
        return 'unsupported_model';
    }
    if ([
        'no_channel',
        'no_available_channel',
        'no_available_provider',
        'no_available_upstream',
    ].some((code) => signals.codes.has(code) || signals.types.has(code))
        || /\b(?:no|zero)\s+available\s+(?:channel|provider|upstream)s?\b/.test(message)
        || /\bno\s+(?:channel|provider|upstream)s?\s+available\b/.test(message)
        || /(?:\u6682\u65e0|\u6ca1\u6709|\u65e0)\u53ef\u7528(?:\u6e20\u9053|\u4e0a\u6e38|\u4f9b\u5e94\u5546)/.test(message)) {
        return 'no_channel';
    }
    const transportCodes = [
        'econnreset',
        'econnrefused',
        'econnaborted',
        'etimedout',
        'epipe',
        'eai_again',
        'enotfound',
        'ehostunreach',
        'enetunreach',
        'und_err_socket',
        'und_err_connect_timeout',
        'und_err_headers_timeout',
        'und_err_body_timeout',
        'und_err_aborted',
        'err_stream_premature_close',
        'err_socket_closed',
        'stream_read_error',
    ];
    const explicitStreamFailure = transportCodes.some((code) => signals.codes.has(code))
        || /\b(?:responses relay |provider )?stream (?:ended unexpectedly|interrupted|stalled)\b/.test(message)
        || /\binvalid sse data frame\b/.test(message)
        || /\bstream(?:_|\s+)read(?:_|\s+)error\b/.test(message)
        || /\b(?:read )?econn(?:reset|aborted)\b/.test(message)
        || /\b(?:connection|socket) (?:was )?(?:reset|closed)\b/.test(message)
        || /\b(?:socket hang up|other side closed|premature close|reset by peer)\b/.test(message)
        || /\b(?:err_stream_premature_close|und_err_socket|und_err_body_timeout)\b/.test(message)
        || /\b(?:fetch failed|network socket disconnected|terminated)\b/.test(message);
    if (!explicitStreamFailure
        && (status === 400
            || status === 422
            || signals.types.has('invalid_request_error')
            || signals.types.has('bad_request_error')
            || signals.types.has('validation_error')
            || Array.from(signals.codes).some((code) => (code === 'request_token_budget'
                || code === 'context_length_exceeded'
                || code === 'unsupported_parameter'
                || code.startsWith('invalid_request'))))) {
        return 'other';
    }
    if ([
        'rate_limit_exceeded',
        'rate_limit_error',
        'server_error',
        'service_unavailable',
        'temporarily_unavailable',
        'overloaded_error',
        'upstream_timeout',
        'gateway_timeout',
        'unavailable',
    ].some((code) => signals.codes.has(code) || signals.types.has(code))
        || explicitStreamFailure
        || /\b(?:408|409|429|5\d{2})\b/.test(message)
        || /\bservice\s+(?:is\s+)?unavailable\b/.test(message)
        || /\btemporarily\s+unavailable\b/.test(message)
        || /\b(?:rate\s+limit|too\s+many\s+requests|timed?\s*out|timeout|overloaded)\b/.test(message)
        || /\u670d\u52a1\u6682\u4e0d\u53ef\u7528/.test(message)) {
        return 'temporary_unavailable';
    }
    return 'other';
}
export function recordCodexRelaySourceModelSuccess(db, sourceId, publicModelId, nowMs = Date.now()) {
    const result = db.prepare(`
    UPDATE codex_relay_source_models
    SET runtime_status = 'healthy',
        runtime_consecutive_failures = 0,
        runtime_cooldown_until = NULL,
        runtime_last_error = NULL,
        runtime_last_success_at = ?,
        updated_at = datetime('now')
    WHERE source_id = ? AND public_model_id = ?
  `).run(new Date(nowMs).toISOString(), sourceId, publicModelId);
    return result.changes > 0;
}
export function recordCodexRelaySourceUsed(db, sourceId, apiKeyId) {
    db.transaction(() => {
        db.prepare(`
      UPDATE codex_relay_source_keys
      SET status = 'healthy', last_used_at = datetime('now'), last_error = NULL,
          failure_count = 0, cooldown_until = NULL, updated_at = datetime('now')
      WHERE source_id = ? AND api_key_id = ?
    `).run(sourceId, apiKeyId);
        db.prepare(`
      UPDATE api_keys SET status = 'healthy', last_checked_at = datetime('now')
      WHERE id = ? AND role = 'codex_relay'
    `).run(apiKeyId);
    })();
    recomputeCodexRelaySourceStatus(db, sourceId);
}
/**
 * Persist a credential-wide Relay protection. Callers must reserve this for
 * authentication failure or confirmed balance exhaustion; transient/model
 * failures belong to the current request's fallback state and diagnostics.
 */
export function recordCodexRelaySourceFailure(db, sourceId, apiKeyId, options = {}) {
    const message = sanitizeProviderErrorMessage(options.error ?? 'Codex relay request failed').slice(0, 2_000);
    db.transaction(() => {
        const statusAssignment = options.authenticationFailure ? ", status = 'invalid'" : '';
        const cooldownAssignment = options.cooldownUntil === undefined ? '' : ', cooldown_until = ?';
        const values = [message];
        if (options.cooldownUntil !== undefined)
            values.push(options.cooldownUntil);
        values.push(sourceId, apiKeyId);
        db.prepare(`
      UPDATE codex_relay_source_keys
      SET last_used_at = datetime('now'), last_error = ?, failure_count = failure_count + 1
          ${statusAssignment}
          ${cooldownAssignment}, updated_at = datetime('now')
      WHERE source_id = ? AND api_key_id = ?
    `).run(...values);
        if (options.authenticationFailure) {
            db.prepare("UPDATE api_keys SET status = 'invalid', last_checked_at = datetime('now') WHERE id = ? AND role = 'codex_relay'")
                .run(apiKeyId);
        }
    })();
    recomputeCodexRelaySourceStatus(db, sourceId);
}
function relayEndpointUrl(baseUrl, endpoint) {
    return `${baseUrl.replace(/\/+$/, '')}/${endpoint}`;
}
function redactKnownSecret(value, secret) {
    return secret ? value.split(secret).join('[redacted-key]') : value;
}
function isAbortError(error) {
    if (!(error instanceof Error))
        return false;
    return error.name === 'AbortError' || /operation was aborted|timed out/i.test(error.message);
}
async function retryRelayAbort(operation) {
    let lastError;
    for (let attempt = 0; attempt <= CODEX_RELAY_ABORT_RETRIES; attempt += 1) {
        try {
            return await operation(attempt === 0 ? CODEX_RELAY_HEALTH_TIMEOUT_MS : CODEX_RELAY_RETRY_TIMEOUT_MS);
        }
        catch (error) {
            lastError = error;
            if (!isAbortError(error) || attempt === CODEX_RELAY_ABORT_RETRIES)
                throw error;
        }
    }
    throw lastError;
}
function relayHealthErrorMessage(error, retried) {
    if (isAbortError(error)) {
        const retryNote = retried ? '（已自动重试 1 次）' : '';
        return `上游在 ${CODEX_RELAY_HEALTH_TIMEOUT_MS / 1_000} 秒内未响应，健康检测已超时${retryNote}`;
    }
    return sanitizeProviderErrorMessage(error).slice(0, 2_000);
}
export function discoveredModelsFromListPayload(payload) {
    const data = Array.isArray(payload)
        ? payload
        : payload && typeof payload === 'object' && Array.isArray(payload.data)
            ? payload.data
            : payload && typeof payload === 'object' && Array.isArray(payload.models)
                ? payload.models
                : [];
    return data
        .map((entry) => {
        if (typeof entry === 'string')
            return entry;
        if (!entry || typeof entry !== 'object')
            return '';
        const value = entry.id
            ?? entry.model
            ?? entry.name;
        return typeof value === 'string' ? value : '';
    })
        .map((model) => model.trim())
        .filter((model, index, all) => Boolean(model) && all.indexOf(model) === index)
        .sort((left, right) => left.localeCompare(right))
        .slice(0, 200);
}
/**
 * Read an OpenAI-compatible model catalog without changing relay health or
 * routing state. This is deliberately separate from the health probe: model
 * discovery only proves that GET /models is readable, not that /responses or
 * /chat/completions works.
 */
export async function discoverCodexRelayModelsWithCredentials(baseUrl, apiKey) {
    try {
        const response = await retryRelayAbort((timeoutMs) => proxyFetch(relayEndpointUrl(baseUrl, 'models'), {
            method: 'GET',
            headers: {
                Authorization: `Bearer ${apiKey}`,
                Accept: 'application/json',
            },
            signal: AbortSignal.timeout(timeoutMs),
        }, 'custom', 'chat', timeoutMs));
        if (!response.ok) {
            const body = await response.text().catch(() => '');
            throw new Error(`Relay model discovery failed with HTTP ${response.status}: ` +
                redactKnownSecret(body.slice(0, 500), apiKey));
        }
        const payload = await response.json().catch(() => null);
        const models = discoveredModelsFromListPayload(payload);
        if (models.length === 0) {
            throw new Error('Relay model discovery returned no readable model IDs');
        }
        return models;
    }
    catch (error) {
        const rawMessage = isAbortError(error)
            ? relayHealthErrorMessage(error, true)
            : sanitizeProviderErrorMessage(error);
        const message = redactKnownSecret(rawMessage, apiKey);
        throw new Error(message.slice(0, 2_000));
    }
}
/** Use the first saved credential that can read the supplier's model list. */
export async function discoverCodexRelaySourceModels(db, sourceId) {
    const rows = db.prepare(`
    SELECT
      sk.api_key_id,
      COALESCE(NULLIF(TRIM(s.base_url), ''), k.base_url) AS base_url,
      k.encrypted_key,
      k.iv,
      k.auth_tag
    FROM codex_relay_sources s
    JOIN codex_relay_source_keys sk ON sk.source_id = s.id
    JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
    WHERE s.id = ?
    ORDER BY
      CASE
        WHEN sk.enabled = 1 AND sk.status = 'healthy' THEN 0
        WHEN sk.enabled = 1 THEN 1
        ELSE 2
      END ASC,
      sk.priority ASC,
      sk.api_key_id ASC
  `).all(sourceId);
    if (rows.length === 0) {
        const exists = db.prepare('SELECT 1 FROM codex_relay_sources WHERE id = ?').get(sourceId);
        if (!exists)
            throw new Error('Codex relay source not found');
        throw new Error('Codex relay source has no API keys');
    }
    let lastError = null;
    for (const row of rows) {
        try {
            const apiKey = decrypt(row.encrypted_key, row.iv, row.auth_tag);
            const models = await discoverCodexRelayModelsWithCredentials(row.base_url, apiKey);
            return { models, apiKeyId: row.api_key_id };
        }
        catch (error) {
            lastError = error instanceof Error ? error : new Error(String(error));
        }
    }
    throw lastError ?? new Error('Relay model discovery failed for every saved API key');
}
function modelFromResponsesPayload(payload) {
    if (!payload || typeof payload !== 'object') {
        throw new Error('Relay health check returned an invalid Responses payload');
    }
    const response = payload;
    if (response.error != null || response.status === 'failed') {
        throw new Error('Relay health check returned a failed Responses object');
    }
    if (typeof response.id !== 'string' || !response.id.trim()) {
        throw new Error('Relay health check Responses payload is missing an id');
    }
    if (response.object !== undefined && response.object !== 'response') {
        throw new Error('Relay health check returned a non-Responses object');
    }
    if (typeof response.model !== 'string' || !response.model.trim()) {
        throw new Error('Relay health check Responses payload is missing a model');
    }
    return response.model.trim();
}
/**
 * Probe one credential without changing any sibling credential. Native
 * Responses suppliers issue a deliberately tiny non-streaming /responses
 * request because a successful model listing does not prove the Responses
 * wire protocol. The credential revision comparison prevents a slow probe
 * from overwriting the result of a Key rotation that completed meanwhile.
 */
export async function checkCodexRelaySourceKeyHealth(db, sourceId, apiKeyId, options = {}) {
    const row = db.prepare(`
    SELECT
      s.id,
      s.protocol,
      COALESCE(NULLIF(TRIM(s.base_url), ''), k.base_url) AS base_url,
      sk.api_key_id,
      sk.credential_revision,
      sk.status,
      sk.failure_count,
      k.encrypted_key,
      k.iv,
      k.auth_tag
    FROM codex_relay_sources s
    JOIN codex_relay_source_keys sk ON sk.source_id = s.id
    JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
    WHERE s.id = ? AND sk.api_key_id = ?
  `).get(sourceId, apiKeyId);
    if (!row)
        throw new Error('Codex relay source API key not found');
    let discoveredModels = [];
    const isResponses = row.protocol === 'responses';
    const retryAbort = options.retryAbort ?? true;
    try {
        const apiKey = decrypt(row.encrypted_key, row.iv, row.auth_tag);
        const responseModel = isResponses
            ? db.prepare(`
          SELECT upstream_model_id AS modelId
          FROM codex_relay_source_models
          WHERE source_id = ? AND enabled = 1
          ORDER BY public_model_id ASC
          LIMIT 1
        `).get(sourceId)
            : undefined;
        if (isResponses && !responseModel?.modelId.trim()) {
            throw new Error('Native Responses health check requires an enabled model mapping');
        }
        const request = (timeoutMs) => proxyFetch(relayEndpointUrl(row.base_url, isResponses ? 'responses' : 'models'), {
            method: isResponses ? 'POST' : 'GET',
            headers: {
                Authorization: `Bearer ${apiKey}`,
                Accept: 'application/json',
                ...(isResponses ? { 'Content-Type': 'application/json' } : {}),
            },
            ...(isResponses ? {
                body: JSON.stringify({
                    model: responseModel.modelId.trim(),
                    input: 'Reply with OK.',
                    max_output_tokens: 16,
                    stream: false,
                    store: false,
                }),
            } : {}),
            signal: AbortSignal.timeout(timeoutMs),
        }, 'custom', 'chat', timeoutMs);
        // GET /models is idempotent and free to retry. A Responses probe may have
        // reached the upstream even when its response timed out, so do not submit a
        // second potentially billable generation. Automatic create-time checks
        // also disable the GET retry so creating one source means at most one
        // upstream request.
        const response = isResponses
            ? await request(CODEX_RELAY_HEALTH_TIMEOUT_MS)
            : retryAbort
                ? await retryRelayAbort(request)
                : await request(CODEX_RELAY_HEALTH_TIMEOUT_MS);
        if (!response.ok) {
            const body = await response.text().catch(() => '');
            throw providerHttpError(response, `Relay health check failed with HTTP ${response.status}: ` +
                redactKnownSecret(body.slice(0, 500), apiKey));
        }
        const payload = await response.json().catch(() => null);
        discoveredModels = isResponses
            ? [modelFromResponsesPayload(payload)]
            : discoveredModelsFromListPayload(payload);
        db.transaction(() => {
            const updated = db.prepare(`
        UPDATE codex_relay_source_keys
        SET status = 'healthy', last_error = NULL, last_checked_at = datetime('now'),
            failure_count = 0, cooldown_until = NULL, updated_at = datetime('now')
        WHERE source_id = ? AND api_key_id = ? AND credential_revision = ?
      `).run(sourceId, apiKeyId, row.credential_revision);
            if (updated.changes > 0) {
                db.prepare(`
          UPDATE api_keys SET status = 'healthy', last_checked_at = datetime('now')
          WHERE id = ? AND role = 'codex_relay'
        `).run(apiKeyId);
            }
        })();
    }
    catch (error) {
        const status = relayModelErrorStatus(error);
        const kind = classifyCodexRelayModelFailure(error);
        const authenticationFailure = status === 401 || isKeyAuthError(error);
        const message = relayHealthErrorMessage(error, !isResponses && retryAbort);
        if (authenticationFailure) {
            db.transaction(() => {
                const updated = db.prepare(`
          UPDATE codex_relay_source_keys
          SET status = 'invalid', last_error = ?, last_checked_at = datetime('now'),
              failure_count = failure_count + 1, updated_at = datetime('now')
          WHERE source_id = ? AND api_key_id = ? AND credential_revision = ?
        `).run(message, sourceId, apiKeyId, row.credential_revision);
                if (updated.changes > 0) {
                    db.prepare(`
            UPDATE api_keys SET status = 'invalid', last_checked_at = datetime('now')
            WHERE id = ? AND role = 'codex_relay'
          `).run(apiKeyId);
                }
            })();
        }
        else if (kind === 'out_of_credits') {
            db.prepare(`
        UPDATE codex_relay_source_keys
        SET last_error = ?, last_checked_at = datetime('now'),
            failure_count = failure_count + 1, cooldown_until = ?,
            updated_at = datetime('now')
        WHERE source_id = ? AND api_key_id = ? AND credential_revision = ?
      `).run(message, new Date(Date.now() + CODEX_RELAY_MODEL_OUT_OF_CREDITS_COOLDOWN_MS).toISOString(), sourceId, apiKeyId, row.credential_revision);
        }
        else {
            // Transient probe failures remain visible for diagnostics but never
            // change eligibility. The next user request may still try this Key.
            db.prepare(`
        UPDATE codex_relay_source_keys
        SET last_error = ?, last_checked_at = datetime('now'),
            failure_count = failure_count + 1, updated_at = datetime('now')
        WHERE source_id = ? AND api_key_id = ? AND credential_revision = ?
      `).run(message, sourceId, apiKeyId, row.credential_revision);
        }
    }
    recomputeCodexRelaySourceStatus(db, sourceId);
    return { source: getCodexRelaySource(db, sourceId), discoveredModels };
}
/** Probe every credential belonging to the supplier and aggregate discovery. */
export async function checkCodexRelaySourceHealth(db, sourceId) {
    const exists = db.prepare('SELECT 1 FROM codex_relay_sources WHERE id = ?').get(sourceId);
    if (!exists)
        throw new Error('Codex relay source not found');
    const keyIds = db.prepare(`
    SELECT api_key_id
    FROM codex_relay_source_keys
    WHERE source_id = ?
    ORDER BY priority ASC, api_key_id ASC
  `).all(sourceId);
    if (keyIds.length === 0)
        throw new Error('Codex relay source has no API keys');
    const discovered = new Set();
    let cursor = 0;
    const worker = async () => {
        while (cursor < keyIds.length) {
            const key = keyIds[cursor];
            cursor += 1;
            const result = await checkCodexRelaySourceKeyHealth(db, sourceId, key.api_key_id);
            for (const model of result.discoveredModels)
                discovered.add(model);
        }
    };
    await Promise.all(Array.from({ length: Math.min(3, keyIds.length) }, () => worker()));
    return {
        source: getCodexRelaySource(db, sourceId),
        discoveredModels: [...discovered],
    };
}
/**
 * Probe one exact public-to-upstream model mapping. A successful GET /models
 * or source-level health check does not prove that this particular model is
 * accepted by the relay, so this probe supplies mapping-level diagnostics.
 * Administrator enablement remains the routing gate: a failed probe does not
 * bench the mapping for later user requests. The credential is isolated only
 * when the response identifies a key-wide authentication or balance problem.
 */
export async function checkCodexRelaySourceModelHealth(db, sourceId, publicModelId) {
    const row = db.prepare(`
    SELECT
      s.protocol,
      COALESCE(NULLIF(TRIM(s.base_url), ''), k.base_url) AS base_url,
      sk.api_key_id,
      k.encrypted_key,
      k.iv,
      k.auth_tag,
      sm.upstream_model_id
    FROM codex_relay_sources s
    JOIN codex_relay_source_models sm
      ON sm.source_id = s.id AND sm.public_model_id = ?
    JOIN codex_relay_source_keys sk ON sk.source_id = s.id
    JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
    WHERE s.id = ? AND sk.enabled = 1 AND k.enabled = 1
    ORDER BY
      CASE WHEN sk.status = 'healthy' THEN 0 WHEN sk.status = 'unknown' THEN 1 ELSE 2 END,
      CASE WHEN sk.cooldown_until IS NULL OR datetime(sk.cooldown_until) <= datetime('now') THEN 0 ELSE 1 END,
      sk.priority ASC,
      sk.api_key_id ASC
    LIMIT 1
  `).get(publicModelId, sourceId);
    if (!row) {
        const sourceExists = db.prepare('SELECT 1 FROM codex_relay_sources WHERE id = ?').get(sourceId);
        if (!sourceExists)
            throw new Error('Codex relay source not found');
        const mappingExists = db.prepare(`
      SELECT 1 FROM codex_relay_source_models
      WHERE source_id = ? AND public_model_id = ?
    `).get(sourceId, publicModelId);
        if (!mappingExists)
            throw new Error('Codex relay model mapping not found');
        throw new Error('Codex relay source has no enabled API key');
    }
    const apiKey = decrypt(row.encrypted_key, row.iv, row.auth_tag);
    const endpoint = row.protocol === 'responses'
        ? relayEndpointUrl(row.base_url, 'responses')
        : relayEndpointUrl(row.base_url, 'chat/completions');
    const body = row.protocol === 'responses'
        ? {
            model: row.upstream_model_id,
            input: 'Reply with OK.',
            max_output_tokens: 16,
            stream: false,
            store: false,
        }
        : {
            model: row.upstream_model_id,
            messages: [{ role: 'user', content: 'Reply with OK.' }],
            max_tokens: 16,
            stream: false,
        };
    const timeoutMs = 30_000;
    try {
        const response = await proxyFetch(endpoint, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${apiKey}`,
                'Content-Type': 'application/json',
                Accept: 'application/json',
            },
            body: JSON.stringify(body),
            signal: AbortSignal.timeout(timeoutMs),
        }, 'custom', 'chat', timeoutMs);
        if (!response.ok) {
            const errorBody = await response.text().catch(() => '');
            throw providerHttpError(response, `Relay model health check failed with HTTP ${response.status}: ${redactKnownSecret(errorBody.slice(0, 500), apiKey)}`);
        }
        const payload = await response.json().catch(() => null);
        if (!payload || typeof payload !== 'object') {
            throw new Error('Relay model health check returned an invalid JSON response');
        }
        if (row.protocol === 'responses') {
            const responsePayload = payload;
            if (typeof responsePayload.id !== 'string'
                || !responsePayload.id.trim()
                || responsePayload.status === 'failed'
                || responsePayload.error != null) {
                throw new Error('Relay model health check returned a failed Responses object');
            }
        }
        else {
            const chatPayload = payload;
            if (!Array.isArray(chatPayload.choices)) {
                throw new Error('Relay model health check returned no chat completion choices');
            }
        }
        recordCodexRelaySourceModelSuccess(db, sourceId, publicModelId);
        const source = getCodexRelaySource(db, sourceId);
        const model = source?.modelMappings.find((mapping) => mapping.publicModelId === publicModelId);
        if (!source || !model)
            throw new Error('Codex relay source changed during model health check');
        return {
            source,
            model,
            apiKeyId: row.api_key_id,
            success: true,
            message: 'Relay model health check passed',
        };
    }
    catch (error) {
        const status = relayModelErrorStatus(error);
        const kind = classifyCodexRelayModelFailure(error);
        const message = sanitizeProviderErrorMessage(error).slice(0, 2_000);
        if (status === 401 || isKeyAuthError(error)) {
            recordCodexRelaySourceFailure(db, sourceId, row.api_key_id, {
                error: message,
                authenticationFailure: true,
                cooldownUntil: new Date(Date.now() + 5 * 60 * 1_000).toISOString(),
            });
        }
        else if (kind === 'out_of_credits') {
            recordCodexRelaySourceFailure(db, sourceId, row.api_key_id, {
                error: message,
                cooldownUntil: new Date(Date.now() + CODEX_RELAY_MODEL_OUT_OF_CREDITS_COOLDOWN_MS).toISOString(),
            });
        }
        const source = getCodexRelaySource(db, sourceId);
        const model = source?.modelMappings.find((mapping) => mapping.publicModelId === publicModelId);
        if (!source || !model)
            throw new Error('Codex relay source changed during model health check');
        return {
            source,
            model,
            apiKeyId: row.api_key_id,
            success: false,
            message,
        };
    }
}
//# sourceMappingURL=codex-relay-sources.js.map