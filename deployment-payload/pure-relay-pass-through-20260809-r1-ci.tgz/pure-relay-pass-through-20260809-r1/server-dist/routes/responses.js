import crypto from 'crypto';
import { gzipSync, gunzipSync } from 'zlib';
import { Router } from 'express';
import { z } from 'zod';
import { routeRequest, hasEnabledToolsModel, requiresCodexMultiTurnCapability, routingReserveTokens, resolveModelGroupCandidates } from '../services/router.js';
import { getDb, getUnifiedApiKey } from '../db/index.js';
import { contentToString } from '../lib/content.js';
import { repairToolArguments, toolSchemaMap } from '../lib/tool-args.js';
import { rescueInlineToolCalls, startsWithDialectMarker, couldBecomeDialectMarker, containsDialectMarker } from '../lib/tool-call-rescue.js';
import { timingSafeStringEqual, extractApiToken, getRequestGroupId, getStickyModel, setStickyModel, traceRouteEvent, logRequest, } from './proxy.js';
import { runFallbackLoop, newFallbackState, recordCommittedUpstreamFailure, recordUpstreamSuccess, setFallbackHeaders, } from '../lib/fallback-loop.js';
import { applyTokenBudget, tokenBudgetMessage } from '../lib/guardrails.js';
import { samplingParamSchemaFields, pickSamplingParams } from '../lib/sampling-params.js';
import { enforceJsonContent } from '../lib/structured-output.js';
import { sanitizeProviderErrorMessage } from '../lib/error-redaction.js';
import { providerStreamErrorFromChunk } from '../lib/error-classify.js';
import { inferQuotaPoolKey } from '../services/provider-quota.js';
import { getClientContext } from '../lib/client-context.js';
import { signInternalPayload } from '../lib/crypto.js';
import { getCodexConsumerGroupModelDbId, getCodexConsumerModelDbId, normalizeCodexModelId, } from '../services/model-listing.js';
import { getModelGroups, isUnifyEnabled, resolveRequestedIdToMembers } from '../services/model-groups.js';
import { applyNativeResponsesExplicitPromptCache, applyNativeResponsesPromptCacheKey, NativeResponsesSseRewriter, nativeResponsesStablePrefixSeed, prepareNativeResponsesCompactRequestBody, prepareNativeResponsesRequestBody, requestNativeResponsesCompactRelay, requestNativeResponsesRelay, responsePayloadErrorDetails, rewriteNativeResponsesModel, } from '../lib/native-responses-relay.js';
import { CodexCompactionEnvelopeError, findCodexCompactionUpstreamPin, unwrapCodexCompactionRequest, wrapCodexCompactionResponse, } from '../lib/codex-compaction-envelope.js';
import { relayMappingRequiresExplicitPromptCache, requiresExplicitPromptCache } from '../lib/codex-prompt-cache.js';
import { codexCachedInputTokensFromUsage, codexCacheWriteTokensFromUsage, normalizeCodexPromptCacheUsage, } from '../lib/codex-cache-usage.js';
import { assertWalletStreamBudget, isWalletSafetyBalanceReachedError, WALLET_SAFETY_STOP_MESSAGE, } from '../services/wallet-stream-budget.js';
export const responsesRouter = Router();
// ─────────────────────────────────────────────────────────────────────────
// OpenAI Responses API shim (POST /v1/responses).
//
// Current Codex versions only speak the Responses API — `wire_api = "chat"`
// is rejected — so the existing /v1/chat/completions endpoint isn't reachable
// from Codex (see issue #96). This endpoint accepts a Responses-shaped request
// and runs it through the SAME shared fallback loop as the proxy
// (lib/fallback-loop.ts). Official Codex OAuth accounts and third-party sources
// explicitly configured for Responses are forwarded natively; ordinary and
// Chat-Completions relay providers use the compatibility adapter.
//
// A thin adapter: the cooldown/skip/penalty/exhaustion machinery is shared, and
// only the Responses request/stream translation lives here. This is what fixed
// the drift where /v1/responses ignored a provider Retry-After and under-benched
// a 403 (both are now handled identically to /chat/completions by the shared
// loop) and committed the SSE skeleton on the first raw chunk (the commit point
// is now held until the first meaningful content, so a pre-content failure fails
// over invisibly).
// ─────────────────────────────────────────────────────────────────────────
const MAX_RETRIES = 20;
function newId(prefix) {
    return `${prefix}_${crypto.randomBytes(18).toString('hex')}`;
}
function nowUnix() {
    return Math.floor(Date.now() / 1000);
}
// ── Request schema ──────────────────────────────────────────────────────
// Lenient on purpose: the Responses API surface is large and evolving. The
// compatibility adapter maps only known fields; fields such as
// metadata, previous_response_id, …) are accepted and ignored.
const contentPartSchema = z.object({ type: z.string() }).passthrough();
const messageItemSchema = z.object({
    type: z.literal('message').optional(),
    role: z.enum(['system', 'developer', 'user', 'assistant']),
    content: z.union([z.string(), z.array(contentPartSchema)]),
});
const functionCallItemSchema = z.object({
    type: z.literal('function_call'),
    call_id: z.string(),
    name: z.string(),
    arguments: z.string(),
    id: z.string().optional(),
});
const functionCallOutputItemSchema = z.object({
    type: z.literal('function_call_output'),
    call_id: z.string(),
    output: z.union([z.string(), z.array(contentPartSchema), z.record(z.string(), z.unknown())]),
});
const inputItemSchema = z.union([
    functionCallItemSchema,
    functionCallOutputItemSchema,
    messageItemSchema,
    // Responses clients may replay output-only history items such as
    // reasoning, item_reference, web_search_call, etc. They are not directly
    // translatable to chat messages, but rejecting the whole request makes a
    // valid following user message unusable. Keep them for the conversion layer
    // to safely ignore.
    z.record(z.string(), z.unknown()),
    // Some compatible clients use a compact string array for multi-turn input.
    z.string(),
]);
// Accept ANY tool type, not just 'function'. Codex (Responses API) sends
// built-in tools like `web_search` / `local_shell` alongside function tools;
// a strict z.literal('function') rejected the whole request. We validate
// loosely here and drop non-function tools at conversion (toChatTools), since
// chat-completions providers only accept type:'function'.
const responsesToolSchema = z.object({
    type: z.string(),
    name: z.string().optional(),
    description: z.string().nullable().optional(),
    parameters: z.record(z.string(), z.unknown()).nullable().optional(),
    strict: z.boolean().nullable().optional(),
}).passthrough();
const responsesRequestSchema = z.object({
    model: z.string().optional(),
    instructions: z.string().nullable().optional(),
    input: z.union([z.string(), z.array(inputItemSchema)]),
    stream: z.boolean().optional(),
    temperature: z.number().min(0).max(2).nullable().optional(),
    top_p: z.number().min(0).max(1).nullable().optional(),
    max_output_tokens: z.number().int().positive().nullable().optional(),
    tools: z.array(responsesToolSchema).optional(),
    tool_choice: z.union([
        z.enum(['none', 'auto', 'required']),
        // Native Responses supports additional named/built-in tool choice shapes.
        // Keep them intact for native forwarding; the compatibility adapter maps
        // a named choice when possible and otherwise falls back to auto.
        z.record(z.string(), z.unknown()),
    ]).optional(),
    parallel_tool_calls: z.boolean().nullable().optional(),
    // Extended sampling params, validated the same way as /chat/completions.
    // Responses clients express structured output as `text.format` rather than
    // `response_format` — mapped where completionOpts is built.
    ...samplingParamSchemaFields,
    text: z.object({
        format: z.object({
            type: z.enum(['text', 'json_object', 'json_schema']),
            name: z.string().optional(),
            strict: z.boolean().nullable().optional(),
            schema: z.record(z.string(), z.unknown()).optional(),
        }).passthrough().optional(),
    }).passthrough().nullable().optional(),
}).passthrough();
const compactRequestSchema = z.object({
    model: z.string().min(1),
    input: z.array(inputItemSchema),
    instructions: z.string().optional(),
    tools: z.array(responsesToolSchema).optional(),
    parallel_tool_calls: z.boolean().nullable().optional(),
    reasoning: z.record(z.string(), z.unknown()).nullable().optional(),
    service_tier: z.string().optional(),
    prompt_cache_key: z.string().optional(),
    text: z.record(z.string(), z.unknown()).nullable().optional(),
    client_metadata: z.record(z.string(), z.unknown()).optional(),
}).passthrough();
const LEGACY_LOCAL_COMPACTION_PREFIX = 'freellmapi:gzip:v1:';
const LOCAL_COMPACTION_PREFIX = 'freellmapi:gzip:v2:';
const LOCAL_COMPACTION_SIGNING_PURPOSE = 'local-compaction-envelope-v2';
const MAX_LOCAL_COMPACTION_COMPRESSED_BYTES = 2 * 1024 * 1024;
const MAX_LOCAL_COMPACTION_OUTPUT_BYTES = 8 * 1024 * 1024;
const MAX_LOCAL_COMPACTION_ENCODED_CHARS = Math.ceil(MAX_LOCAL_COMPACTION_COMPRESSED_BYTES / 3) * 4;
class LocalCompactionEnvelopeError extends Error {
    status;
    code = 'invalid_local_compaction';
    constructor(message, status = 400) {
        super(message);
        this.status = status;
    }
}
function decodeBoundedLocalCompactionPayload(encoded, encoding) {
    if (!encoded || encoded.length > MAX_LOCAL_COMPACTION_ENCODED_CHARS) {
        throw new LocalCompactionEnvelopeError('Local compacted context exceeds the encoded size limit.', 413);
    }
    const alphabet = encoding === 'base64url'
        ? /^[A-Za-z0-9_-]+$/
        : /^[A-Za-z0-9+/]+={0,2}$/;
    if (!alphabet.test(encoded)) {
        throw new LocalCompactionEnvelopeError('Local compacted context has invalid encoding.');
    }
    let compressed;
    try {
        compressed = Buffer.from(encoded, encoding);
    }
    catch {
        throw new LocalCompactionEnvelopeError('Local compacted context has invalid encoding.');
    }
    if (compressed.length === 0 || compressed.length > MAX_LOCAL_COMPACTION_COMPRESSED_BYTES) {
        throw new LocalCompactionEnvelopeError('Local compacted context exceeds the compressed size limit.', 413);
    }
    try {
        return gunzipSync(compressed, {
            maxOutputLength: MAX_LOCAL_COMPACTION_OUTPUT_BYTES,
        }).toString('utf8');
    }
    catch (error) {
        const message = error instanceof Error ? error.message : '';
        if (/larger than|too large|maxOutputLength|buffer/i.test(message)) {
            throw new LocalCompactionEnvelopeError('Local compacted context exceeds the decompressed size limit.', 413);
        }
        throw new LocalCompactionEnvelopeError('Local compacted context is corrupt.');
    }
}
function encodeLocalCompaction(text) {
    const cleartext = Buffer.from(text, 'utf8');
    if (cleartext.length > MAX_LOCAL_COMPACTION_OUTPUT_BYTES) {
        throw new LocalCompactionEnvelopeError('Local compacted context exceeds the decompressed size limit.', 413);
    }
    const compressed = gzipSync(cleartext);
    if (compressed.length > MAX_LOCAL_COMPACTION_COMPRESSED_BYTES) {
        throw new LocalCompactionEnvelopeError('Local compacted context exceeds the compressed size limit.', 413);
    }
    const payload = compressed.toString('base64url');
    const signature = signInternalPayload(LOCAL_COMPACTION_SIGNING_PURPOSE, payload).toString('base64url');
    return `${LOCAL_COMPACTION_PREFIX}${payload}.${signature}`;
}
function decodeLocalCompaction(value) {
    if (typeof value !== 'string')
        return null;
    if (value.startsWith(LOCAL_COMPACTION_PREFIX)) {
        const signed = value.slice(LOCAL_COMPACTION_PREFIX.length);
        const separator = signed.lastIndexOf('.');
        if (separator <= 0 || separator === signed.length - 1) {
            throw new LocalCompactionEnvelopeError('Local compacted context signature is missing.');
        }
        const payload = signed.slice(0, separator);
        const signature = signed.slice(separator + 1);
        if (!/^[A-Za-z0-9_-]+$/.test(signature) || signature.length > 256) {
            throw new LocalCompactionEnvelopeError('Local compacted context signature is invalid.');
        }
        const expected = signInternalPayload(LOCAL_COMPACTION_SIGNING_PURPOSE, payload);
        const provided = Buffer.from(signature, 'base64url');
        if (provided.length !== expected.length || !crypto.timingSafeEqual(provided, expected)) {
            throw new LocalCompactionEnvelopeError('Local compacted context failed verification.');
        }
        return {
            text: decodeBoundedLocalCompactionPayload(payload, 'base64url'),
            trusted: true,
        };
    }
    if (value.startsWith(LEGACY_LOCAL_COMPACTION_PREFIX)) {
        // Legacy v1 values cannot be authenticated retroactively. Decode them only
        // within strict bounds and downgrade them to user-role context. The next
        // /compact call automatically emits a signed v2 envelope.
        return {
            text: decodeBoundedLocalCompactionPayload(value.slice(LEGACY_LOCAL_COMPACTION_PREFIX.length), 'base64'),
            trusted: false,
        };
    }
    return null;
}
/**
 * Local compaction envelopes are owned by this gateway, not by a Responses
 * supplier.  Restore them to ordinary developer messages before any native
 * OAuth/Relay dispatch; otherwise a third party receives an opaque blob it
 * cannot decrypt and silently loses the earlier conversation.
 */
function restoreLocalCompactionForNativeRequest(request) {
    const body = structuredClone(request);
    if (!Array.isArray(body.input))
        return body;
    body.input = body.input.map((item) => {
        if (!item || typeof item !== 'object')
            return item;
        const value = item;
        if (value.type !== 'compaction' && value.type !== 'context_compaction')
            return item;
        const restored = decodeLocalCompaction(value.encrypted_content);
        if (!restored)
            return item;
        return {
            type: 'message',
            // Signed v2 state is gateway-owned. Legacy unsigned v1 state remains
            // readable but cannot be allowed to claim developer authority.
            role: restored.trusted ? 'developer' : 'user',
            content: [{ type: 'input_text', text: restored.text }],
        };
    });
    return body;
}
function validateLocalCompactionInput(input) {
    if (!Array.isArray(input))
        return;
    for (const item of input) {
        if (!item || typeof item !== 'object')
            continue;
        const value = item;
        if (value.type !== 'compaction' && value.type !== 'context_compaction')
            continue;
        // Recognized local envelopes are fully verified/decompressed here, before
        // routing starts. Supplier-owned opaque compaction values return null.
        decodeLocalCompaction(value.encrypted_content);
    }
}
function sendLocalCompactionValidationError(res, error) {
    if (!(error instanceof LocalCompactionEnvelopeError))
        return false;
    res.status(error.status).json({
        error: {
            message: error.message,
            type: error.status === 413 ? 'request_too_large' : 'invalid_request_error',
            code: error.code,
        },
    });
    return true;
}
// Responses content parts → plain text. input_text / output_text both carry
// `text`; other part types (images, etc.) are dropped (parity with the proxy).
function partsToString(content) {
    if (typeof content === 'string')
        return content;
    if (!Array.isArray(content))
        return '';
    return content
        .map((p) => {
        if (typeof p === 'string')
            return p;
        if (!p || typeof p !== 'object')
            return '';
        const part = p;
        if (typeof part.text === 'string')
            return part.text;
        if (typeof part.content === 'string')
            return part.content;
        return '';
    })
        .join('');
}
function responsesContentToChat(content) {
    if (typeof content === 'string')
        return content;
    if (!Array.isArray(content))
        return '';
    const hasImage = content.some((part) => {
        if (!part || typeof part !== 'object')
            return false;
        const value = part;
        if (value.type !== 'input_image' && value.type !== 'image_url' && value.type !== 'image') {
            return false;
        }
        const rawImage = value.image_url ?? value.image;
        return typeof rawImage === 'string'
            || Boolean(rawImage && typeof rawImage === 'object' && 'url' in rawImage
                && typeof rawImage.url === 'string');
    });
    if (!hasImage)
        return partsToString(content);
    return content.flatMap((part) => {
        if (typeof part === 'string')
            return [part];
        if (!part || typeof part !== 'object')
            return [];
        const value = part;
        const rawImage = value.image_url ?? value.image;
        const imageUrl = typeof rawImage === 'string'
            ? rawImage
            : rawImage && typeof rawImage === 'object' && 'url' in rawImage
                ? rawImage.url
                : undefined;
        if ((value.type === 'input_image' || value.type === 'image_url' || value.type === 'image')
            && typeof imageUrl === 'string') {
            return [{
                    type: 'image_url',
                    image_url: {
                        url: imageUrl,
                        ...(typeof value.detail === 'string' ? { detail: value.detail } : {}),
                    },
                }];
        }
        if (typeof value.text === 'string')
            return [{ type: 'text', text: value.text }];
        if (typeof value.content === 'string')
            return [{ type: 'text', text: value.content }];
        return [];
    });
}
// Image input via the Responses API isn't carried through translation yet
// (partsToString flattens to text). Detect it so we can hard-fail with a clear
// pointer to /v1/chat/completions rather than silently dropping the image
// (#118, #125). Recognizes the Responses `input_image` part plus the
// chat-style `image_url` / `image` parts some clients reuse here.
export function responsesInputHasImage(req) {
    if (typeof req.input === 'string')
        return false;
    for (const item of req.input) {
        const content = item.content;
        if (!Array.isArray(content))
            continue;
        if (content.some((p) => {
            const type = p?.type;
            return type === 'input_image' || type === 'image_url' || type === 'image';
        }))
            return true;
    }
    return false;
}
// ── Translate a Responses request → internal chat messages + options ──────
export function toChatMessages(req) {
    const messages = [];
    if (req.instructions) {
        messages.push({ role: 'system', content: req.instructions });
    }
    if (typeof req.input === 'string') {
        messages.push({ role: 'user', content: req.input });
        return messages;
    }
    for (const item of req.input) {
        if (typeof item === 'string') {
            messages.push({ role: 'user', content: item });
            continue;
        }
        if (!item || typeof item !== 'object')
            continue;
        if ('type' in item && (item.type === 'compaction' || item.type === 'context_compaction')) {
            const summary = decodeLocalCompaction(item.encrypted_content);
            if (summary)
                messages.push({
                    role: summary.trusted ? 'system' : 'user',
                    content: summary.text,
                });
            continue;
        }
        if ('type' in item && (item.type === 'function_call' || item.type === 'custom_tool_call')
            && typeof item.call_id === 'string'
            && typeof item.name === 'string'
            && (typeof item.arguments === 'string' || typeof item.input === 'string')) {
            const argumentsText = item.type === 'custom_tool_call'
                ? JSON.stringify({ input: String(item.input ?? '') })
                : String(item.arguments);
            messages.push({
                role: 'assistant',
                content: null,
                tool_calls: [{
                        id: item.call_id,
                        type: 'function',
                        function: { name: item.name, arguments: argumentsText },
                    }],
            });
        }
        else if ('type' in item && (item.type === 'function_call_output' || item.type === 'custom_tool_call_output')
            && typeof item.call_id === 'string') {
            const output = typeof item.output === 'string'
                ? item.output
                : Array.isArray(item.output)
                    ? partsToString(item.output)
                    : JSON.stringify(item.output);
            messages.push({ role: 'tool', tool_call_id: item.call_id, content: output });
        }
        else if (typeof item.role === 'string'
            && ['system', 'developer', 'user', 'assistant'].includes(String(item.role))
            && 'content' in item) {
            const m = item;
            // 'developer' is the Responses-era system role.
            const role = m.role === 'developer' ? 'system' : m.role;
            messages.push({ role, content: responsesContentToChat(m.content) });
        }
        // Unsupported history-only Responses items are intentionally ignored.
    }
    return messages;
}
export function toChatTools(tools) {
    if (!tools?.length)
        return undefined;
    // Forward only function tools — chat-completions upstreams reject other
    // Responses-API tool types (web_search, local_shell, etc.). Codex sends those
    // extras alongside its function tools (shell/exec, apply_patch); dropping them
    // keeps the request valid without losing the tools that actually do the work.
    const fns = tools.filter((t) => typeof t.name === 'string' && t.name.length > 0);
    if (!fns.length)
        return undefined;
    return fns.map((t) => ({
        type: 'function',
        function: {
            name: t.name,
            ...(t.description ? { description: t.description } : {}),
            parameters: t.parameters ?? (t.type === 'custom'
                ? {
                    type: 'object',
                    properties: { input: { type: 'string', description: 'The complete custom tool input.' } },
                    required: ['input'],
                    additionalProperties: false,
                }
                : {}),
            ...(t.strict != null ? { strict: t.strict } : {}),
        },
    }));
}
function customToolInput(argumentsText) {
    try {
        const parsed = JSON.parse(argumentsText);
        if (parsed && typeof parsed === 'object') {
            if (typeof parsed.input === 'string')
                return parsed.input;
            if (typeof parsed.patch === 'string')
                return parsed.patch;
        }
    }
    catch {
        // Some providers return the custom input directly rather than JSON.
    }
    return argumentsText;
}
export function toChatToolChoice(tc) {
    if (!tc)
        return undefined;
    if (typeof tc === 'string')
        return tc;
    return typeof tc.name === 'string' && tc.name
        ? { type: 'function', function: { name: tc.name } }
        : 'auto';
}
function requestDeclaresToolUse(req) {
    return (req.tools?.length ?? 0) > 0 && req.tool_choice !== 'none';
}
function hasToolResultInput(req) {
    return Array.isArray(req.input) && req.input.some((item) => Boolean(item && typeof item === 'object' && 'type' in item
        && (item.type === 'function_call_output' || item.type === 'custom_tool_call_output')));
}
function falselyClaimsToolsUnavailable(text) {
    return /无法(?:直接)?(?:调用|访问|使用).{0,24}(?:文件|工作区|终端|工具)|没有.{0,24}(?:文件系统|终端|本地工具)|当前任务.{0,24}(?:没有|未提供).{0,24}(?:工具|文件系统|终端)|(?:can't|cannot|couldn't).{0,40}(?:access|use).{0,30}(?:filesystem|file tools|shell|terminal|local tools)|did not provide.{0,30}(?:filesystem|shell|terminal|tools)/i.test(text);
}
// ── Build the final (non-stream) Responses object ─────────────────────────
export function buildResponseObject(opts) {
    const output = opts.outputItems ?? [];
    if (!opts.outputItems) {
        if (opts.text.length > 0) {
            output.push({
                type: 'message',
                id: newId('msg'),
                status: 'completed',
                role: 'assistant',
                content: [{ type: 'output_text', text: opts.text, annotations: [] }],
            });
        }
        for (const tc of opts.toolCalls) {
            const custom = opts.customToolNames?.has(tc.function.name) ?? false;
            output.push({
                type: custom ? 'custom_tool_call' : 'function_call',
                id: newId('fc'),
                call_id: tc.id,
                name: tc.function.name,
                ...(custom ? { input: customToolInput(tc.function.arguments) } : { arguments: tc.function.arguments }),
                status: 'completed',
            });
        }
    }
    const status = opts.status ?? 'completed';
    const cachedInputTokens = Math.max(0, Math.floor(opts.cachedInputTokens ?? 0));
    const cacheWriteTokens = Math.max(0, Math.floor(opts.cacheWriteTokens ?? 0));
    return {
        id: opts.id,
        object: 'response',
        created_at: opts.createdAt ?? nowUnix(),
        status,
        completed_at: status === 'completed' ? nowUnix() : null,
        error: null,
        incomplete_details: null,
        instructions: null,
        max_output_tokens: null,
        model: opts.model,
        output,
        output_text: opts.text,
        parallel_tool_calls: true,
        previous_response_id: null,
        reasoning: null,
        reasoning_effort: null,
        store: false,
        temperature: 1,
        text: { format: { type: 'text' } },
        tool_choice: 'auto',
        tools: [],
        top_p: 1,
        truncation: 'disabled',
        user: null,
        metadata: {},
        usage: status === 'completed'
            ? {
                input_tokens: opts.promptTokens,
                input_tokens_details: {
                    cached_tokens: cachedInputTokens,
                    cache_write_tokens: cacheWriteTokens,
                },
                output_tokens: opts.completionTokens,
                output_tokens_details: { reasoning_tokens: 0 },
                total_tokens: opts.promptTokens + opts.completionTokens,
            }
            : null,
    };
}
function compactionTranscript(input) {
    const lines = [];
    for (const item of input) {
        if (!item || typeof item !== 'object')
            continue;
        const value = item;
        if (value.type === 'compaction' || value.type === 'context_compaction') {
            const previous = decodeLocalCompaction(value.encrypted_content);
            if (previous)
                lines.push(previous.text);
            continue;
        }
        if (value.type === 'message' || typeof value.role === 'string') {
            const text = partsToString(value.content);
            if (text)
                lines.push(`${String(value.role ?? 'message').toUpperCase()}: ${text}`);
            continue;
        }
        if (value.type === 'function_call') {
            lines.push(`TOOL CALL ${String(value.name ?? '')}: ${String(value.arguments ?? '')}`);
        }
        else if (value.type === 'function_call_output') {
            lines.push(`TOOL RESULT ${String(value.call_id ?? '')}: ${partsToString(value.output) || JSON.stringify(value.output)}`);
        }
    }
    return [
        'Compacted conversation context. Preserve requirements, decisions, file paths, commands, errors, and unfinished work:',
        lines.join('\n'),
    ].join('\n');
}
function sendLocalCompaction(res, request, mode) {
    const retained = request.input.filter((item) => {
        if (!item || typeof item !== 'object')
            return false;
        const value = item;
        return value.type === 'message' && (value.role === 'user' || value.role === 'developer');
    });
    const turnId = typeof request.client_metadata?.turn_id === 'string'
        ? request.client_metadata.turn_id
        : undefined;
    try {
        const compacted = {
            type: 'compaction',
            encrypted_content: encodeLocalCompaction(compactionTranscript(request.input)),
            ...(turnId ? { internal_chat_message_metadata_passthrough: { turn_id: turnId } } : {}),
        };
        res.setHeader('X-Compaction-Mode', mode);
        res.json({ output: [...retained, compacted] });
    }
    catch (error) {
        const envelopeError = error instanceof LocalCompactionEnvelopeError
            ? error
            : new LocalCompactionEnvelopeError('Local compaction failed.', 500);
        res.status(envelopeError.status).json({
            error: {
                message: envelopeError.message,
                type: envelopeError.status === 413 ? 'request_too_large' : 'invalid_request_error',
                code: envelopeError.code,
            },
        });
    }
}
function quotaContextForRoute(route, endpoint) {
    return {
        platform: route.platform,
        keyId: route.keyId,
        modelId: route.modelId,
        quotaPoolKey: inferQuotaPoolKey(route.platform, route.modelId),
        endpoint,
        origin: 'responses',
    };
}
function supportsNativeCodexResponses(provider) {
    return typeof provider.nativeResponses === 'function';
}
function supportsNativeCodexCompaction(provider) {
    return typeof provider.nativeResponsesCompact === 'function';
}
function parseNativeCodexEvents(raw) {
    const events = [];
    for (const block of raw.replace(/\r\n/g, '\n').split('\n\n')) {
        const data = block.split('\n')
            .filter((line) => line.startsWith('data:'))
            .map((line) => line.slice(5).trimStart())
            .join('\n');
        if (!data || data === '[DONE]')
            continue;
        try {
            events.push(JSON.parse(data));
        }
        catch { /* keepalive/non-JSON */ }
    }
    return events;
}
function nativeEventOutputChars(event) {
    const type = String(event?.type ?? '');
    if (![
        'response.output_text.delta',
        'response.refusal.delta',
        'response.reasoning_summary_text.delta',
        'response.function_call_arguments.delta',
        'response.custom_tool_call_input.delta',
    ].includes(type)) {
        return 0;
    }
    return typeof event?.delta === 'string' ? event.delta.length : 0;
}
function nativeEventUsage(event) {
    return event?.response?.usage ?? event?.usage;
}
function firstNativeUsageToken(...values) {
    for (const value of values) {
        if (typeof value !== 'number' || !Number.isFinite(value) || value < 0)
            continue;
        return Math.floor(value);
    }
    return null;
}
function estimatedTokensFromCharacters(characters) {
    // Keep this aligned with the existing Responses/Chat fallback estimator.
    // A completed response without text (for example a bare tool item) still
    // consumed provider work, so a missing usage payload must never settle at 0.
    return Math.max(1, Math.ceil(Math.max(0, characters) / 4));
}
function nativeResponseOutputChars(response) {
    const output = Array.isArray(response?.output) ? response.output : [];
    let characters = 0;
    const visit = (value, field) => {
        if (typeof value === 'string') {
            if (['text', 'refusal', 'arguments', 'input'].includes(field ?? '')) {
                characters += value.length;
            }
            return;
        }
        if (Array.isArray(value)) {
            for (const item of value)
                visit(item, field);
            return;
        }
        if (!value || typeof value !== 'object')
            return;
        for (const [key, nested] of Object.entries(value)) {
            if (['content', 'summary'].includes(key))
                visit(nested, key);
            else if (['text', 'refusal', 'arguments', 'input'].includes(key))
                visit(nested, key);
        }
    };
    visit(output);
    if (characters === 0 && typeof response?.output_text === 'string') {
        characters = response.output_text.length;
    }
    return characters;
}
function resolveNativeUsage(usage, estimatedInputTokens, observedOutputChars, trustCacheUsage = true) {
    const providerInputTokens = firstNativeUsageToken(usage?.input_tokens, usage?.prompt_tokens);
    const providerOutputTokens = firstNativeUsageToken(usage?.output_tokens, usage?.completion_tokens);
    const providerCachedInputTokens = firstNativeUsageToken(codexCachedInputTokensFromUsage(usage));
    const providerCacheWriteTokens = firstNativeUsageToken(codexCacheWriteTokensFromUsage(usage));
    const inputTokens = providerInputTokens
        ?? Math.max(1, Math.floor(estimatedInputTokens));
    const outputTokens = providerOutputTokens
        ?? estimatedTokensFromCharacters(observedOutputChars);
    const cachedInputTokens = trustCacheUsage
        ? Math.min(inputTokens, providerCachedInputTokens ?? 0)
        : 0;
    const cacheWriteTokens = trustCacheUsage
        ? Math.min(inputTokens - cachedInputTokens, providerCacheWriteTokens ?? 0)
        : 0;
    return {
        inputTokens,
        // Missing cache metadata is intentionally treated as uncached. Guessing a
        // positive cache hit would apply a discount and silently undercharge.
        cachedInputTokens,
        cacheWriteTokens,
        outputTokens,
        inputSource: providerInputTokens === null ? 'estimate' : 'provider',
        cachedInputSource: !trustCacheUsage || providerCachedInputTokens === null
            ? 'conservative_zero'
            : 'provider',
        cacheWriteSource: !trustCacheUsage || providerCacheWriteTokens === null
            ? 'conservative_zero'
            : 'provider',
        outputSource: providerOutputTokens === null ? 'estimate' : 'provider',
    };
}
// Chat-protocol relays use the OpenAI-compatible usage names, but they may
// still report Codex cache details in either prompt_tokens_details or
// input_tokens_details. Keep the same conservative trust gate as native
// Responses while normalizing both shapes for the compatibility adapter.
function resolveCompatUsage(usage, estimatedInputTokens, observedOutputTokens, trustCacheUsage = true) {
    const providerInputTokens = firstNativeUsageToken(usage?.prompt_tokens, usage?.input_tokens);
    const providerOutputTokens = firstNativeUsageToken(usage?.completion_tokens, usage?.output_tokens);
    const providerCachedInputTokens = firstNativeUsageToken(codexCachedInputTokensFromUsage(usage));
    const providerCacheWriteTokens = firstNativeUsageToken(codexCacheWriteTokensFromUsage(usage));
    const inputTokens = providerInputTokens ?? Math.max(1, Math.floor(estimatedInputTokens));
    const outputTokens = providerOutputTokens ?? Math.max(0, Math.floor(observedOutputTokens));
    const cachedInputTokens = trustCacheUsage
        ? Math.min(inputTokens, providerCachedInputTokens ?? 0)
        : 0;
    const cacheWriteTokens = trustCacheUsage
        ? Math.min(inputTokens - cachedInputTokens, providerCacheWriteTokens ?? 0)
        : 0;
    return {
        inputTokens,
        cachedInputTokens,
        cacheWriteTokens,
        outputTokens,
        inputSource: providerInputTokens === null ? 'estimate' : 'provider',
        cachedInputSource: !trustCacheUsage || providerCachedInputTokens === null
            ? 'conservative_zero'
            : 'provider',
        cacheWriteSource: !trustCacheUsage || providerCacheWriteTokens === null
            ? 'conservative_zero'
            : 'provider',
        outputSource: providerOutputTokens === null ? 'estimate' : 'provider',
    };
}
function cacheUsageTrustedForNativeRelay(route, nativeRelay) {
    if (!nativeRelay)
        return true;
    // Compatibility probes are diagnostics only. Billing follows the usage
    // counters returned by the enabled upstream unless an administrator has
    // explicitly disabled trust for that relay.
    return route.codexRelayCacheUsageTrusted !== false;
}
function nativeUsageForRecording(usage, resolved) {
    if (resolved.inputSource === 'provider' && resolved.outputSource === 'provider') {
        return normalizeCodexPromptCacheUsage(usage, 'input_tokens_details');
    }
    const normalizedUsage = normalizeCodexPromptCacheUsage(usage && typeof usage === 'object' ? usage : {}, 'input_tokens_details');
    const providerInputDetails = normalizedUsage?.input_tokens_details;
    const inputDetails = providerInputDetails
        || resolved.cachedInputTokens > 0
        || resolved.cacheWriteTokens > 0
        ? {
            ...(providerInputDetails && typeof providerInputDetails === 'object'
                ? providerInputDetails
                : {}),
            cached_tokens: resolved.cachedInputTokens,
            cache_write_tokens: resolved.cacheWriteTokens,
        }
        : undefined;
    return {
        ...normalizedUsage,
        input_tokens: resolved.inputTokens,
        ...(inputDetails ? { input_tokens_details: inputDetails } : {}),
        output_tokens: resolved.outputTokens,
        total_tokens: firstNativeUsageToken(usage?.total_tokens)
            ?? resolved.inputTokens + resolved.outputTokens,
    };
}
function auditNativeRelayUsageFallback(requestId, route, resolved) {
    if (resolved.inputSource === 'provider' && resolved.outputSource === 'provider')
        return;
    console.warn('[Responses] native-relay-usage-fallback', requestId, `source=${route.codexRelaySourceId ?? 'unknown'}`, `model=${route.billingModelId ?? route.modelId}`, `input=${resolved.inputTokens}:${resolved.inputSource}`, `cached=${resolved.cachedInputTokens}:${resolved.cachedInputSource}`, `cache_write=${resolved.cacheWriteTokens}:${resolved.cacheWriteSource}`, `output=${resolved.outputTokens}:${resolved.outputSource}`);
}
function isNativeResponsesObject(value) {
    return Boolean(value
        && typeof value === 'object'
        && value.object === 'response'
        && typeof value.id === 'string'
        && value.id.length > 0
        && typeof value.model === 'string'
        && value.model.length > 0
        && typeof value.status === 'string'
        && value.status.length > 0);
}
function nativeResponseHasToolCall(value) {
    return Array.isArray(value?.output) && value.output.some((item) => (item?.type === 'function_call' || item?.type === 'custom_tool_call'));
}
const NATIVE_CODEX_PRECOMMIT_BUFFER_LIMIT = 64 * 1024;
const NATIVE_RESPONSES_INACTIVITY_TIMEOUT_MS = 120_000;
async function readNativeResponsesChunk(reader) {
    let timer;
    return Promise.race([
        reader.read(),
        new Promise((_, reject) => {
            timer = setTimeout(() => reject(Object.assign(new Error(`Native Responses stream stalled for ${NATIVE_RESPONSES_INACTIVITY_TIMEOUT_MS}ms`), { status: 504 })), NATIVE_RESPONSES_INACTIVITY_TIMEOUT_MS);
        }),
    ]).finally(() => clearTimeout(timer));
}
function nativeResponsesPayloadError(payload, fallback) {
    const details = responsePayloadErrorDetails(payload, fallback);
    if (!details)
        return null;
    const code = typeof details.code === 'string' && details.code.trim()
        ? details.code.trim()
        : undefined;
    const type = typeof details.type === 'string' && details.type.trim()
        ? details.type.trim()
        : undefined;
    const failure = new Error(sanitizeProviderErrorMessage(details.message));
    failure.status = 502;
    if (code) {
        failure.code = code;
        failure.upstreamCode = code;
    }
    if (type) {
        failure.type = type;
        failure.upstreamType = type;
    }
    return failure;
}
function nativeCodexEventError(event, metadata) {
    if (event?.type !== 'error' && event?.type !== 'response.failed')
        return null;
    const upstreamError = event?.response?.error && typeof event.response.error === 'object'
        ? event.response.error
        : event?.error && typeof event.error === 'object'
            ? event.error
            : undefined;
    const failure = new Error(String(metadata?.message
        ?? upstreamError?.message
        ?? event?.message
        ?? 'Codex stream failed before producing output'));
    const upstreamCode = metadata
        ? metadata.code
        : typeof (upstreamError?.code ?? event?.code) === 'string'
            ? String(upstreamError?.code ?? event?.code).trim()
            : undefined;
    const upstreamType = metadata
        ? metadata.type
        : typeof upstreamError?.type === 'string'
            ? upstreamError.type.trim()
            : undefined;
    const status = metadata
        ? metadata.status
        : [
            upstreamError?.status,
            upstreamError?.status_code,
            event?.response?.status_code,
            event?.status_code,
            event?.status,
        ]
            .map((candidate) => Number(candidate))
            .find((candidate) => Number.isInteger(candidate) && candidate >= 100 && candidate <= 599);
    if (upstreamCode)
        failure.upstreamCode = upstreamCode;
    if (upstreamType)
        failure.upstreamType = upstreamType;
    if (status !== undefined)
        failure.status = status;
    return failure;
}
function isMeaningfulNativeCodexEvent(event) {
    const type = String(event?.type ?? '');
    return type === 'response.completed'
        || type === 'response.incomplete'
        || type === 'response.output_item.added'
        || type === 'response.output_text.delta'
        || type === 'response.refusal.delta'
        || type === 'response.reasoning_summary_text.delta'
        || type === 'response.function_call_arguments.delta'
        || type === 'response.custom_tool_call_input.delta';
}
function inspectNativeCodexPrecommit(raw, metadata) {
    let meaningfulOutputSeen = false;
    for (const event of parseNativeCodexEvents(raw)) {
        const error = nativeCodexEventError(event, metadata);
        if (error) {
            return meaningfulOutputSeen ? { commit: true, error: null } : { commit: false, error };
        }
        if (isMeaningfulNativeCodexEvent(event))
            meaningfulOutputSeen = true;
    }
    return { commit: meaningfulOutputSeen, error: null };
}
responsesRouter.post('/responses/compact', async (req, res) => {
    const start = Date.now();
    const requestGroupId = getRequestGroupId(req);
    res.setHeader('X-Request-ID', requestGroupId);
    const token = extractApiToken(req);
    const unifiedKey = getUnifiedApiKey();
    if (!token || !timingSafeStringEqual(token, unifiedKey)) {
        res.status(401).json({ error: { message: 'Invalid API key', type: 'authentication_error' } });
        return;
    }
    const parsed = compactRequestSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({
            error: {
                message: `Invalid request: ${parsed.error.errors.map((e) => `${e.path.join('.')}: ${e.message}`).join(', ')}`,
                type: 'invalid_request_error',
            },
        });
        return;
    }
    const reqData = parsed.data;
    const clientContext = getClientContext();
    try {
        validateLocalCompactionInput(reqData.input);
    }
    catch (error) {
        if (sendLocalCompactionValidationError(res, error))
            return;
        throw error;
    }
    // Ordinary/unified compatibility callers have no group-owned native
    // Responses source. Preserve the legacy local helper for them only. A
    // Codex-pool key always uses real upstream semantic compaction below.
    if (clientContext.consumerApiKeyType !== 'codex_pool') {
        sendLocalCompaction(res, reqData, 'local-compat');
        return;
    }
    let existingPin;
    let compactBody;
    const consumerKeyId = clientContext.consumerApiKeyId;
    const requestedModel = normalizeCodexModelId(reqData.model.trim());
    try {
        existingPin = findCodexCompactionUpstreamPin(reqData.input);
        if (existingPin && existingPin.publicModelId !== requestedModel) {
            throw new CodexCompactionEnvelopeError(`This compacted conversation belongs to model '${existingPin.publicModelId}', not '${requestedModel}'.`);
        }
        compactBody = existingPin
            ? unwrapCodexCompactionRequest(req.body, existingPin)
            : structuredClone(req.body);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : 'Invalid compacted conversation state.';
        res.status(400).json({
            error: {
                message,
                type: 'invalid_request_error',
                code: error instanceof CodexCompactionEnvelopeError
                    ? error.code
                    : 'invalid_compaction_state',
            },
        });
        return;
    }
    const modelDbId = consumerKeyId === null
        ? null
        : existingPin
            ? getCodexConsumerGroupModelDbId('codex_pool', consumerKeyId, requestedModel)
            : getCodexConsumerModelDbId('codex_pool', consumerKeyId, requestedModel);
    if (modelDbId === null) {
        res.status(400).json({
            error: {
                message: `Codex model '${requestedModel}' is not available for this API key. Refresh /v1/models and select one of the returned models.`,
                type: 'invalid_request_error',
                code: 'model_not_available_for_key',
            },
        });
        return;
    }
    const estimatedInputTokens = Math.max(1, Math.ceil(JSON.stringify(reqData.input).length / 4));
    const strictModelChain = resolveModelGroupCandidates([modelDbId]);
    const rawSessionId = req.headers['x-session-id'];
    const sessionIdHeader = Array.isArray(rawSessionId) ? rawSessionId[0] : rawSessionId;
    const turnId = typeof reqData.client_metadata?.turn_id === 'string'
        ? reqData.client_metadata.turn_id
        : undefined;
    const stablePrefixSeed = nativeResponsesStablePrefixSeed(req.body);
    const affinityKey = [
        consumerKeyId ?? 'operator',
        reqData.prompt_cache_key ?? sessionIdHeader ?? turnId ?? stablePrefixSeed,
    ].join(':');
    const state = newFallbackState();
    const attemptLog = [];
    await runFallbackLoop({
        maxRetries: MAX_RETRIES,
        state,
        attemptLog,
        clientGone: () => res.destroyed,
        route: () => routeRequest(estimatedInputTokens, state.skipKeys.size > 0 ? state.skipKeys : undefined, modelDbId, false, false, state.skipModels.size > 0 ? state.skipModels : undefined, strictModelChain, false, 'responses', affinityKey, existingPin ?? undefined, true, state.skipRelaySources.size > 0 ? state.skipRelaySources : undefined, false, false, existingPin !== null),
        dispatch: async (route, attempt) => {
            const nativeRelay = route.platform === 'openai-codex'
                && route.codexSource === 'relay'
                && route.codexRelayProtocol === 'responses'
                && typeof route.codexRelayBaseUrl === 'string'
                && route.codexRelaySourceId != null;
            const nativeOauth = route.platform === 'openai-codex'
                && route.codexSource !== 'relay'
                && supportsNativeCodexCompaction(route.provider);
            if (!nativeRelay && !nativeOauth) {
                throw Object.assign(new Error('Selected upstream does not support native Responses compaction.'), { status: 502 });
            }
            const routePin = nativeRelay
                ? {
                    sourceType: 'relay',
                    targetId: route.codexRelaySourceId,
                    relayApiKeyId: route.keyId,
                    publicModelId: route.billingModelId ?? requestedModel,
                    upstreamModelId: route.modelId,
                }
                : {
                    sourceType: 'oauth',
                    targetId: Math.abs(route.keyId),
                    publicModelId: route.billingModelId ?? requestedModel,
                    upstreamModelId: route.modelId,
                };
            if (existingPin && (routePin.sourceType !== existingPin.sourceType
                || routePin.targetId !== existingPin.targetId
                || (existingPin.relayApiKeyId !== undefined
                    && routePin.relayApiKeyId !== existingPin.relayApiKeyId)
                || routePin.publicModelId !== existingPin.publicModelId
                || routePin.upstreamModelId !== existingPin.upstreamModelId)) {
                throw Object.assign(new Error('The upstream that owns this compacted conversation is unavailable.'), { status: 503 });
            }
            const upstreamBody = prepareNativeResponsesCompactRequestBody(compactBody, route.modelId);
            let accountDbId = null;
            let releaseSlot;
            try {
                traceRouteEvent('Responses', {
                    event: attempt === 0 ? 'start' : 'next',
                    requestId: requestGroupId,
                    attempt,
                    platform: route.platform,
                    model: route.modelId,
                });
                const upstream = nativeRelay
                    ? {
                        response: await requestNativeResponsesCompactRelay({
                            baseUrl: route.codexRelayBaseUrl,
                            apiKey: route.apiKey,
                            body: upstreamBody,
                            sessionId: sessionIdHeader,
                        }),
                        accountDbId: null,
                        releaseSlot: undefined,
                    }
                    : await route.provider.nativeResponsesCompact(route.apiKey, route.modelId, upstreamBody);
                accountDbId = upstream.accountDbId;
                releaseSlot = upstream.releaseSlot;
                const raw = await upstream.response.text();
                let payload;
                try {
                    payload = JSON.parse(raw);
                }
                catch {
                    throw Object.assign(new Error('Upstream returned non-JSON compaction data.'), { status: 502 });
                }
                const embeddedUpstreamError = responsePayloadErrorDetails(payload, 'Upstream returned an error object');
                if (embeddedUpstreamError) {
                    const code = typeof embeddedUpstreamError.code === 'string'
                        && embeddedUpstreamError.code.trim()
                        ? embeddedUpstreamError.code.trim()
                        : undefined;
                    const message = sanitizeProviderErrorMessage(embeddedUpstreamError.message);
                    const error = Object.assign(new Error(`Upstream compaction error${code ? ` (${code})` : ''}: ${message}`), {
                        status: 502,
                        code,
                        upstreamCode: code,
                        type: typeof embeddedUpstreamError.type === 'string'
                            ? embeddedUpstreamError.type
                            : undefined,
                        upstreamType: typeof embeddedUpstreamError.type === 'string'
                            ? embeddedUpstreamError.type
                            : undefined,
                    });
                    throw error;
                }
                let wrapped;
                try {
                    wrapped = wrapCodexCompactionResponse(payload, routePin);
                }
                catch (error) {
                    throw Object.assign(new Error(error instanceof Error ? error.message : 'Invalid upstream compaction response.'), { status: 502 });
                }
                const usage = payload?.usage;
                const fallbackOutputChars = JSON.stringify(payload?.output ?? '').length;
                const resolvedUsage = resolveNativeUsage(usage, estimatedInputTokens, fallbackOutputChars, cacheUsageTrustedForNativeRelay(route, nativeRelay));
                assertWalletStreamBudget(getDb(), {
                    platform: route.platform,
                    modelId: route.billingModelId ?? requestedModel,
                    inputTokens: resolvedUsage.inputTokens,
                    outputTokens: resolvedUsage.outputTokens,
                    cachedInputTokens: resolvedUsage.cachedInputTokens,
                    cacheWriteTokens: resolvedUsage.cacheWriteTokens,
                });
                if (nativeOauth && accountDbId !== null) {
                    route.provider.recordNativeResponsesUsage({
                        accountDbId,
                        modelId: route.modelId,
                        success: true,
                        usage: nativeUsageForRecording(usage, resolvedUsage),
                    });
                }
                recordUpstreamSuccess(route, resolvedUsage.inputTokens + resolvedUsage.outputTokens);
                setFallbackHeaders(res, attempt, attemptLog);
                res.setHeader('X-Routed-Via', `${route.platform}/${route.billingModelId ?? requestedModel}`);
                res.setHeader('X-Compaction-Mode', 'upstream');
                res.json(wrapped);
                logRequest(route.platform, route.billingModelId ?? requestedModel, route.keyId, 'success', resolvedUsage.inputTokens, resolvedUsage.outputTokens, Date.now() - start, null, null, null, resolvedUsage.cachedInputTokens, resolvedUsage.cacheWriteTokens);
                return 'done';
            }
            catch (error) {
                if (nativeOauth) {
                    const trackedAccountId = accountDbId
                        ?? Number(error?.codexAccountDbId);
                    if (Number.isSafeInteger(trackedAccountId) && trackedAccountId > 0) {
                        route.provider.recordNativeResponsesUsage({
                            accountDbId: trackedAccountId,
                            modelId: route.modelId,
                            success: false,
                            error: error instanceof Error ? error.message : String(error),
                        });
                    }
                }
                const upstreamStatus = Number(error?.status
                    ?? error?.codexStatus);
                if ([404, 405, 501].includes(upstreamStatus)) {
                    Object.assign(error, { status: 502 });
                }
                throw error;
            }
            finally {
                releaseSlot?.();
            }
        },
        logFailure: (route, error, attempt) => {
            const safeError = sanitizeProviderErrorMessage(error.message);
            traceRouteEvent('Responses', {
                event: 'fail',
                requestId: requestGroupId,
                attempt,
                platform: route.platform,
                model: route.modelId,
                latencyMs: Date.now() - start,
                error: safeError,
            });
            logRequest(route.platform, route.billingModelId ?? requestedModel, route.keyId, 'error', estimatedInputTokens, 0, Date.now() - start, safeError);
        },
        onFatal: (route, error, attempt) => {
            setFallbackHeaders(res, attempt, attemptLog);
            res.status(502).json({
                error: {
                    message: `Compaction provider error (${route.displayName}): ${sanitizeProviderErrorMessage(error.message)}`,
                    type: 'provider_error',
                },
            });
        },
        onRoutingExhausted: (_lastError, routeError, exhaustion, info) => {
            setFallbackHeaders(res, info.attempts.length, info.attempts, exhaustion?.retryAfterMs);
            if (!existingPin) {
                sendLocalCompaction(res, reqData, 'local-fallback');
                return;
            }
            res.status(exhaustion?.status ?? routeError.status ?? 503).json({
                error: {
                    message: 'The upstream that owns this compacted conversation is unavailable; its opaque state cannot be moved to another supplier.',
                    type: 'compaction_unavailable',
                    code: 'compaction_unavailable',
                },
            });
        },
        onExhausted: (exhaustion, info) => {
            setFallbackHeaders(res, info.attempts.length, info.attempts, exhaustion.retryAfterMs);
            if (!existingPin) {
                sendLocalCompaction(res, reqData, 'local-fallback');
                return;
            }
            res.status(exhaustion.status).json({
                error: {
                    message: 'The upstream that owns this compacted conversation is unavailable; its opaque state cannot be moved to another supplier.',
                    type: 'compaction_unavailable',
                    code: 'compaction_unavailable',
                },
            });
        },
    });
});
responsesRouter.post('/responses', async (req, res) => {
    const start = Date.now();
    const requestGroupId = getRequestGroupId(req);
    res.setHeader('X-Request-ID', requestGroupId);
    // Same unified-key auth as the proxy (accepts Bearer or x-api-key).
    const token = extractApiToken(req);
    const unifiedKey = getUnifiedApiKey();
    if (!token || !timingSafeStringEqual(token, unifiedKey)) {
        res.status(401).json({ error: { message: 'Invalid API key', type: 'authentication_error' } });
        return;
    }
    const parsed = responsesRequestSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({
            error: {
                message: `Invalid request: ${parsed.error.errors.map((e) => `${e.path.join('.')}: ${e.message}`).join(', ')}`,
                type: 'invalid_request_error',
            },
        });
        return;
    }
    const reqData = parsed.data;
    let compactionPin;
    let nativeRequestBody;
    try {
        compactionPin = findCodexCompactionUpstreamPin(Array.isArray(reqData.input) ? reqData.input : null);
        nativeRequestBody = compactionPin
            ? unwrapCodexCompactionRequest(req.body, compactionPin)
            : req.body;
        validateLocalCompactionInput(nativeRequestBody.input);
        nativeRequestBody = restoreLocalCompactionForNativeRequest(nativeRequestBody);
    }
    catch (error) {
        if (sendLocalCompactionValidationError(res, error))
            return;
        res.status(400).json({
            error: {
                message: error instanceof Error ? error.message : 'Invalid compacted conversation state.',
                type: 'invalid_request_error',
                code: error instanceof CodexCompactionEnvelopeError
                    ? error.code
                    : 'invalid_compaction_state',
            },
        });
        return;
    }
    if (compactionPin && getClientContext().consumerApiKeyType !== 'codex_pool') {
        res.status(403).json({
            error: {
                message: 'This compacted conversation belongs to a Codex-pool upstream.',
                type: 'permission_error',
                code: 'compaction_upstream_scope_mismatch',
            },
        });
        return;
    }
    // Vision isn't carried through the Responses translation yet — fail clearly
    // instead of answering blind to a dropped image (#118, #125).
    const stream = reqData.stream ?? false;
    const messages = toChatMessages(reqData);
    const tools = toChatTools(reqData.tools);
    const customToolNames = new Set((reqData.tools ?? []).filter((tool) => tool.type === 'custom' && tool.name).map((tool) => tool.name));
    // name → parameter schema, for repairing double-encoded tool arguments on
    // the way back out (see lib/tool-args.ts).
    const toolSchemas = toolSchemaMap(tools);
    const tool_choice = tools?.length ? toChatToolChoice(reqData.tool_choice) : undefined;
    // Responses-API structured output arrives as `text.format`; translate it to
    // the internal response_format shape (an explicit response_format on the
    // body, unusual for this surface but valid, wins).
    const samplingParams = pickSamplingParams(reqData);
    const textFormat = reqData.text?.format;
    if (!samplingParams.response_format && textFormat && textFormat.type !== 'text') {
        samplingParams.response_format = textFormat.type === 'json_schema'
            ? { type: 'json_schema', json_schema: { name: textFormat.name, strict: textFormat.strict, schema: textFormat.schema } }
            : { type: 'json_object' };
    }
    const completionOpts = {
        temperature: reqData.temperature ?? undefined,
        max_tokens: reqData.max_output_tokens ?? undefined,
        top_p: reqData.top_p ?? undefined,
        tools,
        tool_choice,
        parallel_tool_calls: reqData.parallel_tool_calls ?? undefined,
        ...samplingParams,
    };
    const estimatedInputTokens = Math.max(1, messages.reduce((sum, m) => sum + Math.ceil(contentToString(m.content).length / 4), 0));
    // Capped output reserve so a large max_output_tokens can't falsely exclude the
    // model pool (#470); input counts in full.
    const estimatedTotal = estimatedInputTokens + routingReserveTokens(reqData.max_output_tokens);
    // Guardrail: per-request token budget (request_max_tokens_budget, default
    // off). A request with no max_output_tokens gets its output capped to the
    // budget remainder instead of a rejection.
    const budgetCheck = applyTokenBudget(estimatedInputTokens, completionOpts.max_tokens);
    if (budgetCheck.rejection) {
        res.status(413).json({
            error: { message: tokenBudgetMessage(budgetCheck.rejection), type: 'invalid_request_error', code: 'request_token_budget' },
        });
        return;
    }
    completionOpts.max_tokens = budgetCheck.maxTokens;
    // Optional client-managed session affinity (mirrors /chat/completions).
    const rawSessionId = req.headers['x-session-id'];
    const sessionIdHeader = Array.isArray(rawSessionId) ? rawSessionId[0] : rawSessionId;
    let preferredModel = getStickyModel(messages, sessionIdHeader);
    let strictModelChain;
    const consumerKeyType = getClientContext().consumerApiKeyType;
    const rawRequestedModel = reqData.model?.trim();
    const requestedModel = rawRequestedModel ? normalizeCodexModelId(rawRequestedModel) : rawRequestedModel;
    if (compactionPin
        && requestedModel
        && requestedModel !== 'codex'
        && compactionPin.publicModelId !== requestedModel) {
        res.status(400).json({
            error: {
                message: `This compacted conversation belongs to model '${compactionPin.publicModelId}', not '${requestedModel}'.`,
                type: 'invalid_request_error',
                code: 'compaction_model_mismatch',
            },
        });
        return;
    }
    const isVirtualAuto = !requestedModel
        || requestedModel.toLowerCase() === 'auto'
        || requestedModel.toLowerCase().startsWith('auto:');
    if (!isVirtualAuto
        && (consumerKeyType === 'codex_pool' || consumerKeyType === 'resource_subpool')) {
        const consumerKeyId = getClientContext().consumerApiKeyId;
        const modelDbId = consumerKeyId === null
            ? null
            : compactionPin
                ? getCodexConsumerGroupModelDbId(consumerKeyType, consumerKeyId, requestedModel)
                : getCodexConsumerModelDbId(consumerKeyType, consumerKeyId, requestedModel);
        if (modelDbId === null) {
            res.status(400).json({
                error: {
                    message: `Codex model '${requestedModel}' is not available for this API key. Refresh /v1/models and select one of the returned models.`,
                    type: 'invalid_request_error',
                    code: 'model_not_available_for_key',
                },
            });
            return;
        }
        preferredModel = modelDbId;
        strictModelChain = resolveModelGroupCandidates([modelDbId]);
    }
    else if (!isVirtualAuto) {
        const db = getDb();
        // Codex Desktop sends native Codex model ids to the Responses surface even
        // with a unified/universal key. Those ids are compatibility aliases for
        // the ordinary pool, not permission to use the scoped Codex OAuth pool.
        // Preserve that established behavior only when the id has no ordinary
        // billable counterpart; every real ordinary model below is strict-pinned.
        const ordinaryMatch = Boolean(db.prepare(`
      SELECT 1
      FROM models m
      JOIN model_billing_rules b
        ON b.platform = m.platform
       AND b.model_id = m.model_id
      WHERE m.platform <> 'openai-codex'
        AND m.model_id = ?
        AND m.enabled = 1
        AND b.billing_enabled = 1
      LIMIT 1
    `).get(requestedModel));
        const nativeCodexAlias = rawRequestedModel === 'openai-codex/codex'
            || requestedModel === 'codex'
            || Boolean(db.prepare(`
        SELECT 1
        FROM models
        WHERE platform = 'openai-codex'
          AND model_id = ?
          AND enabled = 1
        LIMIT 1
      `).get(requestedModel));
        const preserveResponsesCompatibilityAlias = (consumerKeyType === null || consumerKeyType === 'universal')
            && nativeCodexAlias
            && !ordinaryMatch;
        if (!preserveResponsesCompatibilityAlias) {
            // An explicit model must use that logical model's provider group. Routing
            // it through the global auto chain would make prepaid admission/billing
            // disagree with the delivered model.
            const members = isUnifyEnabled()
                ? resolveRequestedIdToMembers(requestedModel, getModelGroups())
                : null;
            if (members && members.length > 0) {
                strictModelChain = resolveModelGroupCandidates(members);
                if (strictModelChain.length === 0) {
                    const placeholders = members.map(() => '?').join(',');
                    const anyEnabled = db.prepare(`SELECT 1 FROM models WHERE id IN (${placeholders}) AND enabled = 1 LIMIT 1`).get(...members);
                    const reason = anyEnabled ? 'has no providers with an enabled key' : 'is disabled';
                    res.status(400).json({
                        error: {
                            message: `Model '${requestedModel}' ${reason}. Use 'auto' (or omit the 'model' field) to auto-route, or call /v1/models for the available list.`,
                            type: 'invalid_request_error',
                            code: 'model_not_found',
                        },
                    });
                    return;
                }
            }
            else {
                const enabled = db.prepare('SELECT id FROM models WHERE model_id = ? AND enabled = 1').get(requestedModel);
                if (enabled) {
                    preferredModel = enabled.id;
                }
                else {
                    const disabled = db.prepare('SELECT id FROM models WHERE model_id = ?').get(requestedModel);
                    const reason = disabled ? 'is disabled' : 'is not in the catalog';
                    res.status(400).json({
                        error: {
                            message: `Model '${requestedModel}' ${reason}. Use 'auto' (or omit the 'model' field) to auto-route, or call /v1/models for the available list.`,
                            type: 'invalid_request_error',
                            code: 'model_not_found',
                        },
                    });
                    return;
                }
            }
        }
    }
    const requestedModelLabel = reqData.model ?? 'auto';
    // Tool-bearing requests (the normal case for Codex/agent clients on this
    // endpoint) must stay on models that emit structured tool_calls. Make the
    // routing decision from the original Responses payload, not the subset of
    // function tools we can forward to chat providers, because Codex may include
    // built-in tool descriptors alongside or instead of function descriptors.
    const wantsTools = requestDeclaresToolUse(reqData);
    const wantsVision = responsesInputHasImage(reqData);
    const canAutoRequireTools = wantsTools
        && reqData.tool_choice !== 'required'
        && !hasToolResultInput(reqData);
    let forceRequiredTools = false;
    let forcedRetryRoute = null;
    if (wantsTools && !hasEnabledToolsModel()) {
        res.status(422).json({
            error: {
                message: 'This request includes tools, but no tool-capable model is enabled. Enable a tool-calling model (e.g. GPT-OSS 120B, Gemini 3.5 Flash, GLM-4.7) in the Fallback Chain.',
                type: 'invalid_request_error',
                code: 'no_tools_model',
            },
        });
        return;
    }
    const responseId = newId('resp');
    const responseCreatedAt = nowUnix();
    const nativeRelayStablePrefixSeed = nativeResponsesStablePrefixSeed(req.body);
    const nativeRelayAffinityKey = [
        getClientContext().consumerApiKeyId ?? 'operator',
        typeof req.body?.prompt_cache_key === 'string'
            ? req.body.prompt_cache_key
            : sessionIdHeader ?? nativeRelayStablePrefixSeed,
    ].join(':');
    const relayHasUpstreamState = compactionPin !== null
        || (typeof nativeRequestBody.previous_response_id === 'string'
            && nativeRequestBody.previous_response_id.trim().length > 0)
        || nativeRequestBody.conversation != null;
    const state = newFallbackState();
    const attemptLog = [];
    let clientGone = false;
    res.on('close', () => { if (!res.writableEnded)
        clientGone = true; });
    // Stream bookkeeping (used only when stream === true). `streamStarted` is the
    // commit flag: true once the response.created/in_progress skeleton has left,
    // after which failover is no longer possible. seq/streamStarted span attempts
    // so the SSE sequence numbers stay monotonic and a committed stream can't be
    // re-committed by a later attempt.
    let seq = 0;
    let streamStarted = false;
    const sse = (event, payload) => {
        res.write(`event: ${event}\n`);
        res.write(`data: ${JSON.stringify({ type: event, sequence_number: seq++, ...payload })}\n\n`);
    };
    await runFallbackLoop({
        maxRetries: MAX_RETRIES,
        state,
        attemptLog,
        clientGone: () => clientGone,
        route: () => {
            if (forcedRetryRoute) {
                const route = forcedRetryRoute;
                forcedRetryRoute = null;
                return route;
            }
            return routeRequest(estimatedTotal, state.skipKeys.size > 0 ? state.skipKeys : undefined, preferredModel, wantsVision, wantsTools, state.skipModels.size > 0 ? state.skipModels : undefined, strictModelChain, completionOpts.response_format !== undefined, 'responses', nativeRelayAffinityKey, compactionPin ?? undefined, 
            // A compact pin only preserves upstream affinity for this ordinary
            // follow-up. It does not make the request a standalone /compact call:
            // real failures here must continue to update relay health.
            false, state.skipRelaySources.size > 0 ? state.skipRelaySources : undefined, stream, requiresCodexMultiTurnCapability(messages), relayHasUpstreamState);
        },
        dispatch: async (route, attempt) => {
            // Chat-protocol Codex relays only expose terminal usage when the
            // upstream stream is requested with include_usage. This is internal
            // bookkeeping; the Responses surface always presents usage in its final
            // response and does not expose a separate usage-only event.
            const collectCompatUsage = route.codexSource === 'relay'
                && route.codexRelayProtocol === 'chat_completions';
            const attemptOpts = {
                ...(forceRequiredTools
                    ? { ...completionOpts, tool_choice: 'required' }
                    : completionOpts),
                ...(collectCompatUsage ? { includeUsage: true } : {}),
            };
            traceRouteEvent('Responses', {
                event: attempt === 0 ? 'start' : 'next',
                requestId: requestGroupId,
                attempt,
                platform: route.platform,
                model: route.modelId,
                requestedModel: attempt === 0 ? requestedModelLabel : undefined,
            });
            const nativeOauthCodex = (consumerKeyType === 'codex_pool' || consumerKeyType === 'resource_subpool')
                && route.platform === 'openai-codex'
                && route.codexSource !== 'relay'
                && supportsNativeCodexResponses(route.provider);
            const nativeResponsesRelay = consumerKeyType === 'codex_pool'
                && route.platform === 'openai-codex'
                && route.codexSource === 'relay'
                && route.codexRelayProtocol === 'responses'
                && typeof route.codexRelayBaseUrl === 'string';
            if (nativeOauthCodex || nativeResponsesRelay) {
                const provider = nativeOauthCodex
                    ? route.provider
                    : null;
                let accountDbId = null;
                let nativeUsageRecorded = false;
                let nativeStreamCommitted = false;
                let nativeObservedUsage;
                let nativeObservedOutputChars = 0;
                let releaseSlot;
                const nativeRelayClientController = nativeResponsesRelay
                    ? new AbortController()
                    : null;
                const abortNativeRelayForClient = () => nativeRelayClientController?.abort();
                if (nativeRelayClientController) {
                    if (clientGone)
                        abortNativeRelayForClient();
                    else
                        res.once('close', abortNativeRelayForClient);
                }
                const recordNativeUsage = (args) => {
                    if (!provider || accountDbId === null || nativeUsageRecorded)
                        return;
                    nativeUsageRecorded = true;
                    provider.recordNativeResponsesUsage({ accountDbId, modelId: route.modelId, ...args });
                };
                try {
                    let upstreamBody = prepareNativeResponsesRequestBody(restoreLocalCompactionForNativeRequest(nativeRequestBody), route.modelId, nativeResponsesRelay ? stream : true, {
                        preserveUpstreamState: nativeResponsesRelay
                            && route.codexRelayPreserveUpstreamState === true,
                    });
                    const promptCacheIdentity = {
                        consumerKey: getClientContext().consumerApiKeyId ?? 'operator',
                        sessionId: sessionIdHeader,
                        stablePrefixSeed: nativeRelayStablePrefixSeed,
                    };
                    if (nativeOauthCodex && requiresExplicitPromptCache(route.modelId)) {
                        // The OAuth backend supports the cache-routing key but historically
                        // rejects public explicit-cache options/breakpoints. Keep native
                        // OAuth in safe key-only mode while preserving any client key.
                        upstreamBody = applyNativeResponsesPromptCacheKey(upstreamBody, promptCacheIdentity);
                    }
                    else if (nativeResponsesRelay
                        && route.codexRelayPromptCacheCertified === true
                        && relayMappingRequiresExplicitPromptCache(route.billingModelId ?? route.modelId, route.modelId)) {
                        upstreamBody = applyNativeResponsesExplicitPromptCache(upstreamBody, promptCacheIdentity);
                    }
                    if (completionOpts.max_tokens !== undefined) {
                        upstreamBody.max_output_tokens = completionOpts.max_tokens;
                    }
                    if (forceRequiredTools)
                        upstreamBody.tool_choice = 'required';
                    const upstream = nativeResponsesRelay
                        ? {
                            response: await requestNativeResponsesRelay({
                                baseUrl: route.codexRelayBaseUrl,
                                apiKey: route.apiKey,
                                body: upstreamBody,
                                sessionId: sessionIdHeader,
                                signal: nativeRelayClientController?.signal,
                            }),
                        }
                        : await provider.nativeResponses(route.apiKey, route.modelId, upstreamBody);
                    accountDbId = 'accountDbId' in upstream ? upstream.accountDbId : null;
                    releaseSlot = 'releaseSlot' in upstream
                        ? upstream.releaseSlot
                        : undefined;
                    if (stream) {
                        const reader = upstream.response.body?.getReader();
                        if (!reader)
                            throw new Error('Codex API returned no response body');
                        const decoder = new TextDecoder();
                        const publicModelId = route.billingModelId ?? route.modelId;
                        const sseRewriter = new NativeResponsesSseRewriter();
                        let precommitBuffer = '';
                        let terminalEvent;
                        let readerClosed = false;
                        // Preserve the relay-owned response id once exposed, but fall back
                        // to the gateway id so a locally synthesized terminal failure is
                        // still a valid Responses event.
                        let nativeResponseId = responseId;
                        let nativeSequenceNumber = null;
                        const observeNativeEvents = (raw) => {
                            for (const event of parseNativeCodexEvents(raw)) {
                                if (typeof event?.response?.id === 'string' && event.response.id) {
                                    nativeResponseId = event.response.id;
                                }
                                if (typeof event?.sequence_number === 'number' && Number.isFinite(event.sequence_number)) {
                                    nativeSequenceNumber = Math.floor(event.sequence_number);
                                }
                                nativeObservedOutputChars += nativeEventOutputChars(event);
                                const eventUsage = nativeEventUsage(event);
                                if (eventUsage && typeof eventUsage === 'object') {
                                    nativeObservedUsage = {
                                        ...(nativeObservedUsage && typeof nativeObservedUsage === 'object'
                                            ? nativeObservedUsage
                                            : {}),
                                        ...eventUsage,
                                        input_tokens_details: {
                                            ...(nativeObservedUsage?.input_tokens_details ?? {}),
                                            ...(eventUsage.input_tokens_details ?? {}),
                                        },
                                    };
                                }
                                if ([
                                    'response.completed',
                                    'response.incomplete',
                                    'response.failed',
                                    'error',
                                ].includes(event?.type)) {
                                    terminalEvent = event;
                                }
                            }
                        };
                        const emitNativeStreamFailure = (message = 'Provider stream interrupted', code = 'server_error') => {
                            if (clientGone || res.writableEnded)
                                return;
                            res.write('event: response.failed\n');
                            res.write(`data: ${JSON.stringify({
                                type: 'response.failed',
                                ...(nativeSequenceNumber === null ? {} : { sequence_number: nativeSequenceNumber + 1 }),
                                response: {
                                    id: nativeResponseId,
                                    object: 'response',
                                    status: 'failed',
                                    model: publicModelId,
                                    error: {
                                        code,
                                        message,
                                    },
                                },
                            })}\n\n`);
                        };
                        const cancelReader = async () => {
                            if (readerClosed)
                                return;
                            readerClosed = true;
                            await reader.cancel().catch(() => undefined);
                        };
                        const commitNativeStream = () => {
                            if (nativeStreamCommitted)
                                return;
                            nativeStreamCommitted = true;
                            streamStarted = true;
                            res.status(200);
                            res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
                            res.setHeader('Cache-Control', 'no-cache, no-transform');
                            res.setHeader('Connection', 'keep-alive');
                            res.setHeader('X-Accel-Buffering', 'no');
                            res.setHeader('X-Routed-Via', `${route.platform}/${route.billingModelId ?? route.modelId}`);
                            setFallbackHeaders(res, attempt, attemptLog);
                            if (precommitBuffer) {
                                res.write(precommitBuffer);
                                precommitBuffer = '';
                            }
                        };
                        try {
                            while (true) {
                                if (clientGone) {
                                    await cancelReader();
                                    break;
                                }
                                const { done, value } = await readNativeResponsesChunk(reader);
                                if (done) {
                                    readerClosed = true;
                                    break;
                                }
                                if (clientGone) {
                                    await cancelReader();
                                    break;
                                }
                                const chunk = sseRewriter.push(decoder.decode(value, { stream: true }), publicModelId);
                                if (!chunk)
                                    continue;
                                observeNativeEvents(chunk);
                                const liveUsage = resolveNativeUsage(nativeObservedUsage, estimatedInputTokens, nativeObservedOutputChars, cacheUsageTrustedForNativeRelay(route, nativeResponsesRelay));
                                assertWalletStreamBudget(getDb(), {
                                    platform: route.platform,
                                    modelId: route.billingModelId ?? route.modelId,
                                    inputTokens: liveUsage.inputTokens,
                                    outputTokens: liveUsage.outputTokens,
                                    cachedInputTokens: liveUsage.cachedInputTokens,
                                    cacheWriteTokens: liveUsage.cacheWriteTokens,
                                });
                                if (nativeStreamCommitted) {
                                    res.write(chunk);
                                }
                                else {
                                    precommitBuffer += chunk;
                                    const inspection = inspectNativeCodexPrecommit(precommitBuffer, sseRewriter.terminalErrorMetadata);
                                    if (inspection.error) {
                                        await cancelReader();
                                        // Preserve the upstream error only inside the pre-commit
                                        // retry path (for rate-limit/overload classification). The
                                        // rewriter has already replaced the wire-visible payload.
                                        throw inspection.error;
                                    }
                                    if (inspection.commit || precommitBuffer.length >= NATIVE_CODEX_PRECOMMIT_BUFFER_LIMIT) {
                                        commitNativeStream();
                                    }
                                }
                                if (terminalEvent) {
                                    await cancelReader();
                                    break;
                                }
                                if (sseRewriter.hasInvalidDataFrame) {
                                    throw new Error('Native Responses stream contained an invalid SSE data frame');
                                }
                            }
                            const tail = sseRewriter.push(decoder.decode(), publicModelId) + sseRewriter.flush(publicModelId);
                            if (tail) {
                                observeNativeEvents(tail);
                                if (nativeStreamCommitted)
                                    res.write(tail);
                                else
                                    precommitBuffer += tail;
                            }
                            if (!terminalEvent && sseRewriter.hasInvalidDataFrame) {
                                throw new Error('Native Responses stream contained an invalid SSE data frame');
                            }
                            if (clientGone && !nativeStreamCommitted)
                                return 'committed';
                            const completed = terminalEvent?.type === 'response.completed'
                                || terminalEvent?.type === 'response.incomplete';
                            const finalResponse = terminalEvent?.response ?? terminalEvent;
                            const terminalFailure = nativeCodexEventError(terminalEvent, sseRewriter.terminalErrorMetadata);
                            const errorMessage = terminalFailure?.message;
                            if (!completed && !nativeStreamCommitted) {
                                throw terminalFailure
                                    ?? new Error('Responses stream ended without a terminal event');
                            }
                            commitNativeStream();
                            const resolvedUsage = resolveNativeUsage(finalResponse?.usage ?? nativeObservedUsage, estimatedInputTokens, Math.max(nativeObservedOutputChars, nativeResponseOutputChars(finalResponse)), cacheUsageTrustedForNativeRelay(route, nativeResponsesRelay));
                            if (nativeResponsesRelay) {
                                auditNativeRelayUsageFallback(requestGroupId, route, resolvedUsage);
                            }
                            recordNativeUsage({
                                success: completed,
                                usage: nativeUsageForRecording(finalResponse?.usage ?? nativeObservedUsage, resolvedUsage),
                                error: errorMessage,
                            });
                            // A clean EOF after meaningful output is still an interrupted
                            // Responses stream when the relay never supplied a terminal
                            // event. Complete the public protocol before closing it.
                            if (!completed && !terminalEvent)
                                emitNativeStreamFailure();
                            if (!res.writableEnded)
                                res.end();
                            if (!completed) {
                                const safeError = sanitizeProviderErrorMessage(String(errorMessage ?? 'Responses relay stream ended unexpectedly'));
                                if (!clientGone) {
                                    recordCommittedUpstreamFailure(route, terminalFailure ?? new Error(safeError));
                                }
                                logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', resolvedUsage.inputTokens, resolvedUsage.outputTokens, Date.now() - start, safeError, null, null, resolvedUsage.cachedInputTokens, resolvedUsage.cacheWriteTokens);
                                return 'committed';
                            }
                            const inputTokens = resolvedUsage.inputTokens;
                            const outputTokens = resolvedUsage.outputTokens;
                            recordUpstreamSuccess(route, inputTokens + outputTokens);
                            setStickyModel(messages, route.modelDbId, sessionIdHeader);
                            logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'success', inputTokens, outputTokens, Date.now() - start, null, null, null, resolvedUsage.cachedInputTokens, resolvedUsage.cacheWriteTokens);
                            traceRouteEvent('Responses', { event: 'ok', requestId: requestGroupId, attempt, platform: route.platform, model: route.modelId, latencyMs: Date.now() - start, inputTokens, outputTokens });
                            return 'done';
                        }
                        catch (streamError) {
                            // Once bytes are public we cannot retry another relay. Return a
                            // well-formed terminal failure rather than silently truncating
                            // the client stream on a socket reset, idle timeout, or bad SSE.
                            if (nativeStreamCommitted) {
                                emitNativeStreamFailure(isWalletSafetyBalanceReachedError(streamError)
                                    ? WALLET_SAFETY_STOP_MESSAGE
                                    : 'Provider stream interrupted', isWalletSafetyBalanceReachedError(streamError)
                                    ? 'wallet_safety_balance_reached'
                                    : 'server_error');
                            }
                            throw streamError;
                        }
                        finally {
                            await cancelReader();
                            try {
                                reader.releaseLock();
                            }
                            catch { /* pending reads already cancelled */ }
                        }
                    }
                    const rawNativeResponse = await upstream.response.text();
                    const contentType = upstream.response.headers.get('content-type')?.toLowerCase() ?? '';
                    const looksLikeSse = contentType.includes('text/event-stream')
                        || /(^|\n)\s*(?:event|data):/.test(rawNativeResponse);
                    let finalResponse;
                    if (nativeResponsesRelay && !looksLikeSse) {
                        let parsedResponse;
                        try {
                            parsedResponse = JSON.parse(rawNativeResponse);
                        }
                        catch {
                            throw Object.assign(new Error('Responses relay returned a non-JSON response'), { status: 502 });
                        }
                        const embeddedUpstreamError = nativeResponsesPayloadError(parsedResponse, 'Responses relay returned an error object');
                        if (embeddedUpstreamError)
                            throw embeddedUpstreamError;
                        finalResponse = rewriteNativeResponsesModel(parsedResponse, route.billingModelId ?? route.modelId);
                    }
                    else {
                        const rewriter = new NativeResponsesSseRewriter();
                        const rewritten = rewriter.push(rawNativeResponse, route.billingModelId ?? route.modelId) + rewriter.flush(route.billingModelId ?? route.modelId);
                        const events = parseNativeCodexEvents(rewritten);
                        const terminal = [...events].reverse().find((event) => [
                            'response.completed',
                            'response.incomplete',
                            'response.failed',
                            'error',
                        ].includes(event?.type));
                        if (terminal?.type !== 'response.completed'
                            && terminal?.type !== 'response.incomplete') {
                            throw nativeCodexEventError(terminal, rewriter.terminalErrorMetadata) ?? new Error('Responses stream ended without a terminal event');
                        }
                        finalResponse = terminal.response ?? terminal;
                    }
                    if (nativeResponsesRelay
                        && (!isNativeResponsesObject(finalResponse)
                            || finalResponse.status === 'failed'
                            || finalResponse.error != null)) {
                        throw Object.assign(new Error(String(finalResponse?.error?.message
                            ?? finalResponse?.error
                            ?? 'Responses relay returned an invalid response object')), { status: 502 });
                    }
                    if (wantsTools
                        && (reqData.tool_choice === 'required' || forceRequiredTools)
                        && !nativeResponseHasToolCall(finalResponse)) {
                        throw Object.assign(new Error(`required tool call was not returned by ${route.displayName}`), { skipBench: true });
                    }
                    const resolvedUsage = resolveNativeUsage(finalResponse?.usage, estimatedInputTokens, nativeResponseOutputChars(finalResponse), cacheUsageTrustedForNativeRelay(route, nativeResponsesRelay));
                    if (nativeResponsesRelay) {
                        auditNativeRelayUsageFallback(requestGroupId, route, resolvedUsage);
                    }
                    recordNativeUsage({
                        success: true,
                        usage: nativeUsageForRecording(finalResponse?.usage, resolvedUsage),
                    });
                    const inputTokens = resolvedUsage.inputTokens;
                    const outputTokens = resolvedUsage.outputTokens;
                    try {
                        assertWalletStreamBudget(getDb(), {
                            platform: route.platform,
                            modelId: route.billingModelId ?? route.modelId,
                            inputTokens,
                            outputTokens,
                            cachedInputTokens: resolvedUsage.cachedInputTokens,
                            cacheWriteTokens: resolvedUsage.cacheWriteTokens,
                        });
                    }
                    catch (error) {
                        if (!isWalletSafetyBalanceReachedError(error))
                            throw error;
                        recordNativeUsage({
                            success: true,
                            usage: nativeUsageForRecording(finalResponse?.usage, resolvedUsage),
                        });
                        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', inputTokens, outputTokens, Date.now() - start, WALLET_SAFETY_STOP_MESSAGE, null, null, resolvedUsage.cachedInputTokens, resolvedUsage.cacheWriteTokens);
                        res.status(402).json({
                            error: {
                                message: WALLET_SAFETY_STOP_MESSAGE,
                                type: 'insufficient_balance',
                                code: 'wallet_safety_balance_reached',
                            },
                        });
                        return 'committed';
                    }
                    recordUpstreamSuccess(route, inputTokens + outputTokens);
                    setStickyModel(messages, route.modelDbId, sessionIdHeader);
                    res.setHeader('X-Routed-Via', `${route.platform}/${route.billingModelId ?? route.modelId}`);
                    setFallbackHeaders(res, attempt, attemptLog);
                    res.json(finalResponse);
                    logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'success', inputTokens, outputTokens, Date.now() - start, null, null, null, resolvedUsage.cachedInputTokens, resolvedUsage.cacheWriteTokens);
                    traceRouteEvent('Responses', { event: 'ok', requestId: requestGroupId, attempt, platform: route.platform, model: route.modelId, latencyMs: Date.now() - start, inputTokens, outputTokens });
                    return 'done';
                }
                catch (error) {
                    if (isWalletSafetyBalanceReachedError(error) && !nativeStreamCommitted) {
                        const resolvedUsage = resolveNativeUsage(nativeObservedUsage, estimatedInputTokens, nativeObservedOutputChars, cacheUsageTrustedForNativeRelay(route, nativeResponsesRelay));
                        recordNativeUsage({
                            success: false,
                            usage: nativeUsageForRecording(nativeObservedUsage, resolvedUsage),
                            error: WALLET_SAFETY_STOP_MESSAGE,
                        });
                        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', resolvedUsage.inputTokens, resolvedUsage.outputTokens, Date.now() - start, WALLET_SAFETY_STOP_MESSAGE, null, null, resolvedUsage.cachedInputTokens, resolvedUsage.cacheWriteTokens);
                        res.status(402).json({
                            error: {
                                message: WALLET_SAFETY_STOP_MESSAGE,
                                type: 'insufficient_balance',
                                code: 'wallet_safety_balance_reached',
                            },
                        });
                        return 'committed';
                    }
                    if (nativeStreamCommitted) {
                        const safeError = sanitizeProviderErrorMessage(error instanceof Error ? error.message : String(error));
                        if (!clientGone && !isWalletSafetyBalanceReachedError(error)) {
                            recordCommittedUpstreamFailure(route, error);
                        }
                        const resolvedUsage = resolveNativeUsage(nativeObservedUsage, estimatedInputTokens, nativeObservedOutputChars, cacheUsageTrustedForNativeRelay(route, nativeResponsesRelay));
                        if (nativeResponsesRelay) {
                            auditNativeRelayUsageFallback(requestGroupId, route, resolvedUsage);
                        }
                        recordNativeUsage({
                            success: false,
                            usage: nativeUsageForRecording(nativeObservedUsage, resolvedUsage),
                            error: safeError,
                        });
                        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', resolvedUsage.inputTokens, resolvedUsage.outputTokens, Date.now() - start, safeError, null, null, resolvedUsage.cachedInputTokens, resolvedUsage.cacheWriteTokens);
                        if (!res.writableEnded)
                            res.end();
                        return 'committed';
                    }
                    recordNativeUsage({ success: false, error: error instanceof Error ? error.message : String(error) });
                    throw error;
                }
                finally {
                    if (nativeRelayClientController) {
                        res.off('close', abortNativeRelayForClient);
                    }
                    releaseSlot?.();
                }
            }
            if (stream) {
                let outputIndex = 0;
                let msgItemId = null;
                let msgText = '';
                // tool-call accumulator keyed by the provider's tool_call index
                const toolAcc = new Map();
                let totalOutputTokens = 0;
                let streamUsage;
                const completedOutputItems = [];
                // Inline-dialect hold window (#231): first text is held until it
                // either matches a tool-call dialect marker (held to the end and
                // rescued into function_call items) or provably cannot (flushed and
                // streamed normally). Mirrors the /chat/completions stream loop.
                let dialectMode = 'undecided';
                let heldText = '';
                let upstreamFinish = null;
                // Commit point: headers + the response.created/in_progress skeleton go
                // out only when the first MEANINGFUL output item is about to be emitted
                // (converged with /chat/completions — responses previously committed on
                // the first raw chunk, even a role-only one). Until then a connect-time
                // error, an empty completion, or an unparseable dialect turn fails over
                // on the same connection with no bytes on the wire. Idempotent.
                const commit = () => {
                    if (streamStarted)
                        return;
                    res.setHeader('Content-Type', 'text/event-stream');
                    res.setHeader('Cache-Control', 'no-cache');
                    res.setHeader('Connection', 'keep-alive');
                    res.setHeader('X-Routed-Via', `${route.platform}/${route.billingModelId ?? route.modelId}`);
                    setFallbackHeaders(res, attempt, attemptLog);
                    const skeleton = buildResponseObject({
                        id: responseId, model: route.billingModelId ?? route.modelId, text: '', toolCalls: [],
                        promptTokens: 0, completionTokens: 0, createdAt: responseCreatedAt,
                        status: 'in_progress', outputItems: [],
                    });
                    sse('response.created', { response: skeleton });
                    sse('response.in_progress', { response: skeleton });
                    streamStarted = true;
                };
                // Open the text output item and stream `text` as its first delta.
                const openTextItem = (text) => {
                    commit();
                    msgItemId = newId('msg');
                    sse('response.output_item.added', {
                        output_index: outputIndex,
                        item: { id: msgItemId, type: 'message', status: 'in_progress', role: 'assistant', content: [] },
                    });
                    sse('response.content_part.added', {
                        item_id: msgItemId, output_index: outputIndex, content_index: 0,
                        part: { type: 'output_text', text: '', annotations: [] },
                    });
                    if (text) {
                        sse('response.output_text.delta', { item_id: msgItemId, output_index: outputIndex, content_index: 0, delta: text });
                        msgText += text;
                    }
                };
                try {
                    const gen = route.provider.streamChatCompletion(route.apiKey, messages, route.modelId, attemptOpts, quotaContextForRoute(route, 'responses'));
                    for await (const chunk of gen) {
                        if (clientGone)
                            break; // client hung up: stop pulling; reader.cancel() aborts upstream
                        // In-band upstream error frame ({"error":...} inside a 200 SSE
                        // stream — observed live from Groq). Throwing hands it to the catch
                        // below: pre-commit it fails over, post-commit it surfaces
                        // response.failed.
                        const anyChunk = chunk;
                        const inBandError = providerStreamErrorFromChunk(anyChunk, route.displayName);
                        if (inBandError)
                            throw inBandError;
                        // OpenAI-compatible providers send terminal usage in a chunk with
                        // an empty choices array. Capture it before looking for a delta;
                        // otherwise the compatibility Responses adapter silently bills
                        // estimated input and reports cached tokens as zero.
                        if (anyChunk.usage && typeof anyChunk.usage === 'object') {
                            streamUsage = normalizeCodexPromptCacheUsage(anyChunk.usage, 'prompt_tokens_details');
                        }
                        const choice0 = chunk.choices?.[0];
                        if (choice0?.finish_reason)
                            upstreamFinish = choice0.finish_reason;
                        const delta = choice0?.delta;
                        if (!delta)
                            continue;
                        // Text deltas → output_text events on a single message item, after
                        // the dialect hold window has decided the text is real prose.
                        const text = delta.content ?? '';
                        if (text) {
                            totalOutputTokens += Math.ceil(text.length / 4);
                            assertWalletStreamBudget(getDb(), {
                                platform: route.platform,
                                modelId: route.billingModelId ?? route.modelId,
                                inputTokens: estimatedInputTokens,
                                outputTokens: totalOutputTokens,
                            });
                            if (dialectMode === 'passthrough') {
                                if (msgItemId === null)
                                    openTextItem('');
                                sse('response.output_text.delta', {
                                    item_id: msgItemId, output_index: 0, content_index: 0, delta: text,
                                });
                                msgText += text;
                            }
                            else {
                                heldText += text;
                                if (dialectMode === 'undecided') {
                                    const probe = heldText.trimStart();
                                    if (startsWithDialectMarker(probe)) {
                                        dialectMode = 'dialect';
                                    }
                                    else if (!canAutoRequireTools && (!couldBecomeDialectMarker(probe) || heldText.length > 256)) {
                                        dialectMode = 'passthrough';
                                        openTextItem(heldText);
                                        heldText = '';
                                    }
                                }
                            }
                        }
                        // Tool-call deltas → function_call item + argument deltas.
                        // A structured call proves the desktop tools are available. Flush
                        // any held prose preamble first so output indexes stay ordered.
                        if ((delta.tool_calls?.length ?? 0) > 0 && heldText.length > 0 && dialectMode === 'undecided') {
                            dialectMode = 'passthrough';
                            openTextItem(heldText);
                            heldText = '';
                        }
                        for (const tc of delta.tool_calls ?? []) {
                            const idx = tc.index ?? 0;
                            let acc = toolAcc.get(idx);
                            if (!acc) {
                                // First time we see this tool call: open a new output item.
                                commit();
                                if (msgItemId !== null && msgText.length > 0) {
                                    // close the text item (always output index 0) before starting a function_call item
                                    const completedMessage = { id: msgItemId, type: 'message', status: 'completed', role: 'assistant', content: [{ type: 'output_text', text: msgText, annotations: [] }] };
                                    sse('response.output_text.done', { item_id: msgItemId, output_index: 0, content_index: 0, text: msgText });
                                    sse('response.content_part.done', { item_id: msgItemId, output_index: 0, content_index: 0, part: { type: 'output_text', text: msgText, annotations: [] } });
                                    sse('response.output_item.done', { output_index: 0, item: completedMessage });
                                    completedOutputItems.push(completedMessage);
                                    msgItemId = null;
                                }
                                outputIndex = toolAcc.size + (msgText.length > 0 ? 1 : 0);
                                acc = { outputIndex, itemId: newId('fc'), callId: tc.id || newId('call'), name: tc.function?.name ?? '', args: '' };
                                toolAcc.set(idx, acc);
                                const custom = customToolNames.has(acc.name);
                                sse('response.output_item.added', {
                                    output_index: acc.outputIndex,
                                    item: {
                                        id: acc.itemId,
                                        type: custom ? 'custom_tool_call' : 'function_call',
                                        status: 'in_progress',
                                        call_id: acc.callId,
                                        name: acc.name,
                                        ...(custom ? { input: '' } : { arguments: '' }),
                                    },
                                });
                            }
                            const argFrag = tc.function?.arguments ?? '';
                            if (tc.function?.name && !acc.name)
                                acc.name = tc.function.name;
                            if (argFrag) {
                                acc.args += argFrag;
                                const custom = customToolNames.has(acc.name);
                                if (!custom) {
                                    sse('response.function_call_arguments.delta', {
                                        item_id: acc.itemId,
                                        output_index: acc.outputIndex,
                                        delta: argFrag,
                                    });
                                }
                            }
                        }
                    }
                    // Resolve the dialect hold window now that the full text is known.
                    // Held text was never emitted, so a dead dialect turn can still fail
                    // over on the same SSE stream (nothing has been committed yet).
                    if (heldText.length > 0) {
                        if (canAutoRequireTools
                            && !forceRequiredTools
                            && toolAcc.size === 0
                            && falselyClaimsToolsUnavailable(heldText)) {
                            forceRequiredTools = true;
                            forcedRetryRoute = route;
                            throw Object.assign(new Error('model falsely claimed desktop tools were unavailable'), { skipBench: true });
                        }
                        const rescue = (dialectMode === 'dialect' || containsDialectMarker(heldText))
                            ? rescueInlineToolCalls(heldText, new Set((tools ?? []).map(t => t.function.name)))
                            : { detected: false, calls: null, cleanText: heldText };
                        if (rescue.detected && !rescue.calls) {
                            // Unparseable dialect turn: throw so the shared loop cooldowns this
                            // model+key and fails over (streamStarted is still false).
                            throw new Error(`unparseable inline tool-call dialect from ${route.displayName}: ${heldText.slice(0, 120)}`);
                        }
                        if (rescue.detected && rescue.calls) {
                            // Rescued calls become function_call items, exactly as if the
                            // provider had streamed them structurally.
                            console.log(`[Responses] Rescued ${rescue.calls.length} inline tool call(s) from ${route.displayName}`);
                            if (rescue.cleanText.length > 0 && msgItemId === null)
                                openTextItem(rescue.cleanText);
                            let rescuedIdx = 0;
                            for (const c of rescue.calls) {
                                const idx = 1000 + rescuedIdx++; // synthetic accumulator keys, past any provider index
                                commit();
                                const acc = {
                                    outputIndex: toolAcc.size + (msgText.length > 0 ? 1 : 0),
                                    itemId: newId('fc'), callId: newId('call'), name: c.name, args: c.arguments,
                                };
                                toolAcc.set(idx, acc);
                                sse('response.output_item.added', {
                                    output_index: acc.outputIndex,
                                    item: { id: acc.itemId, type: 'function_call', status: 'in_progress', call_id: acc.callId, name: acc.name, arguments: '' },
                                });
                            }
                        }
                        else if (msgItemId === null) {
                            // Plain short answer that never left the hold window (e.g. "Hi").
                            openTextItem(heldText);
                        }
                        heldText = '';
                    }
                    // Empty completion — the provider returned 200 with no text AND no
                    // tool calls. Seen in production from nemotron-3-super on ~65k-token
                    // contexts: transport-level "success", zero usable output. Nothing has
                    // been committed yet (the skeleton is lazy), so throwing lets the
                    // shared loop fail over to the next model on the same SSE connection.
                    if (msgText.length === 0 && toolAcc.size === 0) {
                        // Disconnect before the commit point: the break above fired with
                        // nothing accumulated — CLIENT behavior, not a provider failure.
                        // Falling through to the empty-completion throw benched a healthy
                        // model+key for 90s on every Ctrl-C during a reasoning model's
                        // TTFB window.
                        if (clientGone && !streamStarted) {
                            console.log(`[Responses] client disconnected before first token from ${route.displayName} — dropping attempt without benching`);
                            return 'committed';
                        }
                        // finish_reason 'length' = the model spent the whole output budget
                        // on hidden reasoning before any visible text: fail over, but skip
                        // the cooldown/penalty (not a provider-health signal).
                        throw Object.assign(new Error(`empty completion from ${route.displayName}`), upstreamFinish === 'length' ? { skipBench: true } : {});
                    }
                    if (clientGone) {
                        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', estimatedInputTokens, totalOutputTokens, Date.now() - start, 'client disconnected after stream usage');
                        return 'committed';
                    }
                    // Finalize any open text item.
                    if (msgItemId !== null) {
                        const completedMessage = { id: msgItemId, type: 'message', status: 'completed', role: 'assistant', content: [{ type: 'output_text', text: msgText, annotations: [] }] };
                        sse('response.output_text.done', { item_id: msgItemId, output_index: 0, content_index: 0, text: msgText });
                        sse('response.content_part.done', { item_id: msgItemId, output_index: 0, content_index: 0, part: { type: 'output_text', text: msgText, annotations: [] } });
                        sse('response.output_item.done', { output_index: 0, item: completedMessage });
                        completedOutputItems.push(completedMessage);
                    }
                    // Finalize tool-call items. Arguments are repaired against the tool's
                    // parameter schema at this point (after the full string accumulated):
                    // models like GLM double-encode nested arrays/objects as strings, and
                    // Codex hard-rejects the call ("invalid type: string, expected a
                    // sequence"). Clients consume the *.done events / final response for
                    // arguments, so repairing here covers the streamed path too.
                    const finalToolCalls = [];
                    for (const acc of toolAcc.values()) {
                        const repairedArgs = repairToolArguments(acc.args, toolSchemas.get(acc.name));
                        const custom = customToolNames.has(acc.name);
                        const customInput = customToolInput(repairedArgs);
                        const completedCall = {
                            id: acc.itemId,
                            type: custom ? 'custom_tool_call' : 'function_call',
                            status: 'completed',
                            call_id: acc.callId,
                            name: acc.name,
                            ...(custom ? { input: customInput } : { arguments: repairedArgs }),
                        };
                        sse(custom ? 'response.custom_tool_call_input.done' : 'response.function_call_arguments.done', {
                            item_id: acc.itemId,
                            output_index: acc.outputIndex,
                            ...(custom ? { input: customInput } : { arguments: repairedArgs }),
                        });
                        sse('response.output_item.done', { output_index: acc.outputIndex, item: completedCall });
                        completedOutputItems.push(completedCall);
                        finalToolCalls.push({ id: acc.callId, type: 'function', function: { name: acc.name, arguments: repairedArgs } });
                    }
                    const resolvedUsage = resolveCompatUsage(streamUsage, estimatedInputTokens, totalOutputTokens, route.codexSource !== 'relay' || route.codexRelayCacheUsageTrusted !== false);
                    const finalResponse = buildResponseObject({
                        id: responseId, model: route.billingModelId ?? route.modelId, text: msgText,
                        toolCalls: finalToolCalls,
                        promptTokens: resolvedUsage.inputTokens,
                        cachedInputTokens: resolvedUsage.cachedInputTokens,
                        cacheWriteTokens: resolvedUsage.cacheWriteTokens,
                        completionTokens: resolvedUsage.outputTokens,
                        createdAt: responseCreatedAt, outputItems: completedOutputItems, customToolNames,
                    });
                    sse('response.completed', { response: finalResponse });
                    res.end();
                    recordUpstreamSuccess(route, resolvedUsage.inputTokens + resolvedUsage.outputTokens);
                    setStickyModel(messages, route.modelDbId, sessionIdHeader);
                    traceRouteEvent('Responses', {
                        event: 'ok',
                        requestId: requestGroupId,
                        attempt,
                        platform: route.platform,
                        model: route.modelId,
                        latencyMs: Date.now() - start,
                        inputTokens: resolvedUsage.inputTokens,
                        outputTokens: resolvedUsage.outputTokens,
                    });
                    logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'success', resolvedUsage.inputTokens, resolvedUsage.outputTokens, Date.now() - start, null, null, null, resolvedUsage.cachedInputTokens, resolvedUsage.cacheWriteTokens);
                    return 'done';
                }
                catch (streamErr) {
                    if (isWalletSafetyBalanceReachedError(streamErr)) {
                        if (streamStarted) {
                            sse('response.failed', {
                                response: {
                                    id: responseId,
                                    object: 'response',
                                    status: 'failed',
                                    error: {
                                        code: 'wallet_safety_balance_reached',
                                        message: WALLET_SAFETY_STOP_MESSAGE,
                                    },
                                },
                            });
                            res.end();
                        }
                        else {
                            res.status(402).json({
                                error: {
                                    message: WALLET_SAFETY_STOP_MESSAGE,
                                    type: 'insufficient_balance',
                                    code: 'wallet_safety_balance_reached',
                                },
                            });
                        }
                        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', estimatedInputTokens, totalOutputTokens, Date.now() - start, WALLET_SAFETY_STOP_MESSAGE);
                        return 'committed';
                    }
                    // A committed stream can't fail over (bytes already sent) — surface a
                    // response.failed event honestly and stop. A pre-commit failure throws
                    // through to the shared loop for cooldown + failover.
                    if (streamStarted) {
                        const safe = sanitizeProviderErrorMessage(streamErr.message);
                        if (!clientGone && !isWalletSafetyBalanceReachedError(streamErr)) {
                            recordCommittedUpstreamFailure(route, streamErr);
                        }
                        traceRouteEvent('Responses', {
                            event: 'fail',
                            requestId: requestGroupId,
                            attempt,
                            platform: route.platform,
                            model: route.modelId,
                            latencyMs: Date.now() - start,
                            error: safe,
                        });
                        logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', estimatedInputTokens, totalOutputTokens, Date.now() - start, safe);
                        sse('response.failed', { response: { id: responseId, object: 'response', status: 'failed', error: { message: `Provider error (${route.displayName}): stream interrupted`, type: 'stream_error' } } });
                        res.end();
                        return 'committed';
                    }
                    throw streamErr;
                }
            }
            const result = await route.provider.chatCompletion(route.apiKey, messages, route.modelId, attemptOpts, quotaContextForRoute(route, 'responses'));
            const msg = result.choices[0]?.message;
            let text = contentToString(msg?.content ?? '');
            let toolCalls = (msg?.tool_calls ?? []).map((tc) => ({
                ...tc,
                function: { ...tc.function, arguments: repairToolArguments(tc.function.arguments, toolSchemas.get(tc.function.name)) },
            }));
            // Inline tool-call dialect rescue (#231) — see /chat/completions.
            if (wantsTools && toolCalls.length === 0 && text) {
                const rescue = rescueInlineToolCalls(text, new Set((tools ?? []).map(t => t.function.name)));
                if (rescue.detected) {
                    if (!rescue.calls) {
                        throw new Error(`unparseable inline tool-call dialect from ${route.displayName}: ${text.slice(0, 120)}`);
                    }
                    console.log(`[Responses] Rescued ${rescue.calls.length} inline tool call(s) from ${route.displayName}`);
                    toolCalls = rescue.calls.map((c, i) => ({
                        id: `call_rescued_${i + 1}`,
                        type: 'function',
                        function: { name: c.name, arguments: repairToolArguments(c.arguments, toolSchemas.get(c.name)) },
                    }));
                    text = rescue.cleanText;
                }
            }
            // Empty completion → fail over via the shared loop (see the streaming
            // path); finish_reason 'length' skips the cooldown/penalty.
            if (!text && toolCalls.length === 0) {
                throw Object.assign(new Error(`empty completion from ${route.displayName}`), result.choices[0]?.finish_reason === 'length' ? { skipBench: true } : {});
            }
            // Structured-output enforcement — see /chat/completions. Heal fenced or
            // prose-wrapped JSON in place, fail over (skipBench + skipModelForRequest
            // — a sibling key would misbehave identically) when the model ignored the
            // requested format; finish_reason 'length' gets an honest "truncated"
            // class instead, since the JSON was cut off by max_tokens, not ignored.
            if (completionOpts.response_format && text && toolCalls.length === 0) {
                const enforced = enforceJsonContent(text);
                if (!enforced.ok) {
                    const truncated = result.choices[0]?.finish_reason === 'length';
                    throw Object.assign(new Error(truncated
                        ? `truncated JSON from ${route.displayName} (finish_reason=length — raise max_tokens for this ${completionOpts.response_format.type} request)`
                        : `${route.displayName} ignored response_format (returned non-JSON despite ${completionOpts.response_format.type})`), { skipBench: true, skipModelForRequest: true });
                }
                if (enforced.healed)
                    text = enforced.content;
            }
            if (canAutoRequireTools
                && !forceRequiredTools
                && toolCalls.length === 0
                && falselyClaimsToolsUnavailable(text)) {
                forceRequiredTools = true;
                forcedRetryRoute = route;
                throw Object.assign(new Error('model falsely claimed desktop tools were unavailable'), { skipBench: true });
            }
            if (wantsTools
                && (completionOpts.tool_choice === 'required' || forceRequiredTools)
                && toolCalls.length === 0) {
                throw Object.assign(new Error(`required tool call was not returned by ${route.displayName}`), { skipBench: true });
            }
            const toolArgumentChars = toolCalls.reduce((sum, toolCall) => sum + (toolCall.function.arguments?.length ?? 0), 0);
            const accountedUsage = resolveCompatUsage(result.usage, estimatedInputTokens, Math.max(1, Math.ceil((text.length + toolArgumentChars) / 4)), route.codexSource !== 'relay' || route.codexRelayCacheUsageTrusted !== false);
            const promptTokens = accountedUsage.inputTokens;
            const completionTokens = accountedUsage.outputTokens;
            if (result.usage) {
                result.usage = normalizeCodexPromptCacheUsage(result.usage, 'prompt_tokens_details');
            }
            // Usage fallback: a missing provider `usage` block used to record 0
            // tokens against the rate-limit ledger; promptTokens/completionTokens
            // above already carry the chars/4 estimate.
            try {
                assertWalletStreamBudget(getDb(), {
                    platform: route.platform,
                    modelId: route.billingModelId ?? route.modelId,
                    inputTokens: promptTokens,
                    outputTokens: completionTokens,
                    cachedInputTokens: accountedUsage.cachedInputTokens,
                    cacheWriteTokens: accountedUsage.cacheWriteTokens,
                });
            }
            catch (error) {
                if (!isWalletSafetyBalanceReachedError(error))
                    throw error;
                logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'partial', promptTokens, completionTokens, Date.now() - start, WALLET_SAFETY_STOP_MESSAGE, null, null, accountedUsage.cachedInputTokens, accountedUsage.cacheWriteTokens);
                res.status(402).json({
                    error: {
                        message: WALLET_SAFETY_STOP_MESSAGE,
                        type: 'insufficient_balance',
                        code: 'wallet_safety_balance_reached',
                    },
                });
                return 'committed';
            }
            recordUpstreamSuccess(route, promptTokens + completionTokens);
            setStickyModel(messages, route.modelDbId, sessionIdHeader);
            res.setHeader('X-Routed-Via', `${route.platform}/${route.billingModelId ?? route.modelId}`);
            setFallbackHeaders(res, attempt, attemptLog);
            res.json(buildResponseObject({
                id: responseId, model: route.billingModelId ?? route.modelId, text, toolCalls,
                promptTokens,
                cachedInputTokens: accountedUsage.cachedInputTokens,
                cacheWriteTokens: accountedUsage.cacheWriteTokens,
                completionTokens,
                createdAt: responseCreatedAt, customToolNames,
            }));
            traceRouteEvent('Responses', {
                event: 'ok',
                requestId: requestGroupId,
                attempt,
                platform: route.platform,
                model: route.modelId,
                latencyMs: Date.now() - start,
                inputTokens: promptTokens,
                outputTokens: completionTokens,
            });
            logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'success', promptTokens, completionTokens, Date.now() - start, null, null, null, accountedUsage.cachedInputTokens, accountedUsage.cacheWriteTokens);
            return 'done';
        },
        logFailure: (route, err, attempt) => {
            const latency = Date.now() - start;
            const safeError = sanitizeProviderErrorMessage(err.message);
            traceRouteEvent('Responses', {
                event: 'fail',
                requestId: requestGroupId,
                attempt,
                platform: route.platform,
                model: route.modelId,
                latencyMs: latency,
                error: safeError,
            });
            logRequest(route.platform, route.billingModelId ?? route.modelId, route.keyId, 'error', estimatedInputTokens, 0, latency, safeError);
        },
        onFatal: (route, err, attempt) => {
            setFallbackHeaders(res, attempt, attemptLog);
            const upstreamStatus = Number(err.status);
            const invalidRelayRequest = route.codexSource === 'relay' && [400, 422].includes(upstreamStatus);
            res.status(invalidRelayRequest ? upstreamStatus : 502).json({
                error: {
                    message: `Provider error (${route.displayName}): ${sanitizeProviderErrorMessage(err.message)}`,
                    type: invalidRelayRequest ? 'invalid_request_error' : 'provider_error',
                },
            });
        },
        onRoutingExhausted: (lastError, routeErr, exhaustion, info) => {
            const status = exhaustion?.status ?? routeErr.status ?? 503;
            const message = exhaustion?.message ?? routeErr.message;
            const type = exhaustion?.type ?? 'routing_error';
            if (streamStarted) {
                sse('response.failed', { response: { id: responseId, object: 'response', status: 'failed', error: { message, type } } });
                res.end();
            }
            else {
                setFallbackHeaders(res, info.attempts.length, info.attempts, exhaustion?.retryAfterMs);
                res.status(status).json({ error: { message, type } });
            }
        },
        onExhausted: (exhaustion, info) => {
            // The streaming skeleton may already be on the wire — close the SSE stream
            // with a failed event instead of writing JSON onto a committed response.
            if (streamStarted) {
                sse('response.failed', { response: { id: responseId, object: 'response', status: 'failed', error: { message: exhaustion.message, type: exhaustion.type } } });
                res.end();
            }
            else {
                setFallbackHeaders(res, info.attempts.length, info.attempts, exhaustion.retryAfterMs);
                res.status(exhaustion.status).json({ error: { message: exhaustion.message, type: exhaustion.type } });
            }
        },
    });
});
//# sourceMappingURL=responses.js.map