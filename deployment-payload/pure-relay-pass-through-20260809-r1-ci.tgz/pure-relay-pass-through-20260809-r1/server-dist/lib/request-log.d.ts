import { type RequestRoutingDiagnostics } from "./client-context.js";
/** Start an isolated routing trace for one fallback loop in this HTTP call. */
export declare function resetRequestRoutingDiagnostics(): void;
/**
 * Publish the newest bounded snapshot and refresh rows already written by
 * earlier failed attempts.  This makes every row in the same fallback chain
 * answer what happened eventually, including a later successful source.
 */
export declare function publishRequestRoutingDiagnostics(diagnostics: RequestRoutingDiagnostics): void;
export declare function logRequest(platform: string, modelId: string, keyId: number, status: string, inputTokens: number, outputTokens: number, latencyMs: number, error: string | null, ttfbMs?: number | null, requestedModel?: string | null, explicitCachedInputTokens?: number | null, explicitCacheWriteTokens?: number | null): number | undefined;
//# sourceMappingURL=request-log.d.ts.map