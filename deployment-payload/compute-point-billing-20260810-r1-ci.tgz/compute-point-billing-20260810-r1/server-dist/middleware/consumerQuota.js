import { getDb, } from '../db/index.js';
import { getSetting } from '../db/index.js';
import { validateConsumerApiKey, listConsumerApiKeys, } from '../services/consumer-api-keys.js';
import { estimateBillingReservation, } from '../services/billing-reservation.js';
import { estimateCodexBillingReservation, } from '../services/codex-billing.js';
import { releaseWalletReservation, reserveWalletBalance, } from '../services/wallet-reservations.js';
import { setWalletReservationId, setConsumerIdentity, setConsumerFreeOnly, setResourceReservation, getClientContext, setFreeModelUsage, } from '../lib/client-context.js';
import { estimateCodexQuotaUnits, releaseSubpoolQuota, reserveSubpoolQuota, ResourceQuotaError, } from '../services/resource-quota.js';
import { consumeFreeModelRequest, releaseFreeModelRequest, getAvailableBalanceMicro, isExplicitFreeModel, PAID_MODEL_SAFETY_BALANCE_MICRO, } from '../services/free-model-access.js';
import { getAvailablePromotionCreditMicro, } from '../services/promotion-credits.js';
import { resolveAnthropicModel } from '../services/anthropic-map.js';
const consumerRequestTimes = new Map();
const consumerUserRequestTimes = new Map();
const consumerCompactRequestTimes = new Map();
const consumerUserCompactRequestTimes = new Map();
const COMPACT_REQUESTS_PER_MINUTE = 10;
function isRecord(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function firstString(value) {
    const first = Array.isArray(value) ? value[0] : value;
    return typeof first === 'string' && first.trim() ? first.trim() : undefined;
}
function isGeminiApiRequest(req) {
    const baseUrl = typeof req.baseUrl === 'string' ? req.baseUrl : '';
    if (baseUrl === '/v1beta' || baseUrl.endsWith('/v1beta'))
        return true;
    const pathname = (req.originalUrl ?? req.url ?? '').split('?')[0];
    return pathname === '/v1beta' || pathname.startsWith('/v1beta/');
}
function geminiStatusForHttp(status) {
    if (status === 400 || status === 413)
        return 'INVALID_ARGUMENT';
    if (status === 401)
        return 'UNAUTHENTICATED';
    if (status === 402)
        return 'FAILED_PRECONDITION';
    if (status === 403)
        return 'PERMISSION_DENIED';
    if (status === 404)
        return 'NOT_FOUND';
    if (status === 409)
        return 'ABORTED';
    if (status === 429)
        return 'RESOURCE_EXHAUSTED';
    if (status === 503)
        return 'UNAVAILABLE';
    return 'INTERNAL';
}
function sendConsumerError(req, res, status, message, type, details = {}) {
    if (isGeminiApiRequest(req)) {
        res.status(status).json({
            error: { code: status, message, status: geminiStatusForHttp(status) },
        });
        return;
    }
    res.status(status).json({ error: { message, type, ...details } });
}
function geminiPathInfo(req) {
    // req.path is mount-relative under /v1beta, whereas originalUrl is stable
    // when this middleware is reused. Accept either form without trusting a body
    // `model` field for Gemini's path-addressed API.
    const requestUrl = typeof req.originalUrl === 'string'
        ? req.originalUrl
        : typeof req.url === 'string'
            ? req.url
            : typeof req.path === 'string'
                ? req.path
                : '';
    const pathname = requestUrl.split('?')[0];
    const mountedPath = `${typeof req.baseUrl === 'string' ? req.baseUrl : ''}${typeof req.path === 'string' ? req.path : ''}`;
    // Model catalog ids may contain `/` and `:`. The operation is the final
    // `:<verb>` suffix, so capture everything before that suffix rather than
    // treating the resource name as one URL segment.
    const match = /(?:^|\/)v1beta\/models\/(.+):(generateContent|streamGenerateContent|countTokens)$/.exec(pathname)
        ?? /\/models\/(.+):(generateContent|streamGenerateContent|countTokens)$/.exec(mountedPath);
    if (!match)
        return null;
    try {
        const model = decodeURIComponent(match[1]).trim().replace(/^models\//i, '');
        if (!model)
            return null;
        return { model, operation: match[2] };
    }
    catch {
        return null;
    }
}
function quotaRequestBody(req, gemini) {
    if (!gemini || (gemini.operation !== 'generateContent' && gemini.operation !== 'streamGenerateContent') || !isRecord(req.body)) {
        return req.body;
    }
    const generationConfig = isRecord(req.body.generationConfig) ? req.body.generationConfig : {};
    const maxOutputTokens = generationConfig.maxOutputTokens;
    // Billing/reservation and resource-quota estimators intentionally consume
    // OpenAI-shaped fields. This is a request-local copy: the native Gemini
    // body reaching the route remains unchanged.
    return {
        ...req.body,
        model: gemini.model,
        ...(maxOutputTokens !== undefined ? { max_tokens: maxOutputTokens } : {}),
        ...(req.body.messages === undefined && req.body.input === undefined ? { messages: req.body.contents } : {}),
    };
}
function isStreamingConsumerRequest(req, gemini) {
    if (gemini?.operation === 'streamGenerateContent')
        return true;
    return isRecord(req.body) && req.body.stream === true;
}
/**
 * Prepaid consumer billing gate.
 *
 * Only tuoke-* consumer API keys are affected.
 *
 * Global/admin unified API keys bypass wallet billing.
 */
export function consumerQuota(req, res, next) {
    /*
     * Read-only endpoints do not create model cost.
     */
    if (req.method === 'GET' ||
        req.method === 'HEAD') {
        next();
        return;
    }
    const bearer = req.headers.authorization
        ?.replace(/^Bearer\s+/i, '')
        .trim();
    const apiKeyHeader = req.headers['x-api-key'];
    const googleApiKeyHeader = req.headers['x-goog-api-key'];
    // Native Gemini clients commonly use `?key=...`; keep it behind bearer and
    // header credentials so a caller that sends both retains the existing
    // precedence while still receiving the same consumer quota enforcement.
    const token = bearer
        || firstString(apiKeyHeader)
        || firstString(googleApiKeyHeader)
        || firstString(req.query?.key);
    /*
     * Admin/global unified key:
     * no consumer wallet billing.
     */
    const dashboardUser = req.user?.userId;
    const isDashboardPlayground = Boolean(dashboardUser
        && (req.path === '/playground/chat' || req.path === '/playground/chat/stream'));
    if (!token?.startsWith('tuoke-') && !isDashboardPlayground) {
        next();
        return;
    }
    const db = getDb();
    const key = token?.startsWith('tuoke-')
        ? validateConsumerApiKey(db, token)
        : listConsumerApiKeys(db, dashboardUser).find((candidate) => candidate.status === 'active'
            && candidate.enabled === 1
            && (!candidate.expiresAt || Date.parse(candidate.expiresAt) > Date.now())) ?? null;
    if (!key && isDashboardPlayground) {
        sendConsumerError(req, res, 400, '请先创建一个可用的 Consumer API Key。', 'playground_key_required');
        return;
    }
    /*
     * Authentication middleware will return the
     * canonical invalid-key response later.
     */
    if (!key) {
        next();
        return;
    }
    // Establish identity before any downstream route can log the request.
    // Global/admin keys never enter this branch because they do not use the
    // tuoke-* consumer-key namespace.
    setConsumerIdentity(key.userId, key.id, key.keyType, key.codexGroupId);
    const gemini = geminiPathInfo(req);
    const originalRequestedModel = gemini?.model
        ?? (typeof req.body?.model === 'string' ? req.body.model.trim() : '');
    let requestedModel = originalRequestedModel;
    let requestBodyForQuota = quotaRequestBody(req, gemini);
    // Claude-family aliases are translated by routes/anthropic.ts after this
    // admission middleware. Mirror only that model resolution for external
    // universal keys so we reserve/limit against the model that will actually
    // be routed, without changing the original Anthropic body or response echo.
    if (!isDashboardPlayground && key.keyType === 'universal' && req.path === '/messages') {
        const resolved = resolveAnthropicModel(originalRequestedModel);
        const mapped = resolved.preferredModelDbId == null
            ? 'auto'
            : db.prepare('SELECT model_id AS modelId FROM models WHERE id = ? AND enabled = 1')
                .get(resolved.preferredModelDbId)?.modelId ?? 'auto';
        requestedModel = mapped;
        if (isRecord(requestBodyForQuota))
            requestBodyForQuota = { ...requestBodyForQuota, model: mapped };
    }
    // The Responses route treats native Codex ids on an external universal key
    // as compatibility aliases for the ordinary `auto` pool, but only when the
    // id has no ordinary billable counterpart. Make the admission/reservation
    // view match that eventual route without rewriting the wire body that the
    // Responses handler uses to preserve its client-facing semantics.
    if (!isDashboardPlayground && key.keyType === 'universal' && req.path === '/responses' && originalRequestedModel) {
        const normalizedResponsesModel = originalRequestedModel === 'openai-codex/codex'
            ? 'codex'
            : originalRequestedModel;
        const ordinaryBillingCounterpart = Boolean(db.prepare(`
      SELECT 1
      FROM models m
      JOIN model_billing_rules b
        ON b.platform = m.platform
       AND b.model_id = m.model_id
      WHERE m.platform <> 'openai-codex'
        AND m.model_id = ?
        AND m.enabled = 1
        AND b.billing_enabled = 1
      LIMIT 1
    `).get(normalizedResponsesModel));
        const nativeCodexResponsesAlias = normalizedResponsesModel === 'codex'
            || Boolean(db.prepare(`
        SELECT 1
        FROM models
        WHERE platform = 'openai-codex'
          AND model_id = ?
          AND enabled = 1
        LIMIT 1
      `).get(normalizedResponsesModel));
        if (nativeCodexResponsesAlias && !ordinaryBillingCounterpart) {
            requestedModel = 'auto';
            if (isRecord(requestBodyForQuota))
                requestBodyForQuota = { ...requestBodyForQuota, model: 'auto' };
        }
    }
    const requestedModelLower = requestedModel.toLowerCase();
    const responsesCompaction = req.path === '/responses/compact';
    // A Codex-pool compaction invokes the same selected upstream and is billed
    // from its returned usage. Other protocol helpers remain local and free.
    const localProtocolHelper = (responsesCompaction && key.keyType !== 'codex_pool')
        || req.path === '/messages/count_tokens'
        || gemini?.operation === 'countTokens';
    // Catalog and metadata requests need consumer identity for per-scope model
    // filtering, but are not inference. Never spend a free request or reserve
    // a wallet/subpool quota merely by browsing `/v1/models` or `/v1beta/models`.
    const nonInferenceMethod = req.method !== 'POST';
    // These routes already reject consumer callers at their own protocol layer.
    // Keep auth + RPM accounting here, but never reserve funds/free quota/subpool
    // units or preempt their canonical error response with a model-scope gate.
    const consumerBillingUnavailableEndpoint = req.path === '/embeddings'
        || req.path === '/images/generations'
        || req.path === '/images/edits'
        || req.path === '/audio/speech';
    const skipInferenceAdmission = nonInferenceMethod || localProtocolHelper || consumerBillingUnavailableEndpoint;
    if (key.keyType === 'codex_pool' && !skipInferenceAdmission) {
        const activeGroup = key.codexGroupId == null
            ? null
            : db.prepare(`
        SELECT 1
        FROM codex_groups
        WHERE id = ?
          AND enabled = 1
        LIMIT 1
      `).get(key.codexGroupId);
        if (!activeGroup) {
            sendConsumerError(req, res, 403, 'This Codex pool API key is not bound to an enabled group. Create a new key and select a Codex group.', 'permission_error');
            return;
        }
    }
    // Every external universal key is a free ordinary-model key. Restrict both
    // virtual auto requests and explicitly selected models to zero-priced
    // ordinary routes; dashboard playground behaviour stays unchanged.
    setConsumerFreeOnly(!isDashboardPlayground
        && key.keyType === 'universal');
    const imageRequest = req.path === '/images/generations' || req.path === '/images/edits';
    const explicitCodexAlias = requestedModel === 'codex'
        || requestedModel === 'openai-codex/codex';
    const knownCodexModel = imageRequest || (requestedModel !== '' && (explicitCodexAlias
        || Boolean(db.prepare(`
      SELECT 1
      FROM models
      WHERE platform = 'openai-codex'
        AND model_id = ?
      LIMIT 1
    `).get(requestedModel))
        || Boolean(db.prepare(`
      SELECT 1
      FROM codex_oauth_account_models
      WHERE model_id = ?
      LIMIT 1
    `).get(requestedModel))));
    const knownOrdinaryModel = requestedModel !== '' && Boolean(db.prepare(`
    SELECT 1
    FROM models m
    JOIN model_billing_rules b
      ON b.platform = m.platform
     AND b.model_id = m.model_id
     AND b.billing_enabled = 1
    WHERE m.platform <> 'openai-codex'
      AND m.model_id = ?
      AND m.enabled = 1
    LIMIT 1
  `).get(requestedModel));
    // Codex desktop sends one of its native model ids to /v1/responses even
    // when a universal key is configured. Treat that id as a client-facing
    // compatibility alias; the router still excludes openai-codex accounts for
    // universal keys and dispatches the request to the ordinary provider pool.
    const universalResponsesAlias = key.keyType === 'universal'
        && req.path === '/responses'
        && knownCodexModel;
    if (key.keyType === 'universal'
        && !skipInferenceAdmission
        && !universalResponsesAlias
        && (explicitCodexAlias || (knownCodexModel && !knownOrdinaryModel))) {
        sendConsumerError(req, res, 403, 'This API key does not have access to Codex pool', 'permission_error');
        return;
    }
    if (key.keyType !== 'universal'
        && !skipInferenceAdmission
        && !knownCodexModel) {
        sendConsumerError(req, res, 403, 'This API key only has access to Codex pool', 'permission_error');
        return;
    }
    const now = Date.now();
    const configuredRpm = key.rateLimitRpm ?? Number(getSetting('default_consumer_rpm') ?? 60);
    const userRpm = Number(getSetting('default_consumer_rpm') ?? 60);
    if (configuredRpm === 0 || userRpm === 0) {
        res.setHeader('Retry-After', '60');
        sendConsumerError(req, res, 429, configuredRpm === 0
            ? 'Consumer API key rate limit exceeded.'
            : 'Consumer user rate limit exceeded.', 'rate_limit_exceeded');
        return;
    }
    if (responsesCompaction) {
        const compactRecent = (consumerCompactRequestTimes.get(key.id) ?? [])
            .filter((time) => now - time < 60_000);
        const compactUserRecent = (consumerUserCompactRequestTimes.get(key.userId) ?? [])
            .filter((time) => now - time < 60_000);
        if (compactRecent.length >= COMPACT_REQUESTS_PER_MINUTE
            || compactUserRecent.length >= COMPACT_REQUESTS_PER_MINUTE) {
            consumerCompactRequestTimes.set(key.id, compactRecent);
            consumerUserCompactRequestTimes.set(key.userId, compactUserRecent);
            res.setHeader('Retry-After', '60');
            sendConsumerError(req, res, 429, 'Conversation compaction rate limit exceeded. Retry in 60 seconds.', 'compaction_rate_limit_exceeded');
            return;
        }
        compactRecent.push(now);
        compactUserRecent.push(now);
        consumerCompactRequestTimes.set(key.id, compactRecent);
        consumerUserCompactRequestTimes.set(key.userId, compactUserRecent);
    }
    else {
        const recent = (consumerRequestTimes.get(key.id) ?? []).filter((time) => now - time < 60_000);
        if (recent.length >= configuredRpm) {
            consumerRequestTimes.set(key.id, recent);
            res.setHeader('Retry-After', '60');
            sendConsumerError(req, res, 429, 'Consumer API key rate limit exceeded.', 'rate_limit_exceeded');
            return;
        }
        const userRecent = (consumerUserRequestTimes.get(key.userId) ?? []).filter((time) => now - time < 60_000);
        if (userRecent.length >= userRpm) {
            consumerRequestTimes.set(key.id, recent);
            consumerUserRequestTimes.set(key.userId, userRecent);
            res.setHeader('Retry-After', '60');
            sendConsumerError(req, res, 429, 'Consumer user rate limit exceeded.', 'rate_limit_exceeded');
            return;
        }
        recent.push(now);
        consumerRequestTimes.set(key.id, recent);
        userRecent.push(now);
        consumerUserRequestTimes.set(key.userId, userRecent);
    }
    if (skipInferenceAdmission) {
        next();
        return;
    }
    if (key.keyType === 'resource_subpool') {
        let resourceReservation;
        try {
            resourceReservation = reserveSubpoolQuota(db, key.userId, key.id, estimateCodexQuotaUnits(db, requestBodyForQuota));
            setResourceReservation(resourceReservation);
        }
        catch (error) {
            if (error instanceof ResourceQuotaError) {
                sendConsumerError(req, res, error.code === 'resource_quota_exhausted' ? 429 : 403, error.message, error.code);
                return;
            }
            throw error;
        }
        // Resource products are prepaid entitlements. Once their isolated quota
        // reservation succeeds, the request must not enter PAYG wallet billing.
        registerResourceCleanup(res, db, resourceReservation.reservationId);
        next();
        return;
    }
    /*
     * Resolve the requested model for admission checks. Billing itself is
     * settled later from the upstream usage snapshot; no amount is estimated
     * or reserved from the wallet at this stage.
     */
    const estimate = key.keyType !== 'universal'
        ? estimateCodexBillingReservation(db, requestBodyForQuota, key.id)
        : estimateBillingReservation(db, requestBodyForQuota);
    /*
     * Consumer requests must never silently use an
     * unpriced model.
     */
    if (estimate.status ===
        'no_billing_rule') {
        const estimatedModel = estimate.requestedModel ?? '';
        const explicitScopedCodexModel = key.keyType === 'codex_pool'
            && Boolean(estimatedModel)
            && estimatedModel !== 'auto'
            && !estimatedModel.startsWith('auto:')
            && estimatedModel !== 'codex'
            && estimatedModel !== 'openai-codex/codex';
        if (explicitScopedCodexModel) {
            // Protocol routes already return their canonical
            // model_not_available_for_key response before dispatch. Let that
            // contract win instead of turning a cross-group model request into a
            // generic billing 503. Routing remains fail-closed to the exact group.
            next();
            return;
        }
        const unknownExplicitGeminiModel = isGeminiApiRequest(req)
            && Boolean(estimatedModel)
            && estimatedModel !== 'auto'
            && !estimatedModel.startsWith('auto:');
        sendConsumerError(req, res, unknownExplicitGeminiModel ? 404 : 503, unknownExplicitGeminiModel
            ? `Model '${estimatedModel}' was not found or is not currently available.`
            : 'This model is not currently available for billed API usage.', unknownExplicitGeminiModel ? 'model_not_found' : 'billing_not_configured', { model: estimate.requestedModel });
        return;
    }
    /*
     * Explicitly configured free model:
     *
     * No wallet reservation is needed.
     * logRequest() will later mark it as free.
     */
    const explicitFreeModel = key.keyType === 'universal'
        && isExplicitFreeModel(db, estimate.requestedModel);
    if (key.keyType === 'universal'
        && !isDashboardPlayground
        && !explicitFreeModel) {
        sendConsumerError(req, res, 403, 'This API key only has access to free ordinary models.', 'permission_error', { model: estimate.requestedModel });
        return;
    }
    if (explicitFreeModel) {
        // A model id can have both zero-priced and paid provider members. Never
        // let an external free-quota request fall through to a paid member merely
        // because one matching billing rule is free. The router enforces this
        // request-scoped flag; dashboard playground behavior stays unchanged.
        if (!isDashboardPlayground)
            setConsumerFreeOnly(true);
        const freeAccess = consumeFreeModelRequest(db, key.userId);
        res.setHeader('X-Free-Model-Daily-Limit', String(freeAccess.limit));
        res.setHeader('X-Free-Model-Daily-Used', String(freeAccess.used));
        if (!freeAccess.allowed) {
            sendConsumerError(req, res, 429, freeAccess.limit === 50
                ? 'Daily free-model limit reached. Purchase the 10-yuan monthly membership to unlock 1000 requests per day.'
                : 'Daily free-model limit reached.', 'free_model_daily_limit_exceeded', { limit: freeAccess.limit, used: freeAccess.used, membership_expires_at: freeAccess.membershipUntil });
            return;
        }
        const usageDate = freeAccess.usageDate;
        setFreeModelUsage(usageDate);
        const context = getClientContext();
        let scheduled = false;
        const cleanup = () => {
            if (scheduled)
                return;
            scheduled = true;
            const timer = setTimeout(() => {
                if (!context.freeModelUsageCommitted)
                    releaseFreeModelRequest(db, key.userId, usageDate);
            }, 5000);
            timer.unref();
        };
        res.once('finish', cleanup);
        res.once('close', cleanup);
        next();
        return;
    }
    const walletAvailableMicro = getAvailableBalanceMicro(db, key.userId);
    const promotionAvailableMicro = getAvailablePromotionCreditMicro(db, key.userId);
    const totalAvailableMicro = Math.max(0, walletAvailableMicro ?? 0) + promotionAvailableMicro;
    if (walletAvailableMicro === null || totalAvailableMicro <= PAID_MODEL_SAFETY_BALANCE_MICRO) {
        sendConsumerError(req, res, 402, 'Paid models require more than 0.10 yuan total API credit.', 'minimum_balance_required', {
            safety_balance_micro: PAID_MODEL_SAFETY_BALANCE_MICRO,
            available_micro: totalAvailableMicro,
            wallet_available_micro: walletAvailableMicro ?? 0,
            promotion_available_micro: promotionAvailableMicro,
        });
        return;
    }
    const reservation = reserveWalletBalance(db, key.userId, null, estimate.requestedModel, 
    // Permanent wallet funds are no longer frozen from a conservative
    // maximum-output estimate. The row remains the exactly-once lifecycle
    // anchor for both wallet settlement and promotion-credit allocations.
    0, {
        // Non-streaming calls cannot be stopped once the provider has already
        // produced its response, so they hold the user's exclusive wallet
        // lifecycle lock. Streams keep sharing the wallet and remain bounded
        // by the live stream budget guard.
        // The opt-out is used only by the first rolling-deployment canary so
        // the old process can drain legacy shared reservations safely. The
        // final instance omits it and enables exclusive locking by default.
        exclusiveWalletLock: process.env.PAID_NON_STREAM_EXCLUSIVE_LOCK_ENABLED !== '0'
            && !isStreamingConsumerRequest(req, gemini),
    });
    if (reservation.status === 'concurrency_conflict') {
        res.setHeader('Retry-After', '5');
        sendConsumerError(req, res, 409, reservation.requestedExclusive
            ? 'Another paid request is still running. Wait for it to finish before starting a non-streaming request.'
            : 'A non-streaming paid request is still running. Wait for it to finish before starting a streaming request.', 'paid_request_concurrency_conflict', {
            requested_mode: reservation.requestedExclusive ? 'non_stream' : 'stream',
            conflicting_mode: reservation.conflictingExclusive === null
                ? 'unknown'
                : reservation.conflictingExclusive
                    ? 'non_stream'
                    : 'stream',
        });
        return;
    }
    if (reservation.status !==
        'reserved') {
        sendConsumerError(req, res, 402, 'Paid models require enough available balance for this request.', 'insufficient_balance', { required_micro: 0, available_micro: reservation.availableMicro });
        return;
    }
    const reservationId = reservation.reservationId;
    /*
     * Make the reservation visible to logRequest()
     * throughout this exact async request.
     */
    setWalletReservationId(reservationId);
    /*
     * Safety cleanup.
     *
     * Successful requests normally settle the
     * reservation inside logRequest().
     *
     * If the entire request fails, authentication
     * rejects it later, the client disconnects, or all
     * provider routes fail, the reservation is released.
     *
     * Delay slightly so streaming handlers that call
     * logRequest immediately after res.end() get time
     * to perform settlement first.
     */
    let cleanupScheduled = false;
    // Non-streaming handlers finish their synchronous billing/logging work in
    // the same turn that ends the response, so an unconsumed exclusive lock can
    // be released on the next event-loop turn. Keeping the old five-second
    // grace period here would reject a perfectly sequential follow-up request
    // after a failed route. Streaming handlers still need the grace period
    // because several of them settle immediately after res.end().
    const cleanupDelayMs = reservation.exclusiveWalletLock ? 0 : 5000;
    const scheduleCleanup = () => {
        if (cleanupScheduled) {
            return;
        }
        cleanupScheduled =
            true;
        const timer = setTimeout(() => {
            try {
                releaseWalletReservation(db, reservationId, 'failed');
            }
            catch (error) {
                console.error('[Billing] Failed to release unfinished reservation:', reservationId, error);
            }
        }, cleanupDelayMs);
        timer.unref();
    };
    res.once('finish', scheduleCleanup);
    res.once('close', scheduleCleanup);
    next();
}
function registerResourceCleanup(res, db, reservationId) {
    if (reservationId === null)
        return;
    const requestContext = getClientContext();
    let scheduled = false;
    const cleanup = () => {
        if (scheduled)
            return;
        scheduled = true;
        const timer = setTimeout(() => {
            try {
                // A disconnected stream may still be unwinding the Provider generator
                // and writing its partial usage record. Never release known usage from
                // this transport-level safety hook; request-log owns its settlement.
                if (!requestContext.resourceUsageObserved)
                    releaseSubpoolQuota(db, reservationId);
            }
            catch (error) {
                console.error('[Resource Quota] Failed to release unfinished reservation:', reservationId, error);
            }
        }, 5000);
        timer.unref();
    };
    res.once('finish', cleanup);
    res.once('close', cleanup);
}
//# sourceMappingURL=consumerQuota.js.map