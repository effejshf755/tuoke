#!/usr/bin/env bash
set -Eeuo pipefail

CONTAINER="tuoke-prod-freellmapi-1"
COMPOSE_FILE="/srv/tuoke-prod/docker-compose.yml"
COMPOSE_PROJECT="tuoke-prod"
COMPOSE_SERVICE="freellmapi"
PUBLIC_ORIGIN="https://tuokeapi.com"
EXPECTED_BASE_IMAGE="migration-japan/tuokeapi:20260810-relay-balance-request-local-r1"
EXPECTED_BASE_RELEASE="relay-balance-request-local-20260810-r1"
NEW_IMAGE="migration-japan/tuokeapi:20260810-account-compute-usage-r1"
RELEASE_LABEL="account-compute-usage-20260810-r1"
CLIENT_JS="index-DQLlbmOq.js"
CLIENT_CSS="index-Bu5ANiKc.css"

RELEASE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="/root/deploy-backups/${RELEASE_LABEL}-${STAMP}"

exec 9>/var/lock/tuoke-api-deploy.lock
flock -n 9 || { echo "deployment_lock=busy" >&2; exit 75; }

test "$(id -u)" -eq 0
test -f "$COMPOSE_FILE"
test -f "$RELEASE_DIR/Dockerfile"
test -f "$RELEASE_DIR/MANIFEST.sha256"
(
  cd "$RELEASE_DIR"
  sha256sum -c MANIFEST.sha256
)

docker inspect "$CONTAINER" >/dev/null
test "$(docker inspect --format '{{.State.Status}}' "$CONTAINER")" = "running"
OLD_IMAGE="$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")"
OLD_IMAGE_ID="$(docker inspect --format '{{.Image}}' "$CONTAINER")"
test -n "$OLD_IMAGE"
test -n "$OLD_IMAGE_ID"
test "$OLD_IMAGE" = "$EXPECTED_BASE_IMAGE"
test "$(docker image inspect --format '{{.Id}}' "$OLD_IMAGE")" = "$OLD_IMAGE_ID"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$OLD_IMAGE")" = "$EXPECTED_BASE_RELEASE"

docker exec "$CONTAINER" sh -lc "
  set -eu
  echo '24d050725cd5bde0a56dc5827579de418a4c51b549a9dadfac486a03ccd9175f  /app/server/dist/lib/compute-points-response.js' | sha256sum -c -
  echo 'f7c175d4da2ee917874ce98dfab4674a2197ebd3b60d7235349bf1802aa1ec50  /app/server/dist/routes/responses.js' | sha256sum -c -
  echo 'c852ad7117221bf0af14750aebec7a4f9dc78f35d76cc15e46d1f2f5a70e990c  /app/server/dist/routes/admin-users.js' | sha256sum -c -
"

assert_live_baseline() {
  local actual_image actual_id tagged_id
  actual_image="$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")"
  actual_id="$(docker inspect --format '{{.Image}}' "$CONTAINER")"
  tagged_id="$(docker image inspect --format '{{.Id}}' "$OLD_IMAGE")"
  test "$actual_image" = "$OLD_IMAGE"
  test "$actual_id" = "$OLD_IMAGE_ID"
  test "$tagged_id" = "$OLD_IMAGE_ID"
}

assert_live_baseline

install -d -m 0700 "$BACKUP_DIR"
cp -a "$COMPOSE_FILE" "$BACKUP_DIR/docker-compose.yml.before"
docker inspect "$CONTAINER" > "$BACKUP_DIR/container-inspect.before.json"
docker volume inspect tuoke-prod_freellmapi-data > "$BACKUP_DIR/data-volume.before.json"
sha256sum "$COMPOSE_FILE" > "$BACKUP_DIR/docker-compose.yml.before.sha256"
printf '%s\n' "$OLD_IMAGE" > "$BACKUP_DIR/previous-image.txt"
printf '%s\n' "$OLD_IMAGE_ID" > "$BACKUP_DIR/previous-image-id.txt"

CONTAINER_DB_BACKUP="/app/server/data/.deploy-backup-${STAMP}.db"
docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  const target = process.argv[1];
  const source = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  await source.backup(target);
  source.close();
  const copy = new Database(target, { readonly: true, fileMustExist: true });
  const result = copy.pragma("quick_check", { simple: true });
  if (result !== "ok") throw new Error(`backup quick_check failed: ${result}`);
  copy.close();
  console.log("database_backup_quick_check=ok");
' "$CONTAINER_DB_BACKUP"
docker cp "$CONTAINER:$CONTAINER_DB_BACKUP" "$BACKUP_DIR/freeapi-before.db"
docker exec "$CONTAINER" rm -f -- "$CONTAINER_DB_BACKUP"
test -s "$BACKUP_DIR/freeapi-before.db"
sha256sum "$BACKUP_DIR/freeapi-before.db" > "$BACKUP_DIR/freeapi-before.db.sha256"

docker build \
  --pull=false \
  --build-arg "BASE_IMAGE=$OLD_IMAGE" \
  --tag "$NEW_IMAGE" \
  "$RELEASE_DIR"

test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$NEW_IMAGE")" = "$RELEASE_LABEL"
NEW_IMAGE_ID="$(docker image inspect --format '{{.Id}}' "$NEW_IMAGE")"
test -n "$NEW_IMAGE_ID"

for file in \
  /app/server/dist/index.js \
  /app/server/dist/lib/compute-points-response.js \
  /app/server/dist/routes/responses.js \
  /app/server/dist/routes/admin-users.js; do
  docker run --rm --entrypoint node "$NEW_IMAGE" --check "$file"
done

docker run --rm --entrypoint sh "$NEW_IMAGE" -lc "
  set -eu
  test -s /app/client/dist/assets/$CLIENT_JS
  test -s /app/client/dist/assets/$CLIENT_CSS
  grep -q /assets/$CLIENT_JS /app/client/dist/index.html
  grep -q /assets/$CLIENT_CSS /app/client/dist/index.html
  test \"\$(stat -c %s /app/client/dist/media/tuoke-cosmos-4k120-v3.mp4)\" = 178630309
  echo '87da021bf5496777a94e0067d293918ed8bf30d2b0701daf40152c4ca67ea79d  /app/client/dist/media/tuoke-cosmos-4k120-v3.mp4' | sha256sum -c -
  grep -q 'Relay declarations are diagnostic only' /app/server/dist/services/router.js
  grep -q 'const DEFAULT_HEALTH_INTERVAL_MS = 0' /app/server/dist/services/codex-relay-maintenance.js
  grep -q 'A balance error is request-local too' /app/server/dist/lib/fallback-loop.js
  grep -q 'installComputePointUsageResponse' /app/server/dist/lib/compute-points-response.js
  grep -q 'ensureConsumerNativeUsage' /app/server/dist/routes/responses.js
  grep -q 'input_compute_points' /app/server/dist/routes/admin-users.js
  ! grep -q 'X-Tuoke-Usage-Unit' /app/server/dist/lib/compute-points-response.js
  ! grep -q 'X-Tuoke-Compute-Points-Per-Million' /app/server/dist/lib/compute-points-response.js
  ! grep -q 'CODEX_RELAY_MODEL_OUT_OF_CREDITS_COOLDOWN_MS' /app/server/dist/services/codex-relay-sources.js
  ! grep -q 'CODEX_RELAY_MODEL_OUT_OF_CREDITS_COOLDOWN_MS' /app/server/dist/services/fusion.js
"

docker run --rm --entrypoint node "$NEW_IMAGE" --input-type=module -e '
  import { convertUsageToComputePoints } from "/app/server/dist/lib/compute-points-response.js";
  const converted = convertUsageToComputePoints({
    input_tokens: 100,
    output_tokens: 20,
    total_tokens: 120,
    input_tokens_details: { cached_tokens: 40, cache_write_tokens: 10 },
  }, 1_500_000);
  const expected = JSON.stringify({
    input_tokens: 150,
    output_tokens: 30,
    total_tokens: 180,
    input_tokens_details: { cached_tokens: 60, cache_write_tokens: 15 },
  });
  if (JSON.stringify(converted) !== expected) throw new Error("account usage conversion check failed");
  console.log("account_usage_conversion_check=ok");
'

# Refuse to switch if another deployment changed production during the build.
assert_live_baseline

SWITCH_STARTED=0
rollback() {
  local code=$?
  set +e
  if [ "$SWITCH_STARTED" -eq 1 ]; then
    cp -a "$BACKUP_DIR/docker-compose.yml.before" "$COMPOSE_FILE"
    chmod 0600 "$COMPOSE_FILE"
    docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"
    for _ in $(seq 1 30); do
      if docker exec "$CONTAINER" node -e '
        fetch("http://127.0.0.1:3001/api/ping")
          .then(async response => {
            const body = await response.json();
            if (!response.ok || body.status !== "ok") process.exit(1);
          })
          .catch(() => process.exit(1));
      ' >/dev/null 2>&1; then
        break
      fi
      sleep 2
    done
    echo "deployment_result=rolled_back" >&2
  fi
  exit "$code"
}
trap rollback ERR

SWITCH_STARTED=1
python3 - "$COMPOSE_FILE" "$NEW_IMAGE" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
image = sys.argv[2]
lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
inside = False
replaced = False
for index, line in enumerate(lines):
    if line.startswith("  freellmapi:"):
        inside = True
        continue
    if inside and line.startswith("  ") and not line.startswith("    ") and line.strip():
        break
    if inside and line.startswith("    image:"):
        newline = "\n" if line.endswith("\n") else ""
        lines[index] = f"    image: {image}{newline}"
        replaced = True
        break
if not replaced:
    raise SystemExit("freellmapi image entry not found")
temporary = path.with_suffix(path.suffix + ".codex-new")
temporary.write_text("".join(lines), encoding="utf-8")
temporary.chmod(0o600)
temporary.replace(path)
PY

docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config -q
docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"

HEALTH_OK=0
for _ in $(seq 1 60); do
  STATUS="$(docker inspect --format '{{.State.Status}}' "$CONTAINER" 2>/dev/null || true)"
  HEALTH="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER" 2>/dev/null || true)"
  if [ "$STATUS" = "running" ] && { [ "$HEALTH" = "healthy" ] || [ "$HEALTH" = "none" ]; }; then
    if docker exec "$CONTAINER" node -e '
      fetch("http://127.0.0.1:3001/api/ping")
        .then(async response => {
          const body = await response.json();
          if (!response.ok || body.status !== "ok") process.exit(1);
        })
        .catch(() => process.exit(1));
    ' >/dev/null 2>&1; then
      HEALTH_OK=1
      break
    fi
  fi
  if [ "$STATUS" = "exited" ] || [ "$STATUS" = "dead" ]; then
    break
  fi
  sleep 2
done
test "$HEALTH_OK" -eq 1

test "$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")" = "$NEW_IMAGE"
test "$(docker inspect --format '{{.Image}}' "$CONTAINER")" = "$NEW_IMAGE_ID"

docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  const db = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  const result = db.pragma("quick_check", { simple: true });
  db.close();
  if (result !== "ok") throw new Error(`live quick_check failed: ${result}`);
  console.log("live_database_quick_check=ok");
'

docker exec "$CONTAINER" sh -lc "
  set -eu
  test -s /app/server/dist/services/router.js
  test -s /app/server/dist/services/codex-relay-sources.js
  test -s /app/server/dist/services/codex-relay-maintenance.js
  test -s /app/client/dist/assets/$CLIENT_JS
  test -s /app/client/dist/assets/$CLIENT_CSS
  grep -q /assets/$CLIENT_JS /app/client/dist/index.html
  grep -q /assets/$CLIENT_CSS /app/client/dist/index.html
  grep -q 'A balance error is request-local too' /app/server/dist/lib/fallback-loop.js
  grep -q 'installComputePointUsageResponse' /app/server/dist/lib/compute-points-response.js
  grep -q 'ensureConsumerNativeUsage' /app/server/dist/routes/responses.js
  grep -q 'input_compute_points' /app/server/dist/routes/admin-users.js
  ! grep -q 'X-Tuoke-Usage-Unit' /app/server/dist/lib/compute-points-response.js
  ! grep -q 'X-Tuoke-Compute-Points-Per-Million' /app/server/dist/lib/compute-points-response.js
  ! grep -q 'CODEX_RELAY_MODEL_OUT_OF_CREDITS_COOLDOWN_MS' /app/server/dist/services/codex-relay-sources.js
  ! grep -q 'CODEX_RELAY_MODEL_OUT_OF_CREDITS_COOLDOWN_MS' /app/server/dist/services/fusion.js
"

docker exec "$CONTAINER" node --input-type=module -e '
  import { convertUsageToComputePoints } from "/app/server/dist/lib/compute-points-response.js";
  const converted = convertUsageToComputePoints({
    input_tokens: 100,
    output_tokens: 20,
    total_tokens: 120,
    input_tokens_details: { cached_tokens: 40, cache_write_tokens: 10 },
  }, 1_500_000);
  const expected = JSON.stringify({
    input_tokens: 150,
    output_tokens: 30,
    total_tokens: 180,
    input_tokens_details: { cached_tokens: 60, cache_write_tokens: 15 },
  });
  if (JSON.stringify(converted) !== expected) throw new Error("live account usage conversion check failed");
  console.log("live_account_usage_conversion_check=ok");
'

PUBLIC_OK=0
for _ in $(seq 1 30); do
  if docker exec "$CONTAINER" node -e "
    Promise.all([
      fetch('$PUBLIC_ORIGIN/api/ping', { cache: 'no-store' }).then(async response => {
        const body = await response.json();
        if (!response.ok || body.status !== 'ok') throw new Error('public ping failed');
      }),
      fetch('$PUBLIC_ORIGIN/', { cache: 'no-store' }).then(async response => {
        const html = await response.text();
        if (!response.ok || !html.includes('/assets/$CLIENT_JS') || !html.includes('/assets/$CLIENT_CSS')) {
          throw new Error('public client assets are stale');
        }
      }),
    ]).catch(() => process.exit(1));
  " >/dev/null 2>&1; then
    PUBLIC_OK=1
    break
  fi
  sleep 2
done
test "$PUBLIC_OK" -eq 1

SWITCH_STARTED=0
trap - ERR
echo "deployment_result=ok"
echo "deployment_mode=verified_account_usage_overlay_compose_recreate"
echo "backup_dir=$BACKUP_DIR"
echo "previous_image=$OLD_IMAGE"
echo "previous_image_id=$OLD_IMAGE_ID"
echo "new_image=$NEW_IMAGE"
echo "new_image_id=$NEW_IMAGE_ID"
