export const DEFAULT_POINTS_PER_MILLION_TOKENS = 1_000_000;
export const MAX_POINTS_PER_MILLION_TOKENS = 1_000_000_000;
function validPointsPerMillionTokens(value) {
    return (Number.isInteger(value) &&
        Number(value) >= DEFAULT_POINTS_PER_MILLION_TOKENS &&
        Number(value) <= MAX_POINTS_PER_MILLION_TOKENS);
}
export function currentPointsPerMillionTokens(db, userId = null) {
    if (Number.isInteger(userId) && Number(userId) > 0) {
        const user = db
            .prepare("SELECT compute_points_per_million_tokens AS pointsPerMillion FROM users WHERE id = ?")
            .get(userId);
        if (validPointsPerMillionTokens(user?.pointsPerMillion)) {
            return Number(user.pointsPerMillion);
        }
    }
    const row = db
        .prepare("SELECT value FROM settings WHERE key = 'compute_points_per_million_tokens'")
        .get();
    const value = Number(row?.value);
    return validPointsPerMillionTokens(value)
        ? value
        : DEFAULT_POINTS_PER_MILLION_TOKENS;
}
/** Convert one raw token bucket using a request-scoped points rate. */
export function tokensToComputePoints(tokens, pointsPerMillion) {
    const safeTokens = Math.max(0, Math.trunc(Number(tokens) || 0));
    const points = Math.round((safeTokens * pointsPerMillion) / 1_000_000);
    if (!Number.isSafeInteger(points)) {
        throw new Error('Compute-point usage exceeds safe integer range');
    }
    return points;
}
export function snapshotComputePoints(db, tokens, userId = null, pointsPerMillionOverride = null) {
    const pointsPerMillion = validPointsPerMillionTokens(pointsPerMillionOverride)
        ? pointsPerMillionOverride
        : currentPointsPerMillionTokens(db, userId);
    const points = tokensToComputePoints(tokens, pointsPerMillion);
    return { points, pointsPerMillion };
}
//# sourceMappingURL=compute-points.js.map