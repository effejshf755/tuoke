import { getDb } from '../db/index.js';
/** Pending orders are intentionally short-lived.  A late provider callback or
 * an administrator confirmation can still settle an expired order; expiring
 * is only a routing/UI state, never a deletion or a balance mutation. */
export const DEFAULT_RECHARGE_ORDER_EXPIRY_MINUTES = 10;
export const RECHARGE_ORDER_CLEANUP_INTERVAL_MS = 60 * 1000;
const OLD_ORDER_CLEANUP_INTERVAL_MS = 24 * 60 * 60 * 1000;
const DEFAULT_RETENTION_DAYS = 90;
export function getRechargeOrderExpiryMinutes() {
    const value = Number(process.env.RECHARGE_ORDER_EXPIRY_MINUTES ?? DEFAULT_RECHARGE_ORDER_EXPIRY_MINUTES);
    return Number.isInteger(value) && value > 0 && value <= 24 * 60
        ? value
        : DEFAULT_RECHARGE_ORDER_EXPIRY_MINUTES;
}
export function getRechargeOrderExpiryModifier() {
    return `+${getRechargeOrderExpiryMinutes()} minutes`;
}
/**
 * Mark only genuinely unpaid pending orders as expired.
 *
 * We cap legacy rows that still carry the old 24-hour/30-minute expiry at the
 * current ten-minute policy.  A manual order with an uploaded proof remains
 * pending for an administrator to inspect, even after its nominal deadline.
 */
export function expirePendingRechargeOrders(db = getDb()) {
    const cutoffModifier = `-${getRechargeOrderExpiryMinutes()} minutes`;
    const result = db.prepare(`
    UPDATE recharge_orders
       SET status = 'expired', updated_at = datetime('now')
     WHERE status = 'pending'
       AND (
         (expires_at IS NOT NULL AND datetime(expires_at) <= datetime('now'))
         OR datetime(created_at) <= datetime('now', ?)
       )
       AND (
         payment_method IS NULL
         OR payment_method <> 'manual'
         OR proof_submitted_at IS NULL
       )
  `).run(cutoffModifier);
    if (result.changes > 0) {
        console.log(`[recharge-expiry] marked ${result.changes} unpaid pending order(s) expired`);
    }
    return result.changes;
}
function retentionDays() {
    const value = Number(process.env.RECHARGE_ORDER_RETENTION_DAYS ?? DEFAULT_RETENTION_DAYS);
    return Number.isInteger(value) && value > 0 ? value : DEFAULT_RETENTION_DAYS;
}
export function cleanupOldRechargeOrders() {
    const result = getDb().prepare(`
    DELETE FROM recharge_orders
    WHERE status IN ('paid', 'cancelled', 'expired')
      AND created_at < datetime('now', '-' || ? || ' days')
  `).run(retentionDays());
    if (result.changes > 0) {
        console.log(`[recharge-cleanup] deleted ${result.changes} orders older than ${retentionDays()} days`);
    }
    return result.changes;
}
export function startRechargeOrderCleanup(scheduler) {
    expirePendingRechargeOrders();
    cleanupOldRechargeOrders();
    scheduler.every(RECHARGE_ORDER_CLEANUP_INTERVAL_MS, () => {
        try {
            expirePendingRechargeOrders();
        }
        catch (error) {
            console.error('[recharge-expiry] scheduled expiry pass failed:', error);
        }
    }, { name: 'recharge-order-expiry' });
    scheduler.every(OLD_ORDER_CLEANUP_INTERVAL_MS, () => {
        try {
            cleanupOldRechargeOrders();
        }
        catch (error) {
            console.error('[recharge-cleanup] scheduled retention pass failed:', error);
        }
    }, { name: 'recharge-order-retention' });
}
//# sourceMappingURL=recharge-retention.js.map