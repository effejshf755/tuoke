import { randomUUID } from 'crypto';
import { Router } from 'express';
import multer from 'multer';
import { z } from 'zod';
import { getDb } from '../db/index.js';
import { getSetting, setSetting } from '../db/index.js';
import { createPagePayment, isAlipayConfigured, settleAlipayOrder, verifyNotify } from '../services/alipay.js';
import { getPromotionOffer } from '../services/promotion-offers.js';
import { expirePendingRechargeOrders, getRechargeOrderExpiryMinutes, getRechargeOrderExpiryModifier, } from '../services/recharge-retention.js';
export const userRechargeRouter = Router();
export const adminRechargeRouter = Router();
export const alipayNotifyRouter = Router();
const MANUAL_RECHARGE_THRESHOLD_MICRO = 100_000_000;
const proofUpload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 3 * 1024 * 1024, files: 1 },
    fileFilter: (_req, file, callback) => callback(null, ['image/jpeg', 'image/png', 'image/webp'].includes(file.mimetype)),
});
const createOrderSchema = z.object({
    amount: z
        .number()
        .positive()
        .max(1_000_000_000)
        .optional(),
    payment_method: z
        .enum([
        'manual',
        'alipay',
        'wechat',
    ])
        .optional(),
    offer_code: z.string().trim().min(1).max(100).optional(),
}).superRefine((value, context) => {
    if (value.offer_code && value.amount !== undefined) {
        context.addIssue({
            code: z.ZodIssueCode.custom,
            message: 'Promotion orders cannot override amount',
            path: ['amount'],
        });
    }
    if (!value.offer_code && value.amount === undefined) {
        context.addIssue({
            code: z.ZodIssueCode.custom,
            message: 'Recharge amount or promotion offer is required',
            path: ['amount'],
        });
    }
});
const markPaidSchema = z.object({
    provider_trade_no: z
        .string()
        .trim()
        .max(200)
        .optional(),
    note: z
        .string()
        .trim()
        .max(500)
        .optional(),
});
function getUserId(req) {
    return req.user.userId;
}
function yuanToMicro(value) {
    const result = Math.round(value * 1_000_000);
    if (!Number.isSafeInteger(result) ||
        result <= 0) {
        throw new Error('Invalid recharge amount');
    }
    return result;
}
function microToYuan(value) {
    return value / 1_000_000;
}
function createOrderNo() {
    const random = randomUUID()
        .replace(/-/g, '')
        .slice(0, 10)
        .toUpperCase();
    return `R${Date.now()}${random}`;
}
function createPaymentReference() {
    return `TK${Date.now().toString().slice(-6)}${Math.floor(1000 + Math.random() * 9000)}`;
}
/** Alipay asynchronous notification. This endpoint must remain unauthenticated. */
alipayNotifyRouter.post('/', (req, res) => {
    const params = Object.fromEntries(Object.entries(req.body ?? {}).map(([key, value]) => [key, Array.isArray(value) ? String(value[0]) : String(value ?? '')]));
    if (!verifyNotify(params)) {
        res.status(400).send('fail');
        return;
    }
    if (params.trade_status !== 'TRADE_SUCCESS' && params.trade_status !== 'TRADE_FINISHED') {
        res.send('success');
        return;
    }
    const order = getDb().prepare('SELECT amount_micro amountMicro FROM recharge_orders WHERE order_no=?').get(params.out_trade_no);
    const paidYuan = Number(params.total_amount);
    if (!order || !Number.isFinite(paidYuan) || Math.round(paidYuan * 1_000_000) !== order.amountMicro) {
        res.status(400).send('fail');
        return;
    }
    try {
        const result = settleAlipayOrder(getDb(), params.out_trade_no, params.trade_no, 'Alipay asynchronous notification');
        if (result.status === 'not_found' || result.status === 'invalid_state') {
            res.status(409).send('fail');
            return;
        }
        res.send('success');
    }
    catch (error) {
        console.error('[Alipay] notification settlement failed:', error);
        res.status(500).send('fail');
    }
});
/*
 * ==========================================================
 * USER
 * ==========================================================
 */
/**
 * POST /api/user/recharge/orders
 *
 * Create a pending recharge order.
 */
userRechargeRouter.post('/orders', (req, res) => {
    expirePendingRechargeOrders();
    const parsed = createOrderSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({
            error: {
                message: 'Invalid recharge request',
                type: 'invalid_request',
                details: parsed.error.flatten(),
            },
        });
        return;
    }
    const userId = getUserId(req);
    const db = getDb();
    const offer = parsed.data.offer_code
        ? getPromotionOffer(db, parsed.data.offer_code)
        : null;
    if (parsed.data.offer_code && (!offer
        || offer.offerKind !== 'recharge_bonus'
        || offer.limitedCreditMicro !== 0
        || offer.permanentCreditMicro <= 0)) {
        res.status(404).json({
            error: { message: 'Recharge promotion offer is unavailable', type: 'offer_not_available' },
        });
        return;
    }
    // The 90-to-100 offer uses the platform QR and manual confirmation. This
    // avoids opening a provider checkout page while preserving an immutable
    // offer snapshot and the same idempotent settlement path as large orders.
    const paymentMethod = offer ? 'manual' : (parsed.data.payment_method ?? 'manual');
    if (offer && parsed.data.payment_method && parsed.data.payment_method !== 'manual') {
        res.status(400).json({
            error: { message: 'This promotion requires manual QR payment', type: 'invalid_payment_method' },
        });
        return;
    }
    const amountMicro = offer
        ? offer.priceMicro
        : yuanToMicro(parsed.data.amount);
    const walletCreditMicro = offer?.permanentCreditMicro ?? amountMicro;
    if (!offer && paymentMethod === 'alipay' && amountMicro >= MANUAL_RECHARGE_THRESHOLD_MICRO) {
        res.status(400).json({ error: { message: '100元及以上请使用大额人工充值', type: 'manual_recharge_required' } });
        return;
    }
    if (!offer && paymentMethod === 'manual' && amountMicro < MANUAL_RECHARGE_THRESHOLD_MICRO) {
        res.status(400).json({ error: { message: '人工充值仅用于100元及以上订单', type: 'manual_recharge_minimum' } });
        return;
    }
    const minMicro = Number(getSetting('minimum_recharge_micro') ?? 1_000_000);
    const maxMicro = Number(getSetting('maximum_recharge_micro') ?? 1_000_000_000_000);
    if (!offer && (amountMicro < minMicro || amountMicro > maxMicro)) {
        res.status(400).json({ error: { message: 'Recharge amount is outside configured limits', type: 'invalid_amount' } });
        return;
    }
    const orderNo = createOrderNo();
    const paymentReference = paymentMethod === 'manual' ? createPaymentReference() : null;
    const inserted = db.prepare(`
        INSERT INTO recharge_orders (
          order_no,
          user_id,
          amount_micro,
          status,
          payment_method,
           payment_provider,
           payment_reference,
           promotion_offer_id,
           offer_code_snapshot,
           wallet_credit_micro,
           promotion_credit_micro,
           promotion_validity_seconds,
           expires_at
        )
        VALUES (
          ?,
          ?,
          ?,
          'pending',
           ?,
           NULL,
           ?,
           ?,
           ?,
           ?,
           ?,
           ?,
           datetime(
             'now',
             ?
          )
        )
      `).run(orderNo, userId, amountMicro, paymentMethod, paymentReference, offer?.id ?? null, offer?.code ?? null, walletCreditMicro, offer?.limitedCreditMicro ?? 0, offer?.validitySeconds ?? null, getRechargeOrderExpiryModifier());
    res.status(201).json({
        order: {
            id: Number(inserted.lastInsertRowid),
            order_no: orderNo,
            amount: microToYuan(amountMicro),
            credited_amount: microToYuan(walletCreditMicro),
            offer_code: offer?.code ?? null,
            status: 'pending',
            payment_method: paymentMethod,
            payment_reference: paymentReference,
            expires_in_minutes: getRechargeOrderExpiryMinutes(),
        },
    });
});
userRechargeRouter.get('/manual-config', (_req, res) => {
    res.json({
        threshold: MANUAL_RECHARGE_THRESHOLD_MICRO / 1_000_000,
        qr_image: getSetting('manual_recharge_qr_image') ?? '',
        instructions: '请使用支付宝扫描收款码，支付订单显示的准确金额并填写唯一备注码。管理员核对实际到账后充值，无需上传付款凭证。',
    });
});
userRechargeRouter.post('/orders/:id/proof', proofUpload.single('proof'), (req, res) => {
    const orderId = Number(req.params.id);
    const userId = getUserId(req);
    if (!req.file) {
        res.status(400).json({ error: { message: '请选择 JPG、PNG 或 WebP 付款截图', type: 'proof_required' } });
        return;
    }
    expirePendingRechargeOrders();
    const result = getDb().prepare(`UPDATE recharge_orders SET payment_proof=?, payment_proof_mime=?,
    proof_submitted_at=datetime('now'), updated_at=datetime('now')
    WHERE id=? AND user_id=? AND status='pending' AND payment_method='manual'`)
        .run(req.file.buffer, req.file.mimetype, orderId, userId);
    if (result.changes !== 1) {
        res.status(409).json({ error: { message: '订单不存在或当前状态不能提交凭证', type: 'invalid_order_state' } });
        return;
    }
    res.json({ submitted: true });
});
/** Create an Alipay page-payment form for an existing order. */
userRechargeRouter.post('/orders/:id/alipay', (req, res) => {
    expirePendingRechargeOrders();
    if (!isAlipayConfigured()) {
        res.status(503).json({ error: { message: 'Alipay is not configured', type: 'payment_unavailable' } });
        return;
    }
    const orderId = Number(req.params.id);
    const userId = getUserId(req);
    const order = getDb().prepare("SELECT id, order_no orderNo, amount_micro amountMicro, status, payment_method paymentMethod FROM recharge_orders WHERE id=? AND user_id=?").get(orderId, userId);
    if (!order) {
        res.status(404).json({ error: { message: 'Recharge order not found', type: 'not_found' } });
        return;
    }
    if (order.status !== 'pending') {
        res.status(409).json({ error: { message: `Order is ${order.status}`, type: 'invalid_order_state' } });
        return;
    }
    if (order.paymentMethod === 'manual') {
        res.status(409).json({ error: { message: '人工充值订单不能发起支付宝支付', type: 'invalid_payment_method' } });
        return;
    }
    const payment = createPagePayment(order.orderNo, order.amountMicro, `FreeLLMAPI 充值 ${order.orderNo}`);
    getDb().prepare("UPDATE recharge_orders SET payment_provider='alipay', payment_method='alipay_page', updated_at=datetime('now') WHERE id=?").run(order.id);
    res.json({ order_no: order.orderNo, mode: 'page', gateway: payment.gateway, params: payment.params, form_action: payment.gateway });
});
/**
 * GET /api/user/recharge/orders
 *
 * List current user's recharge orders.
 */
userRechargeRouter.get('/orders', (req, res) => {
    expirePendingRechargeOrders();
    const userId = getUserId(req);
    const requestedStatus = typeof req.query.status === 'string'
        ? req.query.status.trim()
        : '';
    const status = requestedStatus === 'all' ? '' : requestedStatus;
    const statusClause = status
        ? 'AND status = ?'
        : "AND status NOT IN ('expired', 'cancelled')";
    const rows = getDb()
        .prepare(`
          SELECT
            id,

            order_no AS orderNo,

            amount_micro
              AS amountMicro,

            wallet_credit_micro
              AS walletCreditMicro,

            offer_code_snapshot
              AS offerCode,

            status,

            payment_method
              AS paymentMethod,

            payment_provider
              AS paymentProvider,

            provider_trade_no
              AS providerTradeNo,

             note,
             payment_reference AS paymentReference,
             proof_submitted_at AS proofSubmittedAt,

            created_at
              AS createdAt,

            updated_at
              AS updatedAt,

            expires_at
              AS expiresAt,

            paid_at
              AS paidAt

          FROM recharge_orders

          WHERE user_id = ?
            ${statusClause}

          ORDER BY id DESC

          LIMIT 100
        `)
        .all(userId, ...(status ? [status] : []));
    res.json({
        orders: rows.map((row) => ({
            id: row.id,
            order_no: row.orderNo,
            amount: microToYuan(row.amountMicro),
            credited_amount: microToYuan(row.walletCreditMicro ?? row.amountMicro),
            offer_code: row.offerCode,
            status: row.status,
            payment_method: row.paymentMethod,
            payment_provider: row.paymentProvider,
            provider_trade_no: row.providerTradeNo,
            note: row.note,
            payment_reference: row.paymentReference,
            proof_submitted_at: row.proofSubmittedAt,
            created_at: row.createdAt,
            updated_at: row.updatedAt,
            expires_at: row.expiresAt,
            paid_at: row.paidAt,
        })),
    });
});
/**
 * POST /api/user/recharge/orders/:id/cancel
 *
 * User may cancel only their own pending order.
 */
userRechargeRouter.post('/orders/:id/cancel', (req, res) => {
    expirePendingRechargeOrders();
    const userId = getUserId(req);
    const orderId = Number(req.params.id);
    if (!Number.isInteger(orderId) ||
        orderId <= 0) {
        res.status(400).json({
            error: {
                message: 'Invalid order id',
                type: 'invalid_request',
            },
        });
        return;
    }
    const updated = getDb()
        .prepare(`
          UPDATE recharge_orders

          SET
            status = 'cancelled',
            updated_at =
              datetime('now')

          WHERE id = ?
            AND user_id = ?
            AND status = 'pending'
        `)
        .run(orderId, userId);
    if (updated.changes !==
        1) {
        res.status(409).json({
            error: {
                message: 'Order cannot be cancelled',
                type: 'invalid_order_state',
            },
        });
        return;
    }
    res.json({
        success: true,
    });
});
/*
 * ==========================================================
 * ADMIN
 * ==========================================================
 */
adminRechargeRouter.post('/manual-config/qr', proofUpload.single('qr'), (req, res) => {
    if (!req.file) {
        res.status(400).json({ error: { message: '请选择 JPG、PNG 或 WebP 收款二维码', type: 'qr_required' } });
        return;
    }
    const dataUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
    setSetting('manual_recharge_qr_image', dataUrl);
    res.json({ configured: true });
});
adminRechargeRouter.get('/orders/:id/proof', (req, res) => {
    const row = getDb().prepare(`SELECT payment_proof proof, payment_proof_mime mime
    FROM recharge_orders WHERE id=? AND payment_proof IS NOT NULL`).get(Number(req.params.id));
    if (!row) {
        res.status(404).json({ error: { message: '付款凭证不存在', type: 'not_found' } });
        return;
    }
    res.json({ image: `data:${row.mime};base64,${row.proof.toString('base64')}` });
});
/**
 * GET /api/admin/recharge/orders
 *
 * Admin recharge-order management.
 */
adminRechargeRouter.get('/orders', (req, res) => {
    expirePendingRechargeOrders();
    const q = typeof req.query.q ===
        'string'
        ? req.query.q.trim()
        : '';
    const requestedStatus = typeof req.query.status ===
        'string'
        ? req.query.status.trim()
        : '';
    const status = requestedStatus === 'all' ? '' : requestedStatus;
    const statusClause = status
        ? 'AND ro.status = ?'
        : "AND ro.status NOT IN ('expired', 'cancelled')";
    const db = getDb();
    const rows = db.prepare(`
        SELECT
          ro.id,

          ro.order_no
            AS orderNo,

          ro.user_id
            AS userId,

          CASE
            WHEN u.deleted_at IS NOT NULL THEN '已注销用户'
            ELSE u.email
          END AS email,

          ro.amount_micro
            AS amountMicro,

          ro.status,

          ro.payment_method
            AS paymentMethod,

          ro.payment_provider
            AS paymentProvider,

          ro.provider_trade_no
            AS providerTradeNo,

          ro.note,
          ro.payment_reference AS paymentReference,
          ro.proof_submitted_at AS proofSubmittedAt,

          ro.created_at
            AS createdAt,

          ro.updated_at
            AS updatedAt,

          ro.expires_at
            AS expiresAt,

          ro.paid_at
            AS paidAt

        FROM recharge_orders ro

        JOIN users u
          ON u.id = ro.user_id

        WHERE (
          ? = ''
          OR ro.order_no LIKE '%' || ? || '%'
          OR u.email LIKE '%' || ? || '%'
        )

        ${statusClause}

        ORDER BY
          datetime(COALESCE(ro.paid_at, ro.created_at)) DESC,
          ro.id DESC

        LIMIT 500
      `).all(q, q, q, ...(status ? [status] : []));
    res.json({
        orders: rows.map((row) => ({
            id: row.id,
            order_no: row.orderNo,
            user_id: row.userId,
            email: row.email,
            amount: microToYuan(row.amountMicro),
            status: row.status,
            payment_method: row.paymentMethod,
            payment_provider: row.paymentProvider,
            provider_trade_no: row.providerTradeNo,
            note: row.note,
            payment_reference: row.paymentReference,
            proof_submitted_at: row.proofSubmittedAt,
            created_at: row.createdAt,
            updated_at: row.updatedAt,
            expires_at: row.expiresAt,
            paid_at: row.paidAt,
        })),
    });
});
/**
 * POST /api/admin/recharge/orders/:id/mark-paid
 *
 * Atomic and idempotent recharge settlement.
 */
adminRechargeRouter.post('/orders/:id/mark-paid', (req, res) => {
    const orderId = Number(req.params.id);
    if (!Number.isInteger(orderId) ||
        orderId <= 0) {
        res.status(400).json({
            error: {
                message: 'Invalid order id',
                type: 'invalid_request',
            },
        });
        return;
    }
    const parsed = markPaidSchema.safeParse(req.body ?? {});
    if (!parsed.success) {
        res.status(400).json({
            error: {
                message: 'Invalid request',
                type: 'invalid_request',
            },
        });
        return;
    }
    const db = getDb();
    try {
        const settle = db.transaction(() => {
            const order = db.prepare(`
              SELECT
                id,

                order_no
                  AS orderNo,

                user_id
                  AS userId,

                amount_micro
                  AS amountMicro,

                wallet_credit_micro
                  AS walletCreditMicro,

                status
                , payment_method AS paymentMethod
                , proof_submitted_at AS proofSubmittedAt

              FROM recharge_orders

              WHERE id = ?
            `).get(orderId);
            if (!order) {
                return {
                    status: 'not_found',
                };
            }
            /*
             * This endpoint records an administrator-observed QR transfer. It
             * must never settle Alipay/other provider orders: those are settled
             * only by their signed provider callback path.
             */
            if (order.paymentMethod !==
                'manual') {
                return {
                    status: 'invalid_payment_method',
                    paymentMethod: order.paymentMethod,
                };
            }
            /*
             * Idempotency:
             * already-paid order can never credit
             * the wallet a second time.
             */
            if (order.status ===
                'paid') {
                const wallet = db.prepare(`
                SELECT
                  balance_micro
                    AS balanceMicro

                FROM users

                WHERE id = ?
              `).get(order.userId);
                return {
                    status: 'already_paid',
                    orderNo: order.orderNo,
                    balanceMicro: wallet
                        ?.balanceMicro ??
                        0,
                };
            }
            if (![
                'pending',
                'expired',
                'cancelled',
            ].includes(order.status)) {
                return {
                    status: 'invalid_state',
                    currentStatus: order.status,
                };
            }
            const user = db.prepare(`
              SELECT
                id,

                balance_micro
                  AS balanceMicro

              FROM users

              WHERE id = ?
            `).get(order.userId);
            if (!user) {
                throw new Error('Recharge order user not found');
            }
            const creditedMicro = order.walletCreditMicro ?? order.amountMicro;
            const balanceAfterMicro = user.balanceMicro +
                creditedMicro;
            if (!Number.isSafeInteger(balanceAfterMicro)) {
                throw new Error('Wallet balance exceeds safe integer range');
            }
            /*
             * Mark paid first inside the same transaction.
             * The conditional update prevents concurrent double settlement.
             * Expired/cancelled manual orders remain eligible because a QR
             * transfer can arrive before the user cancels or the timer elapses.
             */
            const paid = db.prepare(`
              UPDATE recharge_orders

              SET
                status = 'paid',

                payment_provider =
                  COALESCE(
                    payment_provider,
                    'manual'
                  ),

                provider_trade_no = ?,

                note =
                  COALESCE(
                    ?,
                    note
                  ),

                paid_at =
                  datetime('now'),

                updated_at =
                  datetime('now')

              WHERE id = ?
                AND payment_method = 'manual'
                AND status IN (
                  'pending',
                  'expired',
                  'cancelled'
                )
            `).run(parsed.data
                .provider_trade_no ??
                null, parsed.data.note ??
                null, order.id);
            if (paid.changes !==
                1) {
                throw new Error('Recharge order state changed during settlement');
            }
            db.prepare(`
            UPDATE users

            SET
              balance_micro = ?

            WHERE id = ?
          `).run(balanceAfterMicro, order.userId);
            db.prepare(`
            INSERT INTO wallet_transactions (
              user_id,

              type,

              delta_micro,
              balance_after_micro,

              recharge_order_id,

              note
            )

            VALUES (
              ?,
              'recharge',
              ?,
              ?,
              ?,
              ?
            )
          `).run(order.userId, creditedMicro, balanceAfterMicro, order.id, `Recharge order ${order.orderNo}`);
            return {
                status: 'paid',
                orderNo: order.orderNo,
                amountMicro: order.amountMicro,
                creditedMicro,
                balanceAfterMicro,
            };
        });
        const result = settle();
        if (result.status ===
            'not_found') {
            res.status(404).json({
                error: {
                    message: 'Recharge order not found',
                    type: 'not_found',
                },
            });
            return;
        }
        if (result.status ===
            'invalid_payment_method') {
            res.status(409).json({
                error: {
                    message: 'Only manual QR recharge orders can be confirmed by an administrator',
                    type: 'invalid_payment_method',
                },
            });
            return;
        }
        if (result.status ===
            'invalid_state') {
            res.status(409).json({
                error: {
                    message: `Order is ${result.currentStatus}`,
                    type: 'invalid_order_state',
                },
            });
            return;
        }
        if (result.status ===
            'already_paid') {
            res.json({
                success: true,
                already_paid: true,
                order_no: result.orderNo,
                balance: microToYuan(result.balanceMicro),
            });
            return;
        }
        res.json({
            success: true,
            already_paid: false,
            order_no: result.orderNo,
            amount: microToYuan(result.amountMicro),
            credited_amount: microToYuan(result.creditedMicro),
            balance_after: microToYuan(result.balanceAfterMicro),
        });
    }
    catch (error) {
        console.error('[Recharge] Settlement failed:', error);
        res.status(500).json({
            error: {
                message: 'Failed to settle recharge order',
                type: 'internal_error',
            },
        });
    }
});
//# sourceMappingURL=recharge.js.map