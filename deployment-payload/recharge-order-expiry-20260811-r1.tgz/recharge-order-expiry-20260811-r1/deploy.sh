#!/usr/bin/env bash
set -Eeuo pipefail

CONTAINER="tuoke-prod-freellmapi-1"
COMPOSE_FILE="/srv/tuoke-prod/docker-compose.yml"
COMPOSE_PROJECT="tuoke-prod"
COMPOSE_SERVICE="freellmapi"
DATA_VOLUME="tuoke-prod_freellmapi-data"
PUBLIC_ORIGIN="https://tuokeapi.com"
EXPECTED_COMPOSE_HASH="1bd13b697102ca2aa01f46ee098b3feb35a2f748a5c8b5cc815ebb0d684f144b"
EXPECTED_BASE_IMAGE="migration-japan/tuokeapi:20260811-codex-relay-financial-ledger-r2"
EXPECTED_BASE_IMAGE_ID="sha256:f1fd1af6a2efae5fa82b83a6628a3ffdd2939b90488c94744ca1fa5b9c40d826"
EXPECTED_BASE_RELEASE="codex-relay-financial-ledger-20260811-r2"
RELEASE_LABEL="recharge-order-expiry-20260811-r1"
NEW_IMAGE="migration-japan/tuokeapi:20260811-recharge-order-expiry-r1"
CLIENT_JS="index-recharge-expiry-r1.js"
CLIENT_CSS="index-Cbkhjyuo.css"
CLIENT_JS_SHA256="76ab04b5aa702fbfb5c1a1fe5af372eb797e0e7064937378e1e33c6d532ba04f"
CLIENT_CSS_SHA256="6f2741eaf5c5e4d3cb0ec87688a4141ae47b97bb3052b91cb00422d31f1b6a9c"

RELEASE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="/root/deploy-backups/${RELEASE_LABEL}-${STAMP}"

stage() { printf 'deployment_stage=%s\n' "$1"; }

stage lock
exec 9>/var/lock/tuoke-api-deploy.lock
flock -n 9 || { echo "deployment_lock=busy" >&2; exit 75; }

stage release_validation
test "$(id -u)" -eq 0
test -f "$COMPOSE_FILE"
test -f "$RELEASE_DIR/Dockerfile"
test -f "$RELEASE_DIR/MANIFEST.sha256"
(cd "$RELEASE_DIR" && sha256sum -c MANIFEST.sha256)
for path in \
  patch-client.mjs \
  server-dist/routes/recharge.js \
  server-dist/routes/recharge.js.map \
  server-dist/services/recharge-retention.js \
  server-dist/services/recharge-retention.js.map; do
  test -s "$RELEASE_DIR/$path"
done

docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config -q
mapfile -t COMPOSE_IMAGES < <(docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config --images)
test "${#COMPOSE_IMAGES[@]}" -eq 1
test "${COMPOSE_IMAGES[0]}" = "$EXPECTED_BASE_IMAGE"
COMPOSE_HASH="$(sha256sum "$COMPOSE_FILE" | awk '{print $1}')"
test "$COMPOSE_HASH" = "$EXPECTED_COMPOSE_HASH"

docker inspect "$CONTAINER" >/dev/null
test "$(docker inspect --format '{{.State.Status}}' "$CONTAINER")" = "running"
test "$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER")" = "healthy"
test "$(docker inspect --format '{{.RestartCount}}' "$CONTAINER")" = "0"
OLD_IMAGE="$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")"
OLD_IMAGE_ID="$(docker inspect --format '{{.Image}}' "$CONTAINER")"
OLD_RELEASE="$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$OLD_IMAGE")"
test "$OLD_IMAGE" = "$EXPECTED_BASE_IMAGE"
test "$OLD_IMAGE_ID" = "$EXPECTED_BASE_IMAGE_ID"
test "$OLD_RELEASE" = "$EXPECTED_BASE_RELEASE"
test "$(docker image inspect --format '{{.Id}}' "$OLD_IMAGE")" = "$OLD_IMAGE_ID"
test "$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project"}}' "$CONTAINER")" = "$COMPOSE_PROJECT"
test "$(docker inspect --format '{{index .Config.Labels "com.docker.compose.service"}}' "$CONTAINER")" = "$COMPOSE_SERVICE"
test "$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project.config_files"}}' "$CONTAINER")" = "$COMPOSE_FILE"
test "$(docker inspect --format '{{index .Config.Labels "com.docker.compose.project.working_dir"}}' "$CONTAINER")" = "/srv/tuoke-prod"
test "$(docker inspect --format '{{range .Mounts}}{{if eq .Destination "/app/server/data"}}{{.Name}}{{end}}{{end}}' "$CONTAINER")" = "$DATA_VOLUME"

EXPIRY_ENV="$(docker exec "$CONTAINER" sh -lc 'printf %s "${RECHARGE_ORDER_EXPIRY_MINUTES:-}"')"
test -z "$EXPIRY_ENV" || test "$EXPIRY_ENV" = "10"
BACKGROUND_DELAY_RAW="$(docker exec "$CONTAINER" sh -lc 'printf %s "${BACKGROUND_JOBS_START_DELAY_MS:-}"')"
BACKGROUND_DELAY_MS="${BACKGROUND_DELAY_RAW:-0}"
case "$BACKGROUND_DELAY_MS" in *[!0-9]*) echo "invalid_background_delay" >&2; exit 81 ;; esac
test "$BACKGROUND_DELAY_MS" -le 900000

assert_live_baseline() {
  test "$(sha256sum "$COMPOSE_FILE" | awk '{print $1}')" = "$COMPOSE_HASH"
  mapfile -t current_compose_images < <(docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config --images)
  test "${#current_compose_images[@]}" -eq 1
  test "${current_compose_images[0]}" = "$OLD_IMAGE"
  test "$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")" = "$OLD_IMAGE"
  test "$(docker inspect --format '{{.Image}}' "$CONTAINER")" = "$OLD_IMAGE_ID"
  test "$(docker image inspect --format '{{.Id}}' "$OLD_IMAGE")" = "$OLD_IMAGE_ID"
  test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$OLD_IMAGE")" = "$OLD_RELEASE"
}

assert_live_baseline
docker exec "$CONTAINER" sh -lc "
  set -eu
  echo '74ef3466404e4c951b54caa039a6559aeddd0e5363c1bc94adbdd9ce3790d845  /app/server/dist/routes/recharge.js' | sha256sum -c -
  echo 'f2a60cf9efb7987010d7ea70a8105a861015a868e6f28b901cea882740b226b1  /app/server/dist/services/recharge-retention.js' | sha256sum -c -
  echo '579d5a518f7ccbca66327a12359453aa7a21415d2b624dc01e03f8af413de18b  /app/server/dist/services/alipay.js' | sha256sum -c -
  echo 'a3cc0564699a6bd9a80889e8ae9f3cde16179c1cff60ba329949610a99bed841  /app/server/dist/services/promotion-offers.js' | sha256sum -c -
  echo '15d1bd4276f7866376b8155ee019807375357694430ba7ad86ca667a6ba5afc2  /app/server/dist/index.js' | sha256sum -c -
  echo 'beca20942ebff5cf10feb6e8ac52cf08e85647b217091030328749340696ac1a  /app/server/dist/routes/codex-relay-sources.js' | sha256sum -c -
  echo 'c1d0f0dc2b72ed90b54ab8ca07ddee4434a99c05ae9816d7fc32ba21d804d308  /app/server/dist/services/codex-relay-financial-ledger.js' | sha256sum -c -
  echo 'bdea2f5ef998f558db163d27b36b1edc0e3e2387535439eb9581ce2aa71ccd6d  /app/server/dist/db/migrate/defaults.js' | sha256sum -c -
  echo 'fe3cedaf58d08a8c901baa5eed451877a69b5369b687eeacf098bd278e7d807f  /app/client/dist/index.html' | sha256sum -c -
  echo '29592a64feea9bd2aca5bd4dd86ef2958b97f65fca7623bf8f418ca8a8b9ac43  /app/client/dist/assets/index-ChV_zJe2.js' | sha256sum -c -
  echo '$CLIENT_CSS_SHA256  /app/client/dist/assets/$CLIENT_CSS' | sha256sum -c -
  grep -Fq 'startRechargeOrderCleanup' /app/server/dist/index.js
  grep -Fq \"status IN ('pending','cancelled','expired')\" /app/server/dist/services/alipay.js
"

stage database_preflight
docker exec -i "$CONTAINER" node --input-type=module - <<'NODE'
import Database from 'better-sqlite3';
const db = new Database('/app/server/data/freeapi.db', { readonly: true, fileMustExist: true });
const assert = (condition, message) => { if (!condition) throw new Error(message); };
assert(db.pragma('quick_check', { simple: true }) === 'ok', 'live quick_check failed');
const rechargeColumns = new Set(db.prepare('PRAGMA table_info(recharge_orders)').all().map((row) => row.name));
const walletColumns = new Set(db.prepare('PRAGMA table_info(wallet_transactions)').all().map((row) => row.name));
for (const name of ['promotion_offer_id', 'offer_code_snapshot', 'wallet_credit_micro', 'promotion_credit_micro', 'promotion_validity_seconds', 'payment_reference', 'proof_submitted_at']) {
  assert(rechargeColumns.has(name), `missing recharge_orders.${name}`);
}
assert(walletColumns.has('recharge_order_id'), 'missing wallet_transactions.recharge_order_id');
assert(Boolean(db.prepare('SELECT 1 FROM migrations WHERE filename = ?').get('20260810_000084_codex_relay_financial_ledger.ts')), 'migration 084 is missing');
const pending = Number(db.prepare("SELECT COUNT(*) AS value FROM recharge_orders WHERE status = 'pending'").get().value);
const overdue = Number(db.prepare("SELECT COUNT(*) AS value FROM recharge_orders WHERE status = 'pending' AND datetime(created_at) <= datetime('now', '-10 minutes') AND (payment_method IS NULL OR payment_method <> 'manual' OR proof_submitted_at IS NULL)").get().value);
console.log(`preflight_pending_orders=${pending}`);
console.log(`preflight_expirable_orders=${overdue}`);
db.close();
NODE

stage backup
install -d -m 0700 "$BACKUP_DIR"
cp -a "$COMPOSE_FILE" "$BACKUP_DIR/docker-compose.yml.before"
chmod 0600 "$BACKUP_DIR/docker-compose.yml.before"
docker inspect "$CONTAINER" > "$BACKUP_DIR/container-inspect.before.json"
docker volume inspect "$DATA_VOLUME" > "$BACKUP_DIR/data-volume.before.json"
printf '%s\n' "$OLD_IMAGE" > "$BACKUP_DIR/previous-image.txt"
printf '%s\n' "$OLD_IMAGE_ID" > "$BACKUP_DIR/previous-image-id.txt"
sha256sum "$COMPOSE_FILE" > "$BACKUP_DIR/docker-compose.yml.before.sha256"

CONTAINER_DB_BACKUP="/app/server/data/.deploy-backup-${STAMP}.db"
docker exec "$CONTAINER" node --input-type=module -e '
  import Database from "better-sqlite3";
  const target = process.argv[1];
  const source = new Database("/app/server/data/freeapi.db", { readonly: true, fileMustExist: true });
  await source.backup(target);
  source.close();
  const copy = new Database(target, { readonly: true, fileMustExist: true });
  const result = copy.pragma("quick_check", { simple: true });
  copy.close();
  if (result !== "ok") throw new Error(`backup quick_check failed: ${result}`);
' "$CONTAINER_DB_BACKUP"
docker cp "$CONTAINER:$CONTAINER_DB_BACKUP" "$BACKUP_DIR/freeapi-before.db"
docker exec "$CONTAINER" rm -f -- "$CONTAINER_DB_BACKUP"
test -s "$BACKUP_DIR/freeapi-before.db"
chmod 0600 "$BACKUP_DIR/freeapi-before.db"
sha256sum "$BACKUP_DIR/freeapi-before.db" > "$BACKUP_DIR/freeapi-before.db.sha256"

stage candidate_build
docker build \
  --pull=false \
  --build-arg "BASE_IMAGE=$OLD_IMAGE" \
  --build-arg "BASE_IMAGE_ID=$OLD_IMAGE_ID" \
  --build-arg "BASE_RELEASE=$OLD_RELEASE" \
  --tag "$NEW_IMAGE" \
  "$RELEASE_DIR"

test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$NEW_IMAGE")" = "$RELEASE_LABEL"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.expected-base"}}' "$NEW_IMAGE")" = "$OLD_IMAGE"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.expected-base-id"}}' "$NEW_IMAGE")" = "$OLD_IMAGE_ID"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.expected-base-release"}}' "$NEW_IMAGE")" = "$OLD_RELEASE"
NEW_IMAGE_ID="$(docker image inspect --format '{{.Id}}' "$NEW_IMAGE")"
test -n "$NEW_IMAGE_ID"

stage candidate_logic_test
docker run --rm -i --entrypoint node "$NEW_IMAGE" --input-type=module - <<'NODE'
import Database from 'better-sqlite3';
import {
  expirePendingRechargeOrders,
  getRechargeOrderExpiryMinutes,
  getRechargeOrderExpiryModifier,
} from '/app/server/dist/services/recharge-retention.js';

process.env.RECHARGE_ORDER_EXPIRY_MINUTES = '10';
const db = new Database(':memory:');
db.exec(`
  CREATE TABLE recharge_orders (
    id INTEGER PRIMARY KEY,
    status TEXT NOT NULL,
    expires_at TEXT,
    created_at TEXT NOT NULL,
    payment_method TEXT,
    proof_submitted_at TEXT,
    updated_at TEXT
  );
  INSERT INTO recharge_orders VALUES (1, 'pending', datetime('now', '+1 hour'), datetime('now', '-11 minutes'), 'alipay', NULL, datetime('now'));
  INSERT INTO recharge_orders VALUES (2, 'pending', datetime('now', '+1 hour'), datetime('now', '-9 minutes'), 'alipay', NULL, datetime('now'));
  INSERT INTO recharge_orders VALUES (3, 'pending', datetime('now', '-1 minute'), datetime('now', '-30 minutes'), 'manual', datetime('now', '-20 minutes'), datetime('now'));
  INSERT INTO recharge_orders VALUES (4, 'paid', datetime('now', '-1 hour'), datetime('now', '-1 hour'), 'alipay', NULL, datetime('now'));
  INSERT INTO recharge_orders VALUES (5, 'pending', datetime('now', '-1 minute'), datetime('now', '-2 minutes'), 'alipay', NULL, datetime('now'));
  INSERT INTO recharge_orders VALUES (6, 'pending', datetime('now', '+1 hour'), datetime('now', '-11 minutes'), 'manual', NULL, datetime('now'));
`);
const assert = (condition, message) => { if (!condition) throw new Error(message); };
assert(getRechargeOrderExpiryMinutes() === 10, 'expiry minutes is not 10');
assert(getRechargeOrderExpiryModifier() === '+10 minutes', 'expiry modifier is not 10 minutes');
assert(expirePendingRechargeOrders(db) === 3, 'unexpected number of expired fixtures');
const states = Object.fromEntries(db.prepare('SELECT id, status FROM recharge_orders ORDER BY id').all().map((row) => [row.id, row.status]));
assert(states[1] === 'expired' && states[5] === 'expired' && states[6] === 'expired', 'eligible fixtures were not expired');
assert(states[2] === 'pending' && states[3] === 'pending' && states[4] === 'paid', 'protected fixtures changed state');
assert(expirePendingRechargeOrders(db) === 0, 'expiry pass is not idempotent');
assert(Number(db.prepare('SELECT COUNT(*) AS value FROM recharge_orders').get().value) === 6, 'orders were physically deleted');
assert(db.pragma('quick_check', { simple: true }) === 'ok', 'fixture database failed quick_check');
db.close();
console.log('candidate_recharge_expiry=ok');
NODE

docker run --rm -i \
  --user root \
  --volume "$BACKUP_DIR:/candidate:ro" \
  --entrypoint node \
  "$NEW_IMAGE" \
  --input-type=module - <<'NODE'
import Database from 'better-sqlite3';
await import('/app/server/dist/routes/recharge.js');
await import('/app/server/dist/services/recharge-retention.js');
const db = new Database('/candidate/freeapi-before.db', { readonly: true, fileMustExist: true });
if (db.pragma('quick_check', { simple: true }) !== 'ok') throw new Error('candidate production copy failed quick_check');
db.close();
console.log('candidate_production_import=ok');
NODE

# Refuse to switch if production changed while the candidate was being built.
assert_live_baseline

SWITCH_STARTED=0
rollback() {
  local code="${1:-1}"
  local rollback_ok=0
  trap - ERR HUP INT TERM
  set +e
  if [ "$SWITCH_STARTED" -eq 1 ]; then
    cp -a "$BACKUP_DIR/docker-compose.yml.before" "$COMPOSE_FILE"
    chmod 0600 "$COMPOSE_FILE"
    docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"
    for _ in $(seq 1 30); do
      if test "$(docker inspect --format '{{.Config.Image}}' "$CONTAINER" 2>/dev/null)" = "$OLD_IMAGE" \
        && test "$(docker inspect --format '{{.Image}}' "$CONTAINER" 2>/dev/null)" = "$OLD_IMAGE_ID" \
        && test "$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER" 2>/dev/null)" = "healthy" \
        && test "$(docker inspect --format '{{.RestartCount}}' "$CONTAINER" 2>/dev/null)" = "0" \
        && docker exec "$CONTAINER" node -e '
          fetch("http://127.0.0.1:3001/api/ping")
            .then(async response => {
              const body = await response.json();
              if (!response.ok || body.status !== "ok") process.exit(1);
            })
            .catch(() => process.exit(1));
        ' >/dev/null 2>&1; then
        rollback_ok=1
        break
      fi
      sleep 2
    done
    if [ "$rollback_ok" -eq 1 ]; then
      echo "deployment_result=rolled_back_image_database_left_forward_compatible" >&2
    else
      echo "deployment_result=rollback_failed" >&2
    fi
  fi
  exit "$code"
}
trap 'rollback $?' ERR
trap 'rollback 129' HUP
trap 'rollback 130' INT
trap 'rollback 143' TERM

stage switch
SWITCH_STARTED=1
python3 - "$COMPOSE_FILE" "$NEW_IMAGE" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
image = sys.argv[2]
lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
inside = False
replaced = False
for index, line in enumerate(lines):
    if line.startswith("  freellmapi:"):
        inside = True
        continue
    if inside and line.startswith("  ") and not line.startswith("    ") and line.strip():
        break
    if inside and line.startswith("    image:"):
        newline = "\n" if line.endswith("\n") else ""
        lines[index] = f"    image: {image}{newline}"
        replaced = True
        break
if not replaced:
    raise SystemExit("freellmapi image entry not found")
temporary = path.with_suffix(path.suffix + ".codex-new")
temporary.write_text("".join(lines), encoding="utf-8")
temporary.chmod(0o600)
temporary.replace(path)
PY

docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config -q
mapfile -t SWITCHED_IMAGES < <(docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" config --images)
test "${#SWITCHED_IMAGES[@]}" -eq 1
test "${SWITCHED_IMAGES[0]}" = "$NEW_IMAGE"
docker compose -p "$COMPOSE_PROJECT" -f "$COMPOSE_FILE" up -d --no-build --no-deps --force-recreate "$COMPOSE_SERVICE"

stage health_check
HEALTH_OK=0
for _ in $(seq 1 60); do
  STATUS="$(docker inspect --format '{{.State.Status}}' "$CONTAINER" 2>/dev/null || true)"
  HEALTH="$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER" 2>/dev/null || true)"
  if [ "$STATUS" = "running" ] && { [ "$HEALTH" = "healthy" ] || [ "$HEALTH" = "none" ]; }; then
    if docker exec "$CONTAINER" node -e '
      fetch("http://127.0.0.1:3001/api/ping")
        .then(async response => {
          const body = await response.json();
          if (!response.ok || body.status !== "ok") process.exit(1);
        })
        .catch(() => process.exit(1));
    ' >/dev/null 2>&1; then
      HEALTH_OK=1
      break
    fi
  fi
  if [ "$STATUS" = "exited" ] || [ "$STATUS" = "dead" ]; then break; fi
  sleep 2
done
test "$HEALTH_OK" -eq 1
test "$(docker inspect --format '{{.Config.Image}}' "$CONTAINER")" = "$NEW_IMAGE"
test "$(docker inspect --format '{{.Image}}' "$CONTAINER")" = "$NEW_IMAGE_ID"
test "$(docker inspect --format '{{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$CONTAINER")" = "healthy"
test "$(docker inspect --format '{{.RestartCount}}' "$CONTAINER")" = "0"
test "$(docker image inspect --format '{{index .Config.Labels "tuoke.release"}}' "$NEW_IMAGE")" = "$RELEASE_LABEL"

stage runtime_verification
docker exec "$CONTAINER" sh -lc "
  set -eu
  echo '486b9a61d4c1106bfa285c0a511c3edce2b4a6ced8c1dd0b31f9a898cb8ec5ed  /app/server/dist/routes/recharge.js' | sha256sum -c -
  echo '385e644ad56746e10949d636827d8bcc7e98b690366e697a5682252e130eaecf  /app/server/dist/services/recharge-retention.js' | sha256sum -c -
  echo 'ef69a9d53e74b1081505d6815b6b8e445019f46e1c1a13fc4d9fe36f88c626fa  /app/client/dist/index.html' | sha256sum -c -
  echo '$CLIENT_JS_SHA256  /app/client/dist/assets/$CLIENT_JS' | sha256sum -c -
  echo '$CLIENT_CSS_SHA256  /app/client/dist/assets/$CLIENT_CSS' | sha256sum -c -
  grep -Fq '/assets/$CLIENT_JS' /app/client/dist/index.html
  grep -Fq '/assets/$CLIENT_CSS' /app/client/dist/index.html
  grep -Fq 'expirePendingRechargeOrders' /app/server/dist/routes/recharge.js
"

# Give delayed background jobs enough time to register and execute their
# immediate cleanup pass before evaluating the live database.
BACKGROUND_START_WAIT_ATTEMPTS=$(((BACKGROUND_DELAY_MS + 1999) / 2000 + 2))
for _ in $(seq 1 "$BACKGROUND_START_WAIT_ATTEMPTS"); do
  sleep 2
done

DB_VERIFY_ATTEMPTS=60
DB_VERIFY_OK=0
for _ in $(seq 1 "$DB_VERIFY_ATTEMPTS"); do
  if docker exec -i "$CONTAINER" node --input-type=module - <<'NODE'
import Database from 'better-sqlite3';
const db = new Database('/app/server/data/freeapi.db', { readonly: true, fileMustExist: true });
const quick = db.pragma('quick_check', { simple: true });
if (quick !== 'ok') throw new Error(`live quick_check failed: ${quick}`);
const overdue = Number(db.prepare(`
  SELECT COUNT(*) AS value
  FROM recharge_orders
  WHERE status = 'pending'
    AND (
      (expires_at IS NOT NULL AND datetime(expires_at) <= datetime('now'))
      OR datetime(created_at) <= datetime('now', '-10 minutes')
    )
    AND (
      payment_method IS NULL
      OR payment_method <> 'manual'
      OR proof_submitted_at IS NULL
    )
`).get().value);
if (overdue !== 0) throw new Error(`overdue pending orders remain: ${overdue}`);
console.log('live_database_quick_check=ok');
console.log('live_overdue_pending_orders=0');
db.close();
NODE
  then
    DB_VERIFY_OK=1
    break
  fi
  sleep 2
done
test "$DB_VERIFY_OK" -eq 1

stage public_verification
PUBLIC_OK=0
for _ in $(seq 1 30); do
  if docker exec "$CONTAINER" node -e "
    const { createHash } = require('node:crypto');
    const hash = text => createHash('sha256').update(text).digest('hex');
    const stamp = Date.now();
    Promise.all([
      fetch('$PUBLIC_ORIGIN/api/ping?release=$RELEASE_LABEL&v=' + stamp, { cache: 'no-store' }).then(async response => {
        const body = await response.json();
        if (!response.ok || body.status !== 'ok') throw new Error('public ping failed');
      }),
      fetch('$PUBLIC_ORIGIN/?release=$RELEASE_LABEL&v=' + stamp, { cache: 'no-store' }).then(async response => {
        const html = await response.text();
        if (!response.ok || !html.includes('/assets/$CLIENT_JS') || !html.includes('/assets/$CLIENT_CSS')) throw new Error('public client index is stale');
      }),
      fetch('$PUBLIC_ORIGIN/assets/$CLIENT_JS?v=' + stamp, { cache: 'no-store' }).then(async response => {
        const source = await response.text();
        if (!response.ok || hash(source) !== '$CLIENT_JS_SHA256' || !source.includes('queryKey:[\`admin-recharge-orders\`') || !source.includes('refetchInterval:6e4') || !source.includes('t.status===\`paid\`?t.amount:0') || !source.includes('/financial-ledger')) throw new Error('public recharge bundle is stale');
      }),
      fetch('$PUBLIC_ORIGIN/assets/$CLIENT_CSS?v=' + stamp, { cache: 'no-store' }).then(async response => {
        const source = await response.text();
        if (!response.ok || hash(source) !== '$CLIENT_CSS_SHA256') throw new Error('public CSS is stale');
      }),
    ]).catch(error => { console.error(error); process.exit(1); });
  " >/dev/null 2>&1; then
    PUBLIC_OK=1
    break
  fi
  sleep 2
done
test "$PUBLIC_OK" -eq 1
test "$(docker inspect --format '{{.RestartCount}}' "$CONTAINER")" = "0"

SWITCH_STARTED=0
trap - ERR HUP INT TERM
echo "deployment_result=ok"
echo "deployment_mode=verified_recharge_expiry_overlay"
echo "backup_dir=$BACKUP_DIR"
echo "previous_image=$OLD_IMAGE"
echo "previous_image_id=$OLD_IMAGE_ID"
echo "new_image=$NEW_IMAGE"
echo "new_image_id=$NEW_IMAGE_ID"
