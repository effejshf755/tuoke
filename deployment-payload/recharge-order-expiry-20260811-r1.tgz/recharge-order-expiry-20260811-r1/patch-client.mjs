import { createHash } from 'node:crypto';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';

const [htmlPath, outputJsPath] = process.argv.slice(2);
if (!htmlPath || !outputJsPath) {
  throw new Error('usage: node patch-client.mjs <index.html> <output.js>');
}

const hash = (value) => createHash('sha256').update(value).digest('hex');
const count = (value, needle) => value.split(needle).length - 1;

let html = readFileSync(htmlPath, 'utf8');
const assetMatch = html.match(/<script type="module" crossorigin src="(\/assets\/index-[^"]+\.js)"><\/script>/);
if (!assetMatch) throw new Error('client entry asset was not found');

const sourceAsset = assetMatch[1];
const sourcePath = join(dirname(htmlPath), sourceAsset.slice(1));
if (!existsSync(sourcePath)) throw new Error(`client entry is missing: ${sourceAsset}`);

let source = readFileSync(sourcePath, 'utf8');
const expectedSourceHash = process.env.EXPECTED_CLIENT_JS_SHA256;
if (expectedSourceHash && hash(source) !== expectedSourceHash) {
  throw new Error('client entry hash does not match the audited production baseline');
}

function replaceExact(label, before, after, expectedCount = 1) {
  const actualCount = count(source, before);
  if (actualCount !== expectedCount) {
    throw new Error(`${label}: expected ${expectedCount} match(es), found ${actualCount}`);
  }
  source = source.split(before).join(after);
}

const userOrdersQuery = 'queryKey:[`user-recharge-orders`],queryFn:()=>X(`/api/user/recharge/orders`)';
replaceExact(
  'user order refresh',
  userOrdersQuery,
  `${userOrdersQuery},refetchInterval:6e4`,
);

const manualConfigQuery = 'p=G({queryKey:[`manual-recharge-config`],queryFn:()=>X(`/api/user/recharge/manual-config`)})';
replaceExact(
  'expired manual order dismissal',
  manualConfigQuery,
  `${manualConfigQuery};(0,S.useEffect)(()=>{if(!i||!u.data)return;let e=u.data.orders.find(e=>e.id===i.id);(!e||e.status!==\`pending\`)&&a(null)},[i,u.data])`,
);

const adminOrdersQuery = 'queryKey:[`admin-recharge-orders`,t,r],queryFn:()=>X(`/api/admin/recharge/orders?q=${encodeURIComponent(t)}&status=${encodeURIComponent(r)}`)';
replaceExact(
  'admin order refresh',
  adminOrdersQuery,
  `${adminOrdersQuery},refetchInterval:6e4`,
);

replaceExact(
  'default status label',
  'var Lwe=[[``,`全部`],',
  'var Lwe=[[``,`待确认和已到账`],',
);
replaceExact(
  'visible order count label',
  'children:[e.items.length,` 条充值记录`]',
  'children:[`当前显示 `,e.items.length,` 条充值记录`]',
);
replaceExact(
  'paid-only amount total',
  'l7(e.items.reduce((e,t)=>e+t.amount,0))',
  'l7(e.items.reduce((e,t)=>e+(t.status===`paid`?t.amount:0),0))',
);

for (const marker of [
  '待确认和已到账',
  '当前显示 ',
  '已到账',
  'refetchInterval:6e4',
  '/financial-ledger',
]) {
  if (!source.includes(marker)) throw new Error(`patched client marker is missing: ${marker}`);
}

writeFileSync(outputJsPath, source, 'utf8');

const outputAsset = `/assets/${outputJsPath.replaceAll('\\', '/').split('/').pop()}`;
const htmlNeedle = `src="${sourceAsset}"`;
if (count(html, htmlNeedle) !== 1) throw new Error('client index entry is ambiguous');
html = html.replace(htmlNeedle, `src="${outputAsset}"`);
writeFileSync(htmlPath, html, 'utf8');

console.log(`base_client_asset=${sourceAsset}`);
console.log(`patched_client_asset=${outputAsset}`);
console.log(`patched_client_sha256=${hash(source)}`);
console.log(`patched_index_sha256=${hash(html)}`);
