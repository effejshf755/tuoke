import "./env.js";
import { createApp } from "./app.js";
import { initDb, getDb, getSetting } from "./db/index.js";
import { startHealthChecker, checkAllKeys } from "./services/health.js";
import { applyProxyUrl, applyProxyEnabled, applyProxyBypass, flushProxyCache, } from "./lib/proxy.js";
import { startWakeDetect } from "./lib/wake-detect.js";
import { startCatalogSync } from "./services/catalog-sync.js";
import { installProcessSafetyNet } from "./lib/process-safety-net.js";
import { NodeScheduler } from "./lib/scheduler.js";
import { loadConfig } from "./lib/config.js";
import { applyDeclarativeConfigFromEnv } from "./services/declarative-config.js";
import { restoreDbBackupIfNeeded, startDbBackupPump } from "./lib/db-backup.js";
import { userCount } from "./services/auth.js";
import { generateSetupCode } from "./lib/setup-code.js";
import { warnOnEnvDrift } from "./lib/env-drift.js";
import { startPlaygroundCleanup } from "./services/playground-cleanup.js";
import { startRechargeOrderCleanup } from "./services/recharge-retention.js";
import { startModelHealthScheduler } from "./services/model-health.js";
import { startResourceMaintenance } from "./services/resource-maintenance.js";
import { startCodexAccountQuotaSync } from "./services/codex-oauth.js";
import { startWalletReservationCleanup } from "./services/wallet-reservations.js";
import { startCodexRelayHealthScheduler } from "./services/codex-relay-maintenance.js";
async function main() {
    const config = loadConfig();
    const { port: PORT, host: HOST } = config;
    warnOnEnvDrift();
    // Install first so a late provider socket reset (undici HTTP/2 error with no
    // listener) can't take the proxy down. Genuine bugs still exit 1.
    installProcessSafetyNet();
    const scheduler = new NodeScheduler();
    if (config.dbPath) {
        await restoreDbBackupIfNeeded(config.dbPath);
    }
    else {
        await restoreDbBackupIfNeeded();
    }
    initDb(config.dbPath ?? undefined);
    applyDeclarativeConfigFromEnv();
    // First-run hardening: when the dashboard is still unclaimed, mint a one-time
    // setup code and log it. A loopback browser can finish setup without it; a
    // remote caller must supply it (see routes/auth.ts). Regenerated each boot.
    if (userCount() === 0) {
        generateSetupCode();
    }
    // Load the persisted proxy settings from the DB (env var wins if set).
    // Must happen after initDb so the settings table is ready.
    applyProxyUrl(getSetting("proxy_url") ?? "");
    applyProxyEnabled(getSetting("proxy_enabled") !== "0"); // default: enabled
    applyProxyBypass(getSetting("proxy_bypass") ?? "");
    const app = createApp(config);
    let backgroundJobsStarted = false;
    const startBackgroundJobs = () => {
        if (backgroundJobsStarted)
            return;
        backgroundJobsStarted = true;
        startHealthChecker(scheduler);
        startModelHealthScheduler(scheduler);
        startCatalogSync(scheduler);
        startDbBackupPump(getDb(), scheduler, config.dbPath ?? undefined);
        startPlaygroundCleanup(scheduler);
        startRechargeOrderCleanup(scheduler);
        startResourceMaintenance(scheduler);
        startCodexAccountQuotaSync(scheduler);
        startCodexRelayHealthScheduler(getDb(), scheduler);
        startWalletReservationCleanup(getDb(), scheduler);
    };
    const requestedBackgroundDelay = Number(process.env.BACKGROUND_JOBS_START_DELAY_MS ?? 0);
    const backgroundJobsStartDelayMs = Number.isFinite(requestedBackgroundDelay)
        ? Math.max(0, Math.min(Math.trunc(requestedBackgroundDelay), 15 * 60 * 1000))
        : 0;
    const onReady = (host) => () => {
        const display = host.includes(":") ? `[${host}]` : host;
        console.log(`Server running on http://${display}:${PORT}`);
        console.log(`Proxy endpoint: http://${display}:${PORT}/v1/chat/completions`);
        if (backgroundJobsStartDelayMs > 0) {
            console.log(`[server] Background jobs delayed by ${backgroundJobsStartDelayMs}ms for rolling deployment`);
            scheduler.after(backgroundJobsStartDelayMs, startBackgroundJobs);
        }
        else {
            startBackgroundJobs();
        }
        // Post-sleep recovery: while the host was suspended (laptop lid, VM
        // pause) timers and keep-alive sockets froze, so the first requests after
        // wake used to hit dead pooled connections and pre-sleep key statuses
        // until the 5-minute health cycle caught up. On a detected wake (>30s
        // wall-clock drift, or SIGCONT/SIGUSR1/2), drop the proxy dispatcher's
        // pooled sockets and re-probe every key immediately.
        startWakeDetect({
            async onWake(event) {
                const idle = Math.round(event.idleMs / 1000);
                console.log(`[wake] resumed after ~${idle}s (${event.reason}${event.signal ? `:${event.signal}` : ""}) — flushing stale sockets, re-probing keys`);
                flushProxyCache();
                try {
                    await checkAllKeys();
                }
                catch (err) {
                    console.error(`[wake] post-wake key re-probe failed: ${err?.message ?? err}`);
                }
            },
        });
    };
    const server = app.listen(Number(PORT), HOST, onReady(HOST));
    let shuttingDown = false;
    const shutdown = (signal) => {
        if (shuttingDown)
            return;
        shuttingDown = true;
        console.log(`[server] ${signal} received; draining active requests before shutdown`);
        const forceExit = setTimeout(() => {
            console.error('[server] Graceful shutdown deadline reached; forcing exit');
            process.exit(1);
        }, 55_000);
        forceExit.unref();
        server.close((error) => {
            clearTimeout(forceExit);
            if (error) {
                console.error(`[server] Graceful shutdown failed: ${error.message}`);
                process.exit(1);
            }
            console.log('[server] Active requests drained; shutdown complete');
            process.exit(0);
        });
    };
    process.once('SIGTERM', () => shutdown('SIGTERM'));
    process.once('SIGINT', () => shutdown('SIGINT'));
    server.on("error", (err) => {
        // The default '::' bind fails where IPv6 is disabled (kernel
        // ipv6.disable=1 and the like) — retry IPv4-only rather than dying.
        // Anything else (EADDRINUSE, an explicit HOST that can't bind) keeps the
        // fail-fast posture documented in main().catch below.
        if (!process.env.HOST &&
            (err.code === "EAFNOSUPPORT" || err.code === "EADDRNOTAVAIL")) {
            console.warn("[server] IPv6 unavailable on this host — falling back to 0.0.0.0 (IPv4-only)");
            app.listen(Number(PORT), "0.0.0.0", onReady("0.0.0.0"));
            return;
        }
        console.error("\n[server] Failed to start:\n  " + (err?.message ?? err) + "\n");
        process.exit(1);
    });
}
main().catch((err) => {
    // A boot failure (e.g. a missing production ENCRYPTION_KEY) must exit
    // non-zero rather than leaving a half-initialized process that never starts
    // listening — that silent state is what surfaces in the client as
    // "Can't reach the server".
    console.error("\n[server] Failed to start:\n  " + (err?.message ?? err) + "\n");
    process.exit(1);
});
//# sourceMappingURL=index.js.map