export function up(db) {
    const columns = db.prepare('PRAGMA table_info(model_billing_rules)').all();
    if (!columns.some((column) => column.name === 'user_display_multiplier_milli')) {
        db.exec('ALTER TABLE model_billing_rules ADD COLUMN user_display_multiplier_milli INTEGER');
    }
}
export function down(db) {
    db.exec('ALTER TABLE model_billing_rules DROP COLUMN user_display_multiplier_milli');
}
//# sourceMappingURL=20260727_000052_codex_user_display_multiplier.js.map