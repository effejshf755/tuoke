import type { Db } from '../types.js';
/**
 * Administrator-maintained recharge records for each independent Relay
 * supplier. These entries are operational bookkeeping only: they never alter
 * a user wallet, supplier request totals, or customer billing.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260808_000080_codex_relay_recharge_ledger.d.ts.map