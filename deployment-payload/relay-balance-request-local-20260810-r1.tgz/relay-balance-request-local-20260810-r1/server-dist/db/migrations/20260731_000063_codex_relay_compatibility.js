/**
 * Persist the latest native Responses compatibility smoke-test report.
 *
 * This is deliberately separate from the lightweight health status. Health
 * answers "can this credential serve a tiny request right now?" while this
 * report records the last bounded protocol/capability acceptance run.
 */
export function up(db) {
    const columns = db.prepare('PRAGMA table_info(codex_relay_sources)').all();
    if (!columns.some((column) => column.name === 'compatibility_status')) {
        db.exec(`
      ALTER TABLE codex_relay_sources
      ADD COLUMN compatibility_status TEXT NOT NULL DEFAULT 'untested'
        CHECK (compatibility_status IN ('untested', 'compatible', 'partial', 'incompatible'))
    `);
    }
    if (!columns.some((column) => column.name === 'compatibility_checked_at')) {
        db.exec(`
      ALTER TABLE codex_relay_sources
      ADD COLUMN compatibility_checked_at TEXT
    `);
    }
    if (!columns.some((column) => column.name === 'compatibility_report')) {
        db.exec(`
      ALTER TABLE codex_relay_sources
      ADD COLUMN compatibility_report TEXT
    `);
    }
}
export function down(db) {
    const columns = db.prepare('PRAGMA table_info(codex_relay_sources)').all();
    if (columns.some((column) => column.name === 'compatibility_report')) {
        db.exec('ALTER TABLE codex_relay_sources DROP COLUMN compatibility_report');
    }
    if (columns.some((column) => column.name === 'compatibility_checked_at')) {
        db.exec('ALTER TABLE codex_relay_sources DROP COLUMN compatibility_checked_at');
    }
    if (columns.some((column) => column.name === 'compatibility_status')) {
        db.exec('ALTER TABLE codex_relay_sources DROP COLUMN compatibility_status');
    }
}
//# sourceMappingURL=20260731_000063_codex_relay_compatibility.js.map