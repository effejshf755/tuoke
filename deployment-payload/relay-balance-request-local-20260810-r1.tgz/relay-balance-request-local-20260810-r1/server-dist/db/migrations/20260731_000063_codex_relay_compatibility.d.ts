import type { Db } from '../types.js';
/**
 * Persist the latest native Responses compatibility smoke-test report.
 *
 * This is deliberately separate from the lightweight health status. Health
 * answers "can this credential serve a tiny request right now?" while this
 * report records the last bounded protocol/capability acceptance run.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260731_000063_codex_relay_compatibility.d.ts.map