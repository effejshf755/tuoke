import type { Db } from '../types.js';
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260731_000062_codex_legacy_group_backfill.d.ts.map