/**
 * Persist explicit prompt-cache certification per relay model mapping. A
 * source-level protocol smoke test is insufficient because cache support can
 * differ by upstream model behind the same credential.
 */
export function up(db) {
    const columns = db.prepare('PRAGMA table_info(codex_relay_source_models)').all();
    if (!columns.some((column) => column.name === 'prompt_cache_status')) {
        db.exec(`
      ALTER TABLE codex_relay_source_models
      ADD COLUMN prompt_cache_status TEXT NOT NULL DEFAULT 'untested'
        CHECK (prompt_cache_status IN ('untested', 'compatible', 'partial', 'incompatible'))
    `);
    }
    if (!columns.some((column) => column.name === 'prompt_cache_checked_at')) {
        db.exec(`
      ALTER TABLE codex_relay_source_models
      ADD COLUMN prompt_cache_checked_at TEXT
    `);
    }
    if (!columns.some((column) => column.name === 'prompt_cache_report')) {
        db.exec(`
      ALTER TABLE codex_relay_source_models
      ADD COLUMN prompt_cache_report TEXT
    `);
    }
    db.exec(`
    CREATE INDEX IF NOT EXISTS idx_codex_relay_source_models_prompt_cache
      ON codex_relay_source_models(public_model_id, enabled, prompt_cache_status, source_id)
  `);
}
export function down(db) {
    db.exec('DROP INDEX IF EXISTS idx_codex_relay_source_models_prompt_cache');
    const columns = db.prepare('PRAGMA table_info(codex_relay_source_models)').all();
    if (columns.some((column) => column.name === 'prompt_cache_report')) {
        db.exec('ALTER TABLE codex_relay_source_models DROP COLUMN prompt_cache_report');
    }
    if (columns.some((column) => column.name === 'prompt_cache_checked_at')) {
        db.exec('ALTER TABLE codex_relay_source_models DROP COLUMN prompt_cache_checked_at');
    }
    if (columns.some((column) => column.name === 'prompt_cache_status')) {
        db.exec('ALTER TABLE codex_relay_source_models DROP COLUMN prompt_cache_status');
    }
}
//# sourceMappingURL=20260731_000065_codex_relay_model_prompt_cache.js.map