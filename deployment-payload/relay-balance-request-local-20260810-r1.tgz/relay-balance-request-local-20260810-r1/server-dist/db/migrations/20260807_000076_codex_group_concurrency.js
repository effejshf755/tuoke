const MULTIPLIER_BACKFILL_AUDIT_TABLE = 'codex_group_multiplier_backfill_audit';
function hasTable(db, tableName) {
    return Boolean(db.prepare(`
    SELECT 1
    FROM sqlite_master
    WHERE type = 'table' AND name = ?
    LIMIT 1
  `).get(tableName));
}
export function up(db) {
    db.transaction(() => {
        const columns = db.prepare('PRAGMA table_info(codex_groups)').all();
        if (!columns.some((column) => column.name === 'max_concurrency')) {
            db.exec(`
        ALTER TABLE codex_groups
        ADD COLUMN max_concurrency INTEGER
        CHECK (max_concurrency IS NULL OR (max_concurrency >= 1 AND max_concurrency <= 1000))
      `);
        }
        // Record only rows this migration owns so down() can distinguish them
        // from pre-existing or subsequently edited administrator configuration.
        db.exec(`
      CREATE TABLE IF NOT EXISTS ${MULTIPLIER_BACKFILL_AUDIT_TABLE} (
        group_id INTEGER NOT NULL,
        model_id TEXT NOT NULL,
        previous_multiplier_milli INTEGER,
        applied_multiplier_milli INTEGER NOT NULL,
        PRIMARY KEY (group_id, model_id)
      );

      INSERT OR IGNORE INTO ${MULTIPLIER_BACKFILL_AUDIT_TABLE} (
        group_id, model_id, previous_multiplier_milli, applied_multiplier_milli
      )
      SELECT
        gm.group_id,
        gm.model_id,
        gm.multiplier_milli_override,
        CAST(ROUND(
          COALESCE(gm.multiplier_milli_override, COALESCE(b.multiplier_milli, 1000))
          * g.multiplier_milli / 1000.0
        ) AS INTEGER)
      FROM codex_group_models gm
      JOIN codex_groups g ON g.id = gm.group_id
      LEFT JOIN model_billing_rules b
        ON b.platform = 'openai-codex'
       AND b.model_id = gm.model_id
      WHERE g.multiplier_milli <> 1000
        AND (
          gm.multiplier_milli_override IS NULL
          OR CAST(ROUND(
            COALESCE(gm.multiplier_milli_override, COALESCE(b.multiplier_milli, 1000))
            * g.multiplier_milli / 1000.0
          ) AS INTEGER) <> gm.multiplier_milli_override
        );

      UPDATE codex_group_models
      SET multiplier_milli_override = (
        SELECT audit.applied_multiplier_milli
        FROM ${MULTIPLIER_BACKFILL_AUDIT_TABLE} audit
        WHERE audit.group_id = codex_group_models.group_id
          AND audit.model_id = codex_group_models.model_id
          AND (
            (audit.previous_multiplier_milli IS NULL AND codex_group_models.multiplier_milli_override IS NULL)
            OR audit.previous_multiplier_milli = codex_group_models.multiplier_milli_override
          )
      )
      WHERE EXISTS (
          SELECT 1
          FROM ${MULTIPLIER_BACKFILL_AUDIT_TABLE} audit
          WHERE audit.group_id = codex_group_models.group_id
          AND audit.model_id = codex_group_models.model_id
          AND (
            (audit.previous_multiplier_milli IS NULL AND codex_group_models.multiplier_milli_override IS NULL)
            OR audit.previous_multiplier_milli = codex_group_models.multiplier_milli_override
          )
        );
    `);
    })();
}
export function down(db) {
    db.transaction(() => {
        if (hasTable(db, MULTIPLIER_BACKFILL_AUDIT_TABLE)) {
            db.exec(`
        UPDATE codex_group_models
        SET multiplier_milli_override = (
          SELECT audit.previous_multiplier_milli
          FROM ${MULTIPLIER_BACKFILL_AUDIT_TABLE} audit
          WHERE audit.group_id = codex_group_models.group_id
            AND audit.model_id = codex_group_models.model_id
            AND audit.applied_multiplier_milli = codex_group_models.multiplier_milli_override
        )
        WHERE EXISTS (
          SELECT 1
          FROM ${MULTIPLIER_BACKFILL_AUDIT_TABLE} audit
          WHERE audit.group_id = codex_group_models.group_id
            AND audit.model_id = codex_group_models.model_id
            AND audit.applied_multiplier_milli = codex_group_models.multiplier_milli_override
        );

        DROP TABLE ${MULTIPLIER_BACKFILL_AUDIT_TABLE};
      `);
        }
        const columns = db.prepare('PRAGMA table_info(codex_groups)').all();
        if (columns.some((column) => column.name === 'max_concurrency')) {
            db.exec('ALTER TABLE codex_groups DROP COLUMN max_concurrency');
        }
    })();
}
//# sourceMappingURL=20260807_000076_codex_group_concurrency.js.map