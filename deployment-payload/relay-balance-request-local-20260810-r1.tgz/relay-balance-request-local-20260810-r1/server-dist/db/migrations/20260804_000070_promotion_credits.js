const RECHARGE_OFFER_CODE = 'recharge_90_get_100';
const SPRINT_OFFER_CODE = 'wallet_20_get_25_24h';
function hasColumn(db, table, column) {
    return db.prepare(`PRAGMA table_info(${table})`).all()
        .some((item) => item.name === column);
}
function addColumn(db, table, column, definition) {
    if (!hasColumn(db, table, column)) {
        db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
    }
}
export function up(db) {
    db.exec(`
    CREATE TABLE IF NOT EXISTS promotion_offers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      description TEXT,
      offer_kind TEXT NOT NULL CHECK(offer_kind IN ('recharge_bonus','wallet_sprint')),
      payment_source TEXT NOT NULL CHECK(payment_source IN ('alipay','wallet')),
      price_micro INTEGER NOT NULL CHECK(price_micro > 0),
      permanent_credit_micro INTEGER NOT NULL DEFAULT 0 CHECK(permanent_credit_micro >= 0),
      limited_credit_micro INTEGER NOT NULL DEFAULT 0 CHECK(limited_credit_micro >= 0),
      validity_seconds INTEGER CHECK(validity_seconds IS NULL OR validity_seconds > 0),
      enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      CHECK(permanent_credit_micro > 0 OR limited_credit_micro > 0),
      CHECK(
        (limited_credit_micro = 0 AND validity_seconds IS NULL)
        OR (limited_credit_micro > 0 AND validity_seconds IS NOT NULL)
      )
    );
  `);
    addColumn(db, 'recharge_orders', 'promotion_offer_id', 'INTEGER REFERENCES promotion_offers(id) ON DELETE SET NULL');
    addColumn(db, 'recharge_orders', 'offer_code_snapshot', 'TEXT');
    addColumn(db, 'recharge_orders', 'wallet_credit_micro', 'INTEGER CHECK(wallet_credit_micro IS NULL OR wallet_credit_micro > 0)');
    addColumn(db, 'recharge_orders', 'promotion_credit_micro', 'INTEGER CHECK(promotion_credit_micro IS NULL OR promotion_credit_micro >= 0)');
    addColumn(db, 'recharge_orders', 'promotion_validity_seconds', 'INTEGER CHECK(promotion_validity_seconds IS NULL OR promotion_validity_seconds > 0)');
    // Permanent wallet funds are intentionally not amount-reserved.  Keep a
    // lightweight lifecycle lock on the existing reservation row instead:
    // non-streaming paid requests are exclusive per user, while streaming
    // requests may coexist with one another.  DEFAULT 0 keeps every pre-existing
    // reservation compatible during an online migration.
    addColumn(db, 'wallet_reservations', 'exclusive_wallet_lock', 'INTEGER NOT NULL DEFAULT 0 CHECK(exclusive_wallet_lock IN (0,1))');
    db.exec(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_reservations_exclusive_active
      ON wallet_reservations(user_id)
      WHERE status = 'reserved' AND exclusive_wallet_lock = 1;

    CREATE TRIGGER IF NOT EXISTS trg_wallet_reservations_exclusive_insert
    BEFORE INSERT ON wallet_reservations
    WHEN NEW.status = 'reserved'
    BEGIN
      SELECT RAISE(ABORT, 'wallet_exclusive_lock_conflict')
      WHERE (
        NEW.exclusive_wallet_lock = 1
        AND EXISTS (
          SELECT 1 FROM wallet_reservations
          WHERE user_id = NEW.user_id AND status = 'reserved'
        )
      ) OR (
        NEW.exclusive_wallet_lock = 0
        AND EXISTS (
          SELECT 1 FROM wallet_reservations
          WHERE user_id = NEW.user_id
            AND status = 'reserved'
            AND exclusive_wallet_lock = 1
        )
      );
    END;

    CREATE TRIGGER IF NOT EXISTS trg_wallet_reservations_exclusive_update
    BEFORE UPDATE OF user_id, status, exclusive_wallet_lock ON wallet_reservations
    WHEN NEW.status = 'reserved'
    BEGIN
      SELECT RAISE(ABORT, 'wallet_exclusive_lock_conflict')
      WHERE (
        NEW.exclusive_wallet_lock = 1
        AND EXISTS (
          SELECT 1 FROM wallet_reservations
          WHERE user_id = NEW.user_id
            AND status = 'reserved'
            AND id <> OLD.id
        )
      ) OR (
        NEW.exclusive_wallet_lock = 0
        AND EXISTS (
          SELECT 1 FROM wallet_reservations
          WHERE user_id = NEW.user_id
            AND status = 'reserved'
            AND exclusive_wallet_lock = 1
            AND id <> OLD.id
        )
      );
    END;
  `);
    // Sprint purchases reuse the existing `purchase` transaction type. This
    // nullable link is enough for idempotent recharge settlement and avoids a
    // production-wide rebuild of wallet_transactions during deployment.
    addColumn(db, 'wallet_transactions', 'recharge_order_id', 'INTEGER REFERENCES recharge_orders(id) ON DELETE SET NULL');
    db.exec(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_recharge_order_once
      ON wallet_transactions(recharge_order_id) WHERE type = 'recharge';
  `);
    db.exec(`
    CREATE TABLE IF NOT EXISTS promotion_purchases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_no TEXT NOT NULL UNIQUE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      offer_id INTEGER REFERENCES promotion_offers(id) ON DELETE SET NULL,
      idempotency_key TEXT NOT NULL,
      offer_code_snapshot TEXT NOT NULL,
      price_micro INTEGER NOT NULL CHECK(price_micro > 0),
      permanent_credit_micro INTEGER NOT NULL DEFAULT 0 CHECK(permanent_credit_micro >= 0),
      limited_credit_micro INTEGER NOT NULL CHECK(limited_credit_micro > 0),
      validity_seconds INTEGER NOT NULL CHECK(validity_seconds > 0),
      status TEXT NOT NULL DEFAULT 'paid' CHECK(status IN ('paid','refunded','reversed')),
      wallet_transaction_id INTEGER UNIQUE REFERENCES wallet_transactions(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      paid_at TEXT NOT NULL DEFAULT (datetime('now')),
      refunded_at TEXT,
      UNIQUE(user_id, idempotency_key)
    );

    CREATE TABLE IF NOT EXISTS promotion_credit_grants (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      offer_id INTEGER REFERENCES promotion_offers(id) ON DELETE SET NULL,
      purchase_id INTEGER UNIQUE REFERENCES promotion_purchases(id) ON DELETE CASCADE,
      recharge_order_id INTEGER UNIQUE REFERENCES recharge_orders(id) ON DELETE CASCADE,
      granted_micro INTEGER NOT NULL CHECK(granted_micro > 0),
      remaining_micro INTEGER NOT NULL CHECK(remaining_micro >= 0),
      reserved_micro INTEGER NOT NULL DEFAULT 0 CHECK(reserved_micro >= 0),
      expires_at TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active'
        CHECK(status IN ('active','exhausted','expired','revoked')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      CHECK(remaining_micro <= granted_micro),
      CHECK(reserved_micro <= remaining_micro),
      CHECK((purchase_id IS NOT NULL) != (recharge_order_id IS NOT NULL))
    );

    CREATE TABLE IF NOT EXISTS promotion_credit_allocations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      wallet_reservation_id INTEGER NOT NULL
        REFERENCES wallet_reservations(id) ON DELETE CASCADE,
      grant_id INTEGER NOT NULL REFERENCES promotion_credit_grants(id) ON DELETE CASCADE,
      reserved_micro INTEGER NOT NULL CHECK(reserved_micro > 0),
      consumed_micro INTEGER NOT NULL DEFAULT 0 CHECK(consumed_micro >= 0),
      status TEXT NOT NULL DEFAULT 'reserved'
        CHECK(status IN ('reserved','settled','released')),
      request_id INTEGER REFERENCES requests(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      settled_at TEXT,
      CHECK(consumed_micro <= reserved_micro),
      UNIQUE(wallet_reservation_id, grant_id)
    );

    CREATE TABLE IF NOT EXISTS promotion_credit_ledger (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      grant_id INTEGER NOT NULL REFERENCES promotion_credit_grants(id) ON DELETE CASCADE,
      event_type TEXT NOT NULL CHECK(event_type IN (
        'grant','reserve','usage','release','expire','refund','revoke'
      )),
      remaining_delta_micro INTEGER NOT NULL DEFAULT 0,
      reserved_delta_micro INTEGER NOT NULL DEFAULT 0,
      remaining_after_micro INTEGER NOT NULL CHECK(remaining_after_micro >= 0),
      reserved_after_micro INTEGER NOT NULL CHECK(reserved_after_micro >= 0),
      wallet_reservation_id INTEGER REFERENCES wallet_reservations(id) ON DELETE SET NULL,
      request_id INTEGER REFERENCES requests(id) ON DELETE SET NULL,
      note TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX idx_promotion_purchases_user
      ON promotion_purchases(user_id, id DESC);
    CREATE INDEX idx_promotion_grants_user_expiry
      ON promotion_credit_grants(user_id, status, expires_at, id);
    CREATE INDEX idx_promotion_allocations_reservation
      ON promotion_credit_allocations(wallet_reservation_id, status);
    CREATE INDEX idx_promotion_allocations_grant
      ON promotion_credit_allocations(grant_id, status);
    CREATE INDEX idx_promotion_ledger_user
      ON promotion_credit_ledger(user_id, id DESC);
    CREATE INDEX idx_promotion_ledger_request
      ON promotion_credit_ledger(request_id);
  `);
    db.prepare(`
    INSERT INTO promotion_offers (
      code, name, description, offer_kind, payment_source, price_micro,
      permanent_credit_micro, limited_credit_micro, validity_seconds,
      enabled, sort_order
    ) VALUES (?, ?, ?, 'recharge_bonus', 'alipay', 90000000,
      100000000, 0, NULL, 1, 10)
    ON CONFLICT(code) DO NOTHING
  `).run(RECHARGE_OFFER_CODE, '充值加赠包', '支付宝实付90元，普通永久钱包到账100元');
    db.prepare(`
    INSERT INTO promotion_offers (
      code, name, description, offer_kind, payment_source, price_micro,
      permanent_credit_micro, limited_credit_micro, validity_seconds,
      enabled, sort_order
    ) VALUES (?, ?, ?, 'wallet_sprint', 'wallet', 20000000,
      0, 25000000, 86400, 1, 20)
    ON CONFLICT(code) DO NOTHING
  `).run(SPRINT_OFFER_CODE, '24小时冲刺套餐包', '普通钱包支付20元，获得25元独立API按量额度，购买成功起24小时有效');
}
export function down(db) {
    const used = db.prepare(`
    SELECT
      (SELECT COUNT(*) FROM promotion_purchases)
      +
      (SELECT COUNT(*) FROM recharge_orders
        WHERE offer_code_snapshot IS NOT NULL) AS count
  `).get();
    if (used.count > 0) {
        throw new Error('Irreversible: promotion purchases or recharge orders exist');
    }
    db.exec(`
    DROP TRIGGER IF EXISTS trg_wallet_reservations_exclusive_update;
    DROP TRIGGER IF EXISTS trg_wallet_reservations_exclusive_insert;
    DROP INDEX IF EXISTS idx_wallet_reservations_exclusive_active;

    DROP INDEX IF EXISTS idx_promotion_ledger_request;
    DROP INDEX IF EXISTS idx_promotion_ledger_user;
    DROP INDEX IF EXISTS idx_promotion_allocations_grant;
    DROP INDEX IF EXISTS idx_promotion_allocations_reservation;
    DROP INDEX IF EXISTS idx_promotion_grants_user_expiry;
    DROP INDEX IF EXISTS idx_promotion_purchases_user;
    DROP TABLE IF EXISTS promotion_credit_ledger;
    DROP TABLE IF EXISTS promotion_credit_allocations;
    DROP TABLE IF EXISTS promotion_credit_grants;
    DROP TABLE IF EXISTS promotion_purchases;
  `);
    if (hasColumn(db, 'wallet_reservations', 'exclusive_wallet_lock')) {
        db.exec('ALTER TABLE wallet_reservations DROP COLUMN exclusive_wallet_lock');
    }
    if (hasColumn(db, 'recharge_orders', 'promotion_validity_seconds')) {
        db.exec('ALTER TABLE recharge_orders DROP COLUMN promotion_validity_seconds');
    }
    if (hasColumn(db, 'recharge_orders', 'promotion_credit_micro')) {
        db.exec('ALTER TABLE recharge_orders DROP COLUMN promotion_credit_micro');
    }
    if (hasColumn(db, 'recharge_orders', 'wallet_credit_micro')) {
        db.exec('ALTER TABLE recharge_orders DROP COLUMN wallet_credit_micro');
    }
    if (hasColumn(db, 'recharge_orders', 'offer_code_snapshot')) {
        db.exec('ALTER TABLE recharge_orders DROP COLUMN offer_code_snapshot');
    }
    if (hasColumn(db, 'recharge_orders', 'promotion_offer_id')) {
        db.exec('ALTER TABLE recharge_orders DROP COLUMN promotion_offer_id');
    }
    db.exec('DROP INDEX IF EXISTS idx_wallet_recharge_order_once;');
    if (hasColumn(db, 'wallet_transactions', 'recharge_order_id')) {
        db.exec('ALTER TABLE wallet_transactions DROP COLUMN recharge_order_id');
    }
    db.exec('DROP TABLE IF EXISTS promotion_offers;');
}
//# sourceMappingURL=20260804_000070_promotion_credits.js.map