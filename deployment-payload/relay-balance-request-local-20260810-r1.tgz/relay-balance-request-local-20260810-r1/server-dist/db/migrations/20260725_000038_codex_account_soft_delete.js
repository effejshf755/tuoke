export function up(db) {
    const columns = db.prepare('PRAGMA table_info(codex_oauth_accounts)').all();
    if (!columns.some(column => column.name === 'deleted_at')) {
        db.exec('ALTER TABLE codex_oauth_accounts ADD COLUMN deleted_at TEXT');
    }
    db.exec('CREATE INDEX IF NOT EXISTS idx_codex_oauth_accounts_deleted ON codex_oauth_accounts(deleted_at)');
}
export function down(db) {
    db.exec('DROP INDEX IF EXISTS idx_codex_oauth_accounts_deleted');
    db.exec('ALTER TABLE codex_oauth_accounts DROP COLUMN deleted_at');
}
//# sourceMappingURL=20260725_000038_codex_account_soft_delete.js.map