export function up(db) {
    const columns = db.prepare('PRAGMA table_info(consumer_api_keys)').all();
    if (!columns.some((column) => column.name === 'key_type')) {
        db.exec(`
      ALTER TABLE consumer_api_keys
      ADD COLUMN key_type TEXT NOT NULL DEFAULT 'universal'
      CHECK (key_type IN ('universal', 'codex_pool'))
    `);
    }
}
export function down(db) {
    const columns = db.prepare('PRAGMA table_info(consumer_api_keys)').all();
    if (columns.some((column) => column.name === 'key_type')) {
        db.exec('ALTER TABLE consumer_api_keys DROP COLUMN key_type');
    }
}
//# sourceMappingURL=20260723_000023_consumer_api_key_type.js.map