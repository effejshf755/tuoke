export function up(db) {
    db.exec(`
    ALTER TABLE wallet_transactions RENAME TO wallet_transactions_before_redemption_codes;
    CREATE TABLE wallet_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      type TEXT NOT NULL CHECK(type IN (
        'recharge','usage','refund','admin_adjustment','bonus','purchase','purchase_refund','redemption_code'
      )),
      delta_micro INTEGER NOT NULL,
      balance_after_micro INTEGER NOT NULL CHECK(balance_after_micro >= 0),
      request_id INTEGER REFERENCES requests(id) ON DELETE SET NULL,
      resource_order_id INTEGER REFERENCES resource_orders(id) ON DELETE SET NULL,
      platform TEXT,
      model_id TEXT,
      input_tokens INTEGER NOT NULL DEFAULT 0,
      output_tokens INTEGER NOT NULL DEFAULT 0,
      multiplier_milli INTEGER,
      input_price_micro_per_million INTEGER,
      output_price_micro_per_million INTEGER,
      note TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      cached_input_tokens INTEGER NOT NULL DEFAULT 0 CHECK (cached_input_tokens >= 0),
      cached_input_multiplier_milli INTEGER NOT NULL DEFAULT 1000 CHECK (cached_input_multiplier_milli >= 0)
    );
    INSERT INTO wallet_transactions (
      id, user_id, type, delta_micro, balance_after_micro, request_id,
      resource_order_id, platform, model_id, input_tokens, output_tokens,
      multiplier_milli, input_price_micro_per_million,
      output_price_micro_per_million, note, created_at,
      cached_input_tokens, cached_input_multiplier_milli
    ) SELECT
      id, user_id, type, delta_micro, balance_after_micro, request_id,
      resource_order_id, platform, model_id, input_tokens, output_tokens,
      multiplier_milli, input_price_micro_per_million,
      output_price_micro_per_million, note, created_at,
      cached_input_tokens, cached_input_multiplier_milli
    FROM wallet_transactions_before_redemption_codes;
    DROP TABLE wallet_transactions_before_redemption_codes;

    CREATE INDEX IF NOT EXISTS idx_wallet_transactions_user ON wallet_transactions(user_id);
    CREATE INDEX IF NOT EXISTS idx_wallet_transactions_created ON wallet_transactions(created_at);
    CREATE INDEX IF NOT EXISTS idx_wallet_transactions_request ON wallet_transactions(request_id);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_bonus_once
      ON wallet_transactions(user_id) WHERE type = 'bonus';
    CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_resource_purchase_once
      ON wallet_transactions(resource_order_id) WHERE type = 'purchase';
    CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_resource_refund_once
      ON wallet_transactions(resource_order_id) WHERE type = 'purchase_refund';

    CREATE TABLE IF NOT EXISTS redemption_codes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL UNIQUE COLLATE NOCASE,
      amount_micro INTEGER NOT NULL CHECK (amount_micro > 0),
      max_redemptions INTEGER NOT NULL CHECK (max_redemptions > 0),
      redemption_count INTEGER NOT NULL DEFAULT 0
        CHECK (redemption_count >= 0 AND redemption_count <= max_redemptions),
      expires_at TEXT,
      created_by INTEGER NOT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      deleted_at TEXT
    );

    CREATE TABLE IF NOT EXISTS redemption_code_uses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      redemption_code_id INTEGER NOT NULL REFERENCES redemption_codes(id),
      user_id INTEGER NOT NULL REFERENCES users(id),
      amount_micro INTEGER NOT NULL CHECK (amount_micro > 0),
      redeemed_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (redemption_code_id, user_id)
    );

    CREATE INDEX IF NOT EXISTS idx_redemption_codes_created
      ON redemption_codes(created_at DESC, id DESC);
    CREATE INDEX IF NOT EXISTS idx_redemption_code_uses_code
      ON redemption_code_uses(redemption_code_id, redeemed_at DESC);
    CREATE INDEX IF NOT EXISTS idx_redemption_code_uses_user
      ON redemption_code_uses(user_id, redeemed_at DESC);
  `);
}
export function down(db) {
    const redeemed = db.prepare(`
    SELECT COUNT(*) AS count FROM wallet_transactions WHERE type = 'redemption_code'
  `).get();
    if (redeemed.count > 0) {
        throw new Error('Cannot reverse redemption code migration while redemption wallet rows exist');
    }
    db.exec(`
    DROP INDEX IF EXISTS idx_redemption_code_uses_user;
    DROP INDEX IF EXISTS idx_redemption_code_uses_code;
    DROP INDEX IF EXISTS idx_redemption_codes_created;
    DROP TABLE IF EXISTS redemption_code_uses;
    DROP TABLE IF EXISTS redemption_codes;

    ALTER TABLE wallet_transactions RENAME TO wallet_transactions_with_redemption_codes;
    CREATE TABLE wallet_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      type TEXT NOT NULL CHECK(type IN (
        'recharge','usage','refund','admin_adjustment','bonus','purchase','purchase_refund'
      )),
      delta_micro INTEGER NOT NULL,
      balance_after_micro INTEGER NOT NULL CHECK(balance_after_micro >= 0),
      request_id INTEGER REFERENCES requests(id) ON DELETE SET NULL,
      resource_order_id INTEGER REFERENCES resource_orders(id) ON DELETE SET NULL,
      platform TEXT,
      model_id TEXT,
      input_tokens INTEGER NOT NULL DEFAULT 0,
      output_tokens INTEGER NOT NULL DEFAULT 0,
      multiplier_milli INTEGER,
      input_price_micro_per_million INTEGER,
      output_price_micro_per_million INTEGER,
      note TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      cached_input_tokens INTEGER NOT NULL DEFAULT 0 CHECK (cached_input_tokens >= 0),
      cached_input_multiplier_milli INTEGER NOT NULL DEFAULT 1000 CHECK (cached_input_multiplier_milli >= 0)
    );
    INSERT INTO wallet_transactions (
      id, user_id, type, delta_micro, balance_after_micro, request_id,
      resource_order_id, platform, model_id, input_tokens, output_tokens,
      multiplier_milli, input_price_micro_per_million,
      output_price_micro_per_million, note, created_at,
      cached_input_tokens, cached_input_multiplier_milli
    ) SELECT
      id, user_id, type, delta_micro, balance_after_micro, request_id,
      resource_order_id, platform, model_id, input_tokens, output_tokens,
      multiplier_milli, input_price_micro_per_million,
      output_price_micro_per_million, note, created_at,
      cached_input_tokens, cached_input_multiplier_milli
    FROM wallet_transactions_with_redemption_codes;
    DROP TABLE wallet_transactions_with_redemption_codes;
    CREATE INDEX IF NOT EXISTS idx_wallet_transactions_user ON wallet_transactions(user_id);
    CREATE INDEX IF NOT EXISTS idx_wallet_transactions_created ON wallet_transactions(created_at);
    CREATE INDEX IF NOT EXISTS idx_wallet_transactions_request ON wallet_transactions(request_id);
    CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_bonus_once
      ON wallet_transactions(user_id) WHERE type = 'bonus';
    CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_resource_purchase_once
      ON wallet_transactions(resource_order_id) WHERE type = 'purchase';
    CREATE UNIQUE INDEX IF NOT EXISTS idx_wallet_resource_refund_once
      ON wallet_transactions(resource_order_id) WHERE type = 'purchase_refund';
  `);
}
//# sourceMappingURL=20260728_000054_redemption_codes.js.map