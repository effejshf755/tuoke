import type { Db } from '../types.js';
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260727_000052_codex_user_display_multiplier.d.ts.map