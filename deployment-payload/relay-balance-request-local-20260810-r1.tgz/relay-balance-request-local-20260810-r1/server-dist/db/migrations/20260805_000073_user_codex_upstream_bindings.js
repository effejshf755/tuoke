/**
 * Optional, strict per-user routing affinity inside one Codex group.  Keeping
 * the group in the primary key preserves the existing isolation boundary for
 * users that own Codex keys in more than one group.
 */
export function up(db) {
    db.exec(`
    CREATE TABLE IF NOT EXISTS user_codex_upstream_bindings (
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      codex_group_id INTEGER NOT NULL REFERENCES codex_groups(id) ON DELETE CASCADE,
      target_type TEXT NOT NULL CHECK (target_type IN ('oauth', 'relay')),
      oauth_account_id INTEGER REFERENCES codex_oauth_accounts(id) ON DELETE RESTRICT,
      relay_source_id INTEGER REFERENCES codex_relay_sources(id) ON DELETE RESTRICT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (user_id, codex_group_id),
      CHECK (
        (target_type = 'oauth' AND oauth_account_id IS NOT NULL AND relay_source_id IS NULL)
        OR
        (target_type = 'relay' AND relay_source_id IS NOT NULL AND oauth_account_id IS NULL)
      )
    );

    CREATE INDEX IF NOT EXISTS idx_user_codex_upstream_oauth
      ON user_codex_upstream_bindings(oauth_account_id)
      WHERE oauth_account_id IS NOT NULL;
    CREATE INDEX IF NOT EXISTS idx_user_codex_upstream_relay
      ON user_codex_upstream_bindings(relay_source_id)
      WHERE relay_source_id IS NOT NULL;
  `);
}
export function down(db) {
    db.exec(`
    DROP INDEX IF EXISTS idx_user_codex_upstream_relay;
    DROP INDEX IF EXISTS idx_user_codex_upstream_oauth;
    DROP TABLE IF EXISTS user_codex_upstream_bindings;
  `);
}
//# sourceMappingURL=20260805_000073_user_codex_upstream_bindings.js.map