import type { Db } from '../types.js';
/**
 * Optional, strict per-user routing affinity inside one Codex group.  Keeping
 * the group in the primary key preserves the existing isolation boundary for
 * users that own Codex keys in more than one group.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260805_000073_user_codex_upstream_bindings.d.ts.map