import type { Db } from '../types.js';
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260725_000031_resource_products_orders.d.ts.map