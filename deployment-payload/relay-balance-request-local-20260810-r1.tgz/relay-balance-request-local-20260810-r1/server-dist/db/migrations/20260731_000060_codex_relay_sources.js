/**
 * Third-party Codex relay credentials deliberately share the encrypted
 * `api_keys` vault, but must never become ordinary custom-provider keys.  The
 * role column makes that separation queryable and the relay tables keep the
 * routing/configuration surface independent from OAuth accounts and resource
 * subpools.
 */
export function up(db) {
    const apiKeyColumns = db.prepare('PRAGMA table_info(api_keys)').all();
    if (!apiKeyColumns.some((column) => column.name === 'role')) {
        db.exec(`
      ALTER TABLE api_keys
      ADD COLUMN role TEXT NOT NULL DEFAULT 'provider'
      CHECK (role IN ('provider', 'codex_relay'))
    `);
    }
    db.exec(`
    CREATE INDEX IF NOT EXISTS idx_api_keys_role ON api_keys(role);

    CREATE TABLE IF NOT EXISTS codex_relay_sources (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      api_key_id INTEGER NOT NULL UNIQUE REFERENCES api_keys(id) ON DELETE RESTRICT,
      name TEXT NOT NULL,
      codex_group_id INTEGER REFERENCES codex_groups(id) ON DELETE SET NULL,
      protocol TEXT NOT NULL DEFAULT 'chat_completions'
        CHECK (protocol IN ('chat_completions', 'responses')),
      enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
      priority INTEGER NOT NULL DEFAULT 100 CHECK (priority >= 0 AND priority <= 1000000),
      status TEXT NOT NULL DEFAULT 'unknown'
        CHECK (status IN ('unknown', 'healthy', 'unhealthy', 'invalid', 'error')),
      last_used_at TEXT,
      last_checked_at TEXT,
      last_error TEXT,
      failure_count INTEGER NOT NULL DEFAULT 0 CHECK (failure_count >= 0),
      cooldown_until TEXT,
      balance REAL,
      balance_currency TEXT,
      balance_synced_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_codex_relay_sources_candidate
      ON codex_relay_sources(enabled, status, cooldown_until, priority, codex_group_id);
    CREATE INDEX IF NOT EXISTS idx_codex_relay_sources_group
      ON codex_relay_sources(codex_group_id);

    CREATE TABLE IF NOT EXISTS codex_relay_source_models (
      source_id INTEGER NOT NULL REFERENCES codex_relay_sources(id) ON DELETE CASCADE,
      public_model_id TEXT NOT NULL,
      upstream_model_id TEXT NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
      supports_tools INTEGER NOT NULL DEFAULT 1 CHECK (supports_tools IN (0, 1)),
      supports_vision INTEGER NOT NULL DEFAULT 0 CHECK (supports_vision IN (0, 1)),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (source_id, public_model_id)
    );
    CREATE INDEX IF NOT EXISTS idx_codex_relay_source_models_lookup
      ON codex_relay_source_models(public_model_id, enabled, source_id);
  `);
}
export function down(db) {
    db.exec(`
    DROP INDEX IF EXISTS idx_codex_relay_source_models_lookup;
    DROP TABLE IF EXISTS codex_relay_source_models;
    DROP INDEX IF EXISTS idx_codex_relay_sources_group;
    DROP INDEX IF EXISTS idx_codex_relay_sources_candidate;
    DROP TABLE IF EXISTS codex_relay_sources;
    DROP INDEX IF EXISTS idx_api_keys_role;
  `);
    const apiKeyColumns = db.prepare('PRAGMA table_info(api_keys)').all();
    if (apiKeyColumns.some((column) => column.name === 'role')) {
        db.exec('ALTER TABLE api_keys DROP COLUMN role');
    }
}
//# sourceMappingURL=20260731_000060_codex_relay_sources.js.map