export function up(db) {
    db.exec(`
    CREATE TABLE IF NOT EXISTS free_model_membership_purchases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      purchase_no TEXT NOT NULL UNIQUE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      wallet_transaction_id INTEGER REFERENCES wallet_transactions(id) ON DELETE SET NULL,
      idempotency_key TEXT NOT NULL,
      price_micro INTEGER NOT NULL CHECK (price_micro > 0),
      starts_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      UNIQUE (user_id, idempotency_key),
      CHECK (datetime(expires_at) > datetime(starts_at))
    );

    CREATE INDEX IF NOT EXISTS idx_free_model_membership_purchases_user
      ON free_model_membership_purchases(user_id, id DESC);
    CREATE INDEX IF NOT EXISTS idx_free_model_membership_purchases_expiry
      ON free_model_membership_purchases(expires_at);
  `);
}
export function down(db) {
    db.exec(`
    DROP INDEX IF EXISTS idx_free_model_membership_purchases_expiry;
    DROP INDEX IF EXISTS idx_free_model_membership_purchases_user;
    DROP TABLE IF EXISTS free_model_membership_purchases;
  `);
}
//# sourceMappingURL=20260806_000075_free_model_memberships.js.map