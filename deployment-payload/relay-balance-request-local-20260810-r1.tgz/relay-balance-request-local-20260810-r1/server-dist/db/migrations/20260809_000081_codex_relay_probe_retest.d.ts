import type { Db } from '../types.js';
/**
 * Keep the legacy four-value compatibility_status columns intact while
 * recording that the latest administrator probe ended in a temporary upstream
 * condition. This avoids rebuilding two live SQLite tables solely to extend a
 * CHECK constraint and keeps older application images able to read the rows.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260809_000081_codex_relay_probe_retest.d.ts.map