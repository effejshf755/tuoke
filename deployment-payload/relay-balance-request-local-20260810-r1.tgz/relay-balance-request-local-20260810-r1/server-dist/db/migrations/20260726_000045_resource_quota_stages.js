export function up(db) {
    const addColumn = (name, definition) => {
        const columns = db.prepare('PRAGMA table_info(resource_subpools)').all();
        if (!columns.some((column) => column.name === name)) {
            db.exec(`ALTER TABLE resource_subpools ADD COLUMN ${name} ${definition}`);
        }
    };
    // Existing pools remain fully released. Newly activated pools explicitly enter stage one.
    addColumn('quota_stage', "INTEGER NOT NULL DEFAULT 2 CHECK (quota_stage IN (1, 2))");
    addColumn('stage_one_release_percent', 'REAL NOT NULL DEFAULT 50 CHECK (stage_one_release_percent > 0 AND stage_one_release_percent < 100)');
    addColumn('stage_one_floor_percent', 'REAL NOT NULL DEFAULT 50 CHECK (stage_one_floor_percent >= 0 AND stage_one_floor_percent <= 100)');
    addColumn('stage_started_official_percent', 'REAL');
    addColumn('stage_one_released_units', 'INTEGER');
    addColumn('stage_one_used_units', 'INTEGER');
    addColumn('stage_one_completed_official_percent', 'REAL');
    addColumn('stage_one_completed_at', 'TEXT');
    addColumn('stage_two_released_at', 'TEXT');
    addColumn('stage_two_multiplier_factor_micros', 'INTEGER NOT NULL DEFAULT 1000000 CHECK (stage_two_multiplier_factor_micros > 0)');
}
export function down(_db) {
    throw new Error('irreversible migration: SQLite requires a table rebuild to remove quota stage columns');
}
//# sourceMappingURL=20260726_000045_resource_quota_stages.js.map