import type { Db } from '../types.js';
export declare function up(db: Db): void;
export declare function down(_db: Db): void;
//# sourceMappingURL=20260723_000020_codex_models.d.ts.map