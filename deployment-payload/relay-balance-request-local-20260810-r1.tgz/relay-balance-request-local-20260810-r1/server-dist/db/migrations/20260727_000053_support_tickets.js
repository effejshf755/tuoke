export function up(db) {
    db.exec(`
    CREATE TABLE IF NOT EXISTS support_tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      subject TEXT NOT NULL CHECK (length(subject) BETWEEN 1 AND 120),
      status TEXT NOT NULL DEFAULT 'open'
        CHECK (status IN ('open', 'admin_replied', 'resolved')),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS support_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticket_id INTEGER NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
      sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      sender_role TEXT NOT NULL CHECK (sender_role IN ('user', 'admin')),
      content TEXT NOT NULL CHECK (length(content) BETWEEN 1 AND 2000),
      read_at TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE INDEX IF NOT EXISTS idx_support_tickets_user_updated
      ON support_tickets(user_id, updated_at DESC);
    CREATE INDEX IF NOT EXISTS idx_support_tickets_status_updated
      ON support_tickets(status, updated_at DESC);
    CREATE INDEX IF NOT EXISTS idx_support_messages_ticket_created
      ON support_messages(ticket_id, created_at ASC, id ASC);
  `);
}
export function down(db) {
    db.exec(`
    DROP INDEX IF EXISTS idx_support_messages_ticket_created;
    DROP INDEX IF EXISTS idx_support_tickets_status_updated;
    DROP INDEX IF EXISTS idx_support_tickets_user_updated;
    DROP TABLE IF EXISTS support_messages;
    DROP TABLE IF EXISTS support_tickets;
  `);
}
//# sourceMappingURL=20260727_000053_support_tickets.js.map