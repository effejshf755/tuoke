export function up(db) {
    db.prepare(`
    UPDATE models
    SET supports_tools = 1
    WHERE platform = 'openai-codex' AND model_id = 'codex'
  `).run();
}
export function down(db) {
    db.prepare(`
    UPDATE models
    SET supports_tools = 0
    WHERE platform = 'openai-codex' AND model_id = 'codex'
  `).run();
}
//# sourceMappingURL=20260725_000041_codex_alias_tools.js.map