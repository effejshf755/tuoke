import type { Db } from '../types.js';
/**
 * Persist explicit prompt-cache certification per relay model mapping. A
 * source-level protocol smoke test is insufficient because cache support can
 * differ by upstream model behind the same credential.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260731_000065_codex_relay_model_prompt_cache.d.ts.map