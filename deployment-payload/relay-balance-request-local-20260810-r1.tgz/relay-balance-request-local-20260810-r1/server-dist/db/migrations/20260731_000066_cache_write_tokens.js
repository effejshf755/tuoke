const TOTAL_CACHE_WRITE_TOKENS_KEY = 'total_cache_write_tokens';
function hasColumn(db, table, column) {
    const columns = db.prepare(`PRAGMA table_info(${table})`).all();
    return columns.some((item) => item.name === column);
}
function addColumn(db, table, column, definition) {
    if (!hasColumn(db, table, column)) {
        db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
    }
}
export function up(db) {
    addColumn(db, 'requests', 'cache_write_tokens', 'INTEGER NOT NULL DEFAULT 0 CHECK (cache_write_tokens >= 0)');
    addColumn(db, 'request_hourly', 'cache_write_tokens', 'INTEGER NOT NULL DEFAULT 0 CHECK (cache_write_tokens >= 0)');
    addColumn(db, 'codex_usage_records', 'cache_write_tokens', 'INTEGER NOT NULL DEFAULT 0 CHECK (cache_write_tokens >= 0)');
    addColumn(db, 'codex_usage_records', 'cache_write_multiplier_milli', 'INTEGER NOT NULL DEFAULT 1250 CHECK (cache_write_multiplier_milli >= 0)');
    addColumn(db, 'codex_usage_stats', 'cache_write_tokens', 'INTEGER NOT NULL DEFAULT 0 CHECK (cache_write_tokens >= 0)');
    addColumn(db, 'wallet_transactions', 'cache_write_tokens', 'INTEGER NOT NULL DEFAULT 0 CHECK (cache_write_tokens >= 0)');
    addColumn(db, 'wallet_transactions', 'cache_write_multiplier_milli', 'INTEGER NOT NULL DEFAULT 1250 CHECK (cache_write_multiplier_milli >= 0)');
    addColumn(db, 'resource_quota_reservations', 'cache_write_tokens', 'INTEGER NOT NULL DEFAULT 0 CHECK (cache_write_tokens >= 0)');
    addColumn(db, 'resource_quota_reservations', 'cache_write_multiplier_micros', 'INTEGER NOT NULL DEFAULT 1250000 CHECK (cache_write_multiplier_micros >= 0)');
    const total = db.prepare(`
    SELECT COALESCE(SUM(cache_write_tokens), 0) AS total
    FROM requests
  `).get();
    db.prepare(`
    INSERT INTO settings (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(TOTAL_CACHE_WRITE_TOKENS_KEY, String(total.total));
}
export function down(db) {
    db.prepare('DELETE FROM settings WHERE key = ?').run(TOTAL_CACHE_WRITE_TOKENS_KEY);
    const columns = [
        ['resource_quota_reservations', 'cache_write_multiplier_micros'],
        ['resource_quota_reservations', 'cache_write_tokens'],
        ['wallet_transactions', 'cache_write_multiplier_milli'],
        ['wallet_transactions', 'cache_write_tokens'],
        ['codex_usage_stats', 'cache_write_tokens'],
        ['codex_usage_records', 'cache_write_multiplier_milli'],
        ['codex_usage_records', 'cache_write_tokens'],
        ['request_hourly', 'cache_write_tokens'],
        ['requests', 'cache_write_tokens'],
    ];
    for (const [table, column] of columns) {
        if (hasColumn(db, table, column)) {
            db.exec(`ALTER TABLE ${table} DROP COLUMN ${column}`);
        }
    }
}
//# sourceMappingURL=20260731_000066_cache_write_tokens.js.map