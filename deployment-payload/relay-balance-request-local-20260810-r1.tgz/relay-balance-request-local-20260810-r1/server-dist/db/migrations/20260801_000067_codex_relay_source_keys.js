function hasTable(db, table) {
    return Boolean(db.prepare(`
    SELECT 1
    FROM sqlite_master
    WHERE type = 'table' AND name = ?
  `).get(table));
}
function hasColumn(db, table, column) {
    const columns = db.prepare(`PRAGMA table_info(${table})`).all();
    return columns.some((candidate) => candidate.name === column);
}
/**
 * Split a relay supplier from its credentials.  The legacy api_key_id stays on
 * codex_relay_sources as a compatibility/primary-key anchor while all runtime
 * selection and per-key health state moves to this child table.
 */
export function up(db) {
    db.transaction(() => {
        const invalidLegacySource = db.prepare(`
      SELECT COUNT(*) AS count
      FROM codex_relay_sources s
      LEFT JOIN api_keys k
        ON k.id = s.api_key_id
       AND k.role = 'codex_relay'
      WHERE k.id IS NULL
         OR k.enabled NOT IN (0, 1)
         OR k.status NOT IN ('unknown', 'healthy', 'unhealthy', 'invalid', 'error')
    `).get();
        if (invalidLegacySource.count > 0) {
            throw new Error('Cannot migrate relay sources: every source must reference one valid codex_relay API key');
        }
        if (!hasColumn(db, 'codex_relay_sources', 'base_url')) {
            db.exec('ALTER TABLE codex_relay_sources ADD COLUMN base_url TEXT');
        }
        db.exec(`
      UPDATE codex_relay_sources
      SET base_url = (
        SELECT k.base_url
        FROM api_keys k
        WHERE k.id = codex_relay_sources.api_key_id
          AND k.role = 'codex_relay'
      )
      WHERE base_url IS NULL OR TRIM(base_url) = '';
    `);
        const missingBaseUrl = db.prepare(`
      SELECT COUNT(*) AS count
      FROM codex_relay_sources
      WHERE base_url IS NULL OR TRIM(base_url) = ''
    `).get();
        if (missingBaseUrl.count > 0) {
            throw new Error('Cannot migrate relay sources: every source must have a non-empty base URL');
        }
        db.exec(`
      CREATE TABLE IF NOT EXISTS codex_relay_source_keys (
        api_key_id INTEGER PRIMARY KEY REFERENCES api_keys(id) ON DELETE RESTRICT,
        source_id INTEGER NOT NULL REFERENCES codex_relay_sources(id) ON DELETE CASCADE,
        label TEXT NOT NULL DEFAULT '',
        priority INTEGER NOT NULL DEFAULT 100 CHECK (priority >= 0 AND priority <= 1000000),
        enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
        status TEXT NOT NULL DEFAULT 'unknown'
          CHECK (status IN ('unknown', 'healthy', 'unhealthy', 'invalid', 'error')),
        last_used_at TEXT,
        last_checked_at TEXT,
        last_error TEXT,
        failure_count INTEGER NOT NULL DEFAULT 0 CHECK (failure_count >= 0),
        cooldown_until TEXT,
        balance REAL,
        balance_currency TEXT,
        balance_synced_at TEXT,
        credential_revision INTEGER NOT NULL DEFAULT 0 CHECK (credential_revision >= 0),
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
      CREATE INDEX IF NOT EXISTS idx_codex_relay_source_keys_source
        ON codex_relay_source_keys(source_id, priority, api_key_id);
      CREATE INDEX IF NOT EXISTS idx_codex_relay_source_keys_candidate
        ON codex_relay_source_keys(source_id, enabled, status, cooldown_until, priority, last_used_at);

      INSERT OR IGNORE INTO codex_relay_source_keys (
        api_key_id, source_id, label, priority, enabled, status,
        last_used_at, last_checked_at, last_error, failure_count,
        cooldown_until, balance, balance_currency, balance_synced_at,
        credential_revision, created_at, updated_at
      )
      SELECT
        s.api_key_id,
        s.id,
        k.label,
        100,
        k.enabled,
        k.status,
        s.last_used_at,
        COALESCE(k.last_checked_at, s.last_checked_at),
        s.last_error,
        s.failure_count,
        s.cooldown_until,
        s.balance,
        s.balance_currency,
        s.balance_synced_at,
        0,
        s.created_at,
        s.updated_at
      FROM codex_relay_sources s
      JOIN api_keys k
        ON k.id = s.api_key_id
       AND k.role = 'codex_relay';
    `);
        // INSERT OR IGNORE keeps re-runs idempotent, so explicitly verify that a
        // pre-existing row did not consume a primary key under the wrong source.
        const missingBackfill = db.prepare(`
      SELECT COUNT(*) AS count
      FROM codex_relay_sources s
      LEFT JOIN codex_relay_source_keys sk
        ON sk.source_id = s.id
       AND sk.api_key_id = s.api_key_id
      WHERE sk.api_key_id IS NULL
    `).get();
        if (missingBackfill.count > 0) {
            throw new Error('Cannot migrate relay sources: primary relay key backfill is incomplete or conflicts with another source');
        }
    })();
}
export function down(db) {
    db.transaction(() => {
        if (hasTable(db, 'codex_relay_source_keys')) {
            const extraKeys = db.prepare(`
        SELECT COUNT(*) AS count
        FROM codex_relay_source_keys sk
        WHERE NOT EXISTS (
          SELECT 1
          FROM codex_relay_sources s
          WHERE s.id = sk.source_id
            AND s.api_key_id = sk.api_key_id
        )
      `).get();
            if (extraKeys.count > 0) {
                throw new Error('Cannot roll back relay multi-key migration while secondary or cross-linked relay keys exist');
            }
            const missingPrimaryKeys = db.prepare(`
        SELECT COUNT(*) AS count
        FROM codex_relay_sources s
        LEFT JOIN codex_relay_source_keys sk
          ON sk.source_id = s.id
         AND sk.api_key_id = s.api_key_id
        WHERE sk.api_key_id IS NULL
      `).get();
            if (missingPrimaryKeys.count > 0) {
                throw new Error('Cannot roll back relay multi-key migration while a primary relay key link is missing');
            }
            // Preserve all state representable by the legacy one-key schema before
            // removing the child table. The encrypted credential itself never left
            // api_keys, so this only synchronizes metadata and the supplier URL.
            db.exec(`
        UPDATE codex_relay_sources
        SET status = (
              SELECT sk.status FROM codex_relay_source_keys sk
              WHERE sk.source_id = codex_relay_sources.id
                AND sk.api_key_id = codex_relay_sources.api_key_id
            ),
            last_used_at = (
              SELECT sk.last_used_at FROM codex_relay_source_keys sk
              WHERE sk.source_id = codex_relay_sources.id
                AND sk.api_key_id = codex_relay_sources.api_key_id
            ),
            last_checked_at = (
              SELECT sk.last_checked_at FROM codex_relay_source_keys sk
              WHERE sk.source_id = codex_relay_sources.id
                AND sk.api_key_id = codex_relay_sources.api_key_id
            ),
            last_error = (
              SELECT sk.last_error FROM codex_relay_source_keys sk
              WHERE sk.source_id = codex_relay_sources.id
                AND sk.api_key_id = codex_relay_sources.api_key_id
            ),
            failure_count = (
              SELECT sk.failure_count FROM codex_relay_source_keys sk
              WHERE sk.source_id = codex_relay_sources.id
                AND sk.api_key_id = codex_relay_sources.api_key_id
            ),
            cooldown_until = (
              SELECT sk.cooldown_until FROM codex_relay_source_keys sk
              WHERE sk.source_id = codex_relay_sources.id
                AND sk.api_key_id = codex_relay_sources.api_key_id
            ),
            balance = (
              SELECT sk.balance FROM codex_relay_source_keys sk
              WHERE sk.source_id = codex_relay_sources.id
                AND sk.api_key_id = codex_relay_sources.api_key_id
            ),
            balance_currency = (
              SELECT sk.balance_currency FROM codex_relay_source_keys sk
              WHERE sk.source_id = codex_relay_sources.id
                AND sk.api_key_id = codex_relay_sources.api_key_id
            ),
            balance_synced_at = (
              SELECT sk.balance_synced_at FROM codex_relay_source_keys sk
              WHERE sk.source_id = codex_relay_sources.id
                AND sk.api_key_id = codex_relay_sources.api_key_id
            );

        UPDATE api_keys
        SET label = (
              SELECT sk.label FROM codex_relay_source_keys sk
              JOIN codex_relay_sources s ON s.id = sk.source_id
              WHERE sk.api_key_id = api_keys.id AND s.api_key_id = api_keys.id
            ),
            enabled = (
              SELECT sk.enabled FROM codex_relay_source_keys sk
              JOIN codex_relay_sources s ON s.id = sk.source_id
              WHERE sk.api_key_id = api_keys.id AND s.api_key_id = api_keys.id
            ),
            status = (
              SELECT sk.status FROM codex_relay_source_keys sk
              JOIN codex_relay_sources s ON s.id = sk.source_id
              WHERE sk.api_key_id = api_keys.id AND s.api_key_id = api_keys.id
            ),
            last_checked_at = (
              SELECT sk.last_checked_at FROM codex_relay_source_keys sk
              JOIN codex_relay_sources s ON s.id = sk.source_id
              WHERE sk.api_key_id = api_keys.id AND s.api_key_id = api_keys.id
            )
        WHERE id IN (SELECT api_key_id FROM codex_relay_sources);

        DROP INDEX IF EXISTS idx_codex_relay_source_keys_candidate;
        DROP INDEX IF EXISTS idx_codex_relay_source_keys_source;
        DROP TABLE codex_relay_source_keys;
      `);
        }
        if (hasColumn(db, 'codex_relay_sources', 'base_url')) {
            db.exec(`
        UPDATE api_keys
        SET base_url = (
          SELECT s.base_url
          FROM codex_relay_sources s
          WHERE s.api_key_id = api_keys.id
        )
        WHERE id IN (SELECT api_key_id FROM codex_relay_sources);

        ALTER TABLE codex_relay_sources DROP COLUMN base_url;
      `);
        }
    })();
}
//# sourceMappingURL=20260801_000067_codex_relay_source_keys.js.map