function columnNames(db, table) {
    return new Set(db.prepare(`PRAGMA table_info(${table})`).all()
        .map((column) => column.name));
}
/**
 * Keep the legacy four-value compatibility_status columns intact while
 * recording that the latest administrator probe ended in a temporary upstream
 * condition. This avoids rebuilding two live SQLite tables solely to extend a
 * CHECK constraint and keeps older application images able to read the rows.
 */
export function up(db) {
    if (!columnNames(db, 'codex_relay_sources').has('compatibility_needs_retest')) {
        db.exec(`
      ALTER TABLE codex_relay_sources
      ADD COLUMN compatibility_needs_retest INTEGER NOT NULL DEFAULT 0
        CHECK (compatibility_needs_retest IN (0, 1))
    `);
    }
    if (!columnNames(db, 'codex_relay_source_keys').has('compatibility_needs_retest')) {
        db.exec(`
      ALTER TABLE codex_relay_source_keys
      ADD COLUMN compatibility_needs_retest INTEGER NOT NULL DEFAULT 0
        CHECK (compatibility_needs_retest IN (0, 1))
    `);
    }
}
export function down(db) {
    if (columnNames(db, 'codex_relay_source_keys').has('compatibility_needs_retest')) {
        db.exec('ALTER TABLE codex_relay_source_keys DROP COLUMN compatibility_needs_retest');
    }
    if (columnNames(db, 'codex_relay_sources').has('compatibility_needs_retest')) {
        db.exec('ALTER TABLE codex_relay_sources DROP COLUMN compatibility_needs_retest');
    }
}
//# sourceMappingURL=20260809_000081_codex_relay_probe_retest.js.map