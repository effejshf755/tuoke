export function up(db) {
    const columns = db.prepare('PRAGMA table_info(consumer_api_keys)').all();
    if (!columns.some((column) => column.name === 'enabled'))
        db.exec('ALTER TABLE consumer_api_keys ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1))');
    db.exec('CREATE INDEX IF NOT EXISTS idx_requests_consumer_api_key ON requests(consumer_api_key_id)');
}
export function down(db) {
    db.exec(`
    DROP INDEX IF EXISTS idx_requests_consumer_api_key;
  `);
}
//# sourceMappingURL=20260719_000008_consumer_api_key_enabled.js.map