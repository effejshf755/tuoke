export function up(db) {
    db.exec(`
    CREATE TABLE IF NOT EXISTS codex_groups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT NOT NULL DEFAULT '',
      enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS codex_group_models (
      group_id INTEGER NOT NULL REFERENCES codex_groups(id) ON DELETE CASCADE,
      model_id TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (group_id, model_id)
    );

    CREATE INDEX IF NOT EXISTS idx_codex_group_models_model
      ON codex_group_models(model_id, group_id);
  `);
    const accountColumns = db.prepare('PRAGMA table_info(codex_oauth_accounts)').all();
    if (!accountColumns.some(column => column.name === 'codex_group_id')) {
        db.exec('ALTER TABLE codex_oauth_accounts ADD COLUMN codex_group_id INTEGER REFERENCES codex_groups(id) ON DELETE SET NULL');
    }
    const keyColumns = db.prepare('PRAGMA table_info(consumer_api_keys)').all();
    if (!keyColumns.some(column => column.name === 'codex_group_id')) {
        db.exec('ALTER TABLE consumer_api_keys ADD COLUMN codex_group_id INTEGER REFERENCES codex_groups(id) ON DELETE SET NULL');
    }
    db.exec(`
    CREATE INDEX IF NOT EXISTS idx_codex_accounts_group ON codex_oauth_accounts(codex_group_id);
    CREATE INDEX IF NOT EXISTS idx_consumer_keys_codex_group ON consumer_api_keys(codex_group_id);
  `);
}
export function down(db) {
    db.exec(`
    DROP INDEX IF EXISTS idx_consumer_keys_codex_group;
    DROP INDEX IF EXISTS idx_codex_accounts_group;
    DROP INDEX IF EXISTS idx_codex_group_models_model;
    DROP TABLE IF EXISTS codex_group_models;
    DROP TABLE IF EXISTS codex_groups;
  `);
    const keyColumns = db.prepare('PRAGMA table_info(consumer_api_keys)').all();
    if (keyColumns.some(column => column.name === 'codex_group_id'))
        db.exec('ALTER TABLE consumer_api_keys DROP COLUMN codex_group_id');
    const accountColumns = db.prepare('PRAGMA table_info(codex_oauth_accounts)').all();
    if (accountColumns.some(column => column.name === 'codex_group_id'))
        db.exec('ALTER TABLE codex_oauth_accounts DROP COLUMN codex_group_id');
}
//# sourceMappingURL=20260729_000055_codex_groups.js.map