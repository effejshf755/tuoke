const RUNTIME_COLUMNS = [
    'runtime_status',
    'runtime_consecutive_failures',
    'runtime_cooldown_until',
    'runtime_last_error',
    'runtime_last_failure_at',
    'runtime_last_success_at',
];
function columnsFor(db) {
    return new Set(db.prepare('PRAGMA table_info(codex_relay_source_models)').all()
        .map((column) => column.name));
}
/**
 * A relay credential can serve several upstream models. Persist runtime health
 * on the mapping so one unsupported or temporarily unavailable model does not
 * remove the supplier's healthy sibling models from routing.
 */
export function up(db) {
    const columns = columnsFor(db);
    const hadRuntimeStatus = columns.has('runtime_status');
    if (!columns.has('runtime_status')) {
        db.exec(`
      ALTER TABLE codex_relay_source_models
      ADD COLUMN runtime_status TEXT NOT NULL DEFAULT 'unknown'
        CHECK (runtime_status IN ('unknown', 'healthy', 'cooldown', 'unsupported', 'error'))
    `);
    }
    if (!columns.has('runtime_consecutive_failures')) {
        db.exec(`
      ALTER TABLE codex_relay_source_models
      ADD COLUMN runtime_consecutive_failures INTEGER NOT NULL DEFAULT 0
        CHECK (runtime_consecutive_failures >= 0)
    `);
    }
    if (!columns.has('runtime_cooldown_until')) {
        db.exec('ALTER TABLE codex_relay_source_models ADD COLUMN runtime_cooldown_until TEXT');
    }
    if (!columns.has('runtime_last_error')) {
        db.exec('ALTER TABLE codex_relay_source_models ADD COLUMN runtime_last_error TEXT');
    }
    if (!columns.has('runtime_last_failure_at')) {
        db.exec('ALTER TABLE codex_relay_source_models ADD COLUMN runtime_last_failure_at TEXT');
    }
    if (!columns.has('runtime_last_success_at')) {
        db.exec('ALTER TABLE codex_relay_source_models ADD COLUMN runtime_last_success_at TEXT');
    }
    // Rows that already existed before runtime health was introduced have
    // already passed the legacy source-level health gate. Keep them routable so
    // a migration does not silently remove every relay from the pool. New rows
    // inserted after this migration retain the column default of `unknown`.
    // Unknown remains routable for compatibility because a mapping is an
    // administrator-confirmed declaration; the first real request supplies the
    // model-level signal. Explicit `error`, `cooldown`, and `unsupported` states
    // are handled by the candidate query and are not silently treated as
    // healthy.
    if (!hadRuntimeStatus) {
        db.exec(`
      UPDATE codex_relay_source_models
      SET runtime_status = 'healthy'
      WHERE runtime_status = 'unknown'
    `);
    }
    db.exec(`
    CREATE INDEX IF NOT EXISTS idx_codex_relay_source_models_runtime_candidate
      ON codex_relay_source_models(
        public_model_id, enabled, runtime_status, runtime_cooldown_until, source_id
      )
  `);
}
export function down(db) {
    db.exec('DROP INDEX IF EXISTS idx_codex_relay_source_models_runtime_candidate');
    const columns = columnsFor(db);
    for (const column of [...RUNTIME_COLUMNS].reverse()) {
        if (columns.has(column)) {
            db.exec(`ALTER TABLE codex_relay_source_models DROP COLUMN ${column}`);
        }
    }
}
//# sourceMappingURL=20260808_000077_codex_relay_model_runtime_health.js.map