import type { Db } from '../types.js';
/**
 * Third-party Codex relay credentials deliberately share the encrypted
 * `api_keys` vault, but must never become ordinary custom-provider keys.  The
 * role column makes that separation queryable and the relay tables keep the
 * routing/configuration surface independent from OAuth accounts and resource
 * subpools.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260731_000060_codex_relay_sources.d.ts.map