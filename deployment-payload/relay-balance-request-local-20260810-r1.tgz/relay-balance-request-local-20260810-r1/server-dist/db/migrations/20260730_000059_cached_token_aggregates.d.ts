import type { Db } from "../types.js";
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260730_000059_cached_token_aggregates.d.ts.map