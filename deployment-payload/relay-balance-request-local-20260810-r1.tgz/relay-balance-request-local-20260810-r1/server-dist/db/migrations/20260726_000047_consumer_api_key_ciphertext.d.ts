import type { Db } from '../types.js';
export declare function up(db: Db): void;
export declare function down(_db: Db): void;
//# sourceMappingURL=20260726_000047_consumer_api_key_ciphertext.d.ts.map