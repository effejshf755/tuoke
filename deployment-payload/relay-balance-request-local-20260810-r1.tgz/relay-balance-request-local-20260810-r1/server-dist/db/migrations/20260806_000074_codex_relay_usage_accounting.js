const USAGE_CONFIRMED_COLUMN = 'upstream_usage_confirmed';
function hasColumn(db, table, column) {
    return db.prepare(`PRAGMA table_info(${table})`).all()
        .some((candidate) => candidate.name === column);
}
function installRequestInsertTrigger(db, accurateUsageOnly) {
    const usageConfirmedAssignment = accurateUsageOnly
        ? `,
        ${USAGE_CONFIRMED_COLUMN} = CASE
          WHEN NEW.status = 'success'
            OR NEW.${USAGE_CONFIRMED_COLUMN} = 1
            OR NEW.cached_input_tokens > 0
            OR NEW.cache_write_tokens > 0
            OR NEW.output_tokens > 0
          THEN 1
          ELSE 0
        END`
        : '';
    const tokenValue = (column) => accurateUsageOnly
        ? `CASE
          WHEN NEW.status = 'success'
            OR NEW.${USAGE_CONFIRMED_COLUMN} = 1
            OR NEW.cached_input_tokens > 0
            OR NEW.cache_write_tokens > 0
            OR NEW.output_tokens > 0
          THEN MAX(0, NEW.${column})
          ELSE 0
        END`
        : `MAX(0, NEW.${column})`;
    db.exec(`
    DROP TRIGGER IF EXISTS trg_codex_relay_request_insert;
    CREATE TRIGGER trg_codex_relay_request_insert
    AFTER INSERT ON requests
    WHEN NEW.platform = 'openai-codex'
    BEGIN
      UPDATE requests
      SET codex_relay_source_id = COALESCE(
        NEW.codex_relay_source_id,
        (
          SELECT source_key.source_id
          FROM codex_relay_source_keys source_key
          WHERE source_key.api_key_id = NEW.key_id
          ORDER BY source_key.source_id ASC
          LIMIT 1
        )
      ),
      codex_relay_source_name = (
        SELECT source.name
        FROM codex_relay_sources source
        WHERE source.id = COALESCE(
          NEW.codex_relay_source_id,
          (
            SELECT source_key.source_id
            FROM codex_relay_source_keys source_key
            WHERE source_key.api_key_id = NEW.key_id
            ORDER BY source_key.source_id ASC
            LIMIT 1
          )
        )
      )${usageConfirmedAssignment}
      WHERE id = NEW.id;

      INSERT INTO codex_relay_source_statistics (
        source_id, request_count, success_count, failure_count, partial_count,
        input_tokens, cached_input_tokens, cache_write_tokens, output_tokens,
        billed_micro, latency_total_ms, last_request_at, updated_at
      )
      SELECT
        source.id,
        1,
        CASE WHEN NEW.status = 'success' THEN 1 ELSE 0 END,
        CASE WHEN NEW.status = 'error' THEN 1 ELSE 0 END,
        CASE WHEN NEW.status = 'partial' THEN 1 ELSE 0 END,
        ${tokenValue('input_tokens')},
        ${tokenValue('cached_input_tokens')},
        ${tokenValue('cache_write_tokens')},
        ${tokenValue('output_tokens')},
        CASE WHEN NEW.billing_status = 'charged'
          THEN MAX(0, NEW.billing_amount_micro)
          ELSE 0
        END,
        MAX(0, NEW.latency_ms),
        NEW.created_at,
        datetime('now')
      FROM codex_relay_sources source
      WHERE source.id = COALESCE(
        NEW.codex_relay_source_id,
        (
          SELECT source_key.source_id
          FROM codex_relay_source_keys source_key
          WHERE source_key.api_key_id = NEW.key_id
          ORDER BY source_key.source_id ASC
          LIMIT 1
        )
      )
        AND source.statistics_started_at IS NOT NULL
        AND datetime(NEW.created_at) >= datetime(source.statistics_started_at)
      ON CONFLICT(source_id) DO UPDATE SET
        request_count = request_count + excluded.request_count,
        success_count = success_count + excluded.success_count,
        failure_count = failure_count + excluded.failure_count,
        partial_count = partial_count + excluded.partial_count,
        input_tokens = input_tokens + excluded.input_tokens,
        cached_input_tokens = cached_input_tokens + excluded.cached_input_tokens,
        cache_write_tokens = cache_write_tokens + excluded.cache_write_tokens,
        output_tokens = output_tokens + excluded.output_tokens,
        billed_micro = billed_micro + excluded.billed_micro,
        latency_total_ms = latency_total_ms + excluded.latency_total_ms,
        last_request_at = excluded.last_request_at,
        updated_at = excluded.updated_at;
    END;
  `);
}
function adjustRetainedUnconfirmedUsage(db, direction) {
    const operator = direction === 1 ? '+' : '-';
    const adjustedValue = (column) => `MAX(
        0,
        ${column} ${operator} COALESCE((
          SELECT SUM(MAX(0, request.${column}))
          FROM requests request
          JOIN codex_relay_sources source
            ON source.id = request.codex_relay_source_id
          WHERE request.codex_relay_source_id = codex_relay_source_statistics.source_id
            AND source.statistics_started_at IS NOT NULL
            AND datetime(request.created_at) >= datetime(source.statistics_started_at)
            AND request.${USAGE_CONFIRMED_COLUMN} = 0
        ), 0)
      )`;
    db.exec(`
    UPDATE codex_relay_source_statistics
    SET input_tokens = ${adjustedValue('input_tokens')},
        cached_input_tokens = ${adjustedValue('cached_input_tokens')},
        cache_write_tokens = ${adjustedValue('cache_write_tokens')},
        output_tokens = ${adjustedValue('output_tokens')},
        updated_at = datetime('now');
  `);
}
/**
 * Relay failures used to add their estimated prompt size to durable supplier
 * totals even when the upstream rejected the request before doing any work.
 * Preserve request/failure counters, but count tokens only for a successful
 * request or a failed/partial request with observable upstream usage.
 */
export function up(db) {
    if (!hasColumn(db, 'requests', USAGE_CONFIRMED_COLUMN)) {
        db.exec(`
      ALTER TABLE requests
      ADD COLUMN ${USAGE_CONFIRMED_COLUMN} INTEGER NOT NULL DEFAULT 0
        CHECK (${USAGE_CONFIRMED_COLUMN} IN (0, 1))
    `);
    }
    db.exec(`
    UPDATE requests
    SET ${USAGE_CONFIRMED_COLUMN} = 1
    WHERE ${USAGE_CONFIRMED_COLUMN} = 0
      AND (
        status = 'success'
        OR cached_input_tokens > 0
        OR cache_write_tokens > 0
        OR output_tokens > 0
      );
  `);
    // Remove the known pollution represented by raw rows that are still within
    // the retention window. Durable request counts, failures, latency, and final
    // billed amounts remain unchanged.
    adjustRetainedUnconfirmedUsage(db, -1);
    installRequestInsertTrigger(db, true);
}
export function down(db) {
    db.exec('DROP TRIGGER IF EXISTS trg_codex_relay_request_insert');
    if (hasColumn(db, 'requests', USAGE_CONFIRMED_COLUMN)) {
        // Restore the legacy totals for retained rows before returning to the old
        // writer. This keeps a one-step rollback internally consistent.
        adjustRetainedUnconfirmedUsage(db, 1);
        db.exec(`ALTER TABLE requests DROP COLUMN ${USAGE_CONFIRMED_COLUMN}`);
    }
    // Migration 071 is immediately before this migration and owns the source
    // name snapshot, so restore its exact insert behavior on rollback.
    installRequestInsertTrigger(db, false);
}
//# sourceMappingURL=20260806_000074_codex_relay_usage_accounting.js.map