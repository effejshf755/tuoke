function hasRuntimeHealthColumns(db) {
    const columns = new Set(db.prepare('PRAGMA table_info(codex_relay_source_models)').all()
        .map((column) => column.name));
    return [
        'runtime_status',
        'runtime_consecutive_failures',
        'runtime_cooldown_until',
        'runtime_last_error',
        'runtime_last_failure_at',
    ].every((column) => columns.has(column));
}
/**
 * Runtime source+model cooldowns were removed from routing policy. Clear every
 * previously persisted failure/cooldown during deployment so old yellow
 * "cooling" states cannot survive the code change or reappear in admin APIs.
 * Keep the columns for rollback/schema compatibility; routing no longer reads
 * them as eligibility gates.
 */
export function up(db) {
    if (!hasRuntimeHealthColumns(db))
        return;
    db.exec(`
    UPDATE codex_relay_source_models
    SET runtime_status = 'unknown',
        runtime_consecutive_failures = 0,
        runtime_cooldown_until = NULL,
        runtime_last_error = NULL,
        runtime_last_failure_at = NULL
  `);
    // The old Relay fallback path also wrote a generic per-model+key cooldown.
    // Remove only rows owned by Relay credentials; official OAuth and ordinary
    // provider cooldowns continue to protect their respective pools. Invalid
    // and out-of-credit Relay keys remain excluded by source-key status/cooldown.
    db.exec(`
    DELETE FROM rate_limit_cooldowns
    WHERE platform = 'openai-codex'
      AND EXISTS (
        SELECT 1
        FROM codex_relay_source_keys source_key
        WHERE source_key.api_key_id = rate_limit_cooldowns.key_id
      )
  `);
    // Older basic-health probes could persist transient 503/429/timeout results
    // as `unhealthy`/`error`, which is also an eligibility gate. Recover only
    // enabled credentials whose saved diagnostic unambiguously describes a
    // transient transport/service failure. Ambiguous rows are deliberately left
    // untouched, and balance/authentication failures are explicitly excluded.
    // This is intentionally conservative: accidentally releasing a 402 balance
    // cooldown would be worse than requiring one successful health check to
    // recover a legacy ambiguous row.
    db.exec(`
    DROP TABLE IF EXISTS _codex_relay_transient_recovery;
    CREATE TEMP TABLE _codex_relay_transient_recovery (
      source_id INTEGER NOT NULL,
      api_key_id INTEGER NOT NULL,
      PRIMARY KEY (source_id, api_key_id)
    );

    INSERT INTO _codex_relay_transient_recovery (source_id, api_key_id)
    SELECT sk.source_id, sk.api_key_id
    FROM codex_relay_source_keys sk
    JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
    WHERE sk.enabled = 1
      AND k.enabled = 1
      AND sk.status = 'unhealthy'
      AND TRIM(COALESCE(sk.last_error, '')) <> ''
      AND (
        LOWER(sk.last_error) LIKE '%http 408%'
        OR LOWER(sk.last_error) LIKE '%http 429%'
        OR LOWER(sk.last_error) GLOB '*http 5[0-9][0-9]*'
        OR LOWER(sk.last_error) GLOB '*error 5[0-9][0-9]*'
        OR LOWER(sk.last_error) GLOB '*status 5[0-9][0-9]*'
        OR LOWER(sk.last_error) LIKE '%rate limit%'
        OR LOWER(sk.last_error) LIKE '%too many request%'
        OR LOWER(sk.last_error) LIKE '%temporarily unavailable%'
        OR LOWER(sk.last_error) LIKE '%temporary unavailable%'
        OR LOWER(sk.last_error) LIKE '%service unavailable%'
        OR LOWER(sk.last_error) LIKE '%gateway timeout%'
        OR LOWER(sk.last_error) LIKE '%timed out%'
        OR LOWER(sk.last_error) LIKE '%timeout%'
        OR LOWER(sk.last_error) LIKE '%aborterror%'
        OR LOWER(sk.last_error) LIKE '%operation was aborted%'
        OR LOWER(sk.last_error) LIKE '%connection reset%'
        OR LOWER(sk.last_error) LIKE '%econnreset%'
        OR LOWER(sk.last_error) LIKE '%socket hang up%'
        OR LOWER(sk.last_error) LIKE '%unexpected eof%'
        OR LOWER(sk.last_error) LIKE '%invalid sse%'
        OR LOWER(sk.last_error) LIKE '%stream stalled%'
        OR LOWER(sk.last_error) LIKE '%fetch failed%'
        OR LOWER(sk.last_error) LIKE '%network error%'
      )
      AND LOWER(sk.last_error) NOT LIKE '%http 402%'
      AND LOWER(sk.last_error) NOT GLOB '*error 402*'
      AND LOWER(sk.last_error) NOT GLOB '*status 402*'
      AND LOWER(sk.last_error) NOT LIKE '%payment required%'
      AND LOWER(sk.last_error) NOT LIKE '%insufficient_quota%'
      AND LOWER(sk.last_error) NOT LIKE '%insufficient quota%'
      AND LOWER(sk.last_error) NOT LIKE '%insufficient_balance%'
      AND LOWER(sk.last_error) NOT LIKE '%insufficient balance%'
      AND LOWER(sk.last_error) NOT LIKE '%out_of_credit%'
      AND LOWER(sk.last_error) NOT LIKE '%out of credit%'
      AND LOWER(sk.last_error) NOT LIKE '%quota exceeded%'
      AND LOWER(sk.last_error) NOT LIKE '%billing%'
      AND sk.last_error NOT LIKE '%余额不足%'
      AND sk.last_error NOT LIKE '%额度不足%'
      AND sk.last_error NOT LIKE '%欠费%';

    UPDATE api_keys
    SET status = 'unknown'
    WHERE role = 'codex_relay'
      AND status = 'error'
      AND id IN (
        SELECT api_key_id
        FROM _codex_relay_transient_recovery
      );

    UPDATE codex_relay_source_keys
    SET status = 'unknown', cooldown_until = NULL
    WHERE (source_id, api_key_id) IN (
      SELECT source_id, api_key_id
      FROM _codex_relay_transient_recovery
    );

    -- Recompute only suppliers touched by the recovery. Sources that contain
    -- an invalid or balance-cooled credential but no recovered sibling are not
    -- rewritten, so their protection cannot be accidentally relaxed.
    UPDATE codex_relay_sources
    SET status = CASE
          WHEN EXISTS (
            SELECT 1
            FROM codex_relay_source_keys sk
            JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
            WHERE sk.source_id = codex_relay_sources.id
              AND sk.enabled = 1 AND k.enabled = 1 AND sk.status = 'healthy'
          ) THEN 'healthy'
          WHEN EXISTS (
            SELECT 1
            FROM codex_relay_source_keys sk
            JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
            WHERE sk.source_id = codex_relay_sources.id
              AND sk.enabled = 1 AND k.enabled = 1 AND sk.status = 'unknown'
          ) THEN 'unknown'
          WHEN EXISTS (
            SELECT 1
            FROM codex_relay_source_keys sk
            JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
            WHERE sk.source_id = codex_relay_sources.id
              AND sk.enabled = 1 AND k.enabled = 1
          ) AND NOT EXISTS (
            SELECT 1
            FROM codex_relay_source_keys sk
            JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
            WHERE sk.source_id = codex_relay_sources.id
              AND sk.enabled = 1 AND k.enabled = 1 AND sk.status <> 'invalid'
          ) THEN 'invalid'
          WHEN EXISTS (
            SELECT 1
            FROM codex_relay_source_keys sk
            JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
            WHERE sk.source_id = codex_relay_sources.id
              AND sk.enabled = 1 AND k.enabled = 1
          ) THEN 'unhealthy'
          ELSE 'unknown'
        END,
        cooldown_until = CASE
          WHEN EXISTS (
            SELECT 1
            FROM codex_relay_source_keys sk
            JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
            WHERE sk.source_id = codex_relay_sources.id
              AND sk.enabled = 1 AND k.enabled = 1
              AND sk.status IN ('healthy', 'unknown')
              AND (
                sk.cooldown_until IS NULL
                OR datetime(sk.cooldown_until) <= datetime('now')
              )
          ) THEN NULL
          ELSE (
            SELECT MIN(sk.cooldown_until)
            FROM codex_relay_source_keys sk
            JOIN api_keys k ON k.id = sk.api_key_id AND k.role = 'codex_relay'
            WHERE sk.source_id = codex_relay_sources.id
              AND sk.enabled = 1 AND k.enabled = 1
              AND sk.cooldown_until IS NOT NULL
              AND datetime(sk.cooldown_until) > datetime('now')
          )
        END
    WHERE id IN (
      SELECT source_id
      FROM _codex_relay_transient_recovery
    );

    DROP TABLE _codex_relay_transient_recovery;
  `);
    db.exec('DROP INDEX IF EXISTS idx_codex_relay_source_models_runtime_candidate');
    db.exec(`
    CREATE INDEX IF NOT EXISTS idx_codex_relay_source_models_routing
      ON codex_relay_source_models(public_model_id, enabled, source_id)
  `);
}
export function down(db) {
    if (!hasRuntimeHealthColumns(db))
        return;
    db.exec('DROP INDEX IF EXISTS idx_codex_relay_source_models_routing');
    db.exec(`
    CREATE INDEX IF NOT EXISTS idx_codex_relay_source_models_runtime_candidate
      ON codex_relay_source_models(
        public_model_id, enabled, runtime_status, runtime_cooldown_until, source_id
      )
  `);
    // Cleared failure state is intentionally not reconstructed: inventing old
    // cooldown timestamps during rollback would unexpectedly bench live routes.
}
//# sourceMappingURL=20260808_000079_codex_relay_disable_model_cooldown.js.map