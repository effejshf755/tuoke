const STATISTICS_RESET_WATERMARK_COLUMN = 'statistics_reset_after_request_id';
function hasColumn(db, table, column) {
    return db.prepare(`PRAGMA table_info(${table})`).all()
        .some((candidate) => candidate.name === column);
}
/**
 * Migration 074 owns the latest request enrichment and accurate upstream
 * usage semantics. Keep that behavior intact while optionally adding the
 * reset watermark predicate introduced by this migration.
 */
function installRequestInsertTrigger(db, enforceResetWatermark) {
    const resetWatermarkPredicate = enforceResetWatermark
        ? `
        AND NEW.id > source.${STATISTICS_RESET_WATERMARK_COLUMN}`
        : '';
    db.exec(`
    DROP TRIGGER IF EXISTS trg_codex_relay_request_insert;
    CREATE TRIGGER trg_codex_relay_request_insert
    AFTER INSERT ON requests
    WHEN NEW.platform = 'openai-codex'
    BEGIN
      UPDATE requests
      SET codex_relay_source_id = COALESCE(
        NEW.codex_relay_source_id,
        (
          SELECT source_key.source_id
          FROM codex_relay_source_keys source_key
          WHERE source_key.api_key_id = NEW.key_id
          ORDER BY source_key.source_id ASC
          LIMIT 1
        )
      ),
      codex_relay_source_name = (
        SELECT source.name
        FROM codex_relay_sources source
        WHERE source.id = COALESCE(
          NEW.codex_relay_source_id,
          (
            SELECT source_key.source_id
            FROM codex_relay_source_keys source_key
            WHERE source_key.api_key_id = NEW.key_id
            ORDER BY source_key.source_id ASC
            LIMIT 1
          )
        )
      ),
      upstream_usage_confirmed = CASE
        WHEN NEW.status = 'success'
          OR NEW.upstream_usage_confirmed = 1
          OR NEW.cached_input_tokens > 0
          OR NEW.cache_write_tokens > 0
          OR NEW.output_tokens > 0
        THEN 1
        ELSE 0
      END
      WHERE id = NEW.id;

      INSERT INTO codex_relay_source_statistics (
        source_id, request_count, success_count, failure_count, partial_count,
        input_tokens, cached_input_tokens, cache_write_tokens, output_tokens,
        billed_micro, latency_total_ms, last_request_at, updated_at
      )
      SELECT
        source.id,
        1,
        CASE WHEN NEW.status = 'success' THEN 1 ELSE 0 END,
        CASE WHEN NEW.status = 'error' THEN 1 ELSE 0 END,
        CASE WHEN NEW.status = 'partial' THEN 1 ELSE 0 END,
        CASE
          WHEN NEW.status = 'success'
            OR NEW.upstream_usage_confirmed = 1
            OR NEW.cached_input_tokens > 0
            OR NEW.cache_write_tokens > 0
            OR NEW.output_tokens > 0
          THEN MAX(0, NEW.input_tokens)
          ELSE 0
        END,
        CASE
          WHEN NEW.status = 'success'
            OR NEW.upstream_usage_confirmed = 1
            OR NEW.cached_input_tokens > 0
            OR NEW.cache_write_tokens > 0
            OR NEW.output_tokens > 0
          THEN MAX(0, NEW.cached_input_tokens)
          ELSE 0
        END,
        CASE
          WHEN NEW.status = 'success'
            OR NEW.upstream_usage_confirmed = 1
            OR NEW.cached_input_tokens > 0
            OR NEW.cache_write_tokens > 0
            OR NEW.output_tokens > 0
          THEN MAX(0, NEW.cache_write_tokens)
          ELSE 0
        END,
        CASE
          WHEN NEW.status = 'success'
            OR NEW.upstream_usage_confirmed = 1
            OR NEW.cached_input_tokens > 0
            OR NEW.cache_write_tokens > 0
            OR NEW.output_tokens > 0
          THEN MAX(0, NEW.output_tokens)
          ELSE 0
        END,
        CASE WHEN NEW.billing_status = 'charged'
          THEN MAX(0, NEW.billing_amount_micro)
          ELSE 0
        END,
        MAX(0, NEW.latency_ms),
        NEW.created_at,
        datetime('now')
      FROM codex_relay_sources source
      WHERE source.id = COALESCE(
        NEW.codex_relay_source_id,
        (
          SELECT source_key.source_id
          FROM codex_relay_source_keys source_key
          WHERE source_key.api_key_id = NEW.key_id
          ORDER BY source_key.source_id ASC
          LIMIT 1
        )
      )
        AND source.statistics_started_at IS NOT NULL
        AND datetime(NEW.created_at) >= datetime(source.statistics_started_at)${resetWatermarkPredicate}
      ON CONFLICT(source_id) DO UPDATE SET
        request_count = request_count + excluded.request_count,
        success_count = success_count + excluded.success_count,
        failure_count = failure_count + excluded.failure_count,
        partial_count = partial_count + excluded.partial_count,
        input_tokens = input_tokens + excluded.input_tokens,
        cached_input_tokens = cached_input_tokens + excluded.cached_input_tokens,
        cache_write_tokens = cache_write_tokens + excluded.cache_write_tokens,
        output_tokens = output_tokens + excluded.output_tokens,
        billed_micro = billed_micro + excluded.billed_micro,
        latency_total_ms = latency_total_ms + excluded.latency_total_ms,
        last_request_at = excluded.last_request_at,
        updated_at = excluded.updated_at;
    END;
  `);
}
/** Restore migration 069 billing deltas, with an optional reset boundary. */
function installBillingUpdateTrigger(db, enforceResetWatermark) {
    const resetWatermarkPredicate = enforceResetWatermark
        ? `
      AND NEW.id > COALESCE((
        SELECT source.${STATISTICS_RESET_WATERMARK_COLUMN}
        FROM codex_relay_sources source
        WHERE source.id = NEW.codex_relay_source_id
      ), 0)`
        : '';
    db.exec(`
    DROP TRIGGER IF EXISTS trg_codex_relay_request_billing_update;
    CREATE TRIGGER trg_codex_relay_request_billing_update
    AFTER UPDATE OF billing_amount_micro, billing_status ON requests
    WHEN NEW.codex_relay_source_id IS NOT NULL${resetWatermarkPredicate}
      AND (
        CASE WHEN NEW.billing_status = 'charged' THEN NEW.billing_amount_micro ELSE 0 END
      ) != (
        CASE WHEN OLD.billing_status = 'charged' THEN OLD.billing_amount_micro ELSE 0 END
      )
    BEGIN
      UPDATE codex_relay_source_statistics
      SET billed_micro = MAX(
            0,
            billed_micro
              + CASE WHEN NEW.billing_status = 'charged' THEN NEW.billing_amount_micro ELSE 0 END
              - CASE WHEN OLD.billing_status = 'charged' THEN OLD.billing_amount_micro ELSE 0 END
          ),
          updated_at = datetime('now')
      WHERE source_id = NEW.codex_relay_source_id;
    END;
  `);
}
/**
 * Administrator-maintained recharge records for each independent Relay
 * supplier. These entries are operational bookkeeping only: they never alter
 * a user wallet, supplier request totals, or customer billing.
 */
export function up(db) {
    if (!hasColumn(db, 'codex_relay_sources', STATISTICS_RESET_WATERMARK_COLUMN)) {
        db.exec(`
      ALTER TABLE codex_relay_sources
      ADD COLUMN ${STATISTICS_RESET_WATERMARK_COLUMN} INTEGER NOT NULL DEFAULT 0
    `);
    }
    db.exec(`
    CREATE TABLE IF NOT EXISTS codex_relay_recharge_ledger_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      source_id INTEGER NOT NULL
        REFERENCES codex_relay_sources(id) ON DELETE CASCADE,
      amount_micro INTEGER NOT NULL
        CHECK (amount_micro > 0 AND amount_micro <= 1000000000000),
      currency TEXT NOT NULL CHECK (currency IN ('USD', 'CNY')),
      note TEXT CHECK (note IS NULL OR length(note) <= 500),
      occurred_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
      created_by_user_id INTEGER
        REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE INDEX IF NOT EXISTS idx_codex_relay_recharge_ledger_source_time
      ON codex_relay_recharge_ledger_entries(source_id, occurred_at DESC, id DESC);
  `);
    installRequestInsertTrigger(db, true);
    installBillingUpdateTrigger(db, true);
}
export function down(db) {
    db.exec(`
    DROP INDEX IF EXISTS idx_codex_relay_recharge_ledger_source_time;
    DROP TABLE IF EXISTS codex_relay_recharge_ledger_entries;
  `);
    // Reinstall the exact pre-080 writers before removing the column they would
    // otherwise reference: migration 074 insert semantics and migration 069
    // billing delta semantics, both without a reset boundary.
    installRequestInsertTrigger(db, false);
    installBillingUpdateTrigger(db, false);
    if (hasColumn(db, 'codex_relay_sources', STATISTICS_RESET_WATERMARK_COLUMN)) {
        db.exec(`
      ALTER TABLE codex_relay_sources
      DROP COLUMN ${STATISTICS_RESET_WATERMARK_COLUMN}
    `);
    }
}
//# sourceMappingURL=20260808_000080_codex_relay_recharge_ledger.js.map