function hasColumn(db, table, column) {
    return db.prepare(`PRAGMA table_info(${table})`).all()
        .some((item) => item.name === column);
}
export function up(db) {
    if (!hasColumn(db, 'promotion_credit_grants', 'admin_deleted_at')) {
        db.exec('ALTER TABLE promotion_credit_grants ADD COLUMN admin_deleted_at TEXT');
    }
    if (!hasColumn(db, 'promotion_credit_grants', 'admin_deleted_by')) {
        db.exec(`
      ALTER TABLE promotion_credit_grants
      ADD COLUMN admin_deleted_by INTEGER REFERENCES users(id) ON DELETE SET NULL
    `);
    }
    db.exec(`
    CREATE INDEX IF NOT EXISTS idx_promotion_grants_admin_visible
      ON promotion_credit_grants(user_id, purchase_id)
      WHERE admin_deleted_at IS NULL;
  `);
}
export function down(db) {
    const deleted = db.prepare(`
    SELECT COUNT(*) AS count
    FROM promotion_credit_grants
    WHERE admin_deleted_at IS NOT NULL
  `).get();
    if (deleted.count > 0) {
        throw new Error('Irreversible: administrator-deleted promotion grants exist');
    }
    db.exec('DROP INDEX IF EXISTS idx_promotion_grants_admin_visible');
    if (hasColumn(db, 'promotion_credit_grants', 'admin_deleted_by')) {
        db.exec('ALTER TABLE promotion_credit_grants DROP COLUMN admin_deleted_by');
    }
    if (hasColumn(db, 'promotion_credit_grants', 'admin_deleted_at')) {
        db.exec('ALTER TABLE promotion_credit_grants DROP COLUMN admin_deleted_at');
    }
}
//# sourceMappingURL=20260805_000072_promotion_admin_controls.js.map