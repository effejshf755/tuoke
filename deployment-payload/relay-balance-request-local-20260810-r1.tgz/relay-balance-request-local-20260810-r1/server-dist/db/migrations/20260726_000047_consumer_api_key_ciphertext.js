export function up(db) {
    const columns = db.prepare('PRAGMA table_info(consumer_api_keys)').all();
    const addColumn = (name) => {
        if (!columns.some((column) => column.name === name)) {
            db.exec(`ALTER TABLE consumer_api_keys ADD COLUMN ${name} TEXT`);
        }
    };
    addColumn('key_encrypted');
    addColumn('key_iv');
    addColumn('key_auth_tag');
}
export function down(_db) {
    throw new Error('irreversible migration: SQLite requires a table rebuild to remove consumer API key ciphertext columns');
}
//# sourceMappingURL=20260726_000047_consumer_api_key_ciphertext.js.map