import type { Db } from '../types.js';
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260722_000017_openrouter_free_billing_rules.d.ts.map