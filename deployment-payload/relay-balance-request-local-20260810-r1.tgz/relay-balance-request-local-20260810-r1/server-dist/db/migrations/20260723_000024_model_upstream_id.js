export function up(db) {
    const columns = db.prepare('PRAGMA table_info(models)').all();
    if (!columns.some((column) => column.name === 'upstream_model_id')) {
        db.exec('ALTER TABLE models ADD COLUMN upstream_model_id TEXT');
    }
    db.prepare(`
    UPDATE models
    SET upstream_model_id = 'gpt-5.6-luna'
    WHERE platform = 'openai-codex' AND model_id = 'codex'
  `).run();
}
export function down(db) {
    const columns = db.prepare('PRAGMA table_info(models)').all();
    if (columns.some((column) => column.name === 'upstream_model_id')) {
        db.exec('ALTER TABLE models DROP COLUMN upstream_model_id');
    }
}
//# sourceMappingURL=20260723_000024_model_upstream_id.js.map