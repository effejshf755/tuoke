import type { Db } from '../types.js';
/**
 * Keep the administrator-defined supplier label on each request.  The source
 * foreign key intentionally uses ON DELETE SET NULL, so without this snapshot
 * a physical source deletion would make old analytics rows anonymous.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260805_000071_codex_relay_source_name_snapshot.d.ts.map