export function up(db) {
    const columns = db.prepare('PRAGMA table_info(users)').all();
    if (!columns.some(column => column.name === 'billing_multiplier_milli')) {
        db.exec(`ALTER TABLE users ADD COLUMN billing_multiplier_milli INTEGER NOT NULL DEFAULT 1000
      CHECK (billing_multiplier_milli >= 0 AND billing_multiplier_milli <= 1000000)`);
    }
}
export function down(db) {
    const columns = db.prepare('PRAGMA table_info(users)').all();
    if (columns.some(column => column.name === 'billing_multiplier_milli')) {
        db.exec('ALTER TABLE users DROP COLUMN billing_multiplier_milli');
    }
}
//# sourceMappingURL=20260729_000057_user_billing_multiplier.js.map