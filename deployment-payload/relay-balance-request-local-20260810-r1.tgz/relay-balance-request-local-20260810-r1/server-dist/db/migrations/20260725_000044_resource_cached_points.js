export function up(db) {
    const addColumn = (table, name, definition) => {
        const columns = db.prepare(`PRAGMA table_info(${table})`).all();
        if (!columns.some((column) => column.name === name)) {
            db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${definition}`);
        }
    };
    addColumn('resource_quota_policy', 'default_cached_input_multiplier_micros', 'INTEGER NOT NULL DEFAULT 250000');
    addColumn('resource_model_multipliers', 'cached_input_multiplier_micros', 'INTEGER NOT NULL DEFAULT 250000');
    addColumn('resource_quota_reservations', 'cached_input_tokens', 'INTEGER');
    addColumn('resource_quota_reservations', 'cached_input_multiplier_micros', 'INTEGER NOT NULL DEFAULT 250000');
    addColumn('codex_usage_records', 'cached_input_tokens', 'INTEGER NOT NULL DEFAULT 0');
    addColumn('codex_usage_stats', 'cached_input_tokens', 'INTEGER NOT NULL DEFAULT 0');
}
export function down(_db) {
    throw new Error('irreversible migration: SQLite requires table rebuilds to remove cached points columns');
}
//# sourceMappingURL=20260725_000044_resource_cached_points.js.map