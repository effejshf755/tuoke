const REQUEST_SOURCE_NAME_COLUMN = 'codex_relay_source_name';
function hasColumn(db, table, column) {
    return db.prepare(`PRAGMA table_info(${table})`).all()
        .some((candidate) => candidate.name === column);
}
function installRequestInsertTrigger(db, snapshotSourceName) {
    const sourceNameAssignment = snapshotSourceName
        ? `,
        codex_relay_source_name = (
          SELECT source.name
          FROM codex_relay_sources source
          WHERE source.id = COALESCE(
            NEW.codex_relay_source_id,
            (
              SELECT source_key.source_id
              FROM codex_relay_source_keys source_key
              WHERE source_key.api_key_id = NEW.key_id
              ORDER BY source_key.source_id ASC
              LIMIT 1
            )
          )
        )`
        : '';
    db.exec(`
    DROP TRIGGER IF EXISTS trg_codex_relay_request_insert;
    CREATE TRIGGER trg_codex_relay_request_insert
    AFTER INSERT ON requests
    WHEN NEW.platform = 'openai-codex'
    BEGIN
      UPDATE requests
      SET codex_relay_source_id = COALESCE(
        NEW.codex_relay_source_id,
        (
          SELECT source_key.source_id
          FROM codex_relay_source_keys source_key
          WHERE source_key.api_key_id = NEW.key_id
          ORDER BY source_key.source_id ASC
          LIMIT 1
        )
      )${sourceNameAssignment}
      WHERE id = NEW.id;

      INSERT INTO codex_relay_source_statistics (
        source_id, request_count, success_count, failure_count, partial_count,
        input_tokens, cached_input_tokens, cache_write_tokens, output_tokens,
        billed_micro, latency_total_ms, last_request_at, updated_at
      )
      SELECT
        source.id,
        1,
        CASE WHEN NEW.status = 'success' THEN 1 ELSE 0 END,
        CASE WHEN NEW.status = 'error' THEN 1 ELSE 0 END,
        CASE WHEN NEW.status = 'partial' THEN 1 ELSE 0 END,
        MAX(0, NEW.input_tokens),
        MAX(0, NEW.cached_input_tokens),
        MAX(0, NEW.cache_write_tokens),
        MAX(0, NEW.output_tokens),
        CASE WHEN NEW.billing_status = 'charged'
          THEN MAX(0, NEW.billing_amount_micro)
          ELSE 0
        END,
        MAX(0, NEW.latency_ms),
        NEW.created_at,
        datetime('now')
      FROM codex_relay_sources source
      WHERE source.id = COALESCE(
        NEW.codex_relay_source_id,
        (
          SELECT source_key.source_id
          FROM codex_relay_source_keys source_key
          WHERE source_key.api_key_id = NEW.key_id
          ORDER BY source_key.source_id ASC
          LIMIT 1
        )
      )
        AND source.statistics_started_at IS NOT NULL
        AND datetime(NEW.created_at) >= datetime(source.statistics_started_at)
      ON CONFLICT(source_id) DO UPDATE SET
        request_count = request_count + excluded.request_count,
        success_count = success_count + excluded.success_count,
        failure_count = failure_count + excluded.failure_count,
        partial_count = partial_count + excluded.partial_count,
        input_tokens = input_tokens + excluded.input_tokens,
        cached_input_tokens = cached_input_tokens + excluded.cached_input_tokens,
        cache_write_tokens = cache_write_tokens + excluded.cache_write_tokens,
        output_tokens = output_tokens + excluded.output_tokens,
        billed_micro = billed_micro + excluded.billed_micro,
        latency_total_ms = latency_total_ms + excluded.latency_total_ms,
        last_request_at = excluded.last_request_at,
        updated_at = excluded.updated_at;
    END;
  `);
}
/**
 * Keep the administrator-defined supplier label on each request.  The source
 * foreign key intentionally uses ON DELETE SET NULL, so without this snapshot
 * a physical source deletion would make old analytics rows anonymous.
 */
export function up(db) {
    if (!hasColumn(db, 'requests', REQUEST_SOURCE_NAME_COLUMN)) {
        db.exec(`ALTER TABLE requests ADD COLUMN ${REQUEST_SOURCE_NAME_COLUMN} TEXT`);
    }
    db.exec(`
    UPDATE requests
    SET codex_relay_source_name = (
      SELECT source.name
      FROM codex_relay_sources source
      WHERE source.id = COALESCE(
        requests.codex_relay_source_id,
        (
          SELECT source_key.source_id
          FROM codex_relay_source_keys source_key
          WHERE source_key.api_key_id = requests.key_id
          ORDER BY source_key.source_id ASC
          LIMIT 1
        )
      )
    )
    WHERE platform = 'openai-codex'
      AND codex_relay_source_name IS NULL
      AND EXISTS (
        SELECT 1
        FROM codex_relay_sources source
        WHERE source.id = COALESCE(
          requests.codex_relay_source_id,
          (
            SELECT source_key.source_id
            FROM codex_relay_source_keys source_key
            WHERE source_key.api_key_id = requests.key_id
            ORDER BY source_key.source_id ASC
            LIMIT 1
          )
        )
      );
  `);
    installRequestInsertTrigger(db, true);
}
export function down(db) {
    db.exec(`DROP TRIGGER IF EXISTS trg_codex_relay_request_insert`);
    if (hasColumn(db, 'requests', REQUEST_SOURCE_NAME_COLUMN)) {
        db.exec(`ALTER TABLE requests DROP COLUMN ${REQUEST_SOURCE_NAME_COLUMN}`);
    }
    // Restore the exact pre-snapshot writer so a one-step rollback leaves the
    // source statistics migration fully operational.
    installRequestInsertTrigger(db, false);
}
//# sourceMappingURL=20260805_000071_codex_relay_source_name_snapshot.js.map