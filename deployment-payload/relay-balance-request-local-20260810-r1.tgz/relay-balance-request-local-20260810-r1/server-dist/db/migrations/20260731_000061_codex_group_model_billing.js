const COLUMNS = [
    {
        name: 'input_price_micro_per_million_override',
        definition: 'INTEGER CHECK (input_price_micro_per_million_override >= 0 AND input_price_micro_per_million_override <= 1000000000000)',
    },
    {
        name: 'output_price_micro_per_million_override',
        definition: 'INTEGER CHECK (output_price_micro_per_million_override >= 0 AND output_price_micro_per_million_override <= 1000000000000)',
    },
    {
        name: 'multiplier_milli_override',
        definition: 'INTEGER CHECK (multiplier_milli_override >= 0 AND multiplier_milli_override <= 1000000)',
    },
    {
        name: 'cached_input_multiplier_milli_override',
        definition: 'INTEGER CHECK (cached_input_multiplier_milli_override >= 0 AND cached_input_multiplier_milli_override <= 1000000)',
    },
];
export function up(db) {
    const existing = new Set(db.prepare('PRAGMA table_info(codex_group_models)').all()
        .map((column) => column.name));
    for (const column of COLUMNS) {
        if (!existing.has(column.name)) {
            db.exec(`ALTER TABLE codex_group_models ADD COLUMN ${column.name} ${column.definition}`);
        }
    }
}
export function down(db) {
    const existing = new Set(db.prepare('PRAGMA table_info(codex_group_models)').all()
        .map((column) => column.name));
    for (const column of [...COLUMNS].reverse()) {
        if (existing.has(column.name)) {
            db.exec(`ALTER TABLE codex_group_models DROP COLUMN ${column.name}`);
        }
    }
}
//# sourceMappingURL=20260731_000061_codex_group_model_billing.js.map