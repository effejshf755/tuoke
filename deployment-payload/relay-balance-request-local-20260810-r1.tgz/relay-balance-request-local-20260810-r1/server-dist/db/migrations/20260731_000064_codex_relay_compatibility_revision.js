/**
 * Monotonic configuration revision used to discard a compatibility result if
 * the endpoint, credential, protocol, or model mappings changed mid-test.
 * Kept separate from 000063 because that migration may already be applied.
 */
export function up(db) {
    const columns = db.prepare('PRAGMA table_info(codex_relay_sources)').all();
    if (!columns.some((column) => column.name === 'compatibility_config_revision')) {
        db.exec(`
      ALTER TABLE codex_relay_sources
      ADD COLUMN compatibility_config_revision INTEGER NOT NULL DEFAULT 1
        CHECK (compatibility_config_revision >= 1)
    `);
    }
}
export function down(db) {
    const columns = db.prepare('PRAGMA table_info(codex_relay_sources)').all();
    if (columns.some((column) => column.name === 'compatibility_config_revision')) {
        db.exec('ALTER TABLE codex_relay_sources DROP COLUMN compatibility_config_revision');
    }
}
//# sourceMappingURL=20260731_000064_codex_relay_compatibility_revision.js.map