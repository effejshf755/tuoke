export function up(db) {
    const columns = db.prepare('PRAGMA table_info(codex_groups)').all();
    if (!columns.some(column => column.name === 'multiplier_milli')) {
        db.exec(`ALTER TABLE codex_groups ADD COLUMN multiplier_milli INTEGER NOT NULL DEFAULT 1000
      CHECK (multiplier_milli >= 0 AND multiplier_milli <= 1000000)`);
    }
}
export function down(db) {
    const columns = db.prepare('PRAGMA table_info(codex_groups)').all();
    if (columns.some(column => column.name === 'multiplier_milli')) {
        db.exec('ALTER TABLE codex_groups DROP COLUMN multiplier_milli');
    }
}
//# sourceMappingURL=20260729_000056_codex_group_multiplier.js.map