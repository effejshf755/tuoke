import type { Db } from '../types.js';
/**
 * A relay credential can serve several upstream models. Persist runtime health
 * on the mapping so one unsupported or temporarily unavailable model does not
 * remove the supplier's healthy sibling models from routing.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260808_000077_codex_relay_model_runtime_health.d.ts.map