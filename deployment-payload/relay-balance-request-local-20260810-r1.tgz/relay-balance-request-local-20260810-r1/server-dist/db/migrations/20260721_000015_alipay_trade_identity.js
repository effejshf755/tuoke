export function up(db) {
    db.exec(`
    CREATE UNIQUE INDEX IF NOT EXISTS idx_recharge_orders_provider_trade_no
    ON recharge_orders(payment_provider, provider_trade_no)
    WHERE payment_provider IS NOT NULL AND provider_trade_no IS NOT NULL;
  `);
}
export function down(db) {
    db.exec('DROP INDEX IF EXISTS idx_recharge_orders_provider_trade_no;');
}
//# sourceMappingURL=20260721_000015_alipay_trade_identity.js.map