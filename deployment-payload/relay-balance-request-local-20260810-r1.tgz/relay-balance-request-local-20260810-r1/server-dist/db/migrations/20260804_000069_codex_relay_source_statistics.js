const SOURCE_START_COLUMN = 'statistics_started_at';
const REQUEST_SOURCE_COLUMN = 'codex_relay_source_id';
function hasColumn(db, table, column) {
    return db.prepare(`PRAGMA table_info(${table})`).all()
        .some((candidate) => candidate.name === column);
}
/**
 * Keep a durable, per-supplier ledger. Raw request rows are intentionally
 * pruned, so lifetime supplier totals cannot be reconstructed from `requests`
 * alone. The triggers preserve exact upstream usage and the final charged
 * amount while each request row still exists.
 */
export function up(db) {
    if (!hasColumn(db, 'codex_relay_sources', SOURCE_START_COLUMN)) {
        db.exec(`ALTER TABLE codex_relay_sources ADD COLUMN ${SOURCE_START_COLUMN} TEXT`);
    }
    if (!hasColumn(db, 'requests', REQUEST_SOURCE_COLUMN)) {
        db.exec(`ALTER TABLE requests ADD COLUMN ${REQUEST_SOURCE_COLUMN} INTEGER
      REFERENCES codex_relay_sources(id) ON DELETE SET NULL`);
    }
    db.exec(`
    CREATE INDEX IF NOT EXISTS idx_requests_codex_relay_source
      ON requests(codex_relay_source_id, created_at);

    CREATE TABLE IF NOT EXISTS codex_relay_source_statistics (
      source_id INTEGER PRIMARY KEY
        REFERENCES codex_relay_sources(id) ON DELETE CASCADE,
      request_count INTEGER NOT NULL DEFAULT 0 CHECK (request_count >= 0),
      success_count INTEGER NOT NULL DEFAULT 0 CHECK (success_count >= 0),
      failure_count INTEGER NOT NULL DEFAULT 0 CHECK (failure_count >= 0),
      partial_count INTEGER NOT NULL DEFAULT 0 CHECK (partial_count >= 0),
      input_tokens INTEGER NOT NULL DEFAULT 0 CHECK (input_tokens >= 0),
      cached_input_tokens INTEGER NOT NULL DEFAULT 0 CHECK (cached_input_tokens >= 0),
      cache_write_tokens INTEGER NOT NULL DEFAULT 0 CHECK (cache_write_tokens >= 0),
      output_tokens INTEGER NOT NULL DEFAULT 0 CHECK (output_tokens >= 0),
      billed_micro INTEGER NOT NULL DEFAULT 0 CHECK (billed_micro >= 0),
      latency_total_ms INTEGER NOT NULL DEFAULT 0 CHECK (latency_total_ms >= 0),
      last_request_at TEXT,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
    db.exec(`
    UPDATE requests
    SET codex_relay_source_id = (
      SELECT source_key.source_id
      FROM codex_relay_source_keys source_key
      WHERE source_key.api_key_id = requests.key_id
      ORDER BY source_key.source_id ASC
      LIMIT 1
    )
    WHERE platform = 'openai-codex'
      AND codex_relay_source_id IS NULL
      AND EXISTS (
        SELECT 1 FROM codex_relay_source_keys source_key
        WHERE source_key.api_key_id = requests.key_id
      );

    UPDATE codex_relay_sources
    SET statistics_started_at = COALESCE(
      (
        SELECT MIN(request.created_at)
        FROM requests request
        WHERE request.codex_relay_source_id = codex_relay_sources.id
      ),
      CASE WHEN enabled = 1 THEN created_at ELSE NULL END
    )
    WHERE statistics_started_at IS NULL;

    INSERT INTO codex_relay_source_statistics (
      source_id, request_count, success_count, failure_count, partial_count,
      input_tokens, cached_input_tokens, cache_write_tokens, output_tokens,
      billed_micro, latency_total_ms, last_request_at, updated_at
    )
    SELECT
      source.id,
      COUNT(request.id),
      COALESCE(SUM(CASE WHEN request.status = 'success' THEN 1 ELSE 0 END), 0),
      COALESCE(SUM(CASE WHEN request.status = 'error' THEN 1 ELSE 0 END), 0),
      COALESCE(SUM(CASE WHEN request.status = 'partial' THEN 1 ELSE 0 END), 0),
      COALESCE(SUM(request.input_tokens), 0),
      COALESCE(SUM(request.cached_input_tokens), 0),
      COALESCE(SUM(request.cache_write_tokens), 0),
      COALESCE(SUM(request.output_tokens), 0),
      COALESCE(SUM(CASE
        WHEN request.billing_status = 'charged' THEN request.billing_amount_micro
        ELSE 0
      END), 0),
      COALESCE(SUM(request.latency_ms), 0),
      MAX(request.created_at),
      datetime('now')
    FROM codex_relay_sources source
    LEFT JOIN requests request
      ON request.codex_relay_source_id = source.id
     AND source.statistics_started_at IS NOT NULL
     AND datetime(request.created_at) >= datetime(source.statistics_started_at)
    GROUP BY source.id
    ON CONFLICT(source_id) DO UPDATE SET
      request_count = excluded.request_count,
      success_count = excluded.success_count,
      failure_count = excluded.failure_count,
      partial_count = excluded.partial_count,
      input_tokens = excluded.input_tokens,
      cached_input_tokens = excluded.cached_input_tokens,
      cache_write_tokens = excluded.cache_write_tokens,
      output_tokens = excluded.output_tokens,
      billed_micro = excluded.billed_micro,
      latency_total_ms = excluded.latency_total_ms,
      last_request_at = excluded.last_request_at,
      updated_at = excluded.updated_at;

    DROP TRIGGER IF EXISTS trg_codex_relay_request_insert;
    CREATE TRIGGER trg_codex_relay_request_insert
    AFTER INSERT ON requests
    WHEN NEW.platform = 'openai-codex'
    BEGIN
      UPDATE requests
      SET codex_relay_source_id = COALESCE(
        NEW.codex_relay_source_id,
        (
          SELECT source_key.source_id
          FROM codex_relay_source_keys source_key
          WHERE source_key.api_key_id = NEW.key_id
          ORDER BY source_key.source_id ASC
          LIMIT 1
        )
      )
      WHERE id = NEW.id;

      INSERT INTO codex_relay_source_statistics (
        source_id, request_count, success_count, failure_count, partial_count,
        input_tokens, cached_input_tokens, cache_write_tokens, output_tokens,
        billed_micro, latency_total_ms, last_request_at, updated_at
      )
      SELECT
        source.id,
        1,
        CASE WHEN NEW.status = 'success' THEN 1 ELSE 0 END,
        CASE WHEN NEW.status = 'error' THEN 1 ELSE 0 END,
        CASE WHEN NEW.status = 'partial' THEN 1 ELSE 0 END,
        MAX(0, NEW.input_tokens),
        MAX(0, NEW.cached_input_tokens),
        MAX(0, NEW.cache_write_tokens),
        MAX(0, NEW.output_tokens),
        CASE WHEN NEW.billing_status = 'charged'
          THEN MAX(0, NEW.billing_amount_micro)
          ELSE 0
        END,
        MAX(0, NEW.latency_ms),
        NEW.created_at,
        datetime('now')
      FROM codex_relay_sources source
      WHERE source.id = COALESCE(
        NEW.codex_relay_source_id,
        (
          SELECT source_key.source_id
          FROM codex_relay_source_keys source_key
          WHERE source_key.api_key_id = NEW.key_id
          ORDER BY source_key.source_id ASC
          LIMIT 1
        )
      )
        AND source.statistics_started_at IS NOT NULL
        AND datetime(NEW.created_at) >= datetime(source.statistics_started_at)
      ON CONFLICT(source_id) DO UPDATE SET
        request_count = request_count + excluded.request_count,
        success_count = success_count + excluded.success_count,
        failure_count = failure_count + excluded.failure_count,
        partial_count = partial_count + excluded.partial_count,
        input_tokens = input_tokens + excluded.input_tokens,
        cached_input_tokens = cached_input_tokens + excluded.cached_input_tokens,
        cache_write_tokens = cache_write_tokens + excluded.cache_write_tokens,
        output_tokens = output_tokens + excluded.output_tokens,
        billed_micro = billed_micro + excluded.billed_micro,
        latency_total_ms = latency_total_ms + excluded.latency_total_ms,
        last_request_at = excluded.last_request_at,
        updated_at = excluded.updated_at;
    END;

    DROP TRIGGER IF EXISTS trg_codex_relay_request_billing_update;
    CREATE TRIGGER trg_codex_relay_request_billing_update
    AFTER UPDATE OF billing_amount_micro, billing_status ON requests
    WHEN NEW.codex_relay_source_id IS NOT NULL
      AND (
        CASE WHEN NEW.billing_status = 'charged' THEN NEW.billing_amount_micro ELSE 0 END
      ) != (
        CASE WHEN OLD.billing_status = 'charged' THEN OLD.billing_amount_micro ELSE 0 END
      )
    BEGIN
      UPDATE codex_relay_source_statistics
      SET billed_micro = MAX(
            0,
            billed_micro
              + CASE WHEN NEW.billing_status = 'charged' THEN NEW.billing_amount_micro ELSE 0 END
              - CASE WHEN OLD.billing_status = 'charged' THEN OLD.billing_amount_micro ELSE 0 END
          ),
          updated_at = datetime('now')
      WHERE source_id = NEW.codex_relay_source_id;
    END;
  `);
}
export function down(db) {
    db.exec(`
    DROP TRIGGER IF EXISTS trg_codex_relay_request_billing_update;
    DROP TRIGGER IF EXISTS trg_codex_relay_request_insert;
    DROP TABLE IF EXISTS codex_relay_source_statistics;
    DROP INDEX IF EXISTS idx_requests_codex_relay_source;
  `);
    if (hasColumn(db, 'requests', REQUEST_SOURCE_COLUMN)) {
        db.exec(`ALTER TABLE requests DROP COLUMN ${REQUEST_SOURCE_COLUMN}`);
    }
    if (hasColumn(db, 'codex_relay_sources', SOURCE_START_COLUMN)) {
        db.exec(`ALTER TABLE codex_relay_sources DROP COLUMN ${SOURCE_START_COLUMN}`);
    }
}
//# sourceMappingURL=20260804_000069_codex_relay_source_statistics.js.map