const LEGACY_GROUP_NAME = '旧账号池';
const LEGACY_GROUP_DESCRIPTION = '自动承接分组功能上线前已有的 Codex 账号和 API Key。';
const LEGACY_GROUP_MULTIPLIER_MILLI = 1_000;
const AUDIT_TABLE = 'codex_legacy_group_backfill_audit';
function hasTable(db, tableName) {
    return Boolean(db.prepare(`
    SELECT 1
    FROM sqlite_master
    WHERE type = 'table' AND name = ?
    LIMIT 1
  `).get(tableName));
}
function createAuditTable(db) {
    db.exec(`
    CREATE TABLE IF NOT EXISTS ${AUDIT_TABLE} (
      kind TEXT NOT NULL
        CHECK (kind IN ('created_group', 'enabled_group', 'oauth_account', 'consumer_key', 'group_model')),
      entity_key TEXT NOT NULL,
      group_id INTEGER NOT NULL,
      previous_value TEXT,
      applied_value TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      PRIMARY KEY (kind, entity_key, group_id)
    );
    CREATE INDEX IF NOT EXISTS idx_codex_legacy_group_backfill_audit_group
      ON ${AUDIT_TABLE}(group_id, kind);
  `);
}
function recordAudit(db, kind, entityKey, groupId, previousValue = null, appliedValue = null) {
    return db.prepare(`
    INSERT OR IGNORE INTO ${AUDIT_TABLE} (
      kind, entity_key, group_id, previous_value, applied_value
    ) VALUES (?, ?, ?, ?, ?)
  `).run(kind, entityKey, groupId, previousValue, appliedValue).changes;
}
function groupHasBindings(db, groupId) {
    return Boolean(db.prepare(`
    SELECT 1
    FROM codex_oauth_accounts
    WHERE codex_group_id = ?
    UNION ALL
    SELECT 1
    FROM consumer_api_keys
    WHERE codex_group_id = ?
    UNION ALL
    SELECT 1
    FROM codex_relay_sources
    WHERE codex_group_id = ?
    LIMIT 1
  `).get(groupId, groupId, groupId));
}
function ensureLegacyGroup(db) {
    let group = db.prepare(`
    SELECT id, name, description, enabled, multiplier_milli, updated_at
    FROM codex_groups
    WHERE name = ?
    LIMIT 1
  `).get(LEGACY_GROUP_NAME);
    if (!group) {
        const result = db.prepare(`
      INSERT INTO codex_groups (
        name, description, enabled, multiplier_milli
      ) VALUES (?, ?, 1, ?)
    `).run(LEGACY_GROUP_NAME, LEGACY_GROUP_DESCRIPTION, LEGACY_GROUP_MULTIPLIER_MILLI);
        const groupId = Number(result.lastInsertRowid);
        recordAudit(db, 'created_group', String(groupId), groupId);
        return groupId;
    }
    // A group with this explicit migration name is the intended reuse target.
    // It must be enabled so migrated active keys do not remain unusable. Preserve
    // every other administrator-owned setting and track this one state change so
    // a down migration can restore it when no post-migration binding depends on it.
    if (group.enabled !== 1) {
        const appliedAt = db.prepare(`SELECT strftime('%Y-%m-%d %H:%M:%f', 'now') AS value`)
            .get().value;
        const previousState = {
            name: group.name,
            description: group.description,
            multiplierMilli: group.multiplier_milli,
            updatedAt: group.updated_at,
        };
        const recorded = recordAudit(db, 'enabled_group', String(group.id), group.id, JSON.stringify(previousState), appliedAt);
        if (recorded > 0) {
            db.prepare(`
        UPDATE codex_groups
        SET enabled = 1, updated_at = ?
        WHERE id = ? AND enabled = 0
      `).run(appliedAt, group.id);
            group = { ...group, enabled: 1, updated_at: appliedAt };
        }
    }
    return group.id;
}
export function up(db) {
    db.transaction(() => {
        createAuditTable(db);
        const accountRows = db.prepare(`
      SELECT id
      FROM codex_oauth_accounts
      WHERE resource_scope = 'codex_pool'
        AND codex_group_id IS NULL
        AND deleted_at IS NULL
      ORDER BY id
    `).all();
        const keyRows = db.prepare(`
      SELECT id
      FROM consumer_api_keys
      WHERE key_scope = 'codex_pool'
        AND status = 'active'
        AND codex_group_id IS NULL
      ORDER BY id
    `).all();
        // Fresh installs have no legacy rows. Keep the migration inert apart from
        // its rollback audit table instead of cluttering them with an empty group.
        if (accountRows.length === 0 && keyRows.length === 0)
            return;
        const modelRows = db.prepare(`
      SELECT DISTINCT am.model_id
      FROM codex_oauth_account_models am
      JOIN codex_oauth_accounts account ON account.id = am.account_id
      WHERE account.resource_scope = 'codex_pool'
        AND account.codex_group_id IS NULL
        AND account.deleted_at IS NULL
        AND trim(am.model_id) <> ''
      ORDER BY am.model_id
    `).all();
        const groupId = ensureLegacyGroup(db);
        const bindAccount = db.prepare(`
      UPDATE codex_oauth_accounts
      SET codex_group_id = ?, updated_at = datetime('now')
      WHERE id = ?
        AND resource_scope = 'codex_pool'
        AND codex_group_id IS NULL
        AND deleted_at IS NULL
    `);
        for (const account of accountRows) {
            recordAudit(db, 'oauth_account', String(account.id), groupId);
            bindAccount.run(groupId, account.id);
        }
        const bindKey = db.prepare(`
      UPDATE consumer_api_keys
      SET codex_group_id = ?
      WHERE id = ?
        AND key_scope = 'codex_pool'
        AND status = 'active'
        AND codex_group_id IS NULL
    `);
        for (const key of keyRows) {
            recordAudit(db, 'consumer_key', String(key.id), groupId);
            bindKey.run(groupId, key.id);
        }
        const groupModelExists = db.prepare(`
      SELECT 1
      FROM codex_group_models
      WHERE group_id = ? AND model_id = ?
      LIMIT 1
    `);
        const insertGroupModel = db.prepare(`
      INSERT OR IGNORE INTO codex_group_models (group_id, model_id)
      VALUES (?, ?)
    `);
        for (const model of modelRows) {
            if (groupModelExists.get(groupId, model.model_id))
                continue;
            recordAudit(db, 'group_model', model.model_id, groupId);
            insertGroupModel.run(groupId, model.model_id);
        }
    })();
}
function unbindTrackedRows(db, groupId) {
    db.prepare(`
    UPDATE codex_oauth_accounts
    SET codex_group_id = NULL, updated_at = datetime('now')
    WHERE codex_group_id = ?
      AND resource_scope = 'codex_pool'
      AND CAST(id AS TEXT) IN (
        SELECT entity_key
        FROM ${AUDIT_TABLE}
        WHERE kind = 'oauth_account' AND group_id = ?
      )
  `).run(groupId, groupId);
    db.prepare(`
    UPDATE consumer_api_keys
    SET codex_group_id = NULL
    WHERE codex_group_id = ?
      AND key_scope = 'codex_pool'
      AND CAST(id AS TEXT) IN (
        SELECT entity_key
        FROM ${AUDIT_TABLE}
        WHERE kind = 'consumer_key' AND group_id = ?
      )
  `).run(groupId, groupId);
}
function removeUnchangedCreatedGroup(db, groupId) {
    const group = db.prepare(`
    SELECT id, name, description, enabled, multiplier_milli, updated_at
    FROM codex_groups
    WHERE id = ?
  `).get(groupId);
    if (!group
        || group.name !== LEGACY_GROUP_NAME
        || group.description !== LEGACY_GROUP_DESCRIPTION
        || group.enabled !== 1
        || group.multiplier_milli !== LEGACY_GROUP_MULTIPLIER_MILLI
        || groupHasBindings(db, groupId)) {
        return;
    }
    // Only a pristine set of default-priced model rows inserted by this
    // migration may be removed with the migration-created group. Any model added
    // or priced by an administrator makes the group user-owned and is preserved.
    const hasUserOwnedModel = Boolean(db.prepare(`
    SELECT 1
    FROM codex_group_models model
    WHERE model.group_id = ?
      AND (
        model.input_price_micro_per_million_override IS NOT NULL
        OR model.output_price_micro_per_million_override IS NOT NULL
        OR model.multiplier_milli_override IS NOT NULL
        OR model.cached_input_multiplier_milli_override IS NOT NULL
        OR NOT EXISTS (
          SELECT 1
          FROM ${AUDIT_TABLE} audit
          WHERE audit.kind = 'group_model'
            AND audit.group_id = model.group_id
            AND audit.entity_key = model.model_id
        )
      )
    LIMIT 1
  `).get(groupId));
    if (hasUserOwnedModel)
        return;
    // Delete model rows explicitly as well as relying on ON DELETE CASCADE so
    // this rollback is deterministic even for direct migration tests that did
    // not enable SQLite foreign-key enforcement.
    db.prepare('DELETE FROM codex_group_models WHERE group_id = ?').run(groupId);
    db.prepare('DELETE FROM codex_groups WHERE id = ?').run(groupId);
}
function removeUnchangedTrackedModelsFromReusedGroup(db, groupId) {
    // A reused group may have had its own accounts, keys, or relay sources before
    // this migration, or acquired them afterwards. In either case its model
    // allow-list is live administrator configuration and must be preserved.
    if (groupHasBindings(db, groupId))
        return;
    db.prepare(`
    DELETE FROM codex_group_models
    WHERE group_id = ?
      AND input_price_micro_per_million_override IS NULL
      AND output_price_micro_per_million_override IS NULL
      AND multiplier_milli_override IS NULL
      AND cached_input_multiplier_milli_override IS NULL
      AND model_id IN (
        SELECT entity_key
        FROM ${AUDIT_TABLE}
        WHERE kind = 'group_model' AND group_id = ?
      )
  `).run(groupId, groupId);
}
function restoreReusedGroupEnabledState(db, audit) {
    if (!audit.previous_value || !audit.applied_value)
        return;
    let previous;
    try {
        previous = JSON.parse(audit.previous_value);
    }
    catch {
        return;
    }
    const current = db.prepare(`
    SELECT id, name, description, enabled, multiplier_milli, updated_at
    FROM codex_groups
    WHERE id = ?
  `).get(audit.group_id);
    if (!current
        || current.enabled !== 1
        || current.updated_at !== audit.applied_value
        || current.name !== previous.name
        || current.description !== previous.description
        || current.multiplier_milli !== previous.multiplierMilli
        || groupHasBindings(db, audit.group_id)) {
        return;
    }
    db.prepare(`
    UPDATE codex_groups
    SET enabled = 0, updated_at = ?
    WHERE id = ? AND enabled = 1 AND updated_at = ?
  `).run(previous.updatedAt, audit.group_id, audit.applied_value);
}
export function down(db) {
    if (!hasTable(db, AUDIT_TABLE))
        return;
    db.transaction(() => {
        const groupIds = db.prepare(`SELECT DISTINCT group_id FROM ${AUDIT_TABLE} ORDER BY group_id`)
            .all().map((row) => row.group_id);
        for (const groupId of groupIds)
            unbindTrackedRows(db, groupId);
        const createdGroups = db.prepare(`
      SELECT entity_key, group_id, previous_value, applied_value
      FROM ${AUDIT_TABLE}
      WHERE kind = 'created_group'
      ORDER BY group_id
    `).all();
        const createdGroupIds = new Set(createdGroups.map((audit) => audit.group_id));
        for (const groupId of groupIds) {
            if (!createdGroupIds.has(groupId)) {
                removeUnchangedTrackedModelsFromReusedGroup(db, groupId);
            }
        }
        for (const audit of createdGroups) {
            removeUnchangedCreatedGroup(db, audit.group_id);
        }
        const enabledGroups = db.prepare(`
      SELECT entity_key, group_id, previous_value, applied_value
      FROM ${AUDIT_TABLE}
      WHERE kind = 'enabled_group'
      ORDER BY group_id
    `).all();
        for (const audit of enabledGroups) {
            restoreReusedGroupEnabledState(db, audit);
        }
        db.exec(`
      DROP INDEX IF EXISTS idx_codex_legacy_group_backfill_audit_group;
      DROP TABLE IF EXISTS ${AUDIT_TABLE};
    `);
    })();
}
//# sourceMappingURL=20260731_000062_codex_legacy_group_backfill.js.map