const CURRENT_SUITE_VERSION = 'native-responses-v2';
function columnsFor(db) {
    return new Set(db.prepare('PRAGMA table_info(codex_relay_source_keys)').all()
        .map((column) => column.name));
}
/**
 * Persist full compatibility evidence beside the exact relay credential that
 * produced it. Source-level columns remain as the latest-run summary for API
 * compatibility, while routing can certify several keys independently.
 */
export function up(db) {
    const columns = columnsFor(db);
    if (!columns.has('compatibility_status')) {
        db.exec(`
      ALTER TABLE codex_relay_source_keys
      ADD COLUMN compatibility_status TEXT NOT NULL DEFAULT 'untested'
        CHECK (compatibility_status IN ('untested', 'compatible', 'partial', 'incompatible'))
    `);
    }
    if (!columns.has('compatibility_checked_at')) {
        db.exec(`
      ALTER TABLE codex_relay_source_keys
      ADD COLUMN compatibility_checked_at TEXT
    `);
    }
    if (!columns.has('compatibility_report')) {
        db.exec(`
      ALTER TABLE codex_relay_source_keys
      ADD COLUMN compatibility_report TEXT
    `);
    }
    // Preserve the one current V2 report that older deployments stored on the
    // source. Legacy-suite or credential-mismatched reports remain available in
    // the source summary for audit, but are not promoted into per-key evidence.
    const rows = db.prepare(`
    SELECT id AS source_id, compatibility_status, compatibility_checked_at,
           compatibility_report
    FROM codex_relay_sources
    WHERE compatibility_report IS NOT NULL
  `).all();
    const linkedKey = db.prepare(`
    SELECT credential_revision
    FROM codex_relay_source_keys
    WHERE source_id = ? AND api_key_id = ?
  `);
    const backfill = db.prepare(`
    UPDATE codex_relay_source_keys
    SET compatibility_status = ?,
        compatibility_checked_at = ?,
        compatibility_report = ?
    WHERE source_id = ?
      AND api_key_id = ?
      AND credential_revision = ?
      AND compatibility_report IS NULL
  `);
    for (const row of rows) {
        let identity;
        try {
            identity = JSON.parse(row.compatibility_report);
        }
        catch {
            continue;
        }
        const apiKeyId = Number(identity.api_key_id);
        const credentialRevision = Number(identity.api_key_credential_revision);
        if (identity.version !== 2
            || identity.suite_version !== CURRENT_SUITE_VERSION
            || !Number.isSafeInteger(apiKeyId)
            || apiKeyId <= 0
            || !Number.isSafeInteger(credentialRevision)
            || credentialRevision < 0) {
            continue;
        }
        const key = linkedKey.get(row.source_id, apiKeyId);
        if (!key || key.credential_revision !== credentialRevision)
            continue;
        backfill.run(row.compatibility_status, row.compatibility_checked_at, row.compatibility_report, row.source_id, apiKeyId, credentialRevision);
    }
}
export function down(db) {
    const columns = columnsFor(db);
    if (columns.has('compatibility_report')) {
        db.exec('ALTER TABLE codex_relay_source_keys DROP COLUMN compatibility_report');
    }
    if (columns.has('compatibility_checked_at')) {
        db.exec('ALTER TABLE codex_relay_source_keys DROP COLUMN compatibility_checked_at');
    }
    if (columns.has('compatibility_status')) {
        db.exec('ALTER TABLE codex_relay_source_keys DROP COLUMN compatibility_status');
    }
}
//# sourceMappingURL=20260808_000078_codex_relay_key_compatibility.js.map