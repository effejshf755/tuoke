import type { Db } from '../types.js';
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260721_000015_alipay_trade_identity.d.ts.map