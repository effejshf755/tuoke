const DEFAULT_POINTS_PER_MILLION = 1_000_000;
export function up(db) {
    const columns = db.prepare("PRAGMA table_info(requests)").all();
    const add = (name) => {
        if (!columns.some((column) => column.name === name)) {
            db.exec(`ALTER TABLE requests ADD COLUMN ${name} INTEGER NOT NULL DEFAULT 0 CHECK (${name} >= 0)`);
        }
    };
    add("input_compute_points");
    add("output_compute_points");
    add("compute_points_per_million_tokens");
    const configured = Number(db
        .prepare("SELECT value FROM settings WHERE key = 'compute_points_per_million_tokens'")
        .get()?.value);
    const pointsPerMillion = Number.isInteger(configured) && configured > 0
        ? configured
        : DEFAULT_POINTS_PER_MILLION;
    db.prepare(`UPDATE requests SET
    input_compute_points = ROUND(input_tokens * ? / 1000000.0),
    output_compute_points = ROUND(output_tokens * ? / 1000000.0),
    compute_points_per_million_tokens = ?
    WHERE compute_points_per_million_tokens = 0`).run(pointsPerMillion, pointsPerMillion, pointsPerMillion);
}
export function down(db) {
    const columns = db.prepare("PRAGMA table_info(requests)").all();
    for (const name of [
        "compute_points_per_million_tokens",
        "output_compute_points",
        "input_compute_points",
    ]) {
        if (columns.some((column) => column.name === name))
            db.exec(`ALTER TABLE requests DROP COLUMN ${name}`);
    }
}
//# sourceMappingURL=20260729_000058_request_compute_points.js.map