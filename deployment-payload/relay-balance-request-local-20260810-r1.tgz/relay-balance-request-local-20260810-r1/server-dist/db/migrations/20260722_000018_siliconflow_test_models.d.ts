import type { Db } from '../types.js';
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260722_000018_siliconflow_test_models.d.ts.map