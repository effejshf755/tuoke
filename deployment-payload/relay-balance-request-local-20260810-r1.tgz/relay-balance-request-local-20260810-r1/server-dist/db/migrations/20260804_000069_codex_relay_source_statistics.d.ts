import type { Db } from '../types.js';
/**
 * Keep a durable, per-supplier ledger. Raw request rows are intentionally
 * pruned, so lifetime supplier totals cannot be reconstructed from `requests`
 * alone. The triggers preserve exact upstream usage and the final charged
 * amount while each request row still exists.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260804_000069_codex_relay_source_statistics.d.ts.map