const COLUMN = 'compute_points_per_million_tokens';
export function up(db) {
    const columns = db.prepare('PRAGMA table_info(users)').all();
    if (!columns.some((column) => column.name === COLUMN)) {
        db.exec(`ALTER TABLE users ADD COLUMN ${COLUMN} INTEGER
      CHECK (${COLUMN} IS NULL OR (${COLUMN} >= 1000000 AND ${COLUMN} <= 1000000000))`);
    }
}
export function down(db) {
    const columns = db.prepare('PRAGMA table_info(users)').all();
    if (columns.some((column) => column.name === COLUMN)) {
        db.exec(`ALTER TABLE users DROP COLUMN ${COLUMN}`);
    }
}
//# sourceMappingURL=20260803_000068_user_compute_points.js.map