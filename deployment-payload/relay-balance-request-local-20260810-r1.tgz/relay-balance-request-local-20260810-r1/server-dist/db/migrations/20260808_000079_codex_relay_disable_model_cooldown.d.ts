import type { Db } from '../types.js';
/**
 * Runtime source+model cooldowns were removed from routing policy. Clear every
 * previously persisted failure/cooldown during deployment so old yellow
 * "cooling" states cannot survive the code change or reappear in admin APIs.
 * Keep the columns for rollback/schema compatibility; routing no longer reads
 * them as eligibility gates.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260808_000079_codex_relay_disable_model_cooldown.d.ts.map