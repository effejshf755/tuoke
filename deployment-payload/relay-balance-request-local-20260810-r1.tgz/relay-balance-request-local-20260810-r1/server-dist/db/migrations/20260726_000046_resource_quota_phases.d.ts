import type { Db } from '../types.js';
export declare function up(db: Db): void;
export declare function down(_db: Db): void;
//# sourceMappingURL=20260726_000046_resource_quota_phases.d.ts.map