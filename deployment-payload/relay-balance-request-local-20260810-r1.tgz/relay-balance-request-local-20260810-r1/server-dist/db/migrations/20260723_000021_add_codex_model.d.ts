import type { Db } from '../types.js';
export declare function up(db: Db): void;
export declare function down(_db: Db): void;
//# sourceMappingURL=20260723_000021_add_codex_model.d.ts.map