import type { Db } from '../types.js';
/**
 * Relay failures used to add their estimated prompt size to durable supplier
 * totals even when the upstream rejected the request before doing any work.
 * Preserve request/failure counters, but count tokens only for a successful
 * request or a failed/partial request with observable upstream usage.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260806_000074_codex_relay_usage_accounting.d.ts.map