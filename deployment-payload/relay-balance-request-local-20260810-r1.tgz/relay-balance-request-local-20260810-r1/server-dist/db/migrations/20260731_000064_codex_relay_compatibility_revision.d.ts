import type { Db } from '../types.js';
/**
 * Monotonic configuration revision used to discard a compatibility result if
 * the endpoint, credential, protocol, or model mappings changed mid-test.
 * Kept separate from 000063 because that migration may already be applied.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260731_000064_codex_relay_compatibility_revision.d.ts.map