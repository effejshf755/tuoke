export function up(db) {
    const columns = db.prepare('PRAGMA table_info(users)').all();
    if (!columns.some((column) => column.name === 'deleted_at')) {
        db.exec('ALTER TABLE users ADD COLUMN deleted_at TEXT');
    }
    db.exec('CREATE INDEX IF NOT EXISTS idx_users_deleted_at ON users(deleted_at)');
}
export function down(db) {
    db.exec('DROP INDEX IF EXISTS idx_users_deleted_at');
    db.exec('ALTER TABLE users DROP COLUMN deleted_at');
}
//# sourceMappingURL=20260727_000051_user_soft_delete.js.map