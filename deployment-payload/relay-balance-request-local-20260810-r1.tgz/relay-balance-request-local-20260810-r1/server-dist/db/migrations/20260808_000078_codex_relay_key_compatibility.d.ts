import type { Db } from '../types.js';
/**
 * Persist full compatibility evidence beside the exact relay credential that
 * produced it. Source-level columns remain as the latest-run summary for API
 * compatibility, while routing can certify several keys independently.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260808_000078_codex_relay_key_compatibility.d.ts.map