const TOTAL_CACHED_INPUT_TOKENS_KEY = "total_cached_input_tokens";
function hasColumn(db, table, column) {
    const columns = db.prepare(`PRAGMA table_info(${table})`).all();
    return columns.some((item) => item.name === column);
}
export function up(db) {
    if (!hasColumn(db, "request_hourly", "cached_input_tokens")) {
        db.exec("ALTER TABLE request_hourly ADD COLUMN cached_input_tokens INTEGER NOT NULL DEFAULT 0 CHECK (cached_input_tokens >= 0)");
    }
    // Cached usage was captured in the Codex ledger before the generic request
    // table started persisting it. Restore linked records without reducing any
    // value that is already present on the request row.
    db.exec(`
    UPDATE requests
    SET cached_input_tokens = (
      SELECT MAX(cached.cached_input_tokens)
      FROM codex_usage_records cached
      WHERE cached.request_id = requests.id
    )
    WHERE EXISTS (
      SELECT 1
      FROM codex_usage_records cached
      WHERE cached.request_id = requests.id
        AND cached.cached_input_tokens > requests.cached_input_tokens
    )
  `);
    // Rebuild the new hourly dimension from all recoverable request rows. Other
    // aggregate columns are left untouched because they may include older rows
    // that have already been pruned from the raw request table.
    db.exec(`
    UPDATE request_hourly
    SET cached_input_tokens = COALESCE((
      SELECT SUM(requests.cached_input_tokens)
      FROM requests
      WHERE substr(requests.created_at, 1, 13) || ':00:00' = request_hourly.hour
    ), 0)
  `);
    const total = db.prepare(`
    SELECT COALESCE(SUM(cached_input_tokens), 0) AS total
    FROM requests
  `).get();
    db.prepare(`
    INSERT INTO settings (key, value) VALUES (?, ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(TOTAL_CACHED_INPUT_TOKENS_KEY, String(total.total));
}
export function down(db) {
    db.prepare("DELETE FROM settings WHERE key = ?").run(TOTAL_CACHED_INPUT_TOKENS_KEY);
    if (hasColumn(db, "request_hourly", "cached_input_tokens")) {
        db.exec("ALTER TABLE request_hourly DROP COLUMN cached_input_tokens");
    }
}
//# sourceMappingURL=20260730_000059_cached_token_aggregates.js.map