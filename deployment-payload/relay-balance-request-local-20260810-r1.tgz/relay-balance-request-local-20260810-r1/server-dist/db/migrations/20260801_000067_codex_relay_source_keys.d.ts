import type { Db } from '../types.js';
/**
 * Split a relay supplier from its credentials.  The legacy api_key_id stays on
 * codex_relay_sources as a compatibility/primary-key anchor while all runtime
 * selection and per-key health state moves to this child table.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260801_000067_codex_relay_source_keys.d.ts.map