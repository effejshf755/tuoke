import type { Db } from '../types.js';
/**
 * Store one bounded, administrator-only routing snapshot beside the existing
 * raw request row.  A nullable column keeps the common no-fallback path small
 * and follows the same retention policy as request analytics; no second log
 * table or independent cleanup job is required.
 */
export declare function up(db: Db): void;
export declare function down(db: Db): void;
//# sourceMappingURL=20260809_000082_request_routing_diagnostics.d.ts.map