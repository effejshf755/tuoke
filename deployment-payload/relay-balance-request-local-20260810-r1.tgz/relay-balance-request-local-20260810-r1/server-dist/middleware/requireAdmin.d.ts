import type { Request, Response, NextFunction } from 'express';
export declare function requireAdmin(req: Request, res: Response, next: NextFunction): void;
//# sourceMappingURL=requireAdmin.d.ts.map