export function requireAdmin(req, res, next) {
    const user = req.user;
    if (user?.role !== 'admin') {
        res.status(403).json({ error: { message: 'Administrator access required', type: 'permission_error' } });
        return;
    }
    next();
}
//# sourceMappingURL=requireAdmin.js.map