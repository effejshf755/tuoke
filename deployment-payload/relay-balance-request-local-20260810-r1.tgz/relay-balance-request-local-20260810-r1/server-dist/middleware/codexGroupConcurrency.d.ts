import type { NextFunction, Request, Response } from 'express';
/** Hold one per-user group slot for the full HTTP response, including streaming. */
export declare function codexGroupConcurrency(req: Request, res: Response, next: NextFunction): Promise<void>;
//# sourceMappingURL=codexGroupConcurrency.d.ts.map