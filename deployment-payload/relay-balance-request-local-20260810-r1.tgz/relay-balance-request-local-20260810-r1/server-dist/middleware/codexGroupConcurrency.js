import { getDb } from '../db/index.js';
import { getClientContext } from '../lib/client-context.js';
import { acquireCodexGroupSlot, CodexGroupConcurrencyError, } from '../services/codex-concurrency.js';
function isInferenceRequest(req) {
    if (req.method !== 'POST')
        return false;
    if (req.path === '/messages/count_tokens'
        || req.path === '/embeddings'
        || req.path === '/images/generations'
        || req.path === '/images/edits'
        || req.path === '/audio/speech'
        || /:countTokens$/.test(req.path)) {
        return false;
    }
    return true;
}
function sendLimitError(req, res, error) {
    res.setHeader('Retry-After', '5');
    const pathname = req.originalUrl ?? req.url ?? '';
    if (pathname.startsWith('/v1beta/')) {
        res.status(503).json({
            error: {
                code: 503,
                message: error.message,
                status: 'UNAVAILABLE',
            },
        });
        return;
    }
    res.status(503).json({
        error: {
            message: error.message,
            type: error.code,
            codex_group_id: error.groupId,
        },
    });
}
function sendIdentityError(req, res) {
    const message = 'Codex consumer identity is incomplete.';
    const pathname = req.originalUrl ?? req.url ?? '';
    if (pathname.startsWith('/v1beta/')) {
        res.status(500).json({
            error: {
                code: 500,
                message,
                status: 'INTERNAL',
            },
        });
        return;
    }
    res.status(500).json({
        error: {
            message,
            type: 'codex_consumer_identity_missing',
        },
    });
}
/** Hold one per-user group slot for the full HTTP response, including streaming. */
export async function codexGroupConcurrency(req, res, next) {
    const context = getClientContext();
    if (!isInferenceRequest(req)
        || context.consumerApiKeyType !== 'codex_pool') {
        next();
        return;
    }
    if (context.consumerCodexGroupId === null || context.consumerUserId === null) {
        sendIdentityError(req, res);
        return;
    }
    const group = getDb().prepare(`
    SELECT max_concurrency AS maxConcurrency
    FROM codex_groups
    WHERE id = ? AND enabled = 1
    LIMIT 1
  `).get(context.consumerCodexGroupId);
    if (!group || group.maxConcurrency === null) {
        next();
        return;
    }
    const controller = new AbortController();
    const abort = () => controller.abort();
    req.once('aborted', abort);
    res.once('close', abort);
    if (req.aborted || res.destroyed)
        abort();
    try {
        const release = await acquireCodexGroupSlot(context.consumerCodexGroupId, context.consumerUserId, group.maxConcurrency, controller.signal);
        if (controller.signal.aborted || res.destroyed) {
            release();
            return;
        }
        let released = false;
        const cleanup = () => {
            if (released)
                return;
            released = true;
            req.off('aborted', abort);
            res.off('close', abort);
            release();
        };
        res.once('finish', cleanup);
        res.once('close', cleanup);
        next();
    }
    catch (error) {
        req.off('aborted', abort);
        res.off('close', abort);
        if (controller.signal.aborted)
            return;
        if (error instanceof CodexGroupConcurrencyError) {
            sendLimitError(req, res, error);
            return;
        }
        next(error);
    }
}
//# sourceMappingURL=codexGroupConcurrency.js.map