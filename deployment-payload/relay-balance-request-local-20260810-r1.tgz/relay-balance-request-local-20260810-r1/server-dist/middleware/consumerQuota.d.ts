import type { NextFunction, Request, Response } from 'express';
/**
 * Prepaid consumer billing gate.
 *
 * Only tuoke-* consumer API keys are affected.
 *
 * Global/admin unified API keys bypass wallet billing.
 */
export declare function consumerQuota(req: Request, res: Response, next: NextFunction): void;
//# sourceMappingURL=consumerQuota.d.ts.map