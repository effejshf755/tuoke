type DeviceSessionStatus = 'pending' | 'complete' | 'failed';
export declare function startCodexDeviceAuthorization(): Promise<{
    loginId: string;
    verificationUrl: string;
    userCode: string;
    expiresInSeconds: number;
}>;
export declare function getCodexDeviceAuthorization(loginId: string): {
    status: DeviceSessionStatus;
    imported: number;
    account_id: string | null;
    models: string[];
    model_discovery_error: string | null;
    error: string | null;
} | null;
export {};
//# sourceMappingURL=codex-device-auth.d.ts.map