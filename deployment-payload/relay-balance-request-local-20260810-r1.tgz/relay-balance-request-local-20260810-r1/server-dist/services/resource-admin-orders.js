import { recordResourceAdminAudit } from './resource-admin-audit.js';
import { refundResourcePurchaseAsAdmin } from './resource-purchase.js';
export const ADMIN_RESOURCE_ORDER_STATUSES = [
    'pending_payment', 'paid_waiting_group', 'grouped', 'active', 'refunded',
];
export function listAdminResourceOrders(db, status) {
    return db.prepare(`SELECT o.id, o.order_no orderNo, o.order_status status,
    o.user_id userId, u.email userEmail,
    o.product_id productId, o.product_key productKey, o.product_version productVersion,
    o.product_name_snapshot productName, o.price_micro priceMicro,
    o.subpool_id subpoolId, s.status subpoolStatus,
    o.member_limit_snapshot memberLimit,
    COALESCE((SELECT COUNT(*) FROM resource_subpool_members count_member
      WHERE count_member.subpool_id = o.subpool_id), 0) memberCount,
    o.payment_method paymentMethod, o.paid_amount_micro paidAmountMicro,
    o.paid_at paidAt, o.refundable_until refundableUntil,
    o.refund_amount_micro refundAmountMicro, o.refund_reason refundReason,
    o.refund_requested_at refundRequestedAt, o.refunded_at refundedAt,
    o.created_at createdAt, o.updated_at updatedAt
    FROM resource_orders o
    JOIN users u ON u.id = o.user_id
    LEFT JOIN resource_subpools s ON s.id = o.subpool_id
    WHERE (? IS NULL OR o.order_status = ?)
    ORDER BY o.id DESC`).all(status ?? null, status ?? null);
}
export function getAdminResourceOrderDetail(db, orderId) {
    const order = db.prepare(`SELECT o.*, u.email userEmail, u.role userRole,
    u.status userStatus, u.balance_micro userBalanceMicro,
    s.name subpoolName, s.status subpoolStatus, s.member_limit subpoolMemberLimit,
    s.starts_at subpoolStartsAt, s.ends_at subpoolEndsAt,
    s.frozen_total_quota_units frozenTotalQuotaUnits,
    s.frozen_member_quota_units frozenMemberQuotaUnits,
    s.frozen_meter_version frozenMeterVersion
    FROM resource_orders o
    JOIN users u ON u.id = o.user_id
    LEFT JOIN resource_subpools s ON s.id = o.subpool_id
    WHERE o.id = ?`).get(orderId);
    if (!order)
        return null;
    const members = db.prepare(`SELECT m.id, m.user_id userId, u.email, m.status,
    m.resource_order_id resourceOrderId, m.consumer_api_key_id consumerApiKeyId,
    q.id memberQuotaId, q.allocation_units allocationUnits,
    q.used_units usedUnits, q.reserved_units reservedUnits, q.status quotaStatus,
    period.id quotaPeriodId, period.status quotaPeriodStatus, period.resets_at quotaResetsAt
    FROM resource_subpool_members m
    JOIN users u ON u.id = m.user_id
    LEFT JOIN resource_subpool_quota_periods period
      ON period.subpool_id = m.subpool_id AND period.status = 'active'
    LEFT JOIN resource_member_quotas q
      ON q.member_id = m.id AND q.subpool_period_id = period.id
    WHERE m.subpool_id = (SELECT subpool_id FROM resource_orders WHERE id = ?)
    ORDER BY m.id`).all(orderId);
    return { order, members };
}
export function adminRefundResourceOrder(db, input) {
    return db.transaction(() => {
        const order = db.prepare(`SELECT id, user_id userId, order_status status,
      paid_at paidAt FROM resource_orders WHERE id = ?`).get(input.orderId);
        if (!order)
            throw new Error('Resource order was not found');
        if (order.status === 'refunded') {
            return refundResourcePurchaseAsAdmin(db, { userId: order.userId, orderId: order.id });
        }
        if (order.status !== 'paid_waiting_group') {
            throw new Error('Only a paid_waiting_group order can be refunded');
        }
        const usage = db.prepare(`SELECT 1
      FROM resource_subpool_members m
      LEFT JOIN resource_member_quotas q ON q.member_id = m.id
      LEFT JOIN resource_quota_reservations reservation ON reservation.member_quota_id = q.id
      LEFT JOIN requests request_log ON request_log.consumer_api_key_id = m.consumer_api_key_id
        AND datetime(request_log.created_at) >= datetime(COALESCE(?, m.joined_at))
      WHERE m.resource_order_id = ?
        AND (reservation.id IS NOT NULL OR request_log.id IS NOT NULL)
      LIMIT 1`).get(order.paidAt, order.id);
        if (usage)
            throw new Error('Resource order has usage records and cannot be refunded');
        const result = refundResourcePurchaseAsAdmin(db, { userId: order.userId, orderId: order.id });
        if (!result.alreadyProcessed) {
            recordResourceAdminAudit(db, {
                adminUserId: input.adminId,
                action: 'resource_order_refunded',
                targetType: 'resource_order',
                targetId: order.id,
                details: { userId: order.userId, refundedMicro: result.refundedMicro },
            });
        }
        return result;
    })();
}
export function adminCancelResourceSubpool(db, input) {
    return db.transaction(() => {
        const pool = db.prepare(`SELECT id, status FROM resource_subpools WHERE id = ?`).get(input.subpoolId);
        if (!pool)
            throw new Error('Resource subpool was not found');
        if (!['waiting_members', 'waiting_resource'].includes(pool.status)) {
            throw new Error('Only a non-activated subpool can be cancelled');
        }
        const orders = db.prepare(`SELECT o.id, o.order_no orderNo, o.user_id userId,
      o.order_status status, o.paid_amount_micro paidAmountMicro
      FROM resource_orders o
      JOIN resource_subpool_members m
        ON m.resource_order_id = o.id AND m.subpool_id = o.subpool_id
      WHERE o.subpool_id = ? AND m.status IN ('waiting', 'active')
      ORDER BY o.id`).all(input.subpoolId);
        if (!orders.length || orders.some((order) => !['paid_waiting_group', 'grouped'].includes(order.status))) {
            throw new Error('Subpool contains an order that cannot be refunded');
        }
        const usage = db.prepare(`SELECT 1
      FROM resource_subpool_members m
      LEFT JOIN resource_member_quotas q ON q.member_id = m.id
      LEFT JOIN resource_quota_reservations reservation ON reservation.member_quota_id = q.id
      LEFT JOIN requests request_log ON request_log.consumer_api_key_id = m.consumer_api_key_id
        AND datetime(request_log.created_at) >= datetime(m.joined_at)
      WHERE m.subpool_id = ?
        AND (reservation.id IS NOT NULL OR request_log.id IS NOT NULL)
      LIMIT 1`).get(input.subpoolId);
        if (usage)
            throw new Error('Resource subpool has usage records and cannot be cancelled');
        let refundedMicro = 0;
        for (const order of orders) {
            const purchase = db.prepare(`SELECT ABS(delta_micro) amount FROM wallet_transactions
        WHERE resource_order_id = ? AND type = 'purchase'`).get(order.id);
            const amount = order.paidAmountMicro ?? purchase?.amount ?? 0;
            if (!purchase || amount <= 0)
                throw new Error(`Original wallet purchase transaction was not found for order ${order.orderNo}`);
            const wallet = db.prepare(`SELECT balance_micro balanceMicro FROM users WHERE id = ?`).get(order.userId);
            if (!wallet || !Number.isSafeInteger(wallet.balanceMicro + amount))
                throw new Error('Wallet refund amount is invalid');
            const balanceAfter = wallet.balanceMicro + amount;
            db.prepare(`UPDATE users SET balance_micro = ? WHERE id = ?`).run(balanceAfter, order.userId);
            db.prepare(`INSERT INTO wallet_transactions
        (user_id, type, delta_micro, balance_after_micro, resource_order_id, note)
        VALUES (?, 'purchase_refund', ?, ?, ?, ?)`).run(order.userId, amount, balanceAfter, order.id, `Resource purchase refund ${order.orderNo}: administrator cancelled subpool ${input.subpoolId}`);
            const updated = db.prepare(`UPDATE resource_orders SET order_status = 'refunded',
        refund_amount_micro = ?, refund_reason = 'administrator cancelled subpool',
        refund_requested_at = datetime('now'), refunded_at = datetime('now'), updated_at = datetime('now')
        WHERE id = ? AND order_status IN ('paid_waiting_group', 'grouped')`).run(amount, order.id);
            if (updated.changes !== 1)
                throw new Error('Order state changed during subpool cancellation');
            refundedMicro += amount;
        }
        db.prepare(`DELETE FROM resource_subpool_members WHERE subpool_id = ?`).run(input.subpoolId);
        const expired = db.prepare(`UPDATE resource_subpools
      SET status = 'expired', pending_codex_account_id = NULL, updated_at = datetime('now')
      WHERE id = ? AND status IN ('waiting_members', 'waiting_resource')`).run(input.subpoolId);
        if (expired.changes !== 1)
            throw new Error('Subpool state changed during cancellation');
        recordResourceAdminAudit(db, {
            adminUserId: input.adminId,
            action: 'resource_subpool_cancelled_and_refunded',
            targetType: 'resource_subpool',
            targetId: input.subpoolId,
            subpoolId: input.subpoolId,
            details: { orderIds: orders.map((order) => order.id), orderCount: orders.length, refundedMicro },
        });
        return { subpoolId: input.subpoolId, orderCount: orders.length, refundedMicro };
    })();
}
export function adminDeleteRefundedResourceOrders(db, input) {
    const orderIds = [...new Set(input.orderIds.map(Number))];
    if (!orderIds.length || orderIds.some((id) => !Number.isSafeInteger(id) || id <= 0)) {
        throw new Error('At least one valid resource order id is required');
    }
    return db.transaction(() => {
        const placeholders = orderIds.map(() => '?').join(', ');
        const orders = db.prepare(`SELECT id, order_no orderNo, order_status status
      FROM resource_orders WHERE id IN (${placeholders}) ORDER BY id`).all(...orderIds);
        if (orders.length !== orderIds.length)
            throw new Error('Resource order was not found');
        if (orders.some((order) => order.status !== 'refunded'))
            throw new Error('Only refunded resource orders can be deleted');
        const member = db.prepare(`SELECT resource_order_id orderId FROM resource_subpool_members
      WHERE resource_order_id IN (${placeholders}) LIMIT 1`).get(...orderIds);
        if (member)
            throw new Error(`Resource order ${member.orderId} is still linked to a subpool member`);
        // Wallet rows remain as immutable financial history; their order FK becomes NULL.
        const deleted = db.prepare(`DELETE FROM resource_orders WHERE id IN (${placeholders})
      AND order_status = 'refunded'`).run(...orderIds);
        if (deleted.changes !== orderIds.length)
            throw new Error('Resource order state changed during deletion');
        recordResourceAdminAudit(db, {
            adminUserId: input.adminId, action: 'resource_orders_deleted', targetType: 'resource_order',
            targetId: orderIds.length === 1 ? orderIds[0] : null, details: { orders },
        });
        return { deletedCount: deleted.changes, orderIds };
    })();
}
export function adminDeleteResourceSubpool(db, input) {
    return db.transaction(() => {
        const pool = db.prepare(`SELECT id, name, status FROM resource_subpools WHERE id = ?`).get(input.subpoolId);
        if (!pool)
            throw new Error('Resource subpool was not found');
        if (pool.status === 'active')
            throw new Error('Running resource subpools cannot be deleted');
        // Dispatches restrict reservation deletion, so remove them before member quotas cascade.
        db.prepare(`DELETE FROM resource_dispatches WHERE subpool_id = ?`).run(pool.id);
        db.prepare(`DELETE FROM resource_subpool_members WHERE subpool_id = ?`).run(pool.id);
        db.prepare(`UPDATE resource_orders SET subpool_id = NULL WHERE subpool_id = ?`).run(pool.id);
        const deleted = db.prepare(`DELETE FROM resource_subpools WHERE id = ? AND status <> 'active'`).run(pool.id);
        if (deleted.changes !== 1)
            throw new Error('Resource subpool state changed during deletion');
        recordResourceAdminAudit(db, {
            adminUserId: input.adminId, action: 'resource_subpool_deleted', targetType: 'resource_subpool',
            targetId: pool.id, details: { name: pool.name, previousStatus: pool.status },
        });
        return { subpoolId: pool.id, deleted: true };
    })();
}
//# sourceMappingURL=resource-admin-orders.js.map