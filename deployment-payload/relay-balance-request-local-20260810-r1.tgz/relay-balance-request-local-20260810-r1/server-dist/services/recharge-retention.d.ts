import type { Scheduler } from '../lib/scheduler.js';
export declare function cleanupOldRechargeOrders(): number;
export declare function startRechargeOrderCleanup(scheduler: Scheduler): void;
//# sourceMappingURL=recharge-retention.d.ts.map