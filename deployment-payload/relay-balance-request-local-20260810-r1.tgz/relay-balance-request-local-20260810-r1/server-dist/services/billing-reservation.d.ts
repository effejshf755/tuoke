import type { Db } from '../db/types.js';
export interface BillingReservationEstimate {
    status: 'ok' | 'no_billing_rule';
    requestedModel: string | null;
    estimatedInputTokens: number;
    maximumOutputTokens: number;
    reserveMicro: number;
    matchedRuleCount: number;
}
/**
 * Calculates a conservative prepaid authorization
 * amount before an upstream model is called.
 *
 * For auto-routing, the highest possible configured
 * model cost is used.
 */
export declare function estimateBillingReservation(db: Db, body: unknown): BillingReservationEstimate;
//# sourceMappingURL=billing-reservation.d.ts.map