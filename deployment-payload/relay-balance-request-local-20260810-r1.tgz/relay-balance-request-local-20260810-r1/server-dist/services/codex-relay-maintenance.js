import { checkCodexRelaySourceHealth, } from './codex-relay-sources.js';
// Relay probing is opt-in. Normal traffic is the source of truth; a background
// synthetic request must not spend upstream quota or change dispatch behavior.
const DEFAULT_HEALTH_INTERVAL_MS = 0;
const DEFAULT_HEALTH_BOOT_DELAY_MS = 45 * 1_000;
const DEFAULT_HEALTH_CONCURRENCY = 2;
const MAX_SOURCES_PER_PASS = 50;
export function resetCodexRelayOperationalStats(db, sourceId, nowMs = Date.now()) {
    const statisticsStartedAt = new Date(nowMs).toISOString();
    const reset = db.transaction(() => {
        const source = db.prepare(`
      UPDATE codex_relay_sources
      SET statistics_started_at = ?,
          statistics_reset_after_request_id = COALESCE((
            SELECT MAX(request.id)
            FROM requests request
            WHERE request.codex_relay_source_id = codex_relay_sources.id
          ), 0),
          updated_at = datetime('now')
      WHERE id = ?
    `).run(statisticsStartedAt, sourceId);
        if (source.changes !== 1)
            return false;
        db.prepare(`
      INSERT INTO codex_relay_source_statistics (
        source_id, request_count, success_count, failure_count, partial_count,
        input_tokens, cached_input_tokens, cache_write_tokens, output_tokens,
        billed_micro, latency_total_ms, last_request_at, updated_at
      ) VALUES (?, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, NULL, datetime('now'))
      ON CONFLICT(source_id) DO UPDATE SET
        request_count = 0,
        success_count = 0,
        failure_count = 0,
        partial_count = 0,
        input_tokens = 0,
        cached_input_tokens = 0,
        cache_write_tokens = 0,
        output_tokens = 0,
        billed_micro = 0,
        latency_total_ms = 0,
        last_request_at = NULL,
        updated_at = datetime('now')
    `).run(sourceId);
        return true;
    })();
    if (!reset)
        return null;
    return getCodexRelayOperationalStats(db, null).sources.find((source) => source.sourceId === sourceId) ?? null;
}
function boundedInteger(raw, fallback, min, max) {
    if (raw === undefined || raw.trim() === '')
        return fallback;
    const parsed = Number(raw);
    if (!Number.isFinite(parsed))
        return fallback;
    return Math.min(max, Math.max(min, Math.floor(parsed)));
}
export function codexRelayHealthIntervalMs() {
    return boundedInteger(process.env.CODEX_RELAY_HEALTH_INTERVAL_MS, DEFAULT_HEALTH_INTERVAL_MS, 0, 24 * 60 * 60 * 1_000);
}
export function codexRelayHealthBootDelayMs() {
    return boundedInteger(process.env.CODEX_RELAY_HEALTH_BOOT_DELAY_MS, DEFAULT_HEALTH_BOOT_DELAY_MS, 0, 60 * 60 * 1_000);
}
export function codexRelayHealthConcurrency() {
    return boundedInteger(process.env.CODEX_RELAY_HEALTH_CONCURRENCY, DEFAULT_HEALTH_CONCURRENCY, 1, 8);
}
function sqliteUtcTimestampMs(value) {
    if (!value)
        return null;
    const parsed = Date.parse(`${value.replace(' ', 'T')}Z`);
    return Number.isFinite(parsed) ? parsed : null;
}
export function listDueCodexRelaySourceIds(db, options = {}) {
    const nowMs = options.nowMs ?? Date.now();
    const intervalMs = options.intervalMs ?? codexRelayHealthIntervalMs();
    const limit = Math.min(MAX_SOURCES_PER_PASS, Math.max(1, options.limit ?? MAX_SOURCES_PER_PASS));
    const rows = db.prepare(`
    SELECT s.id, s.last_checked_at
    FROM codex_relay_sources s
    WHERE s.enabled = 1
      AND EXISTS (
        SELECT 1
        FROM codex_relay_source_keys source_key
        JOIN api_keys source_api_key
         ON source_api_key.id = source_key.api_key_id
         AND source_api_key.role = 'codex_relay'
         AND source_api_key.platform = 'custom'
         AND source_api_key.enabled = 1
        WHERE source_key.source_id = s.id
          AND source_key.enabled = 1
      )
    ORDER BY
      CASE WHEN s.last_checked_at IS NULL THEN 0 ELSE 1 END,
      s.last_checked_at ASC,
      s.priority ASC,
      s.id ASC
  `).all();
    return rows
        .filter((row) => {
        const checkedAt = sqliteUtcTimestampMs(row.last_checked_at);
        return checkedAt === null || nowMs - checkedAt >= intervalMs;
    })
        .slice(0, limit)
        .map((row) => Number(row.id));
}
export async function checkDueCodexRelaySources(db, options = {}) {
    const ids = listDueCodexRelaySourceIds(db, options);
    const concurrency = Math.min(8, Math.max(1, options.concurrency ?? codexRelayHealthConcurrency()));
    const probe = options.probe ?? checkCodexRelaySourceHealth;
    const result = {
        checked: 0,
        healthy: 0,
        unhealthy: 0,
        errors: 0,
    };
    let cursor = 0;
    const worker = async () => {
        while (cursor < ids.length) {
            const id = ids[cursor];
            cursor += 1;
            try {
                const health = await probe(db, id);
                result.checked += 1;
                if (health.source.status === 'healthy')
                    result.healthy += 1;
                else
                    result.unhealthy += 1;
            }
            catch {
                result.checked += 1;
                result.errors += 1;
            }
        }
    };
    await Promise.all(Array.from({ length: Math.min(concurrency, Math.max(ids.length, 1)) }, () => worker()));
    return result;
}
let scheduledPass = null;
export function startCodexRelayHealthScheduler(db, scheduler) {
    const intervalMs = codexRelayHealthIntervalMs();
    if (intervalMs === 0) {
        console.log('[codex-relay-health] automatic checks disabled');
        return null;
    }
    const run = () => {
        if (scheduledPass)
            return scheduledPass;
        scheduledPass = checkDueCodexRelaySources(db, { intervalMs })
            .then((result) => {
            if (result.checked > 0) {
                console.log(`[codex-relay-health] checked=${result.checked} ` +
                    `healthy=${result.healthy} unhealthy=${result.unhealthy} errors=${result.errors}`);
            }
            return result;
        })
            .catch((error) => {
            console.error('[codex-relay-health] pass failed:', error instanceof Error ? error.message : error);
            return { checked: 0, healthy: 0, unhealthy: 0, errors: 1 };
        })
            .finally(() => {
            scheduledPass = null;
        });
        return scheduledPass;
    };
    const scheduledRun = async () => {
        await run();
    };
    const cancelBoot = scheduler.after(codexRelayHealthBootDelayMs(), scheduledRun);
    const cancelInterval = scheduler.every(intervalMs, scheduledRun, {
        name: 'codex-relay-health',
    });
    return () => {
        cancelBoot();
        cancelInterval();
    };
}
function safeNumber(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
}
export function getCodexRelayOperationalStats(db, requestedWindowHours = null) {
    const windowHours = requestedWindowHours === null
        ? null
        : Math.min(24 * 365, Math.max(1, Math.floor(requestedWindowHours)));
    const rows = (windowHours === null
        ? db.prepare(`
        SELECT
          s.id AS source_id,
          s.name AS source_name,
          s.statistics_started_at,
          COALESCE(t.request_count, 0) AS request_count,
          COALESCE(t.success_count, 0) AS success_count,
          COALESCE(t.failure_count, 0) AS failure_count,
          COALESCE(t.partial_count, 0) AS partial_count,
          COALESCE(t.input_tokens, 0) AS input_tokens,
          COALESCE(t.cached_input_tokens, 0) AS cached_input_tokens,
          COALESCE(t.cache_write_tokens, 0) AS cache_write_tokens,
          COALESCE(t.output_tokens, 0) AS output_tokens,
          COALESCE(t.billed_micro, 0) AS billed_micro,
          CASE WHEN COALESCE(t.request_count, 0) > 0
            THEN ROUND(CAST(t.latency_total_ms AS REAL) / t.request_count)
            ELSE 0
          END AS average_latency_ms,
          t.last_request_at
        FROM codex_relay_sources s
        LEFT JOIN codex_relay_source_statistics t ON t.source_id = s.id
        ORDER BY s.priority ASC, s.id ASC
      `).all()
        : db.prepare(`
    SELECT
      s.id AS source_id,
      s.name AS source_name,
      s.statistics_started_at,
      COUNT(r.id) AS request_count,
      SUM(CASE WHEN r.status = 'success' THEN 1 ELSE 0 END) AS success_count,
      SUM(CASE WHEN r.status = 'error' THEN 1 ELSE 0 END) AS failure_count,
      SUM(CASE WHEN r.status = 'partial' THEN 1 ELSE 0 END) AS partial_count,
      COALESCE(SUM(CASE
        WHEN r.upstream_usage_confirmed = 1 THEN r.input_tokens ELSE 0
      END), 0) AS input_tokens,
      COALESCE(SUM(CASE
        WHEN r.upstream_usage_confirmed = 1 THEN r.cached_input_tokens ELSE 0
      END), 0) AS cached_input_tokens,
      COALESCE(SUM(CASE
        WHEN r.upstream_usage_confirmed = 1 THEN r.cache_write_tokens ELSE 0
      END), 0) AS cache_write_tokens,
      COALESCE(SUM(CASE
        WHEN r.upstream_usage_confirmed = 1 THEN r.output_tokens ELSE 0
      END), 0) AS output_tokens,
      COALESCE(SUM(CASE
        WHEN r.billing_status = 'charged' THEN r.billing_amount_micro
        ELSE 0
      END), 0) AS billed_micro,
      COALESCE(ROUND(AVG(r.latency_ms)), 0) AS average_latency_ms,
      MAX(r.created_at) AS last_request_at
    FROM codex_relay_sources s
    LEFT JOIN requests r
      ON r.codex_relay_source_id = s.id
     AND r.platform = 'openai-codex'
     AND s.statistics_started_at IS NOT NULL
     AND datetime(r.created_at) >= datetime(s.statistics_started_at)
     AND r.id > COALESCE(s.statistics_reset_after_request_id, 0)
     AND datetime(r.created_at) >= datetime('now', ?)
    GROUP BY s.id, s.name
    ORDER BY s.priority ASC, s.id ASC
  `).all(`-${windowHours} hours`));
    const sources = rows.map((row) => ({
        sourceId: safeNumber(row.source_id),
        sourceName: String(row.source_name ?? ''),
        statisticsStartedAt: typeof row.statistics_started_at === 'string'
            ? row.statistics_started_at
            : null,
        requests: safeNumber(row.request_count),
        successfulRequests: safeNumber(row.success_count),
        failedRequests: safeNumber(row.failure_count),
        partialRequests: safeNumber(row.partial_count),
        inputTokens: safeNumber(row.input_tokens),
        cachedInputTokens: safeNumber(row.cached_input_tokens),
        cacheWriteTokens: safeNumber(row.cache_write_tokens),
        outputTokens: safeNumber(row.output_tokens),
        billedMicro: safeNumber(row.billed_micro),
        averageLatencyMs: safeNumber(row.average_latency_ms),
        lastRequestAt: typeof row.last_request_at === 'string'
            ? row.last_request_at
            : null,
    }));
    return sources.reduce((summary, source) => {
        summary.requests += source.requests;
        summary.successfulRequests += source.successfulRequests;
        summary.failedRequests += source.failedRequests;
        summary.partialRequests += source.partialRequests;
        summary.inputTokens += source.inputTokens;
        summary.cachedInputTokens += source.cachedInputTokens;
        summary.cacheWriteTokens += source.cacheWriteTokens;
        summary.outputTokens += source.outputTokens;
        summary.billedMicro += source.billedMicro;
        return summary;
    }, {
        scope: windowHours === null ? 'lifetime' : 'window',
        windowHours,
        requests: 0,
        successfulRequests: 0,
        failedRequests: 0,
        partialRequests: 0,
        inputTokens: 0,
        cachedInputTokens: 0,
        cacheWriteTokens: 0,
        outputTokens: 0,
        billedMicro: 0,
        sources,
    });
}
//# sourceMappingURL=codex-relay-maintenance.js.map