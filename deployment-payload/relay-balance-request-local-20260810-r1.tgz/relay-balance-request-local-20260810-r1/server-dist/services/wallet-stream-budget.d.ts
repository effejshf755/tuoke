import type { Db } from '../db/types.js';
export declare const WALLET_SAFETY_STOP_MESSAGE = "Available balance reached the 0.10 yuan safety limit. The active request was stopped; please recharge to continue.";
export declare class WalletSafetyBalanceReachedError extends Error {
    readonly code = "wallet_safety_balance_reached";
    readonly status = 402;
    readonly skipBench = true;
    readonly projectedChargeMicro: number;
    readonly availableMicro: number;
    constructor(projectedChargeMicro: number, availableMicro: number);
}
export declare function isWalletSafetyBalanceReachedError(error: unknown): error is WalletSafetyBalanceReachedError;
export interface WalletStreamUsageSnapshot {
    platform: string;
    modelId: string;
    inputTokens: number;
    outputTokens: number;
    cachedInputTokens?: number;
    cacheWriteTokens?: number;
}
/**
 * Stop a paid consumer stream before its projected observed charge consumes
 * the final 0.10 yuan of combined promotion credit and permanent wallet.
 * Operator calls, free requests, and prepaid resource-subpool requests have no
 * wallet reservation and bypass this guard.
 */
export declare function assertWalletStreamBudget(db: Db, usage: WalletStreamUsageSnapshot): void;
//# sourceMappingURL=wallet-stream-budget.d.ts.map