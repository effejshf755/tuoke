import type { Db } from '../db/types.js';
export type ResourceAlertSeverity = 'warning' | 'critical';
export declare function raiseResourceAlert(db: Db, input: {
    severity: ResourceAlertSeverity;
    alertType: string;
    sourceType: string;
    sourceId: string | number;
    subpoolId?: number | null;
    message: string;
    details?: Record<string, unknown>;
}): number;
export declare function listResourceAlerts(db: Db, status?: 'open' | 'resolved', limit?: number): unknown[];
export declare function resolveResourceAlert(db: Db, alertId: number, adminId: number): boolean;
//# sourceMappingURL=resource-alerts.d.ts.map