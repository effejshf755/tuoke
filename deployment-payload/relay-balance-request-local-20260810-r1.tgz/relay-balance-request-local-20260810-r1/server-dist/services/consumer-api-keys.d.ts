import type { Db } from '../db/types.js';
export type ConsumerApiKeyType = 'universal' | 'codex_pool' | 'resource_subpool';
export interface ConsumerApiKey {
    id: number;
    userId: number;
    name: string;
    keyPrefix: string;
    keyType: ConsumerApiKeyType;
    codexGroupId: number | null;
    codexGroupName: string | null;
    status: 'active' | 'revoked';
    enabled: 0 | 1;
    createdAt: string;
    lastUsedAt: string | null;
    expiresAt: string | null;
    rateLimitRpm: number | null;
    requestCount: number;
    inputTokens: number;
    outputTokens: number;
    totalTokens: number;
}
export interface CreatedConsumerApiKey {
    key: string;
    record: ConsumerApiKey;
}
export type ConsumerApiKeySecretResult = {
    status: 'ok';
    key: string;
} | {
    status: 'not_found';
} | {
    status: 'not_recoverable';
};
/**
 * 用户本月 Token 使用量
 */
export declare function getConsumerMonthlyUsage(db: Db, userId: number): {
    usedTokens: number;
    limit: number;
};
/**
 * 获取用户全部 API Key
 *
 * 同时返回每把 Key 的累计统计：
 * - 请求次数
 * - Input Tokens
 * - Output Tokens
 * - Total Tokens
 */
export declare function listConsumerApiKeys(db: Db, userId: number): ConsumerApiKey[];
/**
 * 创建新的 Tuoke API Key
 *
 * expiresAt:
 * - null = 永久
 * - ISO 时间 = 到期时间
 */
export declare function createConsumerApiKey(db: Db, userId: number, name: string, expiresAt?: string | null, keyType?: ConsumerApiKeyType, codexGroupId?: number | null): CreatedConsumerApiKey;
export declare function getConsumerApiKeySecret(db: Db, id: number, userId: number): ConsumerApiKeySecretResult;
/**
 * 验证消费者 API Key
 *
 * 必须同时满足：
 *
 * status = active
 * enabled = 1
 * 用户账号 active
 * 未过期
 */
export declare function validateConsumerApiKey(db: Db, key: string): ConsumerApiKey | null;
/**
 * 暂停 / 恢复 API Key
 */
export declare function setConsumerApiKeyEnabled(db: Db, id: number, userId: number, enabled: boolean): boolean;
/**
 * 永久撤销 API Key
 *
 * 撤销后不能再次恢复。
 */
export declare function revokeConsumerApiKey(db: Db, id: number, userId?: number): boolean;
//# sourceMappingURL=consumer-api-keys.d.ts.map