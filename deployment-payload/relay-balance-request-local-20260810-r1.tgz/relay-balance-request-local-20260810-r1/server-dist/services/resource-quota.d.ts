import type { Db } from '../db/types.js';
export type ResourceQuotaErrorCode = 'resource_entitlement_required' | 'resource_subpool_inactive' | 'resource_quota_exhausted' | 'resource_official_quota_protected';
export declare class ResourceQuotaError extends Error {
    readonly code: ResourceQuotaErrorCode;
    constructor(code: ResourceQuotaErrorCode, message: string);
}
export interface ResourceQuotaEstimate {
    modelId: string;
    inputTokens: number;
    outputTokens: number;
    inputMultiplierMicros: number;
    cachedInputMultiplierMicros?: number;
    cacheWriteMultiplierMicros?: number;
    outputMultiplierMicros: number;
    units: number;
}
export declare const RESOURCE_TOKENS_PER_POINT = 1500;
export declare function calculateResourcePoints(inputTokens: number, outputTokens: number, inputMultiplierMicros: number, outputMultiplierMicros: number, cachedInputTokens?: number, cachedInputMultiplierMicros?: number, cacheWriteTokens?: number, cacheWriteMultiplierMicros?: number): number;
export declare function estimateCodexQuotaUnits(db: Db, body: unknown): ResourceQuotaEstimate;
export declare function reserveSubpoolQuota(db: Db, userId: number, consumerApiKeyId: number, estimateOrUnits: ResourceQuotaEstimate | number): {
    reservationId: number;
    requestCorrelationId: `${string}-${string}-${string}-${string}-${string}`;
    subpoolId: number;
    memberId: number;
    mode: "scheduled" | "dedicated";
    reservedUnits: number;
};
export type ResourceSettlementStatus = 'failed_before_usage' | 'partial' | 'success';
export declare function finalizeSubpoolQuota(db: Db, reservationId: number, requestId: number | null, usageOrUnits: {
    inputTokens: number;
    cachedInputTokens?: number;
    cacheWriteTokens?: number;
    outputTokens: number;
} | number | null, settlementStatus: ResourceSettlementStatus): {
    status: "already_finalized";
    settlementStatus?: undefined;
} | {
    status: string;
    settlementStatus: ResourceSettlementStatus;
};
export declare function releaseSubpoolQuota(db: Db, reservationId: number): {
    status: "already_finalized";
    settlementStatus?: undefined;
} | {
    status: string;
    settlementStatus: ResourceSettlementStatus;
};
//# sourceMappingURL=resource-quota.d.ts.map