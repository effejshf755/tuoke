export declare const CODEX_CAPACITY_FAILURE_THRESHOLD = 3;
export declare const CODEX_CAPACITY_FAILURE_WINDOW_MS = 60000;
export declare const CODEX_CIRCUIT_INITIAL_OPEN_MS = 30000;
export declare const CODEX_CIRCUIT_MAX_OPEN_MS = 300000;
interface CircuitState {
    failureTimes: number[];
    openUntil: number;
    openLevel: number;
    probeInFlight: boolean;
}
export interface CodexCircuitPermit {
    readonly modelId: string;
    readonly scope: string;
    readonly probe: boolean;
}
export type CodexCircuitGate = {
    allowed: true;
    permit: CodexCircuitPermit;
} | {
    allowed: false;
    retryAfterMs: number;
};
export interface CodexCapacityFailureResult {
    opened: boolean;
    retryAfterMs: number;
}
export declare function isCodexCapacityError(err: unknown): boolean;
/**
 * Checks the cross-request circuit before dispatch. Once an open interval has
 * elapsed, exactly one caller receives a half-open probe permit.
 */
export declare function beginCodexModelRequest(modelId: string, now?: number, scope?: string): CodexCircuitGate;
/** Records only the two known Codex upstream capacity failures. */
export declare function recordCodexCapacityFailure(permit: CodexCircuitPermit, now?: number): CodexCapacityFailureResult;
export declare function recordCodexModelSuccess(permit: CodexCircuitPermit): void;
export declare function releaseCodexModelProbe(permit: CodexCircuitPermit): void;
export declare function resetCodexModelCircuits(): void;
export declare function getCodexModelCircuitState(modelId: string, scope?: string): Readonly<CircuitState> | null;
export {};
//# sourceMappingURL=codex-model-circuit-breaker.d.ts.map