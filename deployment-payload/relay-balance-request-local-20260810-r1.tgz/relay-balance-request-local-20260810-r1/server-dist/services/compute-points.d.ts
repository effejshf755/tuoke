import type { Db } from "../db/types.js";
export declare const DEFAULT_POINTS_PER_MILLION_TOKENS = 1000000;
export declare const MAX_POINTS_PER_MILLION_TOKENS = 1000000000;
export declare function currentPointsPerMillionTokens(db: Db, userId?: number | null): number;
/** Convert one raw token bucket using a request-scoped points rate. */
export declare function tokensToComputePoints(tokens: number, pointsPerMillion: number): number;
export declare function snapshotComputePoints(db: Db, tokens: number, userId?: number | null, pointsPerMillionOverride?: number | null): {
    points: number;
    pointsPerMillion: number;
};
//# sourceMappingURL=compute-points.d.ts.map