import type { Db } from '../db/types.js';
export type CodexRelayPromptCacheStatus = 'compatible' | 'partial' | 'incompatible';
export type CodexRelayPromptCacheRoundTransport = 'json' | 'sse';
export type CodexRelayPromptCacheRoundStatus = 'passed' | 'failed';
export interface CodexRelayPromptCacheUsage {
    input_tokens: number;
    output_tokens: number;
    total_tokens: number;
    cached_tokens: number;
    cache_write_tokens: number;
}
export interface CodexRelayPromptCacheRound {
    round: 1 | 2 | 3 | 4 | 5;
    transport: CodexRelayPromptCacheRoundTransport;
    status: CodexRelayPromptCacheRoundStatus;
    latency_ms: number;
    message: string;
    usage?: CodexRelayPromptCacheUsage;
}
export interface CodexRelayPromptCacheReport {
    version: 1;
    protocol: 'responses';
    source_id: number;
    public_model_id: string;
    upstream_model_id: string;
    started_at: string;
    completed_at: string;
    overall_status: CodexRelayPromptCacheStatus;
    requests_sent: number;
    cold_write_tokens: number | null;
    warm_hit_count: number;
    total_warm_cached_tokens: number;
    required_warm_cached_tokens: number | null;
    aggregate_read_threshold_met: boolean;
    rounds: CodexRelayPromptCacheRound[];
}
export interface CodexRelayPromptCacheTransportRequest {
    endpoint: string;
    apiKey: string;
    body: Record<string, unknown>;
    stream: boolean;
    signal: AbortSignal;
    timeoutMs: number;
}
export type CodexRelayPromptCacheTransport = (request: CodexRelayPromptCacheTransportRequest) => Promise<Response>;
export interface CodexRelayPromptCacheTestOptions {
    transport?: CodexRelayPromptCacheTransport;
    stageTimeoutMs?: number;
    overallTimeoutMs?: number;
}
/** Strictly parse the canonical Responses counters plus common aliases. */
export declare function parseCodexRelayPromptCacheUsage(payload: unknown): CodexRelayPromptCacheUsage;
/**
 * Test exactly one source/model mapping with five native Responses requests:
 * JSON, SSE, JSON, SSE, JSON. This service deliberately does not persist the
 * result; callers can use their own revision/CAS rules when storing it.
 */
export declare function testCodexRelayPromptCacheCompatibility(db: Db, sourceId: number, publicModelId: string, options?: CodexRelayPromptCacheTestOptions): Promise<CodexRelayPromptCacheReport>;
//# sourceMappingURL=codex-relay-prompt-cache.d.ts.map