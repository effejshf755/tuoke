import type { Db } from '../db/types.js';
export declare function normalizePem(value: string): string;
export declare function verifyNotify(params: Record<string, string>): boolean;
export declare function isAlipayConfigured(): boolean;
export declare function createPagePayment(orderNo: string, amountMicro: number, subject: string): {
    gateway: string;
    params: Record<string, string>;
};
/** Atomically credits a paid recharge. Safe to call repeatedly for one order. */
export declare function settleAlipayOrder(db: Db, orderNo: string, tradeNo: string, note?: string): {
    status: "not_found";
    currentStatus?: undefined;
    amountMicro?: undefined;
    creditedMicro?: undefined;
    balanceAfterMicro?: undefined;
} | {
    status: "already_paid";
    currentStatus?: undefined;
    amountMicro?: undefined;
    creditedMicro?: undefined;
    balanceAfterMicro?: undefined;
} | {
    status: "invalid_state";
    currentStatus: string;
    amountMicro?: undefined;
    creditedMicro?: undefined;
    balanceAfterMicro?: undefined;
} | {
    status: "paid";
    amountMicro: number;
    creditedMicro: number;
    balanceAfterMicro: number;
    currentStatus?: undefined;
};
//# sourceMappingURL=alipay.d.ts.map