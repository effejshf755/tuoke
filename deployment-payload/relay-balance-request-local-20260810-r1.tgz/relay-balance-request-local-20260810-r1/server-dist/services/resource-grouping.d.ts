import type { Db } from '../db/types.js';
import { type ResourceOrderRow } from './resource-orders.js';
export interface ResourceGroupingResult {
    order: ResourceOrderRow;
    subpoolId: number;
    memberId: number;
    memberCount: number;
    memberLimit: number;
    formed: boolean;
    subpoolStatus: 'waiting_members' | 'waiting_resource';
}
/** Payment adapters call this after their own settlement succeeds. */
export declare function markResourceOrderPaidForGrouping(db: Db, orderId: number): ResourceOrderRow;
export declare function groupPaidResourceOrder(db: Db, orderId: number): ResourceGroupingResult;
export declare function processPaidResourceOrder(db: Db, orderId: number): ResourceGroupingResult;
//# sourceMappingURL=resource-grouping.d.ts.map