import type { Db } from '../db/types.js';
import { type ResourceOrderRow } from './resource-orders.js';
import { type ResourceGroupingResult } from './resource-grouping.js';
export type ResourcePurchaseErrorCode = 'insufficient_balance' | 'invalid_idempotency_key' | 'purchase_conflict' | 'refund_not_allowed';
export declare class ResourcePurchaseError extends Error {
    readonly code: ResourcePurchaseErrorCode;
    constructor(code: ResourcePurchaseErrorCode, message: string);
}
export interface ResourcePurchaseResult {
    order: ResourceOrderRow;
    grouping: ResourceGroupingResult;
    chargedMicro: number;
    balanceAfterMicro: number;
    alreadyProcessed: boolean;
}
export interface ResourceRefundResult {
    order: ResourceOrderRow;
    refundedMicro: number;
    balanceAfterMicro: number;
    alreadyProcessed: boolean;
}
export declare function purchaseResourceProduct(db: Db, input: {
    userId: number;
    productId: number;
    idempotencyKey: string;
}): ResourcePurchaseResult;
export declare function refundResourcePurchase(db: Db, input: {
    userId: number;
    orderId: number;
}): ResourceRefundResult;
export declare function refundResourcePurchaseAsAdmin(db: Db, input: {
    userId: number;
    orderId: number;
}): ResourceRefundResult;
export declare function refundTimedOutResourcePurchase(db: Db, orderId: number): ResourceRefundResult;
//# sourceMappingURL=resource-purchase.d.ts.map