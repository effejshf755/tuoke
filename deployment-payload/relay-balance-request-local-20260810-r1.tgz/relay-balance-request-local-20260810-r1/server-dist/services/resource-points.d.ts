import type { Db } from '../db/types.js';
export interface ResourceMultiplierInput {
    modelId: string;
    inputMultiplier: number;
    cachedInputMultiplier?: number;
    outputMultiplier: number;
    enabled?: boolean;
}
export declare function getResourcePointsPolicy(db: Db): {
    policy: unknown;
    models: unknown[];
};
export declare function updateResourcePointsPolicy(db: Db, input: {
    officialQuotaFloorPercent: number;
    defaultInputMultiplier: number;
    defaultCachedInputMultiplier?: number;
    defaultOutputMultiplier: number;
    models?: ResourceMultiplierInput[];
}): {
    policy: unknown;
    models: unknown[];
};
//# sourceMappingURL=resource-points.d.ts.map