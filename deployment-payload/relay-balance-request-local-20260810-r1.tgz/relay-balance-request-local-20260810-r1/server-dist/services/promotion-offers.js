export const RECHARGE_BONUS_OFFER_CODE = 'recharge_90_get_100';
export const SPRINT_PROMOTION_OFFER_CODE = 'wallet_20_get_25_24h';
const OFFER_SELECT = `
  SELECT
    id,
    code,
    name,
    description,
    offer_kind AS offerKind,
    payment_source AS paymentSource,
    price_micro AS priceMicro,
    permanent_credit_micro AS permanentCreditMicro,
    limited_credit_micro AS limitedCreditMicro,
    validity_seconds AS validitySeconds,
    enabled,
    sort_order AS sortOrder
  FROM promotion_offers
`;
function mapOffer(row) {
    return { ...row, enabled: row.enabled === 1 };
}
export function getPromotionOffer(db, code, options = {}) {
    const normalizedCode = code.trim();
    if (!normalizedCode)
        return null;
    const row = db.prepare(`
    ${OFFER_SELECT}
    WHERE code = ?
      ${options.includeDisabled ? '' : 'AND enabled = 1'}
    LIMIT 1
  `).get(normalizedCode);
    return row ? mapOffer(row) : null;
}
export function listPromotionOffers(db, options = {}) {
    const rows = db.prepare(`
    ${OFFER_SELECT}
    ${options.includeDisabled ? '' : 'WHERE enabled = 1'}
    ORDER BY sort_order, id
  `).all();
    return rows.map(mapOffer);
}
export function requirePromotionOffer(db, code, expected = {}) {
    const offer = getPromotionOffer(db, code);
    if (!offer)
        throw new PromotionOfferError('offer_not_found', 'Promotion offer is unavailable');
    if (expected.offerKind && offer.offerKind !== expected.offerKind) {
        throw new PromotionOfferError('invalid_offer_kind', 'Promotion offer cannot be used for this purchase');
    }
    if (expected.paymentSource && offer.paymentSource !== expected.paymentSource) {
        throw new PromotionOfferError('invalid_payment_source', 'Promotion offer requires a different payment source');
    }
    return offer;
}
export class PromotionOfferError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.code = code;
        this.name = 'PromotionOfferError';
    }
}
//# sourceMappingURL=promotion-offers.js.map