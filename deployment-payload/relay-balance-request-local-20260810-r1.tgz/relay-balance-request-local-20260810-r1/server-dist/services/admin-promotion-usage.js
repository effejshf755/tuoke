import { SPRINT_PROMOTION_OFFER_CODE } from './promotion-offers.js';
export class AdminSprintMutationError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.code = code;
        this.name = 'AdminSprintMutationError';
    }
}
function sqliteDateToMs(value) {
    if (!value)
        return null;
    const parsed = Date.parse(`${value.replace(' ', 'T')}Z`);
    return Number.isFinite(parsed) ? parsed : null;
}
function mapPurchase(row, nowMs = Date.now()) {
    const grantedMicro = Number(row.grantedMicro ?? row.snapshotGrantedMicro ?? 0);
    const usedMicro = Math.max(0, Number(row.usedMicro ?? 0));
    const rawRemainingMicro = Math.max(0, Number(row.rawRemainingMicro ?? 0));
    const reservedMicro = Math.max(0, Number(row.rawReservedMicro ?? 0));
    const expiresAtMs = sqliteDateToMs(row.expiresAt);
    const expiredByTime = expiresAtMs !== null && expiresAtMs <= nowMs;
    let status;
    if (row.purchaseStatus === 'refunded' || row.purchaseStatus === 'reversed') {
        status = row.purchaseStatus;
    }
    else if (row.grantId === null) {
        status = 'missing';
    }
    else if (row.creditStatus === 'revoked') {
        status = 'revoked';
    }
    else if (expiredByTime && row.creditStatus === 'active' && reservedMicro > 0) {
        status = 'expired_settling';
    }
    else if (expiredByTime || row.creditStatus === 'expired') {
        status = 'expired';
    }
    else if (row.creditStatus === 'exhausted' || rawRemainingMicro === 0) {
        status = 'exhausted';
    }
    else {
        status = 'active';
    }
    const remainingMicro = status === 'active' ? rawRemainingMicro : 0;
    const availableMicro = status === 'active'
        ? Math.max(0, rawRemainingMicro - reservedMicro)
        : 0;
    const pendingSettlementMicro = status === 'expired_settling' ? reservedMicro : 0;
    const forfeitedMicro = row.grantId === null || status === 'active'
        ? 0
        : Math.max(0, grantedMicro - usedMicro - pendingSettlementMicro);
    return {
        purchase_id: row.purchaseId,
        purchase_no: row.purchaseNo,
        price_micro: Number(row.priceMicro ?? 0),
        granted_micro: grantedMicro,
        used_micro: usedMicro,
        remaining_micro: remainingMicro,
        reserved_micro: reservedMicro,
        available_micro: availableMicro,
        forfeited_micro: forfeitedMicro,
        purchase_status: row.purchaseStatus,
        credit_status: row.creditStatus,
        status,
        purchased_at: row.purchasedAt,
        expires_at: row.expiresAt,
    };
}
function escapeLike(value) {
    return value.replace(/[\\%_]/g, character => `\\${character}`);
}
export function listAdminSprintUsers(db, input) {
    const search = input.q.trim().toLowerCase();
    const pattern = `%${escapeLike(search)}%`;
    const whereSearch = search ? "AND LOWER(u.email) LIKE ? ESCAPE '\\'" : '';
    const searchArgs = search ? [pattern] : [];
    const count = db.prepare(`
    SELECT COUNT(DISTINCT p.user_id) AS total
    FROM promotion_purchases p
    JOIN users u ON u.id = p.user_id
    WHERE p.offer_code_snapshot = ?
      AND u.deleted_at IS NULL
      AND NOT EXISTS (
        SELECT 1 FROM promotion_credit_grants deleted_grant
        WHERE deleted_grant.purchase_id = p.id
          AND deleted_grant.admin_deleted_at IS NOT NULL
      )
      ${whereSearch}
  `).get(SPRINT_PROMOTION_OFFER_CODE, ...searchArgs);
    const total = Number(count.total ?? 0);
    const totalPages = total === 0 ? 0 : Math.ceil(total / input.limit);
    const page = Math.min(input.page, Math.max(1, totalPages));
    const offset = (page - 1) * input.limit;
    const buyers = db.prepare(`
    SELECT u.id AS userId, u.email, MAX(p.id) AS latestPurchaseId
    FROM promotion_purchases p
    JOIN users u ON u.id = p.user_id
    WHERE p.offer_code_snapshot = ?
      AND u.deleted_at IS NULL
      AND NOT EXISTS (
        SELECT 1 FROM promotion_credit_grants deleted_grant
        WHERE deleted_grant.purchase_id = p.id
          AND deleted_grant.admin_deleted_at IS NOT NULL
      )
      ${whereSearch}
    GROUP BY u.id, u.email
    ORDER BY latestPurchaseId DESC
    LIMIT ? OFFSET ?
  `).all(SPRINT_PROMOTION_OFFER_CODE, ...searchArgs, input.limit, offset);
    if (buyers.length === 0) {
        return { users: [], pagination: { page, limit: input.limit, total, total_pages: totalPages } };
    }
    const userIds = buyers.map(item => item.userId);
    const placeholders = userIds.map(() => '?').join(', ');
    const summaries = db.prepare(`
    WITH usage_by_grant AS (
      SELECT grant_id,
        COALESCE(SUM(CASE WHEN event_type = 'usage'
          THEN -remaining_delta_micro ELSE 0 END), 0) AS usedMicro
      FROM promotion_credit_ledger
      WHERE user_id IN (${placeholders})
      GROUP BY grant_id
    )
    SELECT
      p.user_id AS userId,
      COUNT(*) AS purchaseCount,
      COALESCE(SUM(CASE
        WHEN p.status = 'paid' AND g.status = 'active'
          AND datetime(g.expires_at) > datetime('now')
        THEN 1 ELSE 0 END), 0) AS activeCount,
      COALESCE(SUM(COALESCE(g.granted_micro, p.limited_credit_micro)), 0) AS grantedMicro,
      COALESCE(SUM(COALESCE(usage.usedMicro, 0)), 0) AS usedMicro,
      COALESCE(SUM(CASE
        WHEN p.status = 'paid' AND g.status = 'active'
          AND datetime(g.expires_at) > datetime('now')
        THEN g.remaining_micro ELSE 0 END), 0) AS remainingMicro,
      COALESCE(SUM(COALESCE(g.reserved_micro, 0)), 0) AS reservedMicro,
      COALESCE(SUM(CASE
        WHEN p.status = 'paid' AND g.status = 'active'
          AND datetime(g.expires_at) > datetime('now')
        THEN MAX(0, g.remaining_micro - g.reserved_micro) ELSE 0 END), 0) AS availableMicro,
      COALESCE(SUM(CASE
        WHEN g.id IS NULL THEN 0
        WHEN p.status = 'paid' AND g.status = 'active'
          AND datetime(g.expires_at) > datetime('now') THEN 0
        ELSE MAX(0,
          g.granted_micro - COALESCE(usage.usedMicro, 0)
          - CASE WHEN p.status = 'paid' AND g.status = 'active'
              AND datetime(g.expires_at) <= datetime('now') AND g.reserved_micro > 0
            THEN g.reserved_micro ELSE 0 END
        ) END), 0) AS forfeitedMicro,
      MIN(CASE
        WHEN p.status = 'paid' AND g.status = 'active'
          AND datetime(g.expires_at) > datetime('now')
        THEN g.expires_at ELSE NULL END) AS nextExpiresAt,
      MAX(p.paid_at) AS lastPurchasedAt
    FROM promotion_purchases p
    LEFT JOIN promotion_credit_grants g ON g.purchase_id = p.id
    LEFT JOIN usage_by_grant usage ON usage.grant_id = g.id
    WHERE p.offer_code_snapshot = ? AND p.user_id IN (${placeholders})
      AND NOT EXISTS (
        SELECT 1 FROM promotion_credit_grants deleted_grant
        WHERE deleted_grant.purchase_id = p.id
          AND deleted_grant.admin_deleted_at IS NOT NULL
      )
    GROUP BY p.user_id
  `).all(...userIds, SPRINT_PROMOTION_OFFER_CODE, ...userIds);
    const requestTokens = db.prepare(`
    SELECT consumer_user_id AS userId,
      COALESCE(SUM(input_tokens), 0) AS inputTokens,
      COALESCE(SUM(output_tokens), 0) AS outputTokens
    FROM requests
    WHERE consumer_user_id IN (${placeholders})
    GROUP BY consumer_user_id
  `).all(...userIds);
    const byUserId = new Map(summaries.map(item => [Number(item.userId), item]));
    const tokensByUserId = new Map(requestTokens.map(item => [Number(item.userId), item]));
    const users = buyers.flatMap((buyer) => {
        const summary = byUserId.get(buyer.userId);
        if (!summary)
            return [];
        const tokens = tokensByUserId.get(buyer.userId);
        return [{
                user_id: buyer.userId,
                email: buyer.email,
                purchase_count: Number(summary.purchaseCount ?? 0),
                active_count: Number(summary.activeCount ?? 0),
                granted_micro: Number(summary.grantedMicro ?? 0),
                used_micro: Number(summary.usedMicro ?? 0),
                remaining_micro: Number(summary.remainingMicro ?? 0),
                reserved_micro: Number(summary.reservedMicro ?? 0),
                total_input_tokens: Number(tokens?.inputTokens ?? 0),
                total_output_tokens: Number(tokens?.outputTokens ?? 0),
                available_micro: Number(summary.availableMicro ?? 0),
                forfeited_micro: Number(summary.forfeitedMicro ?? 0),
                next_expires_at: summary.nextExpiresAt ?? null,
                last_purchased_at: summary.lastPurchasedAt,
            }];
    });
    return { users, pagination: { page, limit: input.limit, total, total_pages: totalPages } };
}
export function listAdminSprintPurchases(db, input) {
    const user = db.prepare(`
    SELECT id, email FROM users WHERE id = ? AND deleted_at IS NULL
  `).get(input.userId);
    if (!user)
        return { user: null, items: [], next_before_id: null, has_more: false };
    const cursorClause = input.beforeId === undefined ? '' : 'AND p.id < ?';
    const cursorArgs = input.beforeId === undefined ? [] : [input.beforeId];
    const rows = db.prepare(`
    WITH selected_purchases AS (
      SELECT p.id, p.purchase_no, p.price_micro, p.limited_credit_micro,
        p.status, p.paid_at
      FROM promotion_purchases p
      WHERE p.user_id = ? AND p.offer_code_snapshot = ?
        AND NOT EXISTS (
          SELECT 1 FROM promotion_credit_grants deleted_grant
          WHERE deleted_grant.purchase_id = p.id
            AND deleted_grant.admin_deleted_at IS NOT NULL
        )
        ${cursorClause}
      ORDER BY p.id DESC
      LIMIT ?
    ), usage_by_grant AS (
      SELECT l.grant_id,
        COALESCE(SUM(CASE WHEN l.event_type = 'usage'
          THEN -l.remaining_delta_micro ELSE 0 END), 0) AS usedMicro
      FROM promotion_credit_ledger l
      WHERE l.user_id = ?
        AND EXISTS (
          SELECT 1 FROM promotion_credit_grants target_grant
          JOIN selected_purchases target_purchase
            ON target_purchase.id = target_grant.purchase_id
          WHERE target_grant.id = l.grant_id
        )
      GROUP BY l.grant_id
    )
    SELECT
      p.id AS purchaseId, p.purchase_no AS purchaseNo,
      p.price_micro AS priceMicro, p.limited_credit_micro AS snapshotGrantedMicro,
      p.status AS purchaseStatus, p.paid_at AS purchasedAt,
      g.id AS grantId, g.granted_micro AS grantedMicro,
      COALESCE(usage.usedMicro, 0) AS usedMicro,
      g.remaining_micro AS rawRemainingMicro,
      g.reserved_micro AS rawReservedMicro,
      g.status AS creditStatus, g.expires_at AS expiresAt
    FROM selected_purchases p
    LEFT JOIN promotion_credit_grants g ON g.purchase_id = p.id
    LEFT JOIN usage_by_grant usage ON usage.grant_id = g.id
    ORDER BY p.id DESC
  `).all(input.userId, SPRINT_PROMOTION_OFFER_CODE, ...cursorArgs, input.limit + 1, input.userId);
    const hasMore = rows.length > input.limit;
    const pageRows = hasMore ? rows.slice(0, input.limit) : rows;
    const items = pageRows.map(row => mapPurchase(row));
    return {
        user,
        items,
        next_before_id: hasMore && items.length > 0 ? items.at(-1).purchase_id : null,
        has_more: hasMore,
    };
}
export function extendAdminSprintUserCredits(db, input) {
    const seconds = Math.round(input.hours * 3_600);
    if (!Number.isSafeInteger(seconds) || seconds <= 0) {
        throw new Error('Extension duration must be positive');
    }
    return db.transaction(() => {
        const user = db.prepare(`
      SELECT id FROM users WHERE id = ? AND deleted_at IS NULL
    `).get(input.userId);
        if (!user) {
            throw new AdminSprintMutationError('not_found', 'User not found');
        }
        const modifier = `+${seconds} seconds`;
        const updated = db.prepare(`
      UPDATE promotion_credit_grants
      SET expires_at = datetime(
          CASE
            WHEN datetime(expires_at) > datetime('now') THEN expires_at
            ELSE datetime('now')
          END,
          ?
        ),
        updated_at = datetime('now')
      WHERE user_id = ?
        AND admin_deleted_at IS NULL
        AND status = 'active'
        AND remaining_micro > 0
        AND EXISTS (
          SELECT 1 FROM promotion_purchases purchase
          WHERE purchase.id = promotion_credit_grants.purchase_id
            AND purchase.offer_code_snapshot = ?
            AND purchase.status = 'paid'
        )
    `).run(modifier, input.userId, SPRINT_PROMOTION_OFFER_CODE);
        if (updated.changes === 0) {
            throw new AdminSprintMutationError('nothing_to_extend', 'This user has no active sprint credit that can be extended');
        }
        const next = db.prepare(`
      SELECT MIN(expires_at) AS nextExpiresAt
      FROM promotion_credit_grants
      WHERE user_id = ? AND admin_deleted_at IS NULL
        AND status = 'active' AND remaining_micro > 0
        AND datetime(expires_at) > datetime('now')
    `).get(input.userId);
        return {
            extended_count: updated.changes,
            extended_seconds: seconds,
            next_expires_at: next.nextExpiresAt ?? null,
        };
    })();
}
export function revokeAdminSprintPurchase(db, input) {
    return db.transaction(() => {
        const row = db.prepare(`
      SELECT p.id AS purchaseId, g.id AS grantId,
        g.remaining_micro AS remainingMicro,
        g.reserved_micro AS reservedMicro,
        g.admin_deleted_at AS adminDeletedAt
      FROM promotion_purchases p
      JOIN promotion_credit_grants g ON g.purchase_id = p.id
      WHERE p.id = ? AND p.user_id = ? AND p.offer_code_snapshot = ?
    `).get(input.purchaseId, input.userId, SPRINT_PROMOTION_OFFER_CODE);
        if (!row) {
            throw new AdminSprintMutationError('not_found', 'Sprint purchase not found');
        }
        if (row.adminDeletedAt) {
            return { purchase_id: row.purchaseId, revoked: true, already_deleted: true };
        }
        if (row.reservedMicro > 0) {
            throw new AdminSprintMutationError('in_flight', 'This sprint credit is settling an in-flight request; retry after settlement');
        }
        const updated = db.prepare(`
      UPDATE promotion_credit_grants
      SET remaining_micro = 0,
        status = 'revoked',
        admin_deleted_at = datetime('now'),
        admin_deleted_by = ?,
        updated_at = datetime('now')
      WHERE id = ? AND admin_deleted_at IS NULL AND reserved_micro = 0
    `).run(input.adminUserId, row.grantId);
        if (updated.changes !== 1) {
            throw new AdminSprintMutationError('in_flight', 'Sprint credit changed while it was being deleted; retry after settlement');
        }
        db.prepare(`
      INSERT INTO promotion_credit_ledger (
        user_id, grant_id, event_type, remaining_delta_micro,
        reserved_delta_micro, remaining_after_micro, reserved_after_micro,
        note
      ) VALUES (?, ?, 'revoke', ?, 0, 0, 0, ?)
    `).run(input.userId, row.grantId, -Math.max(0, Number(row.remainingMicro ?? 0)), `Deleted without refund by administrator #${input.adminUserId}`);
        return { purchase_id: row.purchaseId, revoked: true, already_deleted: false };
    })();
}
//# sourceMappingURL=admin-promotion-usage.js.map