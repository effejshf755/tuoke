import { decryptCodexToken } from './codex-token.js';
import { discoverCodexModels, replaceCodexAccountModels } from './codex-model-discovery.js';
import { proxyFetch } from '../lib/proxy.js';
import { getDb } from '../db/index.js';
const CODEX_USAGE_ENDPOINT = 'https://chatgpt.com/backend-api/wham/usage';
export function listCodexAccounts(db) {
    const accounts = db
        .prepare(`
      SELECT
        id,
        label,
        account_id,
        enabled,
        status,
        last_used_at,
        last_error,
        quota_used_percent,
        quota_remaining_percent,
        quota_reset_at,
        quota_synced_at,
        plan_type,
        resource_scope,
        codex_group_id,
        (SELECT name FROM codex_groups g WHERE g.id = codex_oauth_accounts.codex_group_id) AS codex_group_name
      FROM codex_oauth_accounts
      WHERE deleted_at IS NULL
      ORDER BY id DESC
    `)
        .all();
    const modelRows = db.prepare(`
    SELECT account_id, model_id
    FROM codex_oauth_account_models
    WHERE enabled = 1
    ORDER BY account_id DESC, model_id ASC
  `).all();
    const modelsByAccount = new Map();
    for (const row of modelRows) {
        const models = modelsByAccount.get(row.account_id) ?? [];
        models.push(row.model_id);
        modelsByAccount.set(row.account_id, models);
    }
    return accounts.map(account => ({
        ...account,
        models: modelsByAccount.get(account.id) ?? [],
    }));
}
export function createCodexAccount(db, data) {
    if (data.account_id) {
        const existing = db.prepare(`
      SELECT id
      FROM codex_oauth_accounts
      WHERE account_id = ?
      ORDER BY id DESC
      LIMIT 1
    `).get(data.account_id);
        if (existing) {
            db.prepare(`
        UPDATE codex_oauth_accounts
        SET label = ?,
            access_token_encrypted = ?,
            access_token_iv = ?,
            access_token_auth_tag = ?,
            refresh_token_encrypted = ?,
            refresh_token_iv = ?,
            refresh_token_auth_tag = ?,
            token_expires_at = ?,
            enabled = 0,
            status = 'unknown',
            last_error = NULL,
            failure_count = 0,
            cooldown_until = NULL,
            deleted_at = NULL,
            updated_at = datetime('now')
        WHERE id = ?
      `).run(data.label, data.access_token_encrypted, data.access_token_iv, data.access_token_auth_tag, data.refresh_token_encrypted, data.refresh_token_iv, data.refresh_token_auth_tag, data.token_expires_at ?? null, existing.id);
            return existing.id;
        }
    }
    const result = db.prepare(`
    INSERT INTO codex_oauth_accounts (
      label,
      account_id,
      access_token_encrypted,
      access_token_iv,
      access_token_auth_tag,
      refresh_token_encrypted,
      refresh_token_iv,
      refresh_token_auth_tag,
      token_expires_at,
      enabled
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
  `).run(data.label, data.account_id ?? null, data.access_token_encrypted, data.access_token_iv, data.access_token_auth_tag, data.refresh_token_encrypted, data.refresh_token_iv, data.refresh_token_auth_tag, data.token_expires_at ?? null);
    return Number(result.lastInsertRowid);
}
export function setCodexAccountScope(db, id, scope) {
    return db.transaction(() => {
        const account = db.prepare('SELECT resource_scope scope FROM codex_oauth_accounts WHERE id = ?')
            .get(id);
        if (!account)
            return false;
        if (account.scope === scope)
            return true;
        const assigned = db.prepare(`SELECT 1 FROM resource_subpool_bindings
      WHERE codex_account_id = ? AND status IN ('active', 'migrating')
      UNION ALL
      SELECT 1 FROM resource_subpools
      WHERE pending_codex_account_id = ? AND status = 'waiting_resource' LIMIT 1`).get(id, id);
        if (assigned)
            throw new Error('A Codex account assigned to a resource subpool cannot change scope');
        db.prepare(`UPDATE codex_oauth_accounts SET resource_scope = ?, updated_at = datetime('now') WHERE id = ?`)
            .run(scope, id);
        return true;
    })();
}
export function setCodexAccountGroup(db, id, groupId) {
    return db.transaction(() => {
        const group = db.prepare('SELECT 1 FROM codex_groups WHERE id = ? AND enabled = 1').get(groupId);
        if (!group)
            throw new Error('Codex group not found or disabled');
        const account = db.prepare('SELECT resource_scope FROM codex_oauth_accounts WHERE id = ? AND deleted_at IS NULL')
            .get(id);
        if (!account)
            return false;
        if (account.resource_scope === 'resource_subpool') {
            const assigned = db.prepare(`SELECT 1 FROM resource_subpool_bindings
        WHERE codex_account_id = ? AND status IN ('active', 'migrating')
        UNION ALL SELECT 1 FROM resource_subpools
        WHERE pending_codex_account_id = ? AND status = 'waiting_resource' LIMIT 1`).get(id, id);
            if (assigned)
                throw new Error('A Codex account assigned to a resource subpool cannot change group');
        }
        db.prepare(`UPDATE codex_oauth_accounts
      SET resource_scope = 'codex_pool', codex_group_id = ?, updated_at = datetime('now') WHERE id = ?`)
            .run(groupId, id);
        return true;
    })();
}
async function syncCodexAccountQuota(db, id, accessToken, accountId) {
    const response = await proxyFetch(CODEX_USAGE_ENDPOINT, {
        headers: {
            Authorization: `Bearer ${accessToken}`,
            Accept: 'application/json',
            ...(accountId ? { 'ChatGPT-Account-Id': accountId } : {}),
        },
    }, 'openai-codex');
    if (!response.ok)
        throw new Error(`Codex quota sync failed with HTTP ${response.status}`);
    const payload = await response.json();
    const window = payload.rate_limit?.primary_window;
    const used = Number(window?.used_percent);
    const resetAtSeconds = Number(window?.reset_at);
    const usedPercent = Number.isFinite(used) ? Math.min(100, Math.max(0, used)) : null;
    const remainingPercent = usedPercent == null ? null : Math.max(0, 100 - usedPercent);
    const resetAt = Number.isFinite(resetAtSeconds) && resetAtSeconds > 0
        ? new Date(resetAtSeconds * 1_000).toISOString()
        : null;
    const planType = typeof payload.plan_type === 'string' ? payload.plan_type.slice(0, 100) : null;
    db.prepare(`
    UPDATE codex_oauth_accounts
    SET quota_used_percent=?,
        quota_remaining_percent=?,
        quota_reset_at=?,
        quota_synced_at=datetime('now'),
        plan_type=?,
        updated_at=datetime('now')
    WHERE id=?
  `).run(usedPercent, remainingPercent, resetAt, planType, id);
}
export function deleteCodexAccount(db, id) {
    return db.transaction(() => {
        const account = db.prepare(`SELECT id FROM codex_oauth_accounts
      WHERE id = ? AND deleted_at IS NULL`).get(id);
        if (!account)
            return false;
        const activeAssignment = db.prepare(`SELECT 1 FROM resource_subpool_bindings
      WHERE codex_account_id = ? AND status IN ('active', 'migrating')
      UNION ALL
      SELECT 1 FROM resource_subpools
      WHERE pending_codex_account_id = ? AND status = 'waiting_resource' LIMIT 1`).get(id, id);
        if (activeAssignment) {
            throw new Error('Codex account is assigned to a resource subpool and cannot be deleted');
        }
        const result = db.prepare(`UPDATE codex_oauth_accounts
      SET enabled = 0, status = 'deleted', deleted_at = datetime('now'),
          cooldown_until = NULL, updated_at = datetime('now')
      WHERE id = ? AND deleted_at IS NULL`).run(id);
        return result.changes === 1;
    })();
}
export function setCodexAccountEnabled(db, id, enabled) {
    const result = db.prepare(`
    UPDATE codex_oauth_accounts
    SET enabled = ?,
        updated_at = datetime('now')
    WHERE id = ?
  `).run(enabled ? 1 : 0, id);
    return result.changes === 1;
}
export async function checkCodexAccountHealth(db, id) {
    const account = db.prepare(`
    SELECT id, account_id, access_token_encrypted, access_token_iv, access_token_auth_tag
    FROM codex_oauth_accounts
    WHERE id = ?
  `).get(id);
    if (!account)
        throw new Error('Codex OAuth account not found');
    try {
        const accessToken = decryptCodexToken(account.access_token_encrypted, account.access_token_iv, account.access_token_auth_tag);
        const models = await discoverCodexModels(accessToken, account.account_id);
        replaceCodexAccountModels(db, id, models);
        await syncCodexAccountQuota(db, id, accessToken, account.account_id);
        db.prepare(`
      UPDATE codex_oauth_accounts
      SET status='healthy', last_error=NULL, failure_count=0,
          cooldown_until=NULL, updated_at=datetime('now')
      WHERE id=?
    `).run(id);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : 'Codex account health check failed';
        db.prepare(`
      UPDATE codex_oauth_accounts
      SET status='unhealthy', last_error=?, failure_count=failure_count+1,
          updated_at=datetime('now')
      WHERE id=?
    `).run(message.slice(0, 2_000), id);
    }
    return listCodexAccounts(db).find(accountRow => accountRow.id === id);
}
export async function syncEnabledCodexAccountQuotas(db, check = syncCodexAccountQuotaOnly) {
    const accounts = db.prepare(`
    SELECT id FROM codex_oauth_accounts
    WHERE enabled = 1 AND deleted_at IS NULL
    ORDER BY id
  `).all();
    for (const account of accounts) {
        try {
            await check(db, account.id);
        }
        catch (error) {
            console.error(`[codex-quota-sync] account ${account.id} failed:`, error instanceof Error ? error.message : error);
        }
    }
    return accounts.length;
}
async function syncCodexAccountQuotaOnly(db, id) {
    const account = db.prepare(`
    SELECT account_id, access_token_encrypted, access_token_iv, access_token_auth_tag
    FROM codex_oauth_accounts
    WHERE id = ? AND enabled = 1 AND deleted_at IS NULL
  `).get(id);
    if (!account)
        return;
    const accessToken = decryptCodexToken(account.access_token_encrypted, account.access_token_iv, account.access_token_auth_tag);
    await syncCodexAccountQuota(db, id, accessToken, account.account_id);
}
const CODEX_QUOTA_SYNC_INTERVAL_MS = 60_000;
let codexQuotaSyncStarted = false;
export function startCodexAccountQuotaSync(scheduler) {
    if (codexQuotaSyncStarted)
        return;
    codexQuotaSyncStarted = true;
    let running = false;
    const run = async () => {
        if (running)
            return;
        running = true;
        try {
            await syncEnabledCodexAccountQuotas(getDb());
        }
        catch (error) {
            console.error('[codex-quota-sync] failed:', error instanceof Error ? error.message : error);
        }
        finally {
            running = false;
        }
    };
    void run();
    scheduler.every(CODEX_QUOTA_SYNC_INTERVAL_MS, run, { name: 'codex-account-quota-sync' });
}
//# sourceMappingURL=codex-oauth.js.map