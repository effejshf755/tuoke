import type { Db } from '../db/types.js';
export declare function getActiveProfileId(db: Db): number | null;
export declare function ensureModelInProfiles(db: Db, modelDbId: number): void;
export declare function ensureAllModelsInProfiles(db: Db): void;
//# sourceMappingURL=profile-models.d.ts.map