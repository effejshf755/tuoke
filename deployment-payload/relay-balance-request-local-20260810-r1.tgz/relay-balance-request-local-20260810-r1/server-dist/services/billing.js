import { ensurePromotionCreditReservation, releasePromotionCreditReservation, settlePromotionCreditReservation, } from './promotion-credits.js';
export const DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI = 1_250;
export function getUserWallet(db, userId) {
    const row = db.prepare(`
    SELECT
      id AS userId,
      balance_micro AS balanceMicro
    FROM users
    WHERE id = ?
  `).get(userId);
    return row ?? null;
}
export function getModelBillingRule(db, platform, modelId) {
    const row = db.prepare(`
    SELECT
      id,
      platform,
      model_id AS modelId,
      input_price_micro_per_million
        AS inputPriceMicroPerMillion,
      output_price_micro_per_million
        AS outputPriceMicroPerMillion,
      multiplier_milli
        AS multiplierMilli,
      cached_input_multiplier_milli
        AS cachedInputMultiplierMilli,
      billing_enabled
        AS billingEnabled
    FROM model_billing_rules
    WHERE platform = ?
      AND model_id = ?
    LIMIT 1
  `).get(platform, modelId);
    return row ?? null;
}
/**
 * Resolve a Codex group's optional per-model price override while preserving
 * the global rule's billing switch. Non-Codex requests and resource-subpool
 * keys continue to use the global model rule unchanged.
 */
export function getEffectiveModelBillingRule(db, platform, modelId, consumerApiKeyId) {
    const globalRule = getModelBillingRule(db, platform, modelId);
    if (!globalRule || platform !== 'openai-codex' || consumerApiKeyId === null) {
        return globalRule;
    }
    try {
        const override = db.prepare(`
      SELECT
        gm.input_price_micro_per_million_override AS inputPriceMicroPerMillion,
        gm.output_price_micro_per_million_override AS outputPriceMicroPerMillion,
        gm.multiplier_milli_override AS multiplierMilli,
        gm.cached_input_multiplier_milli_override AS cachedInputMultiplierMilli
      FROM consumer_api_keys k
      JOIN codex_group_models gm
        ON gm.group_id = k.codex_group_id
       AND gm.model_id = ?
      WHERE k.id = ?
        AND k.key_scope = 'codex_pool'
      LIMIT 1
    `).get(modelId, consumerApiKeyId);
        if (!override)
            return globalRule;
        return {
            ...globalRule,
            inputPriceMicroPerMillion: override.inputPriceMicroPerMillion ?? globalRule.inputPriceMicroPerMillion,
            outputPriceMicroPerMillion: override.outputPriceMicroPerMillion ?? globalRule.outputPriceMicroPerMillion,
            multiplierMilli: override.multiplierMilli ?? globalRule.multiplierMilli,
            cachedInputMultiplierMilli: override.cachedInputMultiplierMilli ?? globalRule.cachedInputMultiplierMilli,
        };
    }
    catch (error) {
        if (/no such table: codex_group_models|no such column: gm\.(?:input_price|output_price|multiplier|cached_input)/i
            .test(String(error))) {
            return globalRule;
        }
        throw error;
    }
}
/**
 * 精确计算一次模型请求费用。
 *
 * 金额单位：
 * 1 元 = 1,000,000 micro
 *
 * 模型价格单位：
 * micro / 1,000,000 tokens
 *
 * 倍率：
 * 1000 = 1x
 * 1500 = 1.5x
 * 2000 = 2x
 *
 * 最终结果向上取整到 1 micro，
 * 避免极小调用因为整数除法变成 0 元。
 */
export function calculateBillingAmountMicro(inputTokens, outputTokens, inputPriceMicroPerMillion, outputPriceMicroPerMillion, multiplierMilli, cachedInputTokens = 0, cachedInputMultiplierMilli = 1_000, cacheWriteTokens = 0, cacheWriteMultiplierMilli = DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI) {
    const safeInputTokens = Math.max(0, Math.trunc(inputTokens));
    const safeOutputTokens = Math.max(0, Math.trunc(outputTokens));
    const safeCachedInputTokens = Math.min(safeInputTokens, Math.max(0, Math.trunc(cachedInputTokens)));
    // Upstream input_tokens includes both cache reads and cache writes. Keep the
    // three input buckets disjoint so no token is billed twice.
    const safeCacheWriteTokens = Math.min(safeInputTokens - safeCachedInputTokens, Math.max(0, Math.trunc(cacheWriteTokens)));
    const safeInputPrice = Math.max(0, Math.trunc(inputPriceMicroPerMillion));
    const safeOutputPrice = Math.max(0, Math.trunc(outputPriceMicroPerMillion));
    const safeMultiplier = Math.max(0, Math.trunc(multiplierMilli));
    const safeCachedMultiplier = Math.max(0, Math.trunc(cachedInputMultiplierMilli));
    const safeCacheWriteMultiplier = Math.max(0, Math.trunc(cacheWriteMultiplierMilli));
    const regularRaw = BigInt(safeInputTokens - safeCachedInputTokens - safeCacheWriteTokens) *
        BigInt(safeInputPrice)
        +
            BigInt(safeOutputTokens) *
                BigInt(safeOutputPrice);
    const cachedRaw = BigInt(safeCachedInputTokens) *
        BigInt(safeInputPrice);
    const cacheWriteRaw = BigInt(safeCacheWriteTokens) *
        BigInt(safeInputPrice);
    if ((regularRaw === 0n && cachedRaw === 0n && cacheWriteRaw === 0n) ||
        safeMultiplier === 0) {
        return 0;
    }
    /*
     * raw:
     * token × micro-per-million
     *
     * 再乘 multiplierMilli。
     *
     * 分母：
     * 1,000,000 tokens
     * × 1,000 multiplier scale
     * = 1,000,000,000
     */
    const numerator = regularRaw *
        BigInt(safeMultiplier) *
        1000n
        +
            cachedRaw *
                BigInt(safeMultiplier) *
                BigInt(safeCachedMultiplier)
        +
            cacheWriteRaw *
                BigInt(safeMultiplier) *
                BigInt(safeCacheWriteMultiplier);
    const denominator = 1000000000000n;
    const roundedUp = (numerator +
        denominator -
        1n) /
        denominator;
    if (roundedUp >
        BigInt(Number.MAX_SAFE_INTEGER)) {
        throw new Error('Billing amount exceeds safe integer range');
    }
    return Number(roundedUp);
}
function safeStoredComputePoints(value) {
    const numeric = Number(value);
    return Number.isSafeInteger(numeric) && numeric >= 0 ? numeric : null;
}
function convertTokensToComputePoints(tokens, pointsPerMillion) {
    const safeTokens = Math.max(0, Math.trunc(tokens));
    const points = Math.round((safeTokens * pointsPerMillion) / 1_000_000);
    if (!Number.isSafeInteger(points)) {
        throw new Error('Compute-point usage exceeds safe integer range');
    }
    return points;
}
/**
 * Prices every request bucket in compute points. New request rows carry the
 * exact conversion snapshot used when their usage was recorded; legacy rows
 * without a snapshot retain the historical 1:1 token behavior.
 */
export function calculateComputePointBillingAmountMicro(usage, inputPriceMicroPerMillion, outputPriceMicroPerMillion, multiplierMilli, cachedInputMultiplierMilli = 1_000, cacheWriteMultiplierMilli = DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI) {
    const pointsPerMillion = safeStoredComputePoints(usage.computePointsPerMillionTokens);
    if (pointsPerMillion === null || pointsPerMillion === 0) {
        return calculateBillingAmountMicro(usage.inputTokens, usage.outputTokens, inputPriceMicroPerMillion, outputPriceMicroPerMillion, multiplierMilli, usage.cachedInputTokens ?? 0, cachedInputMultiplierMilli, usage.cacheWriteTokens ?? 0, cacheWriteMultiplierMilli);
    }
    const inputPoints = safeStoredComputePoints(usage.inputComputePoints)
        ?? convertTokensToComputePoints(usage.inputTokens, pointsPerMillion);
    const outputPoints = safeStoredComputePoints(usage.outputComputePoints)
        ?? convertTokensToComputePoints(usage.outputTokens, pointsPerMillion);
    const cachedInputPoints = convertTokensToComputePoints(usage.cachedInputTokens ?? 0, pointsPerMillion);
    const cacheWritePoints = convertTokensToComputePoints(usage.cacheWriteTokens ?? 0, pointsPerMillion);
    return calculateBillingAmountMicro(inputPoints, outputPoints, inputPriceMicroPerMillion, outputPriceMicroPerMillion, multiplierMilli, cachedInputPoints, cachedInputMultiplierMilli, cacheWritePoints, cacheWriteMultiplierMilli);
}
/**
 * 根据 request_id 对一次请求进行结算。
 *
 * 重要：
 * - 只对 success 请求收费
 * - 系统/管理员非消费者请求不收费
 * - 使用实际 platform + model_id
 * - 使用实际 input/output tokens
 * - 已结算请求不会重复收费
 * - 扣余额、写流水、更新 requests 在同一事务完成
 */
export function chargeRequest(db, requestId) {
    const transaction = db.transaction(() => {
        const request = db.prepare(`
            SELECT
              id,
              platform,
              model_id AS modelId,
              status,
              input_tokens AS inputTokens,
              cached_input_tokens AS cachedInputTokens,
              cache_write_tokens AS cacheWriteTokens,
              output_tokens AS outputTokens,
              input_compute_points AS inputComputePoints,
              output_compute_points AS outputComputePoints,
              compute_points_per_million_tokens AS computePointsPerMillionTokens,
              consumer_user_id
                AS consumerUserId,
              consumer_api_key_id AS consumerApiKeyId,
              billing_amount_micro
                AS billingAmountMicro,
              billing_status
                AS billingStatus
            FROM requests
            WHERE id = ?
          `).get(requestId);
        if (!request) {
            return {
                status: 'request_not_found',
            };
        }
        if (request.billingStatus !==
            'unbilled') {
            return {
                status: 'already_processed',
            };
        }
        /*
         * 请求失败不收费。
         */
        if (request.status !==
            'success') {
            db.prepare(`
            UPDATE requests
            SET
              billing_status =
                'exempt',
              billing_amount_micro = 0
            WHERE id = ?
              AND billing_status =
                'unbilled'
          `).run(request.id);
            return {
                status: 'not_billable',
            };
        }
        /*
         * 没有消费者用户身份：
         * 例如管理员内部调用、
         * 系统调用或全局统一 Key。
         */
        if (request.consumerUserId ===
            null) {
            db.prepare(`
            UPDATE requests
            SET
              billing_status =
                'exempt',
              billing_amount_micro = 0
            WHERE id = ?
              AND billing_status =
                'unbilled'
          `).run(request.id);
            return {
                status: 'not_billable',
            };
        }
        const rule = getEffectiveModelBillingRule(db, request.platform, request.modelId, request.consumerApiKeyId);
        /*
         * 没有设置计费规则时，
         * 绝不能偷偷按免费处理。
         *
         * 保持 unbilled，
         * 后续调用前拦截会禁止
         * 未配置价格的模型。
         */
        if (!rule ||
            !rule.billingEnabled) {
            return {
                status: 'no_billing_rule',
            };
        }
        const effectiveMultiplierMilli = applyUserBillingMultiplier(db, request.consumerUserId, applyCodexGroupMultiplier(db, request.platform, request.consumerApiKeyId, rule.multiplierMilli));
        const amountMicro = calculateComputePointBillingAmountMicro(request, rule.inputPriceMicroPerMillion, rule.outputPriceMicroPerMillion, effectiveMultiplierMilli, rule.cachedInputMultiplierMilli, DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI);
        const wallet = getUserWallet(db, request.consumerUserId);
        if (!wallet) {
            return {
                status: 'insufficient_balance',
                amountMicro,
                balanceAfterMicro: 0,
            };
        }
        /*
         * 管理员可以显式把某模型价格设为 0，
         * 这种请求记录为 free。
         */
        if (amountMicro === 0) {
            db.prepare(`
            UPDATE requests
            SET
              billing_status =
                'free',
              billing_amount_micro = 0
            WHERE id = ?
              AND billing_status =
                'unbilled'
          `).run(request.id);
            return {
                status: 'free',
                amountMicro: 0,
                balanceAfterMicro: wallet.balanceMicro,
            };
        }
        /*
         * 余额不足时绝不允许变成负数。
         *
         * 当前先返回 insufficient_balance。
         * 后续我们会在请求进入模型之前
         * 增加预付余额检查，
         * 避免请求已经完成才发现钱不够。
         */
        // chargeRequest() is the legacy/fallback settlement path used when a
        // request did not carry the normal admission-time wallet reservation.
        // Give it the same promotion-first order by creating a zero-value
        // lifecycle anchor here. Normal consumer traffic uses
        // chargeReservedRequest(), which allocates before the upstream starts
        // and therefore settles promotion credit against the observed usage
        // without relying on an admission-time amount estimate.
        const trackingReservationId = Number(db.prepare(`
            INSERT INTO wallet_reservations (
              user_id,
              consumer_api_key_id,
              request_id,
              requested_model,
              reserved_micro,
              status
            ) VALUES (?, ?, ?, ?, 0, 'reserved')
          `).run(request.consumerUserId, request.consumerApiKeyId, request.id, request.modelId).lastInsertRowid);
        const promotionReservation = ensurePromotionCreditReservation(db, {
            userId: request.consumerUserId,
            walletReservationId: trackingReservationId,
            targetMicro: amountMicro,
        });
        const walletChargeMicro = Math.max(0, amountMicro - promotionReservation.totalReservedMicro);
        if (wallet.balanceMicro < walletChargeMicro) {
            releasePromotionCreditReservation(db, trackingReservationId);
            db.prepare(`
            UPDATE wallet_reservations
            SET status = 'failed', settled_at = datetime('now')
            WHERE id = ? AND status = 'reserved'
          `).run(trackingReservationId);
            return {
                status: 'insufficient_balance',
                amountMicro,
                balanceAfterMicro: wallet.balanceMicro,
            };
        }
        const promotionSettlement = settlePromotionCreditReservation(db, {
            userId: request.consumerUserId,
            walletReservationId: trackingReservationId,
            requestId: request.id,
            chargeMicro: amountMicro,
        });
        if (promotionSettlement.consumedMicro + promotionSettlement.uncoveredMicro !== amountMicro
            || promotionSettlement.uncoveredMicro !== walletChargeMicro) {
            throw new Error('Promotion and wallet fallback settlement changed during charge');
        }
        const balanceAfterMicro = wallet.balanceMicro - walletChargeMicro;
        const updated = db.prepare(`
            UPDATE users
            SET
              balance_micro =
                balance_micro - ?
            WHERE id = ?
              AND balance_micro >= ?
          `).run(walletChargeMicro, request.consumerUserId, walletChargeMicro);
        if (updated.changes !== 1) {
            // Promotion settlement already happened inside this transaction;
            // throw to roll every side effect back instead of committing a
            // partially consumed activity batch.
            throw new Error('Wallet balance changed during fallback settlement');
        }
        /*
         * 保存完整价格快照。
         *
         * 以后管理员修改价格或倍率，
         * 历史账单仍保持原始计费数据。
         */
        if (walletChargeMicro > 0) {
            db.prepare(`
            INSERT INTO wallet_transactions (
              user_id,
              type,
              delta_micro,
              balance_after_micro,
              request_id,
              platform,
              model_id,
              input_tokens,
              cached_input_tokens,
              cache_write_tokens,
              output_tokens,
              multiplier_milli,
              cached_input_multiplier_milli,
              cache_write_multiplier_milli,
              input_price_micro_per_million,
              output_price_micro_per_million,
              note
            )
            VALUES (
              ?,
              'usage',
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?,
              ?
            )
          `).run(request.consumerUserId, -walletChargeMicro, balanceAfterMicro, request.id, request.platform, request.modelId, request.inputTokens, request.cachedInputTokens, request.cacheWriteTokens, request.outputTokens, effectiveMultiplierMilli, rule.cachedInputMultiplierMilli, DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI, rule.inputPriceMicroPerMillion, rule.outputPriceMicroPerMillion, 'API usage wallet remainder after promotion credit (fallback settlement)');
        }
        const marked = db.prepare(`
            UPDATE requests
            SET
              billing_amount_micro = ?,
              billing_status =
                'charged'
            WHERE id = ?
              AND billing_status =
                'unbilled'
          `).run(amountMicro, request.id);
        if (marked.changes !== 1) {
            throw new Error('Request billing state changed during settlement');
        }
        const markedReservation = db.prepare(`
          UPDATE wallet_reservations
          SET actual_micro = ?, status = 'settled', settled_at = datetime('now')
          WHERE id = ? AND status = 'reserved'
        `).run(amountMicro, trackingReservationId);
        if (markedReservation.changes !== 1) {
            throw new Error('Fallback wallet reservation state changed during settlement');
        }
        return {
            status: 'charged',
            amountMicro,
            balanceAfterMicro,
        };
    });
    return transaction();
}
export function applyCodexGroupMultiplier(_db, _platform, _consumerApiKeyId, modelMultiplierMilli) {
    // The group control now writes the selected value directly into every
    // codex_group_models multiplier override. Settlement must apply it once.
    return modelMultiplierMilli;
}
export function getUserBillingMultiplierMilli(db, userId) {
    const row = db.prepare('SELECT billing_multiplier_milli AS multiplierMilli FROM users WHERE id = ?')
        .get(userId);
    return row ? Math.max(0, Number(row.multiplierMilli)) : 1_000;
}
export function applyUserBillingMultiplier(db, userId, multiplierMilli) {
    return Math.round(Math.max(0, multiplierMilli) * getUserBillingMultiplierMilli(db, userId) / 1_000);
}
//# sourceMappingURL=billing.js.map