import { getDb } from '../db/index.js';
import { isUnifyEnabled, getModelGroups } from './model-groups.js';
import { getModelHealthMap } from './model-health.js';
import { customProviderKeyMatchSql } from '../lib/custom-provider-pool.js';
import { requiresExplicitPromptCache } from '../lib/codex-prompt-cache.js';
import { getUserCodexUpstreamBinding, } from './user-codex-upstream-bindings.js';
export function normalizeCodexModelId(modelId) {
    return modelId === 'openai-codex/codex' ? 'codex' : modelId;
}
/**
 * Consumer keys must only discover models that can actually be called by a
 * billed user: the model is enabled, an enabled provider key can serve it, and
 * the administrator has enabled a billing rule for it.
 *
 * This deliberately stays a query-time filter. The administrator's catalog
 * and billing pages continue to use the complete model inventory.
 */
export function getConsumerCallableCanonicalIds() {
    const db = getDb();
    const health = getModelHealthMap(db);
    const providerKeyMatch = customProviderKeyMatchSql('m', 'k');
    const rows = db.prepare(`
    SELECT DISTINCT m.id AS modelDbId, m.model_id AS modelId, m.platform
    FROM models m
    JOIN model_billing_rules b
      ON b.platform = m.platform
     AND b.model_id = m.model_id
     AND b.billing_enabled = 1
     AND b.input_price_micro_per_million = 0
     AND b.output_price_micro_per_million = 0
    WHERE m.enabled = 1
      AND m.platform <> 'openai-codex'
      AND (
        EXISTS (
          SELECT 1
          FROM api_keys k
          WHERE k.platform = m.platform
            AND k.enabled = 1
            AND ${providerKeyMatch}
        )
        OR (
        m.platform = 'openai-codex'
        AND EXISTS (
          SELECT 1
          FROM codex_oauth_accounts c
          WHERE c.enabled = 1
            AND c.status IN ('healthy', 'unknown')
            AND (c.cooldown_until IS NULL OR c.cooldown_until <= datetime('now'))
        )
        )
      )
  `).all();
    const healthyRows = rows.filter(row => health[`${row.platform ?? ''}:${row.modelId}`]?.status !== 'failed');
    if (!isUnifyEnabled()) {
        return new Set(healthyRows.map(row => row.modelId));
    }
    const callableModelDbIds = new Set(healthyRows.map(row => row.modelDbId));
    return new Set(getModelGroups()
        .filter(group => group.members.some(member => callableModelDbIds.has(member.model_db_id)))
        .map(group => group.canonicalId));
}
/**
 * Apply the consumer visibility policy to a shared catalog listing.
 * Consumer callers never receive disabled, keyless, or unconfigured models.
 */
export function filterModelListingForConsumer(_listing) {
    const callableIds = getConsumerCallableCanonicalIds();
    // Build the consumer view without Codex rows before model-id de-duplication
    // or group aggregation. Filtering the already-aggregated catalog by id can
    // leak Codex ownership/capability metadata when an ordinary provider uses
    // the same model id.
    const ordinaryListing = buildModelListing({ excludeOpenAICodex: true });
    const models = ordinaryListing.models.filter(model => callableIds.has(model.id) && model.available === 1);
    // Native Codex ids remain accepted as /v1/responses compatibility aliases
    // for Codex Desktop. A universal key cannot safely use those ids on the
    // generic chat/completions surface, however, so they must not be advertised
    // by the shared /v1/models catalog.
    const contextWindows = models
        .map(model => model.contextWindow)
        .filter((value) => value != null);
    return {
        models,
        autoContextWindow: contextWindows.length ? Math.max(...contextWindows) : null,
    };
}
/**
 * Codex keys expose only the real models supported by their permitted OAuth
 * account(s). Ordinary provider models and the internal `codex` alias are
 * intentionally excluded from this listing.
 */
export function filterModelListingForCodexConsumer(_listing, keyType, consumerKeyId) {
    const rows = getCodexConsumerCallableRows(keyType, consumerKeyId);
    const models = rows.map(row => ({
        id: row.modelId,
        name: row.name,
        ownedBy: 'openai-codex',
        available: 1,
        enabled: row.enabled,
        contextWindow: row.contextWindow,
        intel: row.intel,
        platforms: ['openai-codex'],
        supportsTools: row.supportsTools === 1,
    }));
    const contexts = models.map(model => model.contextWindow).filter((value) => value != null);
    return { models, autoContextWindow: contexts.length ? Math.max(...contexts) : null };
}
function getCodexConsumerCallableRows(keyType, consumerKeyId) {
    const db = getDb();
    let upstreamBinding = null;
    if (keyType === 'codex_pool') {
        const enabledGroup = db.prepare(`
      SELECT consumer.user_id AS userId, consumer.codex_group_id AS codexGroupId
      FROM consumer_api_keys consumer
      JOIN codex_groups g
        ON g.id = consumer.codex_group_id
       AND g.enabled = 1
      WHERE consumer.id = ?
        AND consumer.key_scope = 'codex_pool'
        AND consumer.status = 'active'
      LIMIT 1
    `).get(consumerKeyId);
        if (!enabledGroup)
            return [];
        upstreamBinding = getUserCodexUpstreamBinding(db, enabledGroup.userId, enabledGroup.codexGroupId);
    }
    const accountPredicate = keyType === 'codex_pool'
        ? `a.resource_scope = 'codex_pool' AND a.enabled = 1
       AND (SELECT codex_group_id FROM consumer_api_keys WHERE id = ?) IS NOT NULL
       AND a.codex_group_id = (SELECT codex_group_id FROM consumer_api_keys WHERE id = ?)
       AND EXISTS (
         SELECT 1
         FROM codex_groups enabled_group
         JOIN codex_group_models gm ON gm.group_id = enabled_group.id
         WHERE enabled_group.id = a.codex_group_id
           AND enabled_group.enabled = 1
           AND gm.model_id = am.model_id
       )
       AND a.status IN ('healthy', 'unknown')
       AND (a.cooldown_until IS NULL OR a.cooldown_until <= datetime('now'))
       AND (a.quota_remaining_percent IS NULL OR a.quota_remaining_percent > 0
            OR (a.quota_reset_at IS NOT NULL AND datetime(a.quota_reset_at) <= datetime('now')))`
        : `EXISTS (
         SELECT 1 FROM resource_subpool_members sm
         JOIN resource_member_api_keys mk ON mk.member_id = sm.id
         JOIN resource_subpools ss ON ss.id = sm.subpool_id AND ss.status = 'active'
         JOIN resource_subpool_bindings sb ON sb.subpool_id = ss.id AND sb.status = 'active'
         WHERE mk.consumer_api_key_id = ? AND sb.codex_account_id = a.id
       )
       AND a.resource_scope = 'resource_subpool' AND a.enabled = 1
       AND a.status IN ('healthy', 'unknown')
       AND (a.cooldown_until IS NULL OR a.cooldown_until <= datetime('now'))
       AND (a.quota_remaining_percent IS NULL OR a.quota_remaining_percent > 0
            OR (a.quota_reset_at IS NOT NULL AND datetime(a.quota_reset_at) <= datetime('now')))`;
    const params = keyType === 'codex_pool' ? [consumerKeyId, consumerKeyId] : [consumerKeyId];
    const oauthCandidates = db.prepare(`
    SELECT DISTINCT a.id AS upstreamTargetId, am.model_id modelId, m.display_name name,
      m.context_window contextWindow, m.intelligence_rank intel,
      m.enabled enabled, m.supports_tools supportsTools
    FROM codex_oauth_accounts a
    JOIN codex_oauth_account_models am ON am.account_id = a.id AND am.enabled = 1
    JOIN models m ON m.platform = 'openai-codex' AND m.model_id = am.model_id AND m.enabled = 1
    JOIN model_billing_rules b ON b.platform = 'openai-codex' AND b.model_id = am.model_id AND b.billing_enabled = 1
    WHERE ${accountPredicate}
      AND am.model_id <> 'codex'
    ORDER BY m.intelligence_rank ASC, am.model_id ASC
  `).all(...params);
    const oauthRows = oauthCandidates
        // Shared Codex keys must remain able to exercise their locally authorised
        // OAuth accounts, including GPT-5.6+, so administrators can verify those
        // accounts independently from third-party relay certification. Dedicated
        // resource-subpool keys retain the fail-closed 5.6+ boundary.
        .filter((row) => keyType === 'codex_pool' || !requiresExplicitPromptCache(row.modelId))
        .filter((row) => !upstreamBinding || (upstreamBinding.targetType === 'oauth'
        && row.upstreamTargetId === upstreamBinding.targetId))
        .map(({ upstreamTargetId: _upstreamTargetId, ...row }) => row);
    // A relay source is deliberately absent from resource_subpool scheduling.
    // For a normal shared Codex key, merge its explicit public-model mappings
    // with OAuth account capabilities. A relay can only narrow a catalog model's
    // tool/vision capability; it must never manufacture a new public model or
    // bypass the administrator's Codex billing rule.
    if (keyType !== 'codex_pool')
        return oauthRows;
    const merged = new Map();
    for (const row of oauthRows)
        merged.set(row.modelId, { ...row });
    const relayRows = db.prepare(`
    SELECT DISTINCT
      s.id AS upstreamTargetId,
      sm.public_model_id AS modelId,
      sm.upstream_model_id AS upstreamModelId,
      sm.prompt_cache_status AS promptCacheStatus,
      sm.prompt_cache_checked_at AS promptCacheCheckedAt,
      s.protocol AS relayProtocol,
      m.display_name AS name,
      m.context_window AS contextWindow,
      m.intelligence_rank AS intel,
      m.enabled AS enabled,
      1 AS supportsTools
    FROM codex_relay_sources s
    JOIN codex_relay_source_models sm
      ON sm.source_id = s.id
     AND sm.enabled = 1
    JOIN models m
      ON m.platform = 'openai-codex'
     AND m.model_id = sm.public_model_id
     AND m.enabled = 1
    JOIN model_billing_rules b
      ON b.platform = 'openai-codex'
     AND b.model_id = sm.public_model_id
     AND b.billing_enabled = 1
    JOIN consumer_api_keys consumer
      ON consumer.id = ?
     AND consumer.key_scope = 'codex_pool'
     AND consumer.status = 'active'
    WHERE s.enabled = 1
      AND EXISTS (
        SELECT 1
        FROM codex_relay_source_keys source_key
        JOIN api_keys source_api_key
         ON source_api_key.id = source_key.api_key_id
         AND source_api_key.role = 'codex_relay'
         AND source_api_key.platform = 'custom'
         AND source_api_key.enabled = 1
        WHERE source_key.source_id = s.id
          AND source_key.enabled = 1
          AND source_key.status IN ('healthy', 'unknown')
          AND (
            source_key.cooldown_until IS NULL
            OR datetime(source_key.cooldown_until) <= datetime('now')
          )
      )
      AND consumer.codex_group_id IS NOT NULL
      AND consumer.codex_group_id = s.codex_group_id
      AND EXISTS (
        SELECT 1 FROM codex_groups enabled_group
        WHERE enabled_group.id = s.codex_group_id AND enabled_group.enabled = 1
      )
      AND EXISTS (
        SELECT 1
        FROM codex_group_models group_model
        WHERE group_model.group_id = s.codex_group_id
          AND group_model.model_id = sm.public_model_id
      )
    ORDER BY m.intelligence_rank ASC, sm.public_model_id ASC
  `).all(consumerKeyId);
    for (const row of relayRows.filter((candidate) => (!upstreamBinding || (upstreamBinding.targetType === 'relay'
        && candidate.upstreamTargetId === upstreamBinding.targetId)))) {
        const existing = merged.get(row.modelId);
        if (!existing) {
            merged.set(row.modelId, { ...row });
            continue;
        }
        existing.supportsTools = Math.max(existing.supportsTools, row.supportsTools);
        existing.enabled = Math.max(existing.enabled, row.enabled);
    }
    return [...merged.values()].sort((a, b) => a.intel - b.intel || a.modelId.localeCompare(b.modelId));
}
export function getCodexConsumerCallableModelIds(keyType, consumerKeyId) {
    return new Set(getCodexConsumerCallableRows(keyType, consumerKeyId).map(row => row.modelId));
}
/** Resolve an explicit Codex model against the accounts available to one key. */
export function getCodexConsumerModelDbId(keyType, consumerKeyId, requestedModel) {
    const modelId = normalizeCodexModelId(requestedModel);
    if (modelId !== 'codex' && !getCodexConsumerCallableModelIds(keyType, consumerKeyId).has(modelId)) {
        return null;
    }
    const row = getDb().prepare(`
    SELECT id
    FROM models
    WHERE platform = 'openai-codex' AND model_id = ? AND enabled = 1
    LIMIT 1
  `).get(modelId);
    return row?.id ?? null;
}
/**
 * Resolve a model that belongs to the consumer's configured Codex group
 * without requiring a currently healthy upstream. A compacted conversation
 * already carries an upstream pin, so a temporary source outage must reach
 * the router and become its explicit 503 instead of an earlier model 400.
 */
export function getCodexConsumerGroupModelDbId(keyType, consumerKeyId, requestedModel) {
    const modelId = normalizeCodexModelId(requestedModel);
    if (modelId === 'codex')
        return null;
    const row = getDb().prepare(`
    SELECT m.id
    FROM consumer_api_keys consumer
    JOIN codex_groups group_row
      ON group_row.id = consumer.codex_group_id
     AND group_row.enabled = 1
    JOIN codex_group_models group_model
      ON group_model.group_id = group_row.id
     AND group_model.model_id = ?
    JOIN models m
      ON m.platform = 'openai-codex'
     AND m.model_id = group_model.model_id
     AND m.enabled = 1
    WHERE consumer.id = ?
      AND consumer.key_scope = ?
      AND consumer.status = 'active'
    LIMIT 1
  `).get(modelId, consumerKeyId, keyType);
    return row?.id ?? null;
}
export function buildModelListing(options = {}) {
    const providerKeyMatch = customProviderKeyMatchSql('m', 'k');
    const availableExpr = `
    (CASE WHEN m.enabled = 1 AND (
      EXISTS (
        SELECT 1 FROM api_keys k
        WHERE k.platform = m.platform
          AND k.enabled = 1
          AND ${providerKeyMatch}
      )
      OR (
        m.platform = 'openai-codex'
        AND EXISTS (
          SELECT 1 FROM codex_oauth_accounts c
          WHERE c.enabled = 1
            AND c.status IN ('healthy', 'unknown')
            AND (c.cooldown_until IS NULL OR c.cooldown_until <= datetime('now'))
        )
      )
      OR (
        m.platform = 'openai-codex'
        AND EXISTS (
          SELECT 1
          FROM codex_relay_sources relay
          JOIN codex_relay_source_models relay_model
            ON relay_model.source_id = relay.id
           AND relay_model.public_model_id = m.model_id
           AND relay_model.enabled = 1
          WHERE relay.enabled = 1
            AND EXISTS (
              SELECT 1
              FROM codex_relay_source_keys relay_source_key
              JOIN api_keys relay_api_key
                ON relay_api_key.id = relay_source_key.api_key_id
               AND relay_api_key.role = 'codex_relay'
               AND relay_api_key.platform = 'custom'
              WHERE relay_source_key.source_id = relay.id
                AND relay_source_key.enabled = 1
                AND relay_source_key.status IN ('healthy', 'unknown')
                AND (
                  relay_source_key.cooldown_until IS NULL
                  OR datetime(relay_source_key.cooldown_until) <= datetime('now')
                )
            )
        )
      )
    ) THEN 1 ELSE 0 END)`;
    const db = getDb();
    let allListed;
    if (isUnifyEnabled()) {
        const rows = db.prepare(`
      SELECT m.id, m.platform, m.intelligence_rank, m.context_window, m.supports_tools,
             m.enabled AS enabled, ${availableExpr} AS available
      FROM models m
    `).all().filter(row => !options.excludeOpenAICodex || row.platform !== 'openai-codex');
        const byId = new Map(rows.map(r => [r.id, r]));
        allListed = getModelGroups().flatMap(g => {
            const infos = g.members.map(m => byId.get(m.model_db_id)).filter(Boolean);
            if (infos.length === 0)
                return [];
            const ctxs = infos.map(i => i.context_window).filter((c) => c != null);
            return [{
                    id: g.canonicalId,
                    name: g.groupLabel,
                    ownedBy: 'freellmapi',
                    available: infos.some(i => i.available === 1) ? 1 : 0,
                    enabled: infos.some(i => i.enabled === 1) ? 1 : 0,
                    contextWindow: ctxs.length ? Math.max(...ctxs) : null,
                    intel: infos.length ? Math.min(...infos.map(i => i.intelligence_rank)) : Number.MAX_SAFE_INTEGER,
                    platforms: [...new Set(infos.map(i => i.platform))],
                    supportsTools: infos.some(i => i.supports_tools === 1),
                }];
        });
    }
    else {
        // Unify OFF: one entry per model_id (dedup picks the available, smartest
        // representative row).
        const models = db.prepare(`
      SELECT platform, model_id, display_name, context_window, enabled, available, intelligence_rank, id, supports_tools
      FROM (
        SELECT m.platform, m.model_id, m.display_name, m.context_window, m.intelligence_rank, m.id, m.supports_tools,
               m.enabled AS enabled,
               ${availableExpr} AS available,
               ROW_NUMBER() OVER (
                 PARTITION BY m.model_id
                 ORDER BY ${availableExpr} DESC, m.intelligence_rank ASC, m.id ASC
               ) AS rn
        FROM models m
        ${options.excludeOpenAICodex ? "WHERE m.platform <> 'openai-codex'" : ''}
      )
      WHERE rn = 1
    `).all();
        allListed = models.map(m => ({
            id: m.model_id, name: m.display_name, ownedBy: m.platform,
            available: m.available, enabled: m.enabled, contextWindow: m.context_window,
            intel: m.intelligence_rank,
            platforms: [m.platform],
            supportsTools: m.supports_tools === 1,
        }));
    }
    // Stable order: usable first, then enabled, then smartest, then name.
    allListed.sort((a, b) => (b.available - a.available) || (b.enabled - a.enabled) || (a.intel - b.intel) || a.name.localeCompare(b.name));
    const availableContextWindows = allListed
        .filter(m => m.available === 1 && m.contextWindow != null)
        .map(m => m.contextWindow);
    const autoContextWindow = availableContextWindows.length > 0
        ? Math.max(...availableContextWindows)
        : null;
    return { models: allListed, autoContextWindow };
}
//# sourceMappingURL=model-listing.js.map