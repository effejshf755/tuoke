import type { Db } from '../db/types.js';
export declare const RECHARGE_BONUS_OFFER_CODE = "recharge_90_get_100";
export declare const SPRINT_PROMOTION_OFFER_CODE = "wallet_20_get_25_24h";
export type PromotionOfferKind = 'recharge_bonus' | 'wallet_sprint';
export type PromotionPaymentSource = 'alipay' | 'wallet';
export interface PromotionOffer {
    id: number;
    code: string;
    name: string;
    description: string | null;
    offerKind: PromotionOfferKind;
    paymentSource: PromotionPaymentSource;
    priceMicro: number;
    permanentCreditMicro: number;
    limitedCreditMicro: number;
    validitySeconds: number | null;
    enabled: boolean;
    sortOrder: number;
}
export declare function getPromotionOffer(db: Db, code: string, options?: {
    includeDisabled?: boolean;
}): PromotionOffer | null;
export declare function listPromotionOffers(db: Db, options?: {
    includeDisabled?: boolean;
}): PromotionOffer[];
export declare function requirePromotionOffer(db: Db, code: string, expected?: {
    offerKind?: PromotionOfferKind;
    paymentSource?: PromotionPaymentSource;
}): PromotionOffer;
export type PromotionOfferErrorCode = 'offer_not_found' | 'invalid_offer_kind' | 'invalid_payment_source';
export declare class PromotionOfferError extends Error {
    readonly code: PromotionOfferErrorCode;
    constructor(code: PromotionOfferErrorCode, message: string);
}
//# sourceMappingURL=promotion-offers.d.ts.map