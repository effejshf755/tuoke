import { randomBytes } from 'node:crypto';
import { relayMappingRequiresExplicitPromptCache } from '../lib/codex-prompt-cache.js';
import { decrypt } from '../lib/crypto.js';
import { sanitizeProviderErrorMessage } from '../lib/error-redaction.js';
import { prepareNativeResponsesRequestBody } from '../lib/native-responses-relay.js';
import { proxyFetch } from '../lib/proxy.js';
const ROUND_TRANSPORTS = [
    'json',
    'sse',
    'json',
    'sse',
    'json',
];
const MIN_CACHE_TOKENS = 1_024;
const WARM_ROUND_COUNT = 4;
const MIN_AGGREGATE_READ_RATIO = 0.8;
const DEFAULT_STAGE_TIMEOUT_MS = 20_000;
const DEFAULT_OVERALL_TIMEOUT_MS = 110_000;
const MAX_JSON_RESPONSE_BYTES = 256 * 1024;
const MAX_SSE_RESPONSE_BYTES = 512 * 1024;
const MAX_CONCURRENT_TESTS = 2;
const runningTests = new Set();
const INPUT_TOKEN_PATHS = [
    ['input_tokens'],
    ['prompt_tokens'],
    ['inputTokens'],
    ['promptTokens'],
];
const OUTPUT_TOKEN_PATHS = [
    ['output_tokens'],
    ['completion_tokens'],
    ['outputTokens'],
    ['completionTokens'],
];
const TOTAL_TOKEN_PATHS = [
    ['total_tokens'],
    ['totalTokens'],
];
const CACHED_TOKEN_PATHS = [
    ['input_tokens_details', 'cached_tokens'],
    ['prompt_tokens_details', 'cached_tokens'],
    ['input_tokens_details', 'cache_read_tokens'],
    ['prompt_tokens_details', 'cache_read_tokens'],
    ['inputTokensDetails', 'cachedTokens'],
    ['promptTokensDetails', 'cachedTokens'],
    ['cache_read_input_tokens'],
    ['cacheReadInputTokens'],
    ['cached_input_tokens'],
    ['cachedInputTokens'],
    ['input_cached_tokens'],
    ['inputCachedTokens'],
    ['cached_tokens'],
    ['cachedTokens'],
];
const CACHE_WRITE_TOKEN_PATHS = [
    ['input_tokens_details', 'cache_write_tokens'],
    ['prompt_tokens_details', 'cache_write_tokens'],
    ['input_tokens_details', 'cache_creation_tokens'],
    ['prompt_tokens_details', 'cache_creation_tokens'],
    ['inputTokensDetails', 'cacheWriteTokens'],
    ['promptTokensDetails', 'cacheWriteTokens'],
    ['inputTokensDetails', 'cacheCreationTokens'],
    ['promptTokensDetails', 'cacheCreationTokens'],
    ['cache_creation_input_tokens'],
    ['cacheCreationInputTokens'],
    ['cache_write_input_tokens'],
    ['cacheWriteInputTokens'],
    ['cache_write_tokens'],
    ['cacheWriteTokens'],
    ['cache_creation_tokens'],
    ['cacheCreationTokens'],
];
function isRecord(value) {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function valueAtPath(source, path) {
    let current = source;
    for (const segment of path) {
        if (!isRecord(current) || !Object.hasOwn(current, segment))
            return { found: false };
        current = current[segment];
    }
    return { found: true, value: current };
}
function requiredTokenCount(usage, label, paths) {
    const values = [];
    for (const path of paths) {
        const candidate = valueAtPath(usage, path);
        if (!candidate.found)
            continue;
        if (typeof candidate.value !== 'number'
            || !Number.isSafeInteger(candidate.value)
            || candidate.value < 0) {
            throw new Error(`Usage ${label} must be a non-negative integer`);
        }
        values.push(candidate.value);
    }
    if (values.length === 0)
        throw new Error(`Usage is missing ${label}`);
    if (values.some((value) => value !== values[0])) {
        throw new Error(`Usage contains conflicting ${label} values`);
    }
    return values[0];
}
/** Strictly parse the canonical Responses counters plus common aliases. */
export function parseCodexRelayPromptCacheUsage(payload) {
    if (!isRecord(payload) || !isRecord(payload.usage)) {
        throw new Error('Completed response is missing usage');
    }
    const usage = payload.usage;
    const inputTokens = requiredTokenCount(usage, 'input tokens', INPUT_TOKEN_PATHS);
    const outputTokens = requiredTokenCount(usage, 'output tokens', OUTPUT_TOKEN_PATHS);
    const totalTokens = requiredTokenCount(usage, 'total tokens', TOTAL_TOKEN_PATHS);
    const cachedTokens = requiredTokenCount(usage, 'cached tokens', CACHED_TOKEN_PATHS);
    const cacheWriteTokens = requiredTokenCount(usage, 'cache write tokens', CACHE_WRITE_TOKEN_PATHS);
    if (totalTokens !== inputTokens + outputTokens) {
        throw new Error('Usage total tokens do not equal input plus output tokens');
    }
    if (cachedTokens > inputTokens) {
        throw new Error('Usage cached tokens exceed input tokens');
    }
    if (cacheWriteTokens > inputTokens) {
        throw new Error('Usage cache write tokens exceed input tokens');
    }
    return {
        input_tokens: inputTokens,
        output_tokens: outputTokens,
        total_tokens: totalTokens,
        cached_tokens: cachedTokens,
        cache_write_tokens: cacheWriteTokens,
    };
}
function assertCompletedResponse(value) {
    if (!isRecord(value))
        throw new Error('Responses payload is not a JSON object');
    if (value.error != null || value.status === 'failed') {
        throw new Error('Responses payload reported a failure');
    }
    if (typeof value.id !== 'string' || !value.id.trim()) {
        throw new Error('Responses payload is missing an id');
    }
    if (value.object !== 'response') {
        throw new Error('Responses payload has an invalid object field');
    }
    if (value.status !== 'completed') {
        throw new Error('Responses payload did not reach completed status');
    }
    if (typeof value.model !== 'string' || !value.model.trim()) {
        throw new Error('Responses payload is missing a model');
    }
    return value;
}
function parseJsonCompletedResponse(body, contentType) {
    if (!/\bjson\b/i.test(contentType)) {
        throw new Error('Non-streaming probe did not return application/json');
    }
    let parsed;
    try {
        parsed = JSON.parse(body);
    }
    catch {
        throw new Error('Non-streaming probe returned malformed JSON');
    }
    return assertCompletedResponse(parsed);
}
function parseSseCompletedResponse(body, contentType) {
    if (!/^text\/event-stream\b/i.test(contentType)) {
        throw new Error('Streaming probe did not return text/event-stream');
    }
    let completed = null;
    for (const frame of body.replace(/\r\n/g, '\n').split('\n\n')) {
        if (!frame.trim())
            continue;
        let eventName = '';
        const dataLines = [];
        for (const line of frame.split('\n')) {
            if (line.startsWith('event:'))
                eventName = line.slice(6).trim();
            if (line.startsWith('data:'))
                dataLines.push(line.slice(5).trimStart());
        }
        const data = dataLines.join('\n').trim();
        if (!data || data === '[DONE]')
            continue;
        let event;
        try {
            event = JSON.parse(data);
        }
        catch {
            throw new Error('Responses stream contained malformed JSON');
        }
        if (!isRecord(event) || typeof event.type !== 'string') {
            throw new Error('Responses stream contained an untyped event');
        }
        if (eventName && eventName !== event.type) {
            throw new Error('Responses stream event name did not match its payload type');
        }
        if (event.type === 'error' || event.type === 'response.failed') {
            throw new Error('Responses stream ended with an error event');
        }
        if (event.type === 'response.completed') {
            completed = assertCompletedResponse(event.response);
        }
    }
    if (!completed)
        throw new Error('Responses stream omitted response.completed');
    return completed;
}
async function readBoundedResponseBody(response, maxBytes) {
    const declaredLength = Number(response.headers.get('content-length'));
    if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
        await response.body?.cancel().catch(() => undefined);
        throw new Error(`Probe response exceeded the ${maxBytes}-byte safety limit`);
    }
    if (!response.body)
        return '';
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let received = 0;
    let result = '';
    try {
        while (true) {
            const chunk = await reader.read();
            if (chunk.done)
                break;
            received += chunk.value.byteLength;
            if (received > maxBytes) {
                await reader.cancel().catch(() => undefined);
                throw new Error(`Probe response exceeded the ${maxBytes}-byte safety limit`);
            }
            result += decoder.decode(chunk.value, { stream: true });
        }
        result += decoder.decode();
        return result;
    }
    finally {
        reader.releaseLock();
    }
}
function relayResponsesUrl(baseUrl) {
    return `${baseUrl.replace(/\/+$/, '')}/responses`;
}
async function defaultTransport(request) {
    return proxyFetch(request.endpoint, {
        method: 'POST',
        headers: {
            Authorization: `Bearer ${request.apiKey}`,
            'Content-Type': 'application/json',
            Accept: request.stream ? 'text/event-stream' : 'application/json',
        },
        body: JSON.stringify(request.body),
        signal: request.signal,
    }, 'custom', 'chat', request.timeoutMs);
}
function makeProbeCacheKey() {
    return `tuoke:probe:${randomBytes(24).toString('base64url')}`;
}
function makeProbeNonce() {
    return randomBytes(16).toString('hex');
}
function makeStablePrefix(nonce) {
    // Repeating a common standalone word gives a stable prefix comfortably over
    // 1,024 tokens without relying on an application tokenizer. The cold-write
    // usage gate below remains the authoritative proof of its cacheable size.
    return [
        `Tuoke explicit prompt-cache compatibility probe ${nonce}.`,
        Array.from({ length: 1_600 }, () => 'cache').join(' '),
        'The stable prefix ends here. Follow the final user instruction only.',
    ].join('\n');
}
function makeRequestBody(args) {
    return prepareNativeResponsesRequestBody({
        model: args.upstreamModelId,
        input: [
            {
                role: 'developer',
                content: [{
                        type: 'input_text',
                        text: args.stablePrefix,
                        prompt_cache_breakpoint: { mode: 'explicit' },
                    }],
            },
            {
                role: 'user',
                content: [{
                        type: 'input_text',
                        text: `Dynamic suffix ${args.nonce}-${args.round}. Reply exactly CACHE_PROBE_OK.`,
                    }],
            },
        ],
        prompt_cache_key: args.cacheKey,
        prompt_cache_options: { mode: 'explicit', ttl: '30m' },
        max_output_tokens: 32,
    }, args.upstreamModelId, args.stream);
}
function redactProbeError(error, secrets) {
    let message = error instanceof Error ? error.message : String(error ?? 'Prompt-cache probe failed');
    for (const secret of [
        secrets.apiKey,
        secrets.cacheKey,
        secrets.nonce,
        secrets.stablePrefix,
        secrets.endpoint,
    ]) {
        if (secret)
            message = message.split(secret).join('[redacted]');
    }
    return sanitizeProviderErrorMessage(message);
}
function validateRoundUsage(round, usage) {
    if (round === 1) {
        if (usage.cached_tokens !== 0) {
            return 'Cold round reported cached tokens instead of a clean cache write';
        }
        if (usage.cache_write_tokens < MIN_CACHE_TOKENS) {
            return `Cold round wrote fewer than ${MIN_CACHE_TOKENS} cache tokens`;
        }
        return null;
    }
    if (usage.cached_tokens < MIN_CACHE_TOKENS) {
        return `Warm round read fewer than ${MIN_CACHE_TOKENS} cached tokens`;
    }
    if (usage.cache_write_tokens !== 0) {
        return 'Warm round rewrote the cache instead of reusing it';
    }
    return null;
}
function mappingRow(db, sourceId, publicModelId) {
    return db.prepare(`
    SELECT
      s.id AS source_id,
      s.protocol,
      selected_key.api_key_id,
      COALESCE(NULLIF(TRIM(s.base_url), ''), k.base_url) AS base_url,
      k.encrypted_key,
      k.iv,
      k.auth_tag,
      sm.public_model_id,
      sm.upstream_model_id
    FROM codex_relay_sources s
    LEFT JOIN codex_relay_source_keys selected_key
      ON selected_key.api_key_id = (
        SELECT candidate.api_key_id
        FROM codex_relay_source_keys candidate
        JOIN api_keys candidate_key
          ON candidate_key.id = candidate.api_key_id
         AND candidate_key.role = 'codex_relay'
         AND candidate_key.platform = 'custom'
         AND candidate_key.enabled = 1
        WHERE candidate.source_id = s.id
          AND candidate.enabled = 1
          AND candidate.status IN ('healthy', 'unknown')
          AND (
            candidate.cooldown_until IS NULL
            OR datetime(candidate.cooldown_until) <= datetime('now')
          )
        ORDER BY candidate.priority ASC,
                 COALESCE(candidate.last_used_at, '1970-01-01') ASC,
                 candidate.api_key_id ASC
        LIMIT 1
      )
    LEFT JOIN api_keys k
     ON k.id = selected_key.api_key_id
     AND k.role = 'codex_relay'
     AND k.platform = 'custom'
    JOIN codex_relay_source_models sm
      ON sm.source_id = s.id
     AND sm.public_model_id = ?
    WHERE s.id = ?
  `).get(publicModelId, sourceId) ?? null;
}
/**
 * Test exactly one source/model mapping with five native Responses requests:
 * JSON, SSE, JSON, SSE, JSON. This service deliberately does not persist the
 * result; callers can use their own revision/CAS rules when storing it.
 */
export async function testCodexRelayPromptCacheCompatibility(db, sourceId, publicModelId, options = {}) {
    if (!Number.isSafeInteger(sourceId) || sourceId <= 0) {
        throw new Error('A valid relay source id is required');
    }
    const normalizedPublicModelId = publicModelId.trim();
    if (!normalizedPublicModelId)
        throw new Error('A public model id is required');
    const mapping = mappingRow(db, sourceId, normalizedPublicModelId);
    if (!mapping)
        throw new Error('Codex relay model mapping not found');
    if (mapping.protocol !== 'responses') {
        throw new Error('Prompt-cache compatibility testing requires the native Responses protocol');
    }
    if (!relayMappingRequiresExplicitPromptCache(mapping.public_model_id, mapping.upstream_model_id)) {
        throw new Error('Prompt-cache compatibility testing is limited to GPT-5.6+ mappings');
    }
    if (mapping.api_key_id === null
        || mapping.base_url === null
        || mapping.encrypted_key === null
        || mapping.iv === null
        || mapping.auth_tag === null) {
        throw new Error('Prompt-cache compatibility testing requires an available relay API key');
    }
    const runId = `${sourceId}:${normalizedPublicModelId}`;
    if (runningTests.has(runId)) {
        throw new Error('A prompt-cache compatibility test is already running for this mapping');
    }
    if (runningTests.size >= MAX_CONCURRENT_TESTS) {
        throw new Error('Prompt-cache compatibility test concurrency limit reached');
    }
    const transport = options.transport ?? defaultTransport;
    const stageTimeoutMs = Math.max(1, options.stageTimeoutMs ?? DEFAULT_STAGE_TIMEOUT_MS);
    const overallTimeoutMs = Math.max(stageTimeoutMs, options.overallTimeoutMs ?? DEFAULT_OVERALL_TIMEOUT_MS);
    const startedAt = new Date().toISOString();
    const deadlineAt = Date.now() + overallTimeoutMs;
    const apiKey = decrypt(mapping.encrypted_key, mapping.iv, mapping.auth_tag);
    const endpoint = relayResponsesUrl(mapping.base_url);
    const cacheKey = makeProbeCacheKey();
    const nonce = makeProbeNonce();
    const stablePrefix = makeStablePrefix(nonce);
    const secrets = {
        apiKey,
        cacheKey,
        nonce,
        stablePrefix,
        endpoint,
    };
    const rounds = [];
    let requestsSent = 0;
    runningTests.add(runId);
    try {
        for (let index = 0; index < ROUND_TRANSPORTS.length; index += 1) {
            const round = (index + 1);
            const roundTransport = ROUND_TRANSPORTS[index];
            const stream = roundTransport === 'sse';
            const remainingMs = deadlineAt - Date.now();
            if (remainingMs <= 0) {
                rounds.push({
                    round,
                    transport: roundTransport,
                    status: 'failed',
                    latency_ms: 0,
                    message: 'Probe reached its overall safety deadline',
                });
                continue;
            }
            const timeoutMs = Math.min(stageTimeoutMs, remainingMs);
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), timeoutMs);
            const started = Date.now();
            const body = makeRequestBody({
                upstreamModelId: mapping.upstream_model_id,
                cacheKey,
                nonce,
                stablePrefix,
                round,
                stream,
            });
            requestsSent += 1;
            try {
                const response = await transport({
                    endpoint,
                    apiKey,
                    body,
                    stream,
                    signal: controller.signal,
                    timeoutMs,
                });
                const responseBody = await readBoundedResponseBody(response, stream ? MAX_SSE_RESPONSE_BYTES : MAX_JSON_RESPONSE_BYTES);
                if (!response.ok) {
                    throw new Error(`Prompt-cache probe received HTTP ${response.status}`);
                }
                const completed = stream
                    ? parseSseCompletedResponse(responseBody, response.headers.get('content-type') ?? '')
                    : parseJsonCompletedResponse(responseBody, response.headers.get('content-type') ?? '');
                const usage = parseCodexRelayPromptCacheUsage(completed);
                const usageFailure = validateRoundUsage(round, usage);
                rounds.push({
                    round,
                    transport: roundTransport,
                    status: usageFailure ? 'failed' : 'passed',
                    latency_ms: Math.max(0, Date.now() - started),
                    message: usageFailure ?? (round === 1
                        ? 'Cold round reported a valid explicit cache write'
                        : 'Warm round reused the explicit cache without rewriting it'),
                    usage,
                });
            }
            catch (error) {
                rounds.push({
                    round,
                    transport: roundTransport,
                    status: 'failed',
                    latency_ms: Math.max(0, Date.now() - started),
                    message: redactProbeError(error, secrets),
                });
            }
            finally {
                clearTimeout(timeout);
            }
        }
        const coldRound = rounds[0];
        const coldWriteTokens = coldRound?.status === 'passed'
            ? coldRound.usage?.cache_write_tokens ?? null
            : null;
        const warmRounds = rounds.slice(1);
        const warmHitCount = warmRounds.filter((round) => round.status === 'passed').length;
        const totalWarmCachedTokens = warmRounds.reduce((total, round) => total + (round.usage?.cached_tokens ?? 0), 0);
        const requiredWarmCachedTokens = coldWriteTokens == null
            ? null
            : Math.ceil(coldWriteTokens * WARM_ROUND_COUNT * MIN_AGGREGATE_READ_RATIO);
        const aggregateReadThresholdMet = requiredWarmCachedTokens != null
            && totalWarmCachedTokens >= requiredWarmCachedTokens;
        const coldPassed = coldRound?.status === 'passed';
        const overallStatus = !coldPassed
            ? 'incompatible'
            : warmHitCount === WARM_ROUND_COUNT && aggregateReadThresholdMet
                ? 'compatible'
                : warmHitCount === WARM_ROUND_COUNT - 1
                    ? 'partial'
                    : 'incompatible';
        return {
            version: 1,
            protocol: 'responses',
            source_id: sourceId,
            public_model_id: mapping.public_model_id.slice(0, 300),
            upstream_model_id: mapping.upstream_model_id.slice(0, 300),
            started_at: startedAt,
            completed_at: new Date().toISOString(),
            overall_status: overallStatus,
            requests_sent: requestsSent,
            cold_write_tokens: coldWriteTokens,
            warm_hit_count: warmHitCount,
            total_warm_cached_tokens: totalWarmCachedTokens,
            required_warm_cached_tokens: requiredWarmCachedTokens,
            aggregate_read_threshold_met: aggregateReadThresholdMet,
            rounds,
        };
    }
    finally {
        runningTests.delete(runId);
    }
}
//# sourceMappingURL=codex-relay-prompt-cache.js.map