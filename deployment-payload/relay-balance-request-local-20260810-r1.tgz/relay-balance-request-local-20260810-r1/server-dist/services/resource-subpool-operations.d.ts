import type { Db } from '../db/types.js';
export declare function pauseResourceSubpool(db: Db, subpoolId: number, adminId: number): {
    subpoolId: number;
    status: "paused";
};
export declare function resumeResourceSubpool(db: Db, subpoolId: number, adminId: number): {
    subpoolId: number;
    status: "active";
};
export declare function unbindResourceSubpoolAccount(db: Db, subpoolId: number, adminId: number): {
    subpoolId: number;
    accountId: number;
    status: "paused";
};
export declare function changeResourceSubpoolAccount(db: Db, input: {
    subpoolId: number;
    accountId: number;
    adminId: number;
}): {
    subpoolId: number;
    previousAccountId: number | null;
    accountId: number;
    status: "active" | "paused";
};
//# sourceMappingURL=resource-subpool-operations.d.ts.map