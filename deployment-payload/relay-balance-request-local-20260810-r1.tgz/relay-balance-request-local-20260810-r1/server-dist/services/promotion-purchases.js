import { randomUUID } from 'node:crypto';
import { createPromotionCreditGrant } from './promotion-credits.js';
import { requirePromotionOffer } from './promotion-offers.js';
export class PromotionPurchaseError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.code = code;
        this.name = 'PromotionPurchaseError';
    }
}
const PURCHASE_SELECT = `
  SELECT id, purchase_no AS purchaseNo, user_id AS userId, offer_id AS offerId,
    offer_code_snapshot AS offerCode, price_micro AS priceMicro,
    permanent_credit_micro AS permanentCreditMicro,
    limited_credit_micro AS limitedCreditMicro, validity_seconds AS validitySeconds,
    status, wallet_transaction_id AS walletTransactionId,
    created_at AS createdAt, paid_at AS paidAt, refunded_at AS refundedAt
  FROM promotion_purchases
`;
export function getPromotionPurchase(db, purchaseId) {
    return db.prepare(`${PURCHASE_SELECT} WHERE id = ?`).get(purchaseId) ?? null;
}
export function listUserPromotionPurchases(db, userId, limit = 100) {
    const requestedLimit = Number.isFinite(limit) ? Math.trunc(limit) : 100;
    const safeLimit = Math.min(500, Math.max(1, requestedLimit));
    return db.prepare(`
    ${PURCHASE_SELECT}
    WHERE user_id = ?
    ORDER BY id DESC
    LIMIT ?
  `).all(userId, safeLimit);
}
function getGrantForPurchase(db, purchaseId) {
    const row = db.prepare(`
    SELECT id FROM promotion_credit_grants WHERE purchase_id = ?
  `).get(purchaseId);
    if (!row)
        throw new PromotionPurchaseError('purchase_conflict', 'Promotion purchase grant is missing');
    const grant = db.prepare(`
    SELECT id, user_id AS userId, offer_id AS offerId, purchase_id AS purchaseId,
      recharge_order_id AS rechargeOrderId, granted_micro AS grantedMicro,
      COALESCE((
        SELECT SUM(-remaining_delta_micro)
        FROM promotion_credit_ledger
        WHERE grant_id = promotion_credit_grants.id AND event_type = 'usage'
      ), 0) AS usedMicro,
      remaining_micro AS remainingMicro, reserved_micro AS reservedMicro,
      expires_at AS expiresAt, status, created_at AS createdAt
    FROM promotion_credit_grants WHERE id = ?
  `).get(row.id);
    if (!grant)
        throw new PromotionPurchaseError('purchase_conflict', 'Promotion purchase grant is missing');
    const unexpired = Date.parse(`${grant.expiresAt.replace(' ', 'T')}Z`) > Date.now();
    const expiredByTime = grant.status === 'active' && !unexpired;
    return {
        ...grant,
        status: expiredByTime ? 'expired' : grant.status,
        remainingMicro: expiredByTime ? 0 : grant.remainingMicro,
        availableMicro: grant.status === 'active' && unexpired
            ? Math.max(0, grant.remainingMicro - grant.reservedMicro)
            : 0,
    };
}
export function purchaseWalletPromotionOffer(db, input) {
    const idempotencyKey = input.idempotencyKey.trim();
    if (!idempotencyKey || idempotencyKey.length > 200) {
        throw new PromotionPurchaseError('invalid_idempotency_key', 'A valid idempotency key is required');
    }
    return db.transaction(() => {
        const existing = db.prepare(`
      ${PURCHASE_SELECT}
      WHERE user_id = ? AND idempotency_key = ?
      LIMIT 1
    `).get(input.userId, idempotencyKey);
        if (existing) {
            if (existing.offerCode !== input.offerCode) {
                throw new PromotionPurchaseError('purchase_conflict', 'Idempotency key belongs to a different promotion purchase');
            }
            const wallet = db.prepare(`
        SELECT balance_micro AS balanceMicro FROM users WHERE id = ?
      `).get(input.userId);
            if (!wallet)
                throw new PromotionPurchaseError('purchase_conflict', 'Promotion buyer no longer exists');
            return {
                purchase: existing,
                grant: getGrantForPurchase(db, existing.id),
                balanceAfterMicro: wallet.balanceMicro,
                alreadyProcessed: true,
            };
        }
        let offer;
        try {
            offer = requirePromotionOffer(db, input.offerCode, {
                offerKind: 'wallet_sprint',
                paymentSource: 'wallet',
            });
        }
        catch {
            throw new PromotionPurchaseError('offer_not_available', 'Wallet promotion offer is unavailable');
        }
        if (offer.permanentCreditMicro !== 0
            || offer.limitedCreditMicro <= 0
            || offer.validitySeconds === null) {
            throw new PromotionPurchaseError('offer_not_available', 'Wallet promotion offer is misconfigured');
        }
        // API requests intentionally do not freeze a conservative maximum-output
        // estimate. Prevent a package purchase from spending the same permanent
        // wallet funds while a paid request is still awaiting final settlement.
        const inFlightRequest = db.prepare(`
      SELECT 1
      FROM wallet_reservations
      WHERE user_id = ? AND status = 'reserved'
      LIMIT 1
    `).get(input.userId);
        if (inFlightRequest) {
            throw new PromotionPurchaseError('wallet_busy', 'A paid API request is still being settled; retry the purchase shortly');
        }
        const wallet = db.prepare(`
      SELECT balance_micro AS balanceMicro,
        reserved_balance_micro AS reservedBalanceMicro
      FROM users
      WHERE id = ? AND status = 'active' AND deleted_at IS NULL
    `).get(input.userId);
        const availableMicro = wallet
            ? Math.max(0, wallet.balanceMicro - wallet.reservedBalanceMicro)
            : 0;
        if (!wallet || availableMicro < offer.priceMicro) {
            throw new PromotionPurchaseError('insufficient_balance', 'Insufficient permanent wallet balance');
        }
        const balanceAfterMicro = wallet.balanceMicro - offer.priceMicro;
        const deducted = db.prepare(`
      UPDATE users
      SET balance_micro = balance_micro - ?
      WHERE id = ? AND status = 'active' AND deleted_at IS NULL
        AND balance_micro - reserved_balance_micro >= ?
    `).run(offer.priceMicro, input.userId, offer.priceMicro);
        if (deducted.changes !== 1) {
            throw new PromotionPurchaseError('insufficient_balance', 'Insufficient permanent wallet balance');
        }
        const purchaseNo = `P${Date.now()}${randomUUID().replaceAll('-', '').slice(0, 10).toUpperCase()}`;
        const inserted = db.prepare(`
      INSERT INTO promotion_purchases (
        purchase_no, user_id, offer_id, idempotency_key, offer_code_snapshot,
        price_micro, permanent_credit_micro, limited_credit_micro,
        validity_seconds, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'paid')
    `).run(purchaseNo, input.userId, offer.id, idempotencyKey, offer.code, offer.priceMicro, offer.permanentCreditMicro, offer.limitedCreditMicro, offer.validitySeconds);
        const purchaseId = Number(inserted.lastInsertRowid);
        const walletTransaction = db.prepare(`
      INSERT INTO wallet_transactions (
        user_id, type, delta_micro, balance_after_micro, note
      ) VALUES (?, 'purchase', ?, ?, ?)
    `).run(input.userId, -offer.priceMicro, balanceAfterMicro, `Promotion purchase ${purchaseNo} (${offer.code})`);
        db.prepare(`
      UPDATE promotion_purchases SET wallet_transaction_id = ? WHERE id = ?
    `).run(Number(walletTransaction.lastInsertRowid), purchaseId);
        const granted = createPromotionCreditGrant(db, {
            userId: input.userId,
            offerId: offer.id,
            purchaseId,
            grantedMicro: offer.limitedCreditMicro,
            validitySeconds: offer.validitySeconds,
        });
        const purchase = getPromotionPurchase(db, purchaseId);
        if (!purchase)
            throw new Error('Promotion purchase was not persisted');
        return {
            purchase,
            grant: granted.grant,
            balanceAfterMicro,
            alreadyProcessed: false,
        };
    })();
}
//# sourceMappingURL=promotion-purchases.js.map