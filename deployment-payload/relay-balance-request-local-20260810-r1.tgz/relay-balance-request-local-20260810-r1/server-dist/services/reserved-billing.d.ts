import type { Db } from '../db/types.js';
export type ReservedChargeResult = {
    status: 'charged';
    amountMicro: number;
    balanceAfterMicro: number;
} | {
    status: 'free';
    amountMicro: 0;
    balanceAfterMicro: number;
} | {
    status: 'already_processed' | 'not_billable' | 'no_billing_rule' | 'insufficient_balance' | 'request_not_found' | 'reservation_not_found' | 'reservation_already_finalized';
    amountMicro?: number;
    balanceAfterMicro?: number;
};
export declare function chargeReservedRequest(db: Db, requestId: number, reservationId: number): ReservedChargeResult;
//# sourceMappingURL=reserved-billing.d.ts.map