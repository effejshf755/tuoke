import { calculateBillingAmountMicro, DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI, } from './billing.js';
const DEFAULT_MAX_OUTPUT_TOKENS = Math.max(1, Number(process.env.BILLING_DEFAULT_MAX_OUTPUT_TOKENS ?? 8192) || 8192);
const MAX_OUTPUT_TOKEN_SANITY_LIMIT = 262_144;
function estimateInputTokens(body) {
    try {
        return Math.max(1, Math.ceil(JSON.stringify(body ?? {}).length * 1.25));
    }
    catch {
        return 1;
    }
}
function readPositiveInteger(value) {
    const parsed = typeof value === 'number'
        ? value
        : typeof value === 'string'
            ? Number(value)
            : NaN;
    if (!Number.isFinite(parsed) || parsed <= 0)
        return null;
    return Math.max(1, Math.min(MAX_OUTPUT_TOKEN_SANITY_LIMIT, Math.trunc(parsed)));
}
function exactRequestedCodexModel(requestedModel) {
    if (!requestedModel)
        return null;
    const normalized = requestedModel.trim();
    const lower = normalized.toLowerCase();
    if (lower === 'auto'
        || lower.startsWith('auto:')
        || lower === 'codex'
        || lower === 'openai-codex/codex') {
        return null;
    }
    return lower.startsWith('openai-codex/')
        ? normalized.slice('openai-codex/'.length)
        : normalized;
}
/**
 * Reserve against the most expensive real model currently available in the
 * Codex pool. The public alias remains `codex`, while settlement uses the
 * actual model selected by the router. Shared third-party relays are included
 * only when their source and mapping are actually dispatchable for this key.
 */
export function estimateCodexBillingReservation(db, body, consumerApiKeyId) {
    const requestBody = body;
    const requestedModel = typeof requestBody?.model === 'string'
        ? requestBody.model.trim() || null
        : null;
    const exactModel = exactRequestedCodexModel(requestedModel);
    const estimatedInputTokens = estimateInputTokens(body);
    const maximumOutputTokens = readPositiveInteger(requestBody?.max_completion_tokens)
        ?? readPositiveInteger(requestBody?.max_output_tokens)
        ?? readPositiveInteger(requestBody?.max_tokens)
        ?? DEFAULT_MAX_OUTPUT_TOKENS;
    // Keep the reservation candidate set identical in spirit to dispatch:
    //   - shared keys can see shared OAuth accounts plus Chat-compatible relay
    //     mappings in the same Codex group;
    //   - resource-subpool keys only see accounts actively bound to their own
    //     resource subpool, never a relay or another member's capacity.
    // This is intentionally a maximum over callable candidates. It may reserve
    // more than the final selected source costs, but cannot under-authorize an
    // automatic fallback request.
    const rules = db.prepare(`
    SELECT DISTINCT
      inputPriceMicroPerMillion,
      outputPriceMicroPerMillion,
      multiplierMilli,
      cachedInputMultiplierMilli
    FROM (
      SELECT
        CASE
          WHEN k.key_scope = 'codex_pool'
          THEN COALESCE(
            gm.input_price_micro_per_million_override,
            b.input_price_micro_per_million
          )
          ELSE b.input_price_micro_per_million
        END AS inputPriceMicroPerMillion,
        CASE
          WHEN k.key_scope = 'codex_pool'
          THEN COALESCE(
            gm.output_price_micro_per_million_override,
            b.output_price_micro_per_million
          )
          ELSE b.output_price_micro_per_million
        END AS outputPriceMicroPerMillion,
        CASE
          WHEN k.key_scope = 'codex_pool'
          THEN COALESCE(
            gm.cached_input_multiplier_milli_override,
            b.cached_input_multiplier_milli,
            1000
          )
          ELSE COALESCE(b.cached_input_multiplier_milli, 1000)
        END AS cachedInputMultiplierMilli,
        CAST(ROUND(
          CASE
            WHEN k.key_scope = 'codex_pool'
            THEN COALESCE(gm.multiplier_milli_override, b.multiplier_milli)
            ELSE b.multiplier_milli
          END
          * COALESCE(u.billing_multiplier_milli, 1000) / 1000.0
        ) AS INTEGER) AS multiplierMilli
      FROM consumer_api_keys k
      JOIN users u ON u.id = k.user_id
      LEFT JOIN codex_groups g ON g.id = k.codex_group_id
      JOIN codex_oauth_accounts a
        ON a.enabled = 1
       AND a.status IN ('healthy', 'unknown')
       AND (a.cooldown_until IS NULL OR a.cooldown_until <= datetime('now'))
      JOIN codex_oauth_account_models am
        ON am.account_id = a.id
       AND am.enabled = 1
      JOIN model_billing_rules b
        ON b.platform = 'openai-codex'
       AND b.model_id = am.model_id
       AND b.billing_enabled = 1
      LEFT JOIN codex_group_models gm
        ON gm.group_id = k.codex_group_id
       AND gm.model_id = am.model_id
      WHERE k.id = ?
        AND (? IS NULL OR am.model_id = ?)
        AND (
          (
            k.key_scope = 'codex_pool'
            AND a.resource_scope = 'codex_pool'
            AND k.codex_group_id IS NOT NULL
            AND a.codex_group_id = k.codex_group_id
            AND EXISTS (
              SELECT 1
              FROM codex_groups enabled_group
              JOIN codex_group_models gm ON gm.group_id = enabled_group.id
              WHERE enabled_group.id = a.codex_group_id
                AND enabled_group.enabled = 1
                AND gm.model_id = am.model_id
            )
          )
          OR (
            k.key_scope = 'resource_subpool'
            AND a.resource_scope = 'resource_subpool'
            AND EXISTS (
              SELECT 1
              FROM resource_subpool_members sm
              JOIN resource_member_api_keys mk ON mk.member_id = sm.id
              JOIN resource_subpools ss
                ON ss.id = sm.subpool_id
               AND ss.status = 'active'
              JOIN resource_subpool_bindings sb
                ON sb.subpool_id = ss.id
               AND sb.status = 'active'
              WHERE mk.consumer_api_key_id = k.id
                AND sb.codex_account_id = a.id
            )
          )
        )

      UNION ALL

      SELECT
        COALESCE(
          gm.input_price_micro_per_million_override,
          b.input_price_micro_per_million
        ) AS inputPriceMicroPerMillion,
        COALESCE(
          gm.output_price_micro_per_million_override,
          b.output_price_micro_per_million
        ) AS outputPriceMicroPerMillion,
        COALESCE(
          gm.cached_input_multiplier_milli_override,
          b.cached_input_multiplier_milli,
          1000
        ) AS cachedInputMultiplierMilli,
        CAST(ROUND(
          COALESCE(gm.multiplier_milli_override, b.multiplier_milli)
          * COALESCE(u.billing_multiplier_milli, 1000) / 1000.0
        ) AS INTEGER) AS multiplierMilli
      FROM consumer_api_keys k
      JOIN users u ON u.id = k.user_id
      LEFT JOIN codex_groups g ON g.id = k.codex_group_id
      JOIN codex_relay_sources s
        ON s.enabled = 1
      JOIN codex_relay_source_models sm
        ON sm.source_id = s.id
       AND sm.enabled = 1
      JOIN model_billing_rules b
        ON b.platform = 'openai-codex'
       AND b.model_id = sm.public_model_id
       AND b.billing_enabled = 1
      JOIN codex_group_models gm
        ON gm.group_id = s.codex_group_id
       AND gm.model_id = sm.public_model_id
      WHERE k.id = ?
        AND (? IS NULL OR sm.public_model_id = ?)
        AND k.key_scope = 'codex_pool'
        AND k.codex_group_id IS NOT NULL
        AND k.codex_group_id = s.codex_group_id
        AND EXISTS (
          SELECT 1
          FROM codex_relay_source_keys source_key
          JOIN api_keys source_api_key
            ON source_api_key.id = source_key.api_key_id
           AND source_api_key.role = 'codex_relay'
           AND source_api_key.platform = 'custom'
           AND source_api_key.enabled = 1
          WHERE source_key.source_id = s.id
            AND source_key.enabled = 1
            AND source_key.status IN ('healthy', 'unknown')
            AND (
              source_key.cooldown_until IS NULL
              OR datetime(source_key.cooldown_until) <= datetime('now')
            )
        )
        AND EXISTS (
          SELECT 1 FROM codex_groups enabled_group
          WHERE enabled_group.id = s.codex_group_id
            AND enabled_group.enabled = 1
        )
    )
  `).all(consumerApiKeyId ?? -1, exactModel, exactModel, consumerApiKeyId ?? -1, exactModel, exactModel);
    if (rules.length === 0) {
        return {
            status: 'no_billing_rule',
            requestedModel,
            estimatedInputTokens,
            maximumOutputTokens,
            reserveMicro: 0,
            matchedRuleCount: 0,
        };
    }
    let highestCostMicro = 0;
    for (const rule of rules) {
        const cachedOrStandardCost = calculateBillingAmountMicro(estimatedInputTokens, maximumOutputTokens, rule.inputPriceMicroPerMillion, rule.outputPriceMicroPerMillion, rule.multiplierMilli, estimatedInputTokens, Math.max(1_000, rule.cachedInputMultiplierMilli));
        const cacheWriteCost = calculateBillingAmountMicro(estimatedInputTokens, maximumOutputTokens, rule.inputPriceMicroPerMillion, rule.outputPriceMicroPerMillion, rule.multiplierMilli, 0, rule.cachedInputMultiplierMilli, estimatedInputTokens, DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI);
        highestCostMicro = Math.max(highestCostMicro, cachedOrStandardCost, cacheWriteCost);
    }
    return {
        status: 'ok',
        requestedModel,
        estimatedInputTokens,
        maximumOutputTokens,
        // A deliberately free Codex rule must not require the user to hold a
        // positive wallet balance. The middleware skips reservation when this is
        // zero, while paid rules still reserve their calculated maximum cost.
        reserveMicro: Math.max(0, highestCostMicro),
        matchedRuleCount: rules.length,
    };
}
//# sourceMappingURL=codex-billing.js.map