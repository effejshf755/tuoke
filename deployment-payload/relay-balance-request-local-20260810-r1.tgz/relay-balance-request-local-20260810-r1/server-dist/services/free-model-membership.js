import { randomUUID } from 'node:crypto';
import { getFreeModelAccessStatus, } from './free-model-access.js';
export const FREE_MODEL_MEMBERSHIP_PRICE_MICRO = 10_000_000;
export const FREE_MODEL_MEMBERSHIP_PERIOD_DAYS = 30;
export class FreeModelMembershipPurchaseError extends Error {
    code;
    constructor(code, message) {
        super(message);
        this.code = code;
        this.name = 'FreeModelMembershipPurchaseError';
    }
}
const PURCHASE_SELECT = `
  SELECT
    id,
    purchase_no AS purchaseNo,
    user_id AS userId,
    wallet_transaction_id AS walletTransactionId,
    price_micro AS priceMicro,
    starts_at AS startsAt,
    expires_at AS expiresAt,
    created_at AS createdAt
  FROM free_model_membership_purchases
`;
function readPurchase(db, purchaseId) {
    const purchase = db.prepare(`${PURCHASE_SELECT} WHERE id = ?`).get(purchaseId);
    if (!purchase) {
        throw new FreeModelMembershipPurchaseError('purchase_conflict', 'Membership purchase is missing');
    }
    return purchase;
}
export function purchaseFreeModelMembership(db, input) {
    const idempotencyKey = input.idempotencyKey.trim();
    if (!idempotencyKey || idempotencyKey.length > 200) {
        throw new FreeModelMembershipPurchaseError('invalid_idempotency_key', 'A valid idempotency key is required');
    }
    return db.transaction(() => {
        const existing = db.prepare(`
      ${PURCHASE_SELECT}
      WHERE user_id = ? AND idempotency_key = ?
      LIMIT 1
    `).get(input.userId, idempotencyKey);
        if (existing) {
            const wallet = db.prepare(`
        SELECT balance_micro AS balanceMicro
        FROM users
        WHERE id = ?
      `).get(input.userId);
            const membership = getFreeModelAccessStatus(db, input.userId);
            if (!wallet || !membership) {
                throw new FreeModelMembershipPurchaseError('purchase_conflict', 'Membership buyer no longer exists');
            }
            return {
                purchase: existing,
                membership,
                balanceAfterMicro: wallet.balanceMicro,
                alreadyProcessed: true,
            };
        }
        const inFlightRequest = db.prepare(`
      SELECT 1
      FROM wallet_reservations
      WHERE user_id = ? AND status = 'reserved'
      LIMIT 1
    `).get(input.userId);
        if (inFlightRequest) {
            throw new FreeModelMembershipPurchaseError('wallet_busy', 'A paid API request is still being settled; retry the membership purchase shortly');
        }
        const wallet = db.prepare(`
      SELECT
        balance_micro AS balanceMicro,
        reserved_balance_micro AS reservedBalanceMicro,
        free_model_bonus_until AS membershipExpiresAt
      FROM users
      WHERE id = ? AND status = 'active' AND deleted_at IS NULL
    `).get(input.userId);
        const availableMicro = wallet
            ? Math.max(0, wallet.balanceMicro - wallet.reservedBalanceMicro)
            : 0;
        if (!wallet || availableMicro < FREE_MODEL_MEMBERSHIP_PRICE_MICRO) {
            throw new FreeModelMembershipPurchaseError('insufficient_balance', 'Insufficient wallet balance for the membership purchase');
        }
        const period = db.prepare(`
      SELECT
        CASE
          WHEN ? IS NOT NULL AND datetime(?) > datetime('now')
          THEN datetime(?)
          ELSE datetime('now')
        END AS startsAt,
        CASE
          WHEN ? IS NOT NULL AND datetime(?) > datetime('now')
          THEN datetime(?, '+${FREE_MODEL_MEMBERSHIP_PERIOD_DAYS} days')
          ELSE datetime('now', '+${FREE_MODEL_MEMBERSHIP_PERIOD_DAYS} days')
        END AS expiresAt
    `).get(wallet.membershipExpiresAt, wallet.membershipExpiresAt, wallet.membershipExpiresAt, wallet.membershipExpiresAt, wallet.membershipExpiresAt, wallet.membershipExpiresAt);
        const balanceAfterMicro = wallet.balanceMicro - FREE_MODEL_MEMBERSHIP_PRICE_MICRO;
        if (!Number.isSafeInteger(balanceAfterMicro)) {
            throw new FreeModelMembershipPurchaseError('purchase_conflict', 'Wallet balance is invalid');
        }
        const deducted = db.prepare(`
      UPDATE users
      SET
        balance_micro = balance_micro - ?,
        free_model_bonus_until = ?
      WHERE id = ? AND status = 'active' AND deleted_at IS NULL
        AND balance_micro - reserved_balance_micro >= ?
    `).run(FREE_MODEL_MEMBERSHIP_PRICE_MICRO, period.expiresAt, input.userId, FREE_MODEL_MEMBERSHIP_PRICE_MICRO);
        if (deducted.changes !== 1) {
            throw new FreeModelMembershipPurchaseError('insufficient_balance', 'Insufficient wallet balance for the membership purchase');
        }
        const purchaseNo = `M${Date.now()}${randomUUID().replaceAll('-', '').slice(0, 10).toUpperCase()}`;
        const inserted = db.prepare(`
      INSERT INTO free_model_membership_purchases (
        purchase_no,
        user_id,
        idempotency_key,
        price_micro,
        starts_at,
        expires_at
      ) VALUES (?, ?, ?, ?, ?, ?)
    `).run(purchaseNo, input.userId, idempotencyKey, FREE_MODEL_MEMBERSHIP_PRICE_MICRO, period.startsAt, period.expiresAt);
        const purchaseId = Number(inserted.lastInsertRowid);
        const walletTransaction = db.prepare(`
      INSERT INTO wallet_transactions (
        user_id,
        type,
        delta_micro,
        balance_after_micro,
        note
      ) VALUES (?, 'purchase', ?, ?, ?)
    `).run(input.userId, -FREE_MODEL_MEMBERSHIP_PRICE_MICRO, balanceAfterMicro, `Free-model membership purchase ${purchaseNo}`);
        db.prepare(`
      UPDATE free_model_membership_purchases
      SET wallet_transaction_id = ?
      WHERE id = ?
    `).run(Number(walletTransaction.lastInsertRowid), purchaseId);
        const membership = getFreeModelAccessStatus(db, input.userId);
        if (!membership)
            throw new Error('Membership status was not persisted');
        return {
            purchase: readPurchase(db, purchaseId),
            membership,
            balanceAfterMicro,
            alreadyProcessed: false,
        };
    })();
}
//# sourceMappingURL=free-model-membership.js.map