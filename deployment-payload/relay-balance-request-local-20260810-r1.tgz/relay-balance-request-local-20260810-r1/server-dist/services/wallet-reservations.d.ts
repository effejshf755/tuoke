import type { Db } from "../db/types.js";
import type { Scheduler } from "../lib/scheduler.js";
export interface WalletReservation {
    id: number;
    userId: number;
    consumerApiKeyId: number | null;
    requestId: number | null;
    requestedModel: string | null;
    reservedMicro: number;
    exclusiveWalletLock: number;
    actualMicro: number | null;
    status: "reserved" | "settled" | "released" | "failed";
    createdAt: string;
    settledAt: string | null;
}
export type ReserveWalletResult = {
    status: "reserved";
    reservationId: number;
    reservedMicro: number;
    availableAfterMicro: number;
    exclusiveWalletLock: boolean;
} | {
    status: "concurrency_conflict";
    requestedExclusive: boolean;
    conflictingExclusive: boolean | null;
} | {
    status: "insufficient_balance";
    availableMicro: number;
} | {
    status: "user_not_found";
    availableMicro: 0;
};
export type ReleaseReservationResult = {
    status: "released";
    releasedMicro: number;
} | {
    status: "already_finalized" | "reservation_not_found";
    releasedMicro: 0;
};
export interface ReserveWalletOptions {
    exclusiveWalletLock?: boolean;
}
export declare function getAvailableBalanceMicro(db: Db, userId: number): number;
/**
 * Atomically reserves part of a prepaid wallet.
 *
 * balance_micro stays unchanged.
 * reserved_balance_micro increases.
 *
 * Available balance:
 * balance_micro - reserved_balance_micro
 */
export declare function reserveWalletBalance(db: Db, userId: number, consumerApiKeyId: number | null, requestedModel: string | null, requestedReserveMicro: number, options?: ReserveWalletOptions): ReserveWalletResult;
/**
 * Releases a reservation without charging the user.
 *
 * Used when:
 * - request is rejected before provider usage
 * - all provider attempts fail
 * - connection closes before successful settlement
 */
export declare function releaseWalletReservation(db: Db, reservationId: number, finalStatus?: "released" | "failed"): ReleaseReservationResult;
export declare function getWalletReservation(db: Db, reservationId: number): WalletReservation | null;
export interface WalletReservationCleanupResult {
    releasedReservations: number;
    releasedMicro: number;
    reconciledUsers: number;
}
export declare function cleanupStaleWalletReservations(db: Db, staleAfterMinutes?: number): WalletReservationCleanupResult;
export declare function startWalletReservationCleanup(db: Db, scheduler: Scheduler): void;
//# sourceMappingURL=wallet-reservations.d.ts.map