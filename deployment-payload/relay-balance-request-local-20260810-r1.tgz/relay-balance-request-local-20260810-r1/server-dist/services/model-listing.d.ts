export interface NormalizedModel {
    id: string;
    name: string;
    ownedBy: string;
    available: number;
    enabled: number;
    contextWindow: number | null;
    intel: number;
    platforms: string[];
    supportsTools: boolean;
}
export interface ModelListing {
    models: NormalizedModel[];
    autoContextWindow: number | null;
}
export type CodexConsumerKeyType = 'codex_pool' | 'resource_subpool';
export declare function normalizeCodexModelId(modelId: string): string;
/**
 * Consumer keys must only discover models that can actually be called by a
 * billed user: the model is enabled, an enabled provider key can serve it, and
 * the administrator has enabled a billing rule for it.
 *
 * This deliberately stays a query-time filter. The administrator's catalog
 * and billing pages continue to use the complete model inventory.
 */
export declare function getConsumerCallableCanonicalIds(): Set<string>;
/**
 * Apply the consumer visibility policy to a shared catalog listing.
 * Consumer callers never receive disabled, keyless, or unconfigured models.
 */
export declare function filterModelListingForConsumer(_listing: ModelListing): ModelListing;
/**
 * Codex keys expose only the real models supported by their permitted OAuth
 * account(s). Ordinary provider models and the internal `codex` alias are
 * intentionally excluded from this listing.
 */
export declare function filterModelListingForCodexConsumer(_listing: ModelListing, keyType: CodexConsumerKeyType, consumerKeyId: number): ModelListing;
export declare function getCodexConsumerCallableModelIds(keyType: CodexConsumerKeyType, consumerKeyId: number): Set<string>;
/** Resolve an explicit Codex model against the accounts available to one key. */
export declare function getCodexConsumerModelDbId(keyType: CodexConsumerKeyType, consumerKeyId: number, requestedModel: string): number | null;
/**
 * Resolve a model that belongs to the consumer's configured Codex group
 * without requiring a currently healthy upstream. A compacted conversation
 * already carries an upstream pin, so a temporary source outage must reach
 * the router and become its explicit 503 instead of an earlier model 400.
 */
export declare function getCodexConsumerGroupModelDbId(keyType: CodexConsumerKeyType, consumerKeyId: number, requestedModel: string): number | null;
export declare function buildModelListing(options?: {
    excludeOpenAICodex?: boolean;
}): ModelListing;
//# sourceMappingURL=model-listing.d.ts.map