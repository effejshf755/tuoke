export class UserCodexUpstreamBindingError extends Error {
    status;
    code;
    constructor(message, status = 409, code = 'binding_conflict') {
        super(message);
        this.status = status;
        this.code = code;
    }
}
function mapBinding(row) {
    const targetId = row.targetType === 'oauth' ? row.oauthAccountId : row.relaySourceId;
    if (targetId == null) {
        throw new UserCodexUpstreamBindingError('The saved Codex upstream binding no longer has a target', 409, 'invalid_binding');
    }
    return {
        userId: Number(row.userId),
        codexGroupId: Number(row.codexGroupId),
        codexGroupName: row.codexGroupName,
        targetType: row.targetType,
        targetId: Number(targetId),
        targetLabel: row.targetLabel ?? `${row.targetType} #${targetId}`,
        targetEnabled: Boolean(row.targetEnabled),
        targetStatus: row.targetStatus ?? 'missing',
        updatedAt: row.updatedAt,
    };
}
export function getUserCodexUpstreamBinding(db, userId, codexGroupId) {
    if (!Number.isSafeInteger(userId) || !Number.isSafeInteger(codexGroupId))
        return null;
    const row = db.prepare(`
    SELECT
      binding.user_id AS userId,
      binding.codex_group_id AS codexGroupId,
      group_record.name AS codexGroupName,
      binding.target_type AS targetType,
      binding.oauth_account_id AS oauthAccountId,
      binding.relay_source_id AS relaySourceId,
      CASE binding.target_type
        WHEN 'oauth' THEN oauth.label
        ELSE relay.name
      END AS targetLabel,
      CASE binding.target_type
        WHEN 'oauth' THEN oauth.enabled
        ELSE relay.enabled
      END AS targetEnabled,
      CASE binding.target_type
        WHEN 'oauth' THEN oauth.status
        ELSE relay.status
      END AS targetStatus,
      binding.updated_at AS updatedAt
    FROM user_codex_upstream_bindings binding
    JOIN codex_groups group_record ON group_record.id = binding.codex_group_id
    LEFT JOIN codex_oauth_accounts oauth ON oauth.id = binding.oauth_account_id
    LEFT JOIN codex_relay_sources relay ON relay.id = binding.relay_source_id
    WHERE binding.user_id = ? AND binding.codex_group_id = ?
    LIMIT 1
  `).get(userId, codexGroupId);
    return row ? mapBinding(row) : null;
}
function listUserCodexGroups(db, userId) {
    return db.prepare(`
    SELECT DISTINCT group_record.id, group_record.name
    FROM consumer_api_keys consumer
    JOIN codex_groups group_record
      ON group_record.id = consumer.codex_group_id
     AND group_record.enabled = 1
    WHERE consumer.user_id = ?
      AND consumer.key_scope = 'codex_pool'
      AND consumer.status = 'active'
      AND consumer.enabled = 1
      AND (consumer.expires_at IS NULL OR datetime(consumer.expires_at) > datetime('now'))
    ORDER BY group_record.name COLLATE NOCASE, group_record.id
  `).all(userId);
}
function listOptionsForGroup(db, groupId) {
    const oauthRows = db.prepare(`
    SELECT
      account.id AS targetId,
      account.label,
      account.status,
      account.enabled,
      GROUP_CONCAT(DISTINCT capability.model_id) AS modelIds
    FROM codex_oauth_accounts account
    LEFT JOIN codex_oauth_account_models capability
      ON capability.account_id = account.id AND capability.enabled = 1
    WHERE account.codex_group_id = ?
      AND account.resource_scope = 'codex_pool'
      AND account.deleted_at IS NULL
      AND account.enabled = 1
    GROUP BY account.id, account.label, account.status, account.enabled
    ORDER BY account.label COLLATE NOCASE, account.id
  `).all(groupId);
    const relayRows = db.prepare(`
    SELECT
      source.id AS targetId,
      source.name AS label,
      source.status,
      source.enabled,
      source.protocol,
      GROUP_CONCAT(DISTINCT mapping.public_model_id) AS modelIds
    FROM codex_relay_sources source
    LEFT JOIN codex_relay_source_models mapping
      ON mapping.source_id = source.id AND mapping.enabled = 1
    WHERE source.codex_group_id = ? AND source.enabled = 1
    GROUP BY source.id, source.name, source.status, source.enabled, source.protocol
    ORDER BY source.name COLLATE NOCASE, source.id
  `).all(groupId);
    return [
        ...oauthRows.map((row) => ({
            targetType: 'oauth',
            targetId: Number(row.targetId),
            label: row.label,
            status: row.status,
            enabled: Boolean(row.enabled),
            protocol: null,
            modelIds: row.modelIds ? row.modelIds.split(',').filter(Boolean).sort() : [],
        })),
        ...relayRows.map((row) => ({
            targetType: 'relay',
            targetId: Number(row.targetId),
            label: row.label,
            status: row.status,
            enabled: Boolean(row.enabled),
            protocol: row.protocol,
            modelIds: row.modelIds ? row.modelIds.split(',').filter(Boolean).sort() : [],
        })),
    ];
}
export function listUserCodexBindingGroups(db, userId) {
    const user = db.prepare(`
    SELECT id, email FROM users WHERE id = ? AND deleted_at IS NULL
  `).get(userId);
    if (!user)
        return { user: null, groups: [] };
    const groups = listUserCodexGroups(db, userId).map((group) => ({
        ...group,
        binding: getUserCodexUpstreamBinding(db, userId, group.id),
        options: listOptionsForGroup(db, group.id),
    }));
    return { user, groups };
}
function assertUserCanUseGroup(db, userId, codexGroupId) {
    const match = listUserCodexGroups(db, userId).some((group) => group.id === codexGroupId);
    if (!match) {
        throw new UserCodexUpstreamBindingError('User has no active Codex API key in this enabled group', 409, 'group_not_available');
    }
}
function validateTarget(db, codexGroupId, targetType, targetId) {
    const target = targetType === 'oauth'
        ? db.prepare(`
        SELECT 1
        FROM codex_oauth_accounts
        WHERE id = ? AND codex_group_id = ?
          AND resource_scope = 'codex_pool'
          AND deleted_at IS NULL AND enabled = 1
      `).get(targetId, codexGroupId)
        : db.prepare(`
        SELECT 1
        FROM codex_relay_sources
        WHERE id = ? AND codex_group_id = ? AND enabled = 1
      `).get(targetId, codexGroupId);
    if (!target) {
        throw new UserCodexUpstreamBindingError(`Selected ${targetType === 'oauth' ? 'OAuth account' : 'third-party API'} is disabled, missing, or outside this Codex group`, 409, 'target_not_available');
    }
}
export function setUserCodexUpstreamBinding(db, input) {
    assertUserCanUseGroup(db, input.userId, input.codexGroupId);
    validateTarget(db, input.codexGroupId, input.targetType, input.targetId);
    db.prepare(`
    INSERT INTO user_codex_upstream_bindings (
      user_id, codex_group_id, target_type, oauth_account_id, relay_source_id
    ) VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(user_id, codex_group_id) DO UPDATE SET
      target_type = excluded.target_type,
      oauth_account_id = excluded.oauth_account_id,
      relay_source_id = excluded.relay_source_id,
      updated_at = datetime('now')
  `).run(input.userId, input.codexGroupId, input.targetType, input.targetType === 'oauth' ? input.targetId : null, input.targetType === 'relay' ? input.targetId : null);
    const binding = getUserCodexUpstreamBinding(db, input.userId, input.codexGroupId);
    if (!binding)
        throw new UserCodexUpstreamBindingError('Unable to save Codex upstream binding', 500, 'save_failed');
    return binding;
}
export function clearUserCodexUpstreamBinding(db, userId, codexGroupId) {
    return db.prepare(`
    DELETE FROM user_codex_upstream_bindings
    WHERE user_id = ? AND codex_group_id = ?
  `).run(userId, codexGroupId).changes > 0;
}
//# sourceMappingURL=user-codex-upstream-bindings.js.map