export const FREE_DAILY_LIMIT = 50;
export const MEMBER_DAILY_LIMIT = 1000;
// Paid requests may spend only the balance above this safety floor.  The
// gateway no longer freezes a conservative maximum-output estimate; streaming
// routes stop the active upstream when their observed cost reaches this floor.
export const PAID_MODEL_SAFETY_BALANCE_MICRO = 100_000;
// Keep the old export name for callers/tests that still describe this as the
// request admission minimum.
export const PAID_MODEL_MINIMUM_BALANCE_MICRO = PAID_MODEL_SAFETY_BALANCE_MICRO;
/**
 * Paid requests keep a zero-value tracking reservation.  This preserves the
 * existing exactly-once settlement link without hiding spendable funds from
 * the user while the request is running.
 */
export function getPaidRequestDepositMicro(estimatedMicro, availableMicro) {
    const available = Number.isFinite(availableMicro)
        ? Math.max(0, Math.trunc(availableMicro))
        : 0;
    if (available <= PAID_MODEL_SAFETY_BALANCE_MICRO)
        return null;
    // Touch the estimate so invalid callers remain observable during debugging,
    // but never turn it into a wallet hold.
    void estimatedMicro;
    return 0;
}
export function isExplicitFreeModel(db, requestedModel) {
    if (!requestedModel || requestedModel === 'auto' || requestedModel.startsWith('auto:')) {
        return true;
    }
    if (requestedModel.toLowerCase().includes(':free'))
        return true;
    const row = db.prepare(`
    SELECT 1
    FROM models m
    JOIN model_billing_rules b
      ON b.platform = m.platform
     AND b.model_id = m.model_id
    WHERE m.model_id = ?
      AND m.platform <> 'openai-codex'
      AND m.enabled = 1
      AND b.billing_enabled = 1
      AND b.input_price_micro_per_million = 0
      AND b.output_price_micro_per_million = 0
    LIMIT 1
  `).get(requestedModel);
    return Boolean(row);
}
export function consumeFreeModelRequest(db, userId) {
    const user = db.prepare(`
    SELECT free_model_bonus_until AS membershipUntil
    FROM users
    WHERE id = ?
  `).get(userId);
    const member = Boolean(user?.membershipUntil
        && Date.parse(`${user.membershipUntil.replace(' ', 'T')}Z`) > Date.now());
    const limit = member ? MEMBER_DAILY_LIMIT : FREE_DAILY_LIMIT;
    const usageDate = db.prepare("SELECT date('now', '+8 hours') AS value").get();
    const updated = db.prepare(`
    INSERT INTO free_model_daily_usage (
      user_id,
      usage_date,
      request_count,
      updated_at
    )
    VALUES (?, ?, 1, datetime('now'))
    ON CONFLICT(user_id, usage_date) DO UPDATE SET
      request_count = request_count + 1,
      updated_at = datetime('now')
    WHERE request_count < ?
  `).run(userId, usageDate.value, limit);
    const usage = db.prepare(`
    SELECT request_count AS used
    FROM free_model_daily_usage
    WHERE user_id = ? AND usage_date = ?
  `).get(userId, usageDate.value);
    return {
        allowed: updated.changes === 1,
        limit,
        used: usage?.used ?? 0,
        membershipUntil: user?.membershipUntil ?? null,
        usageDate: usageDate.value,
    };
}
export function getFreeModelAccessStatus(db, userId) {
    const user = db.prepare(`
    SELECT free_model_bonus_until AS membershipExpiresAt
    FROM users
    WHERE id = ? AND status = 'active' AND deleted_at IS NULL
  `).get(userId);
    if (!user)
        return null;
    const clock = db.prepare(`
    SELECT
      datetime('now') AS now,
      date('now', '+8 hours') AS usageDate,
      datetime(date('now', '+8 hours'), '+1 day', '-8 hours') AS resetAt
  `).get();
    const membershipActive = Boolean(user.membershipExpiresAt
        && Date.parse(`${user.membershipExpiresAt.replace(' ', 'T')}Z`) > Date.parse(`${clock.now.replace(' ', 'T')}Z`));
    const dailyLimit = membershipActive ? MEMBER_DAILY_LIMIT : FREE_DAILY_LIMIT;
    const usage = db.prepare(`
    SELECT request_count AS used
    FROM free_model_daily_usage
    WHERE user_id = ? AND usage_date = ?
  `).get(userId, clock.usageDate);
    const usedToday = Math.max(0, Number(usage?.used ?? 0));
    const remainingMs = membershipActive && user.membershipExpiresAt
        ? Date.parse(`${user.membershipExpiresAt.replace(' ', 'T')}Z`) - Date.parse(`${clock.now.replace(' ', 'T')}Z`)
        : 0;
    return {
        membershipActive,
        membershipExpiresAt: user.membershipExpiresAt,
        membershipRemainingSeconds: Math.max(0, Math.floor(remainingMs / 1000)),
        usageDate: clock.usageDate,
        resetAt: clock.resetAt,
        dailyLimit,
        usedToday,
        remainingToday: Math.max(0, dailyLimit - usedToday),
    };
}
export function releaseFreeModelRequest(db, userId, usageDate) {
    db.prepare(`
    UPDATE free_model_daily_usage
    SET request_count = MAX(0, request_count - 1), updated_at = datetime('now')
    WHERE user_id = ? AND usage_date = ? AND request_count > 0
  `).run(userId, usageDate);
}
export function getAvailableBalanceMicro(db, userId) {
    const row = db.prepare(`
    SELECT
      balance_micro - COALESCE(reserved_balance_micro, 0) AS availableMicro
    FROM users
    WHERE id = ?
  `).get(userId);
    return row?.availableMicro ?? null;
}
//# sourceMappingURL=free-model-access.js.map