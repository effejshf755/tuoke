import type { Db } from '../db/types.js';
export interface ConsumerCodexModelPricing {
    modelId: string;
    inputPricePerMillion: number;
    outputPricePerMillion: number;
    cachedInputPricePerMillion: number;
    effectiveMultiplier: number;
}
export interface ConsumerCodexGroup {
    id: number;
    name: string;
    description: string;
    multiplier: number;
    maxConcurrency: number | null;
    modelIds: string[];
    oauthAccountCount: number;
    relaySourceCount: number;
    upstreamCount: number;
    modelPricing: ConsumerCodexModelPricing[];
}
export interface ConsumerCodexGroupOption {
    id: number;
    name: string;
    selectable: boolean;
    multiplier: number;
    maxConcurrency: number | null;
    modelPricing: ConsumerCodexModelPricing[];
}
/**
 * Groups offered while creating a shared Codex key must already have at least
 * one enabled, model-compatible upstream bound to them. Runtime health,
 * cooldown, and remaining quota are intentionally handled by the scheduler:
 * a temporary outage must not make an existing group disappear from the key
 * creation form.
 */
export declare function listConsumerCodexGroups(db: Db, userId?: number | null): ConsumerCodexGroup[];
/**
 * Keep every administratively enabled group visible in the consumer form.
 * Empty or incompletely configured groups are exposed as non-selectable so
 * consumers cannot create a key that cannot route any request.
 */
export declare function listConsumerCodexGroupOptions(db: Db, userId?: number | null): ConsumerCodexGroupOption[];
export declare function isConsumerCodexGroupSelectable(db: Db, groupId: number): boolean;
//# sourceMappingURL=consumer-codex-groups.d.ts.map