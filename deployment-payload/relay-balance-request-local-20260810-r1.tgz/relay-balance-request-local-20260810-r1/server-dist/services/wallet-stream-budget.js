import { getClientContext } from '../lib/client-context.js';
import { applyCodexGroupMultiplier, applyUserBillingMultiplier, calculateComputePointBillingAmountMicro, DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI, getEffectiveModelBillingRule, } from './billing.js';
import { currentPointsPerMillionTokens } from './compute-points.js';
import { getAvailableBalanceMicro, PAID_MODEL_SAFETY_BALANCE_MICRO, } from './free-model-access.js';
import { ensurePromotionCreditReservation, getPromotionCreditReservationExpiryBreakdown, } from './promotion-credits.js';
export const WALLET_SAFETY_STOP_MESSAGE = 'Available balance reached the 0.10 yuan safety limit. The active request was stopped; please recharge to continue.';
export class WalletSafetyBalanceReachedError extends Error {
    code = 'wallet_safety_balance_reached';
    status = 402;
    skipBench = true;
    projectedChargeMicro;
    availableMicro;
    constructor(projectedChargeMicro, availableMicro) {
        super(WALLET_SAFETY_STOP_MESSAGE);
        this.name = 'WalletSafetyBalanceReachedError';
        this.projectedChargeMicro = projectedChargeMicro;
        this.availableMicro = availableMicro;
    }
}
export function isWalletSafetyBalanceReachedError(error) {
    return error instanceof WalletSafetyBalanceReachedError
        || (typeof error === 'object'
            && error !== null
            && error.code === 'wallet_safety_balance_reached');
}
/**
 * Stop a paid consumer stream before its projected observed charge consumes
 * the final 0.10 yuan of combined promotion credit and permanent wallet.
 * Operator calls, free requests, and prepaid resource-subpool requests have no
 * wallet reservation and bypass this guard.
 */
export function assertWalletStreamBudget(db, usage) {
    const context = getClientContext();
    if (context.consumerUserId === null
        || context.walletReservationId === null
        || context.consumerApiKeyType === 'resource_subpool') {
        return;
    }
    const rule = getEffectiveModelBillingRule(db, usage.platform, usage.modelId, context.consumerApiKeyId);
    if (!rule || !rule.billingEnabled)
        return;
    const multiplierMilli = applyUserBillingMultiplier(db, context.consumerUserId, applyCodexGroupMultiplier(db, usage.platform, context.consumerApiKeyId, rule.multiplierMilli));
    const projectedChargeMicro = calculateComputePointBillingAmountMicro({
        ...usage,
        // Use the same request snapshot as request-log.ts and the public usage
        // adapter. Falling back to the database keeps non-HTTP callers working.
        computePointsPerMillionTokens: context.computePointsPerMillionTokens
            ?? currentPointsPerMillionTokens(db, context.consumerUserId),
    }, rule.inputPriceMicroPerMillion, rule.outputPriceMicroPerMillion, multiplierMilli, rule.cachedInputMultiplierMilli, DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI);
    // Grow this request's FEFO allocation while grants are still active. Existing
    // allocations remain counted after their batch expires, which preserves the
    // contract that an admitted in-flight request may finish from assigned
    // credit. availableAfterMicro excludes allocations owned by other requests.
    const promotion = ensurePromotionCreditReservation(db, {
        userId: context.consumerUserId,
        walletReservationId: context.walletReservationId,
        targetMicro: projectedChargeMicro,
    });
    const promotionExpiry = getPromotionCreditReservationExpiryBreakdown(db, context.walletReservationId);
    const walletAvailableMicro = getAvailableBalanceMicro(db, context.consumerUserId) ?? 0;
    const availableMicro = promotionExpiry.expiredReservedMicro
        + Math.max(0, promotionExpiry.activeReservedMicro
            + promotion.availableAfterMicro
            + walletAvailableMicro
            - PAID_MODEL_SAFETY_BALANCE_MICRO);
    if (projectedChargeMicro > 0
        && (projectedChargeMicro > availableMicro
            || (projectedChargeMicro === availableMicro
                && projectedChargeMicro > promotionExpiry.expiredReservedMicro))) {
        throw new WalletSafetyBalanceReachedError(projectedChargeMicro, availableMicro);
    }
}
//# sourceMappingURL=wallet-stream-budget.js.map