type ReleaseSlot = () => void;
export declare class CodexConcurrencyError extends Error {
    status: number;
    skipBench: boolean;
    code: string;
    accountId: number;
    constructor(accountId: number);
}
export declare class CodexGroupConcurrencyError extends Error {
    status: number;
    skipBench: boolean;
    code: string;
    groupId: number;
    userId: number;
    constructor(groupId: number, userId: number);
}
export declare class CodexGroupConcurrencyAbortError extends Error {
    code: string;
    groupId: number;
    userId: number;
    constructor(groupId: number, userId: number);
}
/** Update every user's live gate after an administrator changes a group limit. */
export declare function updateCodexGroupConcurrencyLimit(groupId: number, configuredLimit: number | null): void;
export declare function getCodexAccountActiveCount(accountId: number): number;
export declare function getCodexGroupActiveCount(groupId: number, userId?: number): number;
export declare function getCodexConcurrencySnapshot(): {
    activeByAccount: Record<number, number>;
    queuedByAccount: Record<number, number>;
    activeByGroup: Record<number, number>;
    queuedByGroup: Record<number, number>;
    activeByGroupUser: Record<string, number>;
    queuedByGroupUser: Record<string, number>;
    maxConcurrency: number;
    queueTimeoutSeconds: number;
};
export declare function acquireCodexAccountSlot(accountId: number): Promise<ReleaseSlot>;
export declare function acquireCodexGroupSlot(groupId: number, userId: number, configuredLimit: number, signal?: AbortSignal): Promise<ReleaseSlot>;
export declare function resetCodexConcurrencyForTests(): void;
export {};
//# sourceMappingURL=codex-concurrency.d.ts.map