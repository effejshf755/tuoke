import type { Db } from '../db/types.js';
export declare const RESOURCE_TOKEN_METER_VERSION: "tokens-v1";
export declare const RESOURCE_POINTS_METER_VERSION: "points-v1";
export interface CreateResourceProductInput {
    productKey: string;
    name: string;
    description?: string | null;
    priceMicro: number;
    memberLimit: number;
    durationValue: number;
    durationUnit: 'day' | 'month';
    quotaAllocationType?: 'equal' | 'fixed';
    totalQuotaUnits: number;
    memberQuotaUnits: number;
    meterVersion?: string;
    groupTimeoutMinutes: number;
    refundWindowMinutes?: number;
    saleStartsAt?: string | null;
    saleEndsAt?: string | null;
}
export interface ResourceProductRow {
    id: number;
    productKey: string;
    version: number;
    name: string;
    description: string | null;
    status: 'draft' | 'published' | 'unpublished' | 'archived';
    priceMicro: number;
    memberLimit: number;
    durationValue: number;
    durationUnit: 'day' | 'month';
    quotaAllocationType: 'equal' | 'fixed';
    totalQuotaUnits: number;
    memberQuotaUnits: number;
    meterVersion: string;
    groupTimeoutMinutes: number;
    refundWindowMinutes: number;
    saleStartsAt: string | null;
    saleEndsAt: string | null;
    publishedAt: string | null;
    createdAt: string;
    updatedAt: string;
}
export declare function getResourceProduct(db: Db, productId: number): ResourceProductRow | null;
export declare function createResourceProduct(db: Db, input: CreateResourceProductInput): ResourceProductRow;
export declare function publishResourceProduct(db: Db, productId: number): ResourceProductRow;
export declare function unpublishResourceProduct(db: Db, productId: number): ResourceProductRow;
export declare function updateResourceProduct(db: Db, productId: number, overrides: Partial<Omit<CreateResourceProductInput, 'productKey'>>): ResourceProductRow;
export declare function deleteUnpublishedResourceProduct(db: Db, productId: number): ResourceProductRow;
export declare function createNextResourceProductVersion(db: Db, sourceProductId: number, overrides?: Partial<Omit<CreateResourceProductInput, 'productKey'>>): ResourceProductRow;
//# sourceMappingURL=resource-products.d.ts.map