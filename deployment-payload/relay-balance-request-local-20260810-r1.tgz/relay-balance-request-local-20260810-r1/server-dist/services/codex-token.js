import { encrypt, decrypt } from '../lib/crypto.js';
export function encryptCodexToken(token) {
    return encrypt(token);
}
export function decryptCodexToken(encrypted, iv, authTag) {
    return decrypt(encrypted, iv, authTag);
}
//# sourceMappingURL=codex-token.js.map