import type { Db } from '../db/types.js';
export declare function getResourceQuotaStageAnalysis(db: Db, subpoolId: number): any;
export declare function releaseResourceQuotaStageTwo(db: Db, input: {
    subpoolId: number;
    adminId: number;
    multiplierFactor?: number;
}): any;
//# sourceMappingURL=resource-quota-stages.d.ts.map