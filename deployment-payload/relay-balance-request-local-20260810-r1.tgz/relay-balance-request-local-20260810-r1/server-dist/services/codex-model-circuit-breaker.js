export const CODEX_CAPACITY_FAILURE_THRESHOLD = 3;
export const CODEX_CAPACITY_FAILURE_WINDOW_MS = 60_000;
export const CODEX_CIRCUIT_INITIAL_OPEN_MS = 30_000;
export const CODEX_CIRCUIT_MAX_OPEN_MS = 300_000;
const circuits = new Map();
const MAX_OPEN_LEVEL = Math.ceil(Math.log2(CODEX_CIRCUIT_MAX_OPEN_MS / CODEX_CIRCUIT_INITIAL_OPEN_MS));
function circuitKey(modelId, scope) {
    return `${scope}\u0000${modelId}`;
}
function stateFor(modelId, scope) {
    const key = circuitKey(modelId, scope);
    let state = circuits.get(key);
    if (!state) {
        state = { failureTimes: [], openUntil: 0, openLevel: 0, probeInFlight: false };
        circuits.set(key, state);
    }
    return state;
}
function openDurationMs(level) {
    return Math.min(CODEX_CIRCUIT_INITIAL_OPEN_MS * (2 ** level), CODEX_CIRCUIT_MAX_OPEN_MS);
}
export function isCodexCapacityError(err) {
    const message = String(err?.message ?? err ?? '').toLowerCase();
    return message.includes('currently overloaded')
        || message.includes('an error occurred while processing your request');
}
/**
 * Checks the cross-request circuit before dispatch. Once an open interval has
 * elapsed, exactly one caller receives a half-open probe permit.
 */
export function beginCodexModelRequest(modelId, now = Date.now(), scope = 'operator') {
    const state = stateFor(modelId, scope);
    if (state.openUntil > now) {
        return { allowed: false, retryAfterMs: state.openUntil - now };
    }
    if (state.openUntil > 0) {
        if (state.probeInFlight)
            return { allowed: false, retryAfterMs: 1_000 };
        state.probeInFlight = true;
        return { allowed: true, permit: { modelId, scope, probe: true } };
    }
    return { allowed: true, permit: { modelId, scope, probe: false } };
}
/** Records only the two known Codex upstream capacity failures. */
export function recordCodexCapacityFailure(permit, now = Date.now()) {
    const state = stateFor(permit.modelId, permit.scope);
    if (permit.probe) {
        state.probeInFlight = false;
        state.openLevel = Math.min(state.openLevel + 1, MAX_OPEN_LEVEL);
        const duration = openDurationMs(state.openLevel);
        state.openUntil = now + duration;
        state.failureTimes = [];
        return { opened: true, retryAfterMs: duration };
    }
    // A normal request may have started just before another request opened the
    // circuit. Its failure must not shorten or restart the active open interval.
    if (state.openUntil > now) {
        return { opened: true, retryAfterMs: state.openUntil - now };
    }
    const windowStart = now - CODEX_CAPACITY_FAILURE_WINDOW_MS;
    state.failureTimes = state.failureTimes.filter(timestamp => timestamp >= windowStart);
    state.failureTimes.push(now);
    if (state.failureTimes.length < CODEX_CAPACITY_FAILURE_THRESHOLD) {
        return { opened: false, retryAfterMs: 0 };
    }
    const duration = openDurationMs(state.openLevel);
    state.openUntil = now + duration;
    state.failureTimes = [];
    state.probeInFlight = false;
    return { opened: true, retryAfterMs: duration };
}
export function recordCodexModelSuccess(permit) {
    const key = circuitKey(permit.modelId, permit.scope);
    const state = circuits.get(key);
    if (!state)
        return;
    // Only the designated half-open probe may close an open circuit. A normal
    // request that was already in flight when the circuit opened cannot do so.
    if (permit.probe) {
        circuits.delete(key);
    }
}
export function releaseCodexModelProbe(permit) {
    if (!permit.probe)
        return;
    const state = circuits.get(circuitKey(permit.modelId, permit.scope));
    if (state)
        state.probeInFlight = false;
}
export function resetCodexModelCircuits() {
    circuits.clear();
}
export function getCodexModelCircuitState(modelId, scope = 'operator') {
    const state = circuits.get(circuitKey(modelId, scope));
    return state ? { ...state, failureTimes: [...state.failureTimes] } : null;
}
//# sourceMappingURL=codex-model-circuit-breaker.js.map