import { execFile } from 'node:child_process';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
const execFileAsync = promisify(execFile);
export const AGENT_TOOL_DEFINITIONS = [
    { type: 'function', function: { name: 'read_file', description: 'Read a UTF-8 text file inside the workspace.', parameters: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'], additionalProperties: false } } },
    { type: 'function', function: { name: 'write_file', description: 'Write a UTF-8 text file inside the workspace.', parameters: { type: 'object', properties: { path: { type: 'string' }, content: { type: 'string' } }, required: ['path', 'content'], additionalProperties: false } } },
    { type: 'function', function: { name: 'git_diff', description: 'Show the current Git diff inside the workspace.', parameters: { type: 'object', properties: {}, additionalProperties: false } } },
    { type: 'function', function: { name: 'run_command', description: 'Run a short, non-interactive development command inside the workspace.', parameters: { type: 'object', properties: { command: { type: 'string' } }, required: ['command'], additionalProperties: false } } },
];
const DENIED_COMMAND = /(^|[;&|`])\s*(rm\s+-rf|shutdown|reboot|mkfs|dd\s+if=|curl\s+.*\|\s*sh|wget\s+.*\|\s*sh)|>\s*\/etc\//i;
export function agentWorkspace() {
    const configured = process.env.AGENT_WORKSPACE?.trim();
    if (!configured)
        throw new Error('AGENT_WORKSPACE is not configured');
    return path.resolve(configured);
}
function safePath(workspace, requested) {
    if (!requested || path.isAbsolute(requested))
        throw new Error('Path must be relative to the workspace');
    const resolved = path.resolve(workspace, requested);
    if (resolved !== workspace && !resolved.startsWith(`${workspace}${path.sep}`))
        throw new Error('Path escapes the workspace');
    return resolved;
}
async function run(workspace, command) {
    if (!command.trim() || command.length > 2000)
        throw new Error('Command is empty or too long');
    if (DENIED_COMMAND.test(command))
        throw new Error('Command blocked by the workspace safety policy');
    const { stdout, stderr } = await execFileAsync('/bin/sh', ['-lc', command], { cwd: workspace, timeout: 30_000, maxBuffer: 512 * 1024 });
    return `${stdout}${stderr ? `\n[stderr]\n${stderr}` : ''}`.slice(0, 512 * 1024);
}
export async function executeAgentTool(name, rawArguments) {
    const workspace = agentWorkspace();
    const args = JSON.parse(rawArguments || '{}');
    if (name === 'read_file')
        return (await fs.readFile(safePath(workspace, String(args.path ?? '')), 'utf8')).slice(0, 512 * 1024);
    if (name === 'write_file') {
        const target = safePath(workspace, String(args.path ?? ''));
        await fs.mkdir(path.dirname(target), { recursive: true });
        await fs.writeFile(target, String(args.content ?? ''), 'utf8');
        return `Wrote ${path.relative(workspace, target)}`;
    }
    if (name === 'git_diff')
        return run(workspace, 'git diff -- .');
    if (name === 'run_command')
        return run(workspace, String(args.command ?? ''));
    throw new Error(`Unknown agent tool: ${name}`);
}
//# sourceMappingURL=agent-tools.js.map