import type { Db } from '../db/types.js';
export declare function parseCodexModelIds(payload: unknown): string[];
export declare function discoverCodexModels(accessToken: string, accountId?: string | null): Promise<string[]>;
export declare function replaceCodexAccountModels(db: Db, accountId: number, modelIds: string[]): void;
//# sourceMappingURL=codex-model-discovery.d.ts.map