export declare function encryptCodexToken(token: string): {
    encrypted: string;
    iv: string;
    authTag: string;
};
export declare function decryptCodexToken(encrypted: string, iv: string, authTag: string): string;
//# sourceMappingURL=codex-token.d.ts.map