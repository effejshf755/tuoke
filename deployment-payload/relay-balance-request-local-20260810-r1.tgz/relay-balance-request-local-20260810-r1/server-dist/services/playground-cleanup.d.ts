import type { Scheduler } from '../lib/scheduler.js';
export declare function startPlaygroundCleanup(scheduler: Scheduler): void;
//# sourceMappingURL=playground-cleanup.d.ts.map