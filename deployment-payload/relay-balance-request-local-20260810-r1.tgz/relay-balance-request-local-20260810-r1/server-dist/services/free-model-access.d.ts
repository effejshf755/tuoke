import type { Db } from '../db/types.js';
export declare const FREE_DAILY_LIMIT = 50;
export declare const MEMBER_DAILY_LIMIT = 1000;
export declare const PAID_MODEL_SAFETY_BALANCE_MICRO = 100000;
export declare const PAID_MODEL_MINIMUM_BALANCE_MICRO = 100000;
/**
 * Paid requests keep a zero-value tracking reservation.  This preserves the
 * existing exactly-once settlement link without hiding spendable funds from
 * the user while the request is running.
 */
export declare function getPaidRequestDepositMicro(estimatedMicro: number, availableMicro: number): number | null;
export declare function isExplicitFreeModel(db: Db, requestedModel: string | null): boolean;
export declare function consumeFreeModelRequest(db: Db, userId: number): {
    allowed: boolean;
    limit: number;
    used: number;
    membershipUntil: string | null;
    usageDate: string;
};
export interface FreeModelAccessStatus {
    membershipActive: boolean;
    membershipExpiresAt: string | null;
    membershipRemainingSeconds: number;
    usageDate: string;
    resetAt: string;
    dailyLimit: number;
    usedToday: number;
    remainingToday: number;
}
export declare function getFreeModelAccessStatus(db: Db, userId: number): FreeModelAccessStatus | null;
export declare function releaseFreeModelRequest(db: Db, userId: number, usageDate: string): void;
export declare function getAvailableBalanceMicro(db: Db, userId: number): number | null;
//# sourceMappingURL=free-model-access.d.ts.map