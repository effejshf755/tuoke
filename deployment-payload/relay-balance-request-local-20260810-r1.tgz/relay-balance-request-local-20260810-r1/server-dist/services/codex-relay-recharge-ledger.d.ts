import type { Db } from '../db/types.js';
export declare const CODEX_RELAY_LEDGER_CURRENCIES: readonly ["USD", "CNY"];
export type CodexRelayLedgerCurrency = typeof CODEX_RELAY_LEDGER_CURRENCIES[number];
export declare const MAX_CODEX_RELAY_LEDGER_AMOUNT = 1000000;
export declare const MAX_CODEX_RELAY_LEDGER_AMOUNT_MICRO: number;
export declare const MAX_CODEX_RELAY_LEDGER_NOTE_LENGTH = 500;
export interface CodexRelayRechargeLedgerEntry {
    id: number;
    sourceId: number;
    amountMicro: number;
    currency: CodexRelayLedgerCurrency;
    note: string | null;
    occurredAt: string;
    createdAt: string;
    createdByUserId: number | null;
}
export interface CodexRelayRechargeLedgerTotal {
    amountMicro: number;
}
export interface CodexRelayRechargeLedger {
    sourceId: number;
    entries: CodexRelayRechargeLedgerEntry[];
    totals: Record<CodexRelayLedgerCurrency, CodexRelayRechargeLedgerTotal>;
}
/**
 * Convert a JSON decimal amount to exact integer micro-units. Numeric and
 * string inputs are accepted, but rounding is never performed: more than six
 * fractional digits, exponent notation, unsafe values, zero, and values above
 * the per-entry ceiling are rejected.
 */
export declare function decimalRelayLedgerAmountToMicro(value: unknown): number | null;
export declare function listCodexRelayRechargeLedger(db: Db, sourceId: number): CodexRelayRechargeLedger | null;
export declare function createCodexRelayRechargeLedgerEntry(db: Db, input: {
    sourceId: number;
    amountMicro: number;
    currency: CodexRelayLedgerCurrency;
    note?: string | null;
    occurredAt: string;
    createdByUserId?: number | null;
}): CodexRelayRechargeLedgerEntry | null;
export type DeleteCodexRelayRechargeLedgerEntryResult = 'deleted' | 'source_not_found' | 'entry_not_found';
export declare function deleteCodexRelayRechargeLedgerEntry(db: Db, sourceId: number, entryId: number): DeleteCodexRelayRechargeLedgerEntryResult;
//# sourceMappingURL=codex-relay-recharge-ledger.d.ts.map