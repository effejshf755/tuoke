function safeMicro(value, label) {
    const amount = Math.trunc(value);
    if (!Number.isSafeInteger(amount) || amount < 0) {
        throw new Error(`${label} must be a non-negative safe integer`);
    }
    return amount;
}
function insertLedger(db, input) {
    db.prepare(`
    INSERT INTO promotion_credit_ledger (
      user_id, grant_id, event_type, remaining_delta_micro,
      reserved_delta_micro, remaining_after_micro, reserved_after_micro,
      wallet_reservation_id, request_id, note
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(input.userId, input.grantId, input.eventType, input.remainingDeltaMicro ?? 0, input.reservedDeltaMicro ?? 0, input.remainingAfterMicro, input.reservedAfterMicro, input.walletReservationId ?? null, input.requestId ?? null, input.note ?? null);
}
function readGrant(db, grantId) {
    const grant = db.prepare(`
    SELECT g.id, g.user_id AS userId, g.offer_id AS offerId,
      g.purchase_id AS purchaseId, g.recharge_order_id AS rechargeOrderId,
      g.granted_micro AS grantedMicro,
      COALESCE((
        SELECT SUM(-l.remaining_delta_micro)
        FROM promotion_credit_ledger l
        WHERE l.grant_id = g.id AND l.event_type = 'usage'
      ), 0) AS usedMicro,
      g.remaining_micro AS remainingMicro, g.reserved_micro AS reservedMicro,
      g.expires_at AS expiresAt, g.status, g.created_at AS createdAt
    FROM promotion_credit_grants g WHERE g.id = ?
  `).get(grantId);
    if (!grant)
        throw new Error('Promotion credit grant not found');
    return grant;
}
function expireReleasedGrantIfNeeded(db, grantId) {
    const grant = readGrant(db, grantId);
    if (grant.remainingMicro === 0) {
        db.prepare(`
      UPDATE promotion_credit_grants
      SET status = 'exhausted', updated_at = datetime('now')
      WHERE id = ? AND status = 'active'
    `).run(grant.id);
        return;
    }
    const expired = db.prepare(`
    SELECT 1 AS expired WHERE datetime(?) <= datetime('now')
  `).get(grant.expiresAt);
    if (!expired || grant.reservedMicro > 0 || grant.status !== 'active')
        return;
    const updated = db.prepare(`
    UPDATE promotion_credit_grants
    SET remaining_micro = 0, status = 'expired', updated_at = datetime('now')
    WHERE id = ? AND status = 'active' AND reserved_micro = 0
      AND datetime(expires_at) <= datetime('now')
  `).run(grant.id);
    if (updated.changes !== 1)
        return;
    insertLedger(db, {
        userId: grant.userId,
        grantId: grant.id,
        eventType: 'expire',
        remainingDeltaMicro: -grant.remainingMicro,
        remainingAfterMicro: 0,
        reservedAfterMicro: 0,
        note: 'Unused promotion credit expired',
    });
}
export function createPromotionCreditGrant(db, input) {
    const grantedMicro = safeMicro(input.grantedMicro, 'grantedMicro');
    const validitySeconds = Math.trunc(input.validitySeconds);
    if (grantedMicro <= 0 || !Number.isSafeInteger(validitySeconds) || validitySeconds <= 0) {
        throw new Error('Promotion credit grant amount and validity must be positive');
    }
    const purchaseId = input.purchaseId ?? null;
    const rechargeOrderId = input.rechargeOrderId ?? null;
    if ((purchaseId === null) === (rechargeOrderId === null)) {
        throw new Error('Promotion credit grant requires exactly one source order');
    }
    return db.transaction(() => {
        const existing = db.prepare(`
      SELECT id FROM promotion_credit_grants
      WHERE (? IS NOT NULL AND purchase_id = ?)
         OR (? IS NOT NULL AND recharge_order_id = ?)
      LIMIT 1
    `).get(purchaseId, purchaseId, rechargeOrderId, rechargeOrderId);
        if (existing) {
            return { grant: mapGrant(readGrant(db, existing.id)), alreadyCreated: true };
        }
        const inserted = db.prepare(`
      INSERT INTO promotion_credit_grants (
        user_id, offer_id, purchase_id, recharge_order_id, granted_micro,
        remaining_micro, reserved_micro, expires_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, 0, datetime('now', ?), 'active')
    `).run(input.userId, input.offerId, purchaseId, rechargeOrderId, grantedMicro, grantedMicro, `+${validitySeconds} seconds`);
        const grant = readGrant(db, Number(inserted.lastInsertRowid));
        insertLedger(db, {
            userId: input.userId,
            grantId: grant.id,
            eventType: 'grant',
            remainingDeltaMicro: grantedMicro,
            remainingAfterMicro: grantedMicro,
            reservedAfterMicro: 0,
            note: 'Promotion credit granted',
        });
        return { grant: mapGrant(grant), alreadyCreated: false };
    })();
}
function mapGrant(row) {
    const unexpired = Date.parse(`${row.expiresAt.replace(' ', 'T')}Z`) > Date.now();
    const expiredByTime = row.status === 'active' && !unexpired;
    return {
        ...row,
        // Expiry invalidates the user-visible balance immediately. Real usage is
        // tracked separately from forfeited credit in usedMicro.
        status: expiredByTime ? 'expired' : row.status,
        remainingMicro: expiredByTime ? 0 : row.remainingMicro,
        availableMicro: row.status === 'active' && unexpired
            ? Math.max(0, row.remainingMicro - row.reservedMicro)
            : 0,
    };
}
export function getAvailablePromotionCreditMicro(db, userId) {
    const row = db.prepare(`
    SELECT COALESCE(SUM(remaining_micro - reserved_micro), 0) AS availableMicro
    FROM promotion_credit_grants
    WHERE user_id = ? AND status = 'active'
      AND datetime(expires_at) > datetime('now')
      AND remaining_micro > reserved_micro
  `).get(userId);
    return Math.max(0, Number(row.availableMicro ?? 0));
}
export function getReservedPromotionCreditMicro(db, walletReservationId) {
    const row = db.prepare(`
    SELECT COALESCE(SUM(reserved_micro), 0) AS reservedMicro
    FROM promotion_credit_allocations
    WHERE wallet_reservation_id = ? AND status = 'reserved'
  `).get(walletReservationId);
    return Math.max(0, Number(row.reservedMicro ?? 0));
}
export function getPromotionCreditReservationExpiryBreakdown(db, walletReservationId) {
    const row = db.prepare(`
    SELECT
      COALESCE(SUM(CASE
        WHEN g.status = 'active' AND datetime(g.expires_at) > datetime('now')
        THEN a.reserved_micro ELSE 0 END), 0) AS activeReservedMicro,
      COALESCE(SUM(CASE
        WHEN g.status != 'active' OR datetime(g.expires_at) <= datetime('now')
        THEN a.reserved_micro ELSE 0 END), 0) AS expiredReservedMicro
    FROM promotion_credit_allocations a
    JOIN promotion_credit_grants g ON g.id = a.grant_id
    WHERE a.wallet_reservation_id = ? AND a.status = 'reserved'
  `).get(walletReservationId);
    return {
        activeReservedMicro: Math.max(0, Number(row.activeReservedMicro ?? 0)),
        expiredReservedMicro: Math.max(0, Number(row.expiredReservedMicro ?? 0)),
    };
}
export function getPromotionCreditSummary(db, userId, detailLimit = 100) {
    const safeDetailLimit = Math.min(500, Math.max(1, Math.trunc(detailLimit)));
    const totals = db.prepare(`
    WITH usage_by_grant AS (
      SELECT grant_id,
        COALESCE(SUM(CASE WHEN event_type = 'usage'
          THEN -remaining_delta_micro ELSE 0 END), 0) AS usedMicro
      FROM promotion_credit_ledger
      GROUP BY grant_id
    )
    SELECT
      COUNT(*) AS grantCount,
      COALESCE(SUM(g.granted_micro), 0) AS grantedMicro,
      COALESCE(SUM(COALESCE(u.usedMicro, 0)), 0) AS usedMicro,
      COALESCE(SUM(CASE
        WHEN g.status = 'active' AND datetime(g.expires_at) > datetime('now')
        THEN g.remaining_micro ELSE 0 END), 0) AS remainingMicro,
      COALESCE(SUM(CASE
        WHEN g.status = 'active' AND datetime(g.expires_at) > datetime('now')
        THEN g.reserved_micro ELSE 0 END), 0) AS reservedMicro,
      COALESCE(SUM(CASE
        WHEN g.status = 'active' AND datetime(g.expires_at) > datetime('now')
        THEN MAX(0, g.remaining_micro - g.reserved_micro) ELSE 0 END), 0) AS availableMicro,
      MIN(CASE
        WHEN g.status = 'active' AND datetime(g.expires_at) > datetime('now')
          AND g.remaining_micro > g.reserved_micro
        THEN g.expires_at ELSE NULL END) AS nextExpiresAt
    FROM promotion_credit_grants g
    LEFT JOIN usage_by_grant u ON u.grant_id = g.id
    WHERE g.user_id = ?
  `).get(userId);
    const rows = db.prepare(`
    SELECT g.id, g.user_id AS userId, g.offer_id AS offerId,
      g.purchase_id AS purchaseId, g.recharge_order_id AS rechargeOrderId,
      g.granted_micro AS grantedMicro,
      COALESCE((
        SELECT SUM(-l.remaining_delta_micro)
        FROM promotion_credit_ledger l
        WHERE l.grant_id = g.id AND l.event_type = 'usage'
      ), 0) AS usedMicro,
      g.remaining_micro AS remainingMicro, g.reserved_micro AS reservedMicro,
      g.expires_at AS expiresAt, g.status, g.created_at AS createdAt
    FROM promotion_credit_grants g
    WHERE g.user_id = ?
    ORDER BY
      CASE WHEN g.status = 'active' AND datetime(g.expires_at) > datetime('now')
        THEN 0 ELSE 1 END,
      CASE WHEN g.status = 'active' AND datetime(g.expires_at) > datetime('now')
        THEN datetime(g.expires_at) END ASC,
      g.id DESC
    LIMIT ?
  `).all(userId, safeDetailLimit);
    const grants = rows.map(mapGrant);
    return {
        grantedMicro: Number(totals.grantedMicro ?? 0),
        usedMicro: Number(totals.usedMicro ?? 0),
        remainingMicro: Number(totals.remainingMicro ?? 0),
        reservedMicro: Number(totals.reservedMicro ?? 0),
        availableMicro: Number(totals.availableMicro ?? 0),
        nextExpiresAt: totals.nextExpiresAt ?? null,
        grantCount: Number(totals.grantCount ?? 0),
        detailsTruncated: Number(totals.grantCount ?? 0) > grants.length,
        grants,
    };
}
function assertOpenWalletReservation(db, userId, walletReservationId) {
    const row = db.prepare(`
    SELECT user_id AS userId, status
    FROM wallet_reservations WHERE id = ?
  `).get(walletReservationId);
    if (!row || row.userId !== userId)
        throw new Error('Wallet reservation does not belong to user');
    if (row.status !== 'reserved')
        throw new Error('Wallet reservation is already finalized');
}
export function ensurePromotionCreditReservation(db, input) {
    const targetMicro = safeMicro(input.targetMicro, 'targetMicro');
    return db.transaction(() => {
        assertOpenWalletReservation(db, input.userId, input.walletReservationId);
        const finalized = db.prepare(`
      SELECT 1 FROM promotion_credit_allocations
      WHERE wallet_reservation_id = ? AND status <> 'reserved' LIMIT 1
    `).get(input.walletReservationId);
        if (finalized)
            throw new Error('Promotion credit reservation is already finalized');
        const current = db.prepare(`
      SELECT COALESCE(SUM(reserved_micro), 0) AS amount
      FROM promotion_credit_allocations
      WHERE wallet_reservation_id = ? AND status = 'reserved'
    `).get(input.walletReservationId);
        let totalReservedMicro = Number(current.amount ?? 0);
        let neededMicro = Math.max(0, targetMicro - totalReservedMicro);
        let newlyReservedMicro = 0;
        if (neededMicro > 0) {
            const grants = db.prepare(`
        SELECT id, remaining_micro AS remainingMicro, reserved_micro AS reservedMicro
        FROM promotion_credit_grants
        WHERE user_id = ? AND status = 'active'
          AND datetime(expires_at) > datetime('now')
          AND remaining_micro > reserved_micro
        ORDER BY datetime(expires_at), id
      `).all(input.userId);
            for (const grant of grants) {
                if (neededMicro <= 0)
                    break;
                const takeMicro = Math.min(neededMicro, grant.remainingMicro - grant.reservedMicro);
                if (takeMicro <= 0)
                    continue;
                const updated = db.prepare(`
          UPDATE promotion_credit_grants
          SET reserved_micro = reserved_micro + ?, updated_at = datetime('now')
          WHERE id = ? AND user_id = ? AND status = 'active'
            AND datetime(expires_at) > datetime('now')
            AND remaining_micro - reserved_micro >= ?
        `).run(takeMicro, grant.id, input.userId, takeMicro);
                if (updated.changes !== 1)
                    continue;
                db.prepare(`
          INSERT INTO promotion_credit_allocations (
            wallet_reservation_id, grant_id, reserved_micro, status
          ) VALUES (?, ?, ?, 'reserved')
          ON CONFLICT(wallet_reservation_id, grant_id) DO UPDATE SET
            reserved_micro = reserved_micro + excluded.reserved_micro
          WHERE status = 'reserved'
        `).run(input.walletReservationId, grant.id, takeMicro);
                const after = readGrant(db, grant.id);
                insertLedger(db, {
                    userId: input.userId,
                    grantId: grant.id,
                    eventType: 'reserve',
                    reservedDeltaMicro: takeMicro,
                    remainingAfterMicro: after.remainingMicro,
                    reservedAfterMicro: after.reservedMicro,
                    walletReservationId: input.walletReservationId,
                });
                neededMicro -= takeMicro;
                newlyReservedMicro += takeMicro;
                totalReservedMicro += takeMicro;
            }
        }
        return {
            totalReservedMicro,
            newlyReservedMicro,
            availableAfterMicro: getAvailablePromotionCreditMicro(db, input.userId),
        };
    })();
}
function readAllocations(db, walletReservationId) {
    return db.prepare(`
    SELECT a.id, a.wallet_reservation_id AS walletReservationId,
      a.grant_id AS grantId, g.user_id AS userId,
      a.reserved_micro AS reservedMicro, a.consumed_micro AS consumedMicro,
      a.status, a.request_id AS requestId,
      g.remaining_micro AS remainingMicro,
      g.reserved_micro AS grantReservedMicro,
      g.expires_at AS expiresAt
    FROM promotion_credit_allocations a
    JOIN promotion_credit_grants g ON g.id = a.grant_id
    WHERE a.wallet_reservation_id = ?
    ORDER BY datetime(g.expires_at), g.id
  `).all(walletReservationId);
}
export function settlePromotionCreditReservation(db, input) {
    const chargeMicro = safeMicro(input.chargeMicro, 'chargeMicro');
    return db.transaction(() => {
        const allocations = readAllocations(db, input.walletReservationId);
        if (allocations.some((item) => item.userId !== input.userId)) {
            throw new Error('Promotion credit allocation does not belong to user');
        }
        const settled = allocations.filter((item) => item.status === 'settled');
        const reserved = allocations.filter((item) => item.status === 'reserved');
        if (settled.length > 0) {
            if (reserved.length > 0 || settled.some((item) => item.requestId !== input.requestId)) {
                throw new Error('Promotion credit reservation settlement conflict');
            }
            const consumedMicro = settled.reduce((sum, item) => sum + item.consumedMicro, 0);
            return {
                consumedMicro,
                uncoveredMicro: Math.max(0, chargeMicro - consumedMicro),
                releasedMicro: 0,
            };
        }
        let chargeRemaining = chargeMicro;
        let consumedMicro = 0;
        let releasedMicro = 0;
        for (const allocation of reserved) {
            const consumed = Math.min(allocation.reservedMicro, chargeRemaining);
            const released = allocation.reservedMicro - consumed;
            const updated = db.prepare(`
        UPDATE promotion_credit_grants
        SET remaining_micro = remaining_micro - ?,
          reserved_micro = reserved_micro - ?,
          updated_at = datetime('now')
        WHERE id = ? AND user_id = ?
          AND remaining_micro >= ? AND reserved_micro >= ?
      `).run(consumed, allocation.reservedMicro, allocation.grantId, input.userId, consumed, allocation.reservedMicro);
            if (updated.changes !== 1)
                throw new Error('Promotion credit grant changed during settlement');
            const marked = db.prepare(`
        UPDATE promotion_credit_allocations
        SET consumed_micro = ?, status = 'settled', request_id = ?, settled_at = datetime('now')
        WHERE id = ? AND status = 'reserved'
      `).run(consumed, input.requestId, allocation.id);
            if (marked.changes !== 1)
                throw new Error('Promotion credit allocation changed during settlement');
            const after = readGrant(db, allocation.grantId);
            if (consumed > 0) {
                insertLedger(db, {
                    userId: input.userId,
                    grantId: allocation.grantId,
                    eventType: 'usage',
                    remainingDeltaMicro: -consumed,
                    reservedDeltaMicro: -consumed,
                    remainingAfterMicro: after.remainingMicro,
                    reservedAfterMicro: after.reservedMicro + released,
                    walletReservationId: input.walletReservationId,
                    requestId: input.requestId,
                });
            }
            if (released > 0) {
                insertLedger(db, {
                    userId: input.userId,
                    grantId: allocation.grantId,
                    eventType: 'release',
                    reservedDeltaMicro: -released,
                    remainingAfterMicro: after.remainingMicro,
                    reservedAfterMicro: after.reservedMicro,
                    walletReservationId: input.walletReservationId,
                    requestId: input.requestId,
                });
            }
            expireReleasedGrantIfNeeded(db, allocation.grantId);
            chargeRemaining -= consumed;
            consumedMicro += consumed;
            releasedMicro += released;
        }
        return { consumedMicro, uncoveredMicro: chargeRemaining, releasedMicro };
    })();
}
export function releasePromotionCreditReservation(db, walletReservationId) {
    return db.transaction(() => {
        const allocations = readAllocations(db, walletReservationId)
            .filter((item) => item.status === 'reserved');
        let releasedMicro = 0;
        for (const allocation of allocations) {
            const updated = db.prepare(`
        UPDATE promotion_credit_grants
        SET reserved_micro = reserved_micro - ?, updated_at = datetime('now')
        WHERE id = ? AND reserved_micro >= ?
      `).run(allocation.reservedMicro, allocation.grantId, allocation.reservedMicro);
            if (updated.changes !== 1)
                throw new Error('Promotion credit grant changed during release');
            const marked = db.prepare(`
        UPDATE promotion_credit_allocations
        SET status = 'released', settled_at = datetime('now')
        WHERE id = ? AND status = 'reserved'
      `).run(allocation.id);
            if (marked.changes !== 1)
                throw new Error('Promotion credit allocation changed during release');
            const after = readGrant(db, allocation.grantId);
            insertLedger(db, {
                userId: allocation.userId,
                grantId: allocation.grantId,
                eventType: 'release',
                reservedDeltaMicro: -allocation.reservedMicro,
                remainingAfterMicro: after.remainingMicro,
                reservedAfterMicro: after.reservedMicro,
                walletReservationId,
            });
            expireReleasedGrantIfNeeded(db, allocation.grantId);
            releasedMicro += allocation.reservedMicro;
        }
        return { releasedMicro };
    })();
}
export function expirePromotionCreditGrants(db) {
    return db.transaction(() => {
        const rows = db.prepare(`
      SELECT id, remaining_micro AS remainingMicro
      FROM promotion_credit_grants
      WHERE status = 'active' AND reserved_micro = 0
        AND remaining_micro > 0 AND datetime(expires_at) <= datetime('now')
      ORDER BY id
    `).all();
        let grantsExpired = 0;
        let microExpired = 0;
        for (const row of rows) {
            expireReleasedGrantIfNeeded(db, row.id);
            const after = readGrant(db, row.id);
            if (after.status === 'expired') {
                grantsExpired += 1;
                microExpired += row.remainingMicro;
            }
        }
        return { grantsExpired, microExpired };
    })();
}
//# sourceMappingURL=promotion-credits.js.map