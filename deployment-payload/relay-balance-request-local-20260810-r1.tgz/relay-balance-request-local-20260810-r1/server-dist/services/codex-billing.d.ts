import type { Db } from '../db/types.js';
import type { BillingReservationEstimate } from './billing-reservation.js';
/**
 * Reserve against the most expensive real model currently available in the
 * Codex pool. The public alias remains `codex`, while settlement uses the
 * actual model selected by the router. Shared third-party relays are included
 * only when their source and mapping are actually dispatchable for this key.
 */
export declare function estimateCodexBillingReservation(db: Db, body: unknown, consumerApiKeyId?: number | null): BillingReservationEstimate;
//# sourceMappingURL=codex-billing.d.ts.map