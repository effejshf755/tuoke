import type { Db } from '../db/types.js';
import { type ResourceRefundResult } from './resource-purchase.js';
export declare const ADMIN_RESOURCE_ORDER_STATUSES: readonly ["pending_payment", "paid_waiting_group", "grouped", "active", "refunded"];
export type AdminResourceOrderStatus = typeof ADMIN_RESOURCE_ORDER_STATUSES[number];
export declare function listAdminResourceOrders(db: Db, status?: AdminResourceOrderStatus): unknown[];
export declare function getAdminResourceOrderDetail(db: Db, orderId: number): {
    order: {};
    members: unknown[];
} | null;
export declare function adminRefundResourceOrder(db: Db, input: {
    orderId: number;
    adminId: number;
}): ResourceRefundResult;
export declare function adminCancelResourceSubpool(db: Db, input: {
    subpoolId: number;
    adminId: number;
}): {
    subpoolId: number;
    orderCount: number;
    refundedMicro: number;
};
export declare function adminDeleteRefundedResourceOrders(db: Db, input: {
    orderIds: number[];
    adminId: number;
}): {
    deletedCount: number;
    orderIds: number[];
};
export declare function adminDeleteResourceSubpool(db: Db, input: {
    subpoolId: number;
    adminId: number;
}): {
    subpoolId: number;
    deleted: boolean;
};
//# sourceMappingURL=resource-admin-orders.d.ts.map