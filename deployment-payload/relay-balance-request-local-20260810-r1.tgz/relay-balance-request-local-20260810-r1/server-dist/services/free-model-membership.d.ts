import type { Db } from '../db/types.js';
import { type FreeModelAccessStatus } from './free-model-access.js';
export declare const FREE_MODEL_MEMBERSHIP_PRICE_MICRO = 10000000;
export declare const FREE_MODEL_MEMBERSHIP_PERIOD_DAYS = 30;
export type FreeModelMembershipPurchaseErrorCode = 'invalid_idempotency_key' | 'purchase_conflict' | 'insufficient_balance' | 'wallet_busy';
export declare class FreeModelMembershipPurchaseError extends Error {
    readonly code: FreeModelMembershipPurchaseErrorCode;
    constructor(code: FreeModelMembershipPurchaseErrorCode, message: string);
}
export interface FreeModelMembershipPurchase {
    id: number;
    purchaseNo: string;
    userId: number;
    walletTransactionId: number | null;
    priceMicro: number;
    startsAt: string;
    expiresAt: string;
    createdAt: string;
}
export declare function purchaseFreeModelMembership(db: Db, input: {
    userId: number;
    idempotencyKey: string;
}): {
    purchase: FreeModelMembershipPurchase;
    membership: FreeModelAccessStatus;
    balanceAfterMicro: number;
    alreadyProcessed: boolean;
};
//# sourceMappingURL=free-model-membership.d.ts.map