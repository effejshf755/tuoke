import { getDb } from '../db/index.js';
import { decrypt } from '../lib/crypto.js';
import { getProvider, resolveProvider } from '../providers/index.js';
import { customProviderKeyMatchSql } from '../lib/custom-provider-pool.js';
const MODEL_HEALTH_BOOT_DELAY_MS = 10 * 1000;
const MODEL_HEALTH_INTERVAL_MS = 24 * 60 * 60 * 1000;
let cancelModelHealthBoot = null;
let cancelModelHealthInterval = null;
function healthKey(platform, modelId) {
    return `${platform}:${modelId}`;
}
function readHealth(db) {
    const row = db.prepare("SELECT value FROM settings WHERE key = 'model_health'").get();
    if (!row?.value)
        return {};
    try {
        const parsed = JSON.parse(row.value);
        return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    }
    catch {
        return {};
    }
}
function writeHealth(db, health) {
    db.prepare(`
    INSERT INTO settings (key, value) VALUES ('model_health', ?)
    ON CONFLICT(key) DO UPDATE SET value = excluded.value
  `).run(JSON.stringify(health));
}
function errorText(error) {
    const message = error instanceof Error ? error.message : String(error);
    return message.replace(/[\r\n]+/g, ' ').slice(0, 500);
}
function saveResult(db, model, result) {
    const health = readHealth(db);
    health[healthKey(model.platform, model.model_id)] = result;
    writeHealth(db, health);
}
export function getModelHealthMap(db = getDb()) {
    return readHealth(db);
}
export async function checkModelHealth(modelDbId) {
    const db = getDb();
    const model = db.prepare(`
    SELECT id, platform, model_id, display_name, key_id
      FROM models
     WHERE id = ?
  `).get(modelDbId);
    if (!model)
        throw Object.assign(new Error('Unknown model'), { statusCode: 404 });
    const startedAt = Date.now();
    const checkedAt = () => new Date().toISOString();
    try {
        const key = model.key_id == null
            ? db.prepare(`
          SELECT id, platform, encrypted_key, iv, auth_tag, base_url
            FROM api_keys
           WHERE platform = ? AND role = 'provider' AND enabled = 1 AND status IN ('healthy', 'unknown')
           ORDER BY CASE WHEN status = 'healthy' THEN 0 ELSE 1 END, id ASC
           LIMIT 1
        `).get(model.platform)
            : model.platform === 'custom'
                ? db.prepare(`
          SELECT candidate.id, candidate.platform, candidate.encrypted_key,
                 candidate.iv, candidate.auth_tag, candidate.base_url
          FROM api_keys candidate
          JOIN api_keys anchor
            ON anchor.id = ?
           AND anchor.platform = 'custom'
           AND anchor.role = 'provider'
           AND candidate.base_url = anchor.base_url
          WHERE candidate.platform = 'custom'
            AND candidate.role = 'provider'
            AND candidate.enabled = 1
            AND candidate.status IN ('healthy', 'unknown')
          ORDER BY CASE WHEN candidate.status = 'healthy' THEN 0 ELSE 1 END,
                   candidate.last_checked_at ASC,
                   candidate.id ASC
          LIMIT 1
        `).get(model.key_id)
                : db.prepare(`
          SELECT id, platform, encrypted_key, iv, auth_tag, base_url
            FROM api_keys
           WHERE id = ? AND platform = ? AND role = 'provider' AND enabled = 1
        `).get(model.key_id, model.platform);
        if (!key)
            throw new Error(`No enabled API key for platform ${model.platform}`);
        const provider = model.platform === 'custom'
            ? resolveProvider('custom', key.base_url)
            : getProvider(model.platform);
        if (!provider)
            throw new Error(`No provider registered for platform ${model.platform}`);
        const apiKey = decrypt(key.encrypted_key, key.iv, key.auth_tag);
        await provider.chatCompletion(apiKey, [{ role: 'user', content: 'health check' }], model.model_id, { max_tokens: 1, timeoutMs: 60_000 });
        const result = {
            status: 'success',
            lastCheckedAt: checkedAt(),
            error: null,
            latencyMs: Date.now() - startedAt,
        };
        saveResult(db, model, result);
        return result;
    }
    catch (error) {
        const result = {
            status: 'failed',
            lastCheckedAt: checkedAt(),
            error: errorText(error),
            latencyMs: Date.now() - startedAt,
        };
        saveResult(db, model, result);
        return result;
    }
}
export async function checkAllModelsHealth(concurrency = 2) {
    const providerKeyMatch = customProviderKeyMatchSql('m', 'k');
    // Scheduled checks should represent configured routes, not every catalog row.
    // Codex uses its own OAuth account health/quota sync and has no api_keys row.
    const rows = getDb().prepare(`
    SELECT m.id
      FROM models m
     WHERE m.enabled = 1
       AND m.platform <> 'openai-codex'
       AND EXISTS (
         SELECT 1
           FROM api_keys k
          WHERE k.platform = m.platform
            AND k.role = 'provider'
            AND k.enabled = 1
            AND k.status IN ('healthy', 'unknown')
            AND ${providerKeyMatch}
       )
     ORDER BY m.id ASC
  `).all();
    let nextIndex = 0;
    let success = 0;
    let failed = 0;
    const workerCount = Math.min(Math.max(1, concurrency), Math.max(1, rows.length));
    const worker = async () => {
        while (true) {
            const index = nextIndex++;
            const row = rows[index];
            if (!row)
                return;
            const result = await checkModelHealth(row.id);
            if (result.status === 'success')
                success += 1;
            else
                failed += 1;
        }
    };
    await Promise.all(Array.from({ length: workerCount }, () => worker()));
    return { total: rows.length, success, failed };
}
export function startModelHealthScheduler(scheduler) {
    if (cancelModelHealthInterval)
        return;
    const run = () => {
        void checkAllModelsHealth(2)
            .then((result) => {
            console.log(`[model-health] completed: total=${result.total}, success=${result.success}, failed=${result.failed}`);
        })
            .catch((error) => {
            console.error(`[model-health] scheduled check failed: ${error instanceof Error ? error.message : error}`);
        });
    };
    cancelModelHealthBoot = scheduler.after(MODEL_HEALTH_BOOT_DELAY_MS, run);
    cancelModelHealthInterval = scheduler.every(MODEL_HEALTH_INTERVAL_MS, run, { name: 'model-health-daily-check' });
    console.log('[model-health] scheduled: first check in 10s, then every 24h');
}
export function stopModelHealthScheduler() {
    if (cancelModelHealthBoot) {
        cancelModelHealthBoot();
        cancelModelHealthBoot = null;
    }
    if (cancelModelHealthInterval) {
        cancelModelHealthInterval();
        cancelModelHealthInterval = null;
    }
}
//# sourceMappingURL=model-health.js.map