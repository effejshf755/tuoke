import type { Db } from '../db/types.js';
export declare const DEFAULT_CACHE_WRITE_MULTIPLIER_MILLI = 1250;
export interface BillingRule {
    id: number;
    platform: string;
    modelId: string;
    inputPriceMicroPerMillion: number;
    outputPriceMicroPerMillion: number;
    multiplierMilli: number;
    cachedInputMultiplierMilli: number;
    billingEnabled: 0 | 1;
}
export interface WalletSummary {
    userId: number;
    balanceMicro: number;
}
export type ChargeResult = {
    status: 'charged';
    amountMicro: number;
    balanceAfterMicro: number;
} | {
    status: 'free';
    amountMicro: 0;
    balanceAfterMicro: number;
} | {
    status: 'already_processed' | 'not_billable' | 'no_billing_rule' | 'insufficient_balance' | 'request_not_found';
    amountMicro?: number;
    balanceAfterMicro?: number;
};
export declare function getUserWallet(db: Db, userId: number): WalletSummary | null;
export declare function getModelBillingRule(db: Db, platform: string, modelId: string): BillingRule | null;
/**
 * Resolve a Codex group's optional per-model price override while preserving
 * the global rule's billing switch. Non-Codex requests and resource-subpool
 * keys continue to use the global model rule unchanged.
 */
export declare function getEffectiveModelBillingRule(db: Db, platform: string, modelId: string, consumerApiKeyId: number | null): BillingRule | null;
/**
 * 精确计算一次模型请求费用。
 *
 * 金额单位：
 * 1 元 = 1,000,000 micro
 *
 * 模型价格单位：
 * micro / 1,000,000 tokens
 *
 * 倍率：
 * 1000 = 1x
 * 1500 = 1.5x
 * 2000 = 2x
 *
 * 最终结果向上取整到 1 micro，
 * 避免极小调用因为整数除法变成 0 元。
 */
export declare function calculateBillingAmountMicro(inputTokens: number, outputTokens: number, inputPriceMicroPerMillion: number, outputPriceMicroPerMillion: number, multiplierMilli: number, cachedInputTokens?: number, cachedInputMultiplierMilli?: number, cacheWriteTokens?: number, cacheWriteMultiplierMilli?: number): number;
export interface ComputePointBillingUsage {
    inputTokens: number;
    cachedInputTokens?: number;
    cacheWriteTokens?: number;
    outputTokens: number;
    inputComputePoints?: number | null;
    outputComputePoints?: number | null;
    computePointsPerMillionTokens?: number | null;
}
/**
 * Prices every request bucket in compute points. New request rows carry the
 * exact conversion snapshot used when their usage was recorded; legacy rows
 * without a snapshot retain the historical 1:1 token behavior.
 */
export declare function calculateComputePointBillingAmountMicro(usage: ComputePointBillingUsage, inputPriceMicroPerMillion: number, outputPriceMicroPerMillion: number, multiplierMilli: number, cachedInputMultiplierMilli?: number, cacheWriteMultiplierMilli?: number): number;
/**
 * 根据 request_id 对一次请求进行结算。
 *
 * 重要：
 * - 只对 success 请求收费
 * - 系统/管理员非消费者请求不收费
 * - 使用实际 platform + model_id
 * - 使用实际 input/output tokens
 * - 已结算请求不会重复收费
 * - 扣余额、写流水、更新 requests 在同一事务完成
 */
export declare function chargeRequest(db: Db, requestId: number): ChargeResult;
export declare function applyCodexGroupMultiplier(_db: Db, _platform: string, _consumerApiKeyId: number | null, modelMultiplierMilli: number): number;
export declare function getUserBillingMultiplierMilli(db: Db, userId: number): number;
export declare function applyUserBillingMultiplier(db: Db, userId: number, multiplierMilli: number): number;
//# sourceMappingURL=billing.d.ts.map