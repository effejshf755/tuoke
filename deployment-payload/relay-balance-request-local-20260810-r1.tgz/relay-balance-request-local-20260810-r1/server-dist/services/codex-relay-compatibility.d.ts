import type { Db } from '../db/types.js';
export type CodexRelayCompatibilityStatus = 'untested' | 'needs_retest' | 'compatible' | 'partial' | 'incompatible';
export type CodexRelayCompatibilityStageStatus = 'passed' | 'warning' | 'failed' | 'skipped';
export interface CodexRelayCompatibilityStage {
    id: 'model_scope' | 'basic_response' | 'compaction' | 'streaming_sse' | 'multi_turn' | 'tool_call' | 'tool_roundtrip' | 'usage' | 'vision';
    label: string;
    status: CodexRelayCompatibilityStageStatus;
    latency_ms: number;
    message: string;
    details?: Record<string, string | number | boolean | null | string[]>;
}
export interface CodexRelayCompatibilityReport {
    version: 2;
    suite_version: typeof CODEX_RELAY_COMPATIBILITY_SUITE_VERSION;
    protocol: 'responses';
    api_key_id: number;
    api_key_label: string;
    masked_key: string;
    api_key_credential_revision: number;
    /** Public model alias selected by the administrator/default policy. Older
     * version-2 reports may omit this field, so readers must treat it as
     * optional. `model` remains the exact upstream model id used on the wire. */
    public_model_id?: string;
    model: string;
    started_at: string;
    completed_at: string;
    overall_status: Exclude<CodexRelayCompatibilityStatus, 'untested'>;
    requests_sent: number;
    stages: CodexRelayCompatibilityStage[];
    temporary_failure?: ProbeTemporaryFailure;
}
interface ProbeTemporaryFailure {
    status: number | null;
    retryAfterMs: number | null;
    message: string;
    kind: 'rate_limit' | 'temporary_upstream' | 'timeout' | 'connection';
    rateLimitScope?: 'rpm' | 'rpd' | 'account' | 'unknown';
}
export declare const CODEX_RELAY_COMPATIBILITY_SUITE_VERSION: "native-responses-v2";
/**
 * Run a bounded native Responses capability smoke test against one mapped
 * upstream model. This is evidence of protocol acceptance at the time of the
 * run, not a guarantee that every future prompt or vendor-specific feature is
 * compatible.
 */
export declare function testCodexRelaySourceCompatibility(db: Db, sourceId: number, options?: {
    apiKeyId?: number;
    publicModelId?: string;
}): Promise<CodexRelayCompatibilityReport>;
export {};
//# sourceMappingURL=codex-relay-compatibility.d.ts.map