import { decrypt } from '../lib/crypto.js';
import { sanitizeProviderErrorMessage } from '../lib/error-redaction.js';
import { prepareNativeResponsesCompactRequestBody, prepareNativeResponsesRequestBody, responsePayloadErrorDetails, } from '../lib/native-responses-relay.js';
import { proxyFetch } from '../lib/proxy.js';
import { parseRetryAfterMs } from '../providers/base.js';
const STAGE_TIMEOUT_MS = 30_000;
const OVERALL_TIMEOUT_MS = 110_000;
const MAX_CONCURRENT_TESTS = 2;
const MAX_JSON_RESPONSE_BYTES = 256 * 1024;
const MAX_SSE_RESPONSE_BYTES = 512 * 1024;
const MAX_STORED_REPORT_CHARS = 24_000;
export const CODEX_RELAY_COMPATIBILITY_SUITE_VERSION = 'native-responses-v2';
const TOOL_NAME = 'codex_relay_compatibility_echo';
const ONE_PIXEL_PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl2nWQAAAAASUVORK5CYII=';
const runningTests = new Set();
function retryAfterFromHeaders(headers) {
    const rawMilliseconds = headers.get('retry-after-ms');
    if (rawMilliseconds && /^\d+(?:\.\d+)?$/.test(rawMilliseconds.trim())) {
        return Math.max(0, Math.ceil(Number(rawMilliseconds)));
    }
    return parseRetryAfterMs(headers.get('retry-after'));
}
function temporaryProbeFailure(error) {
    const candidate = error && typeof error === 'object'
        ? error
        : null;
    if (candidate?.compatibilityTemporary)
        return candidate.compatibilityTemporary;
    const status = Number(candidate?.status);
    const safeStatus = Number.isInteger(status) ? status : null;
    const message = error instanceof Error ? error.message : String(error ?? '');
    const code = String(candidate?.upstreamCode
        ?? candidate?.code
        ?? candidate?.cause?.code
        ?? '').toLowerCase();
    const type = String(candidate?.upstreamType ?? candidate?.type ?? '').toLowerCase();
    const causeMessage = String(candidate?.cause?.message ?? '');
    const combined = `${message} ${causeMessage} ${code} ${type}`.toLowerCase();
    if (safeStatus === 429 || /rate[_ -]?limit|too many requests|rpm|rpd/.test(combined)) {
        const rateLimitScope = /\brpd\b|requests?\s+per\s+day|daily\s+(?:request|rate)\s+limit/.test(combined)
            ? 'rpd'
            : /\brpm\b|requests?\s+per\s+minute|per-minute/.test(combined)
                ? 'rpm'
                : /account|organization|quota|billing|insufficient[_ -]?quota|credit/.test(combined)
                    ? 'account'
                    : 'unknown';
        return {
            status: safeStatus ?? 429,
            retryAfterMs: candidate?.retryAfterMs ?? null,
            message,
            kind: 'rate_limit',
            rateLimitScope,
        };
    }
    if (safeStatus === 408 || safeStatus === 409 || (safeStatus !== null && safeStatus >= 500)) {
        return {
            status: safeStatus,
            retryAfterMs: candidate?.retryAfterMs ?? null,
            message,
            kind: 'temporary_upstream',
        };
    }
    if (/server[_ -]?error|service[_ -]?unavailable|temporar(?:y|ily) unavailable|overloaded|bad[_ -]?gateway|gateway[_ -]?timeout/.test(combined)) {
        return {
            status: safeStatus,
            retryAfterMs: candidate?.retryAfterMs ?? null,
            message,
            kind: 'temporary_upstream',
        };
    }
    if (/abort|timed?\s*out|timeout|etimedout|header timeout|stream stalled/.test(combined)) {
        return { status: safeStatus, retryAfterMs: candidate?.retryAfterMs ?? null, message, kind: 'timeout' };
    }
    if (/econnreset|econnrefused|eof|socket|connection reset|fetch failed|invalid sse|terminated|premature(?:ly)? closed|other side closed|und_err_socket|und_err_headers_timeout|und_err_body_timeout/.test(combined)) {
        return { status: safeStatus, retryAfterMs: candidate?.retryAfterMs ?? null, message, kind: 'connection' };
    }
    return null;
}
function stoppedProbeError(failure) {
    const error = new Error(failure.message);
    error.status = failure.status ?? undefined;
    error.retryAfterMs = failure.retryAfterMs ?? undefined;
    error.compatibilityTemporary = failure;
    error.compatibilityInitialFailure = false;
    return error;
}
const TOOL_DEFINITION = {
    type: 'function',
    name: TOOL_NAME,
    description: 'Return the supplied compatibility probe value.',
    parameters: {
        type: 'object',
        properties: { value: { type: 'string' } },
        required: ['value'],
        additionalProperties: false,
    },
    strict: true,
};
function relayResponsesUrl(baseUrl) {
    return `${baseUrl.replace(/\/+$/, '')}/responses`;
}
function redactKnownSecret(value, secret) {
    return secret ? value.split(secret).join('[redacted-key]') : value;
}
function compatibilityKeyMarker(secret) {
    return `****${secret.slice(-4)}`;
}
function safeErrorMessage(error, secret) {
    const raw = error instanceof Error ? error.message : String(error ?? 'Compatibility probe failed');
    return sanitizeProviderErrorMessage(redactKnownSecret(raw, secret)).slice(0, 240);
}
function safeReportString(value, secret, maxLength = 240) {
    return sanitizeProviderErrorMessage(redactKnownSecret(String(value ?? ''), secret)).replace(/\s+/g, ' ').trim().slice(0, maxLength);
}
function embeddedUpstreamError(body, secret) {
    let parsed;
    try {
        parsed = JSON.parse(body);
    }
    catch {
        return null;
    }
    const details = responsePayloadErrorDetails(parsed);
    if (!details)
        return null;
    const code = typeof details.code === 'string' && details.code.trim()
        ? details.code.trim()
        : null;
    const message = safeReportString(details.message, secret);
    const error = new Error(`Compatibility probe upstream error${code ? ` (${code})` : ''}: ${message}`);
    Object.assign(error, {
        code: code ?? undefined,
        upstreamCode: code ?? undefined,
        type: typeof details.type === 'string' ? details.type : undefined,
        upstreamType: typeof details.type === 'string' ? details.type : undefined,
    });
    return error;
}
async function readResponseBody(response, maxBytes) {
    const declaredLength = Number(response.headers.get('content-length'));
    if (Number.isFinite(declaredLength) && declaredLength > maxBytes) {
        await response.body?.cancel().catch(() => undefined);
        throw new Error(`Compatibility probe response exceeded the ${maxBytes}-byte safety limit`);
    }
    if (!response.body)
        return '';
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let received = 0;
    let result = '';
    try {
        while (true) {
            const chunk = await reader.read();
            if (chunk.done)
                break;
            received += chunk.value.byteLength;
            if (received > maxBytes) {
                await reader.cancel().catch(() => undefined);
                throw new Error(`Compatibility probe response exceeded the ${maxBytes}-byte safety limit`);
            }
            result += decoder.decode(chunk.value, { stream: true });
        }
        result += decoder.decode();
        return result;
    }
    finally {
        reader.releaseLock();
    }
}
async function postResponses(context, body, stream, endpointPath = 'responses') {
    if (context.temporaryFailure)
        throw stoppedProbeError(context.temporaryFailure);
    const upstreamModelId = typeof body.model === 'string' ? body.model : '';
    const preparedBody = endpointPath === 'responses/compact'
        ? prepareNativeResponsesCompactRequestBody(body, upstreamModelId)
        : prepareNativeResponsesRequestBody(body, upstreamModelId, stream);
    const started = Date.now();
    const remainingMs = context.deadlineAt - Date.now();
    if (remainingMs <= 0) {
        const deadlineError = new Error('Compatibility test reached its overall safety deadline; run the manual test again later');
        deadlineError.status = 408;
        const temporary = {
            status: 408,
            retryAfterMs: null,
            message: deadlineError.message,
            kind: 'timeout',
        };
        deadlineError.compatibilityTemporary = temporary;
        deadlineError.compatibilityInitialFailure = true;
        context.temporaryFailure = temporary;
        throw deadlineError;
    }
    const timeoutMs = Math.min(STAGE_TIMEOUT_MS, remainingMs);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), timeoutMs);
    context.requestsSent += 1;
    try {
        const response = await proxyFetch(endpointPath === 'responses/compact'
            ? `${context.endpoint}/compact`
            : context.endpoint, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${context.apiKey}`,
                'Content-Type': 'application/json',
                Accept: stream ? 'text/event-stream' : 'application/json',
            },
            body: JSON.stringify(preparedBody),
            signal: controller.signal,
        }, 'custom', 'chat', timeoutMs);
        const responseBody = await readResponseBody(response, stream ? MAX_SSE_RESPONSE_BYTES : MAX_JSON_RESPONSE_BYTES);
        if (!response.ok) {
            const safeBody = sanitizeProviderErrorMessage(redactKnownSecret(responseBody.slice(0, 1_000), context.apiKey));
            const requestError = new Error(`Compatibility probe received HTTP ${response.status}: ${safeBody}`);
            requestError.status = response.status;
            requestError.retryAfterMs = retryAfterFromHeaders(response.headers);
            throw requestError;
        }
        if (!stream) {
            const embeddedError = embeddedUpstreamError(responseBody, context.apiKey);
            if (embeddedError)
                throw embeddedError;
        }
        return { response, body: responseBody, latencyMs: Date.now() - started };
    }
    catch (error) {
        const name = error && typeof error === 'object' && 'name' in error
            ? String(error.name ?? '')
            : '';
        const message = error instanceof Error ? error.message : String(error ?? '');
        const timedOut = name === 'AbortError' || /\b(?:aborted|timed?\s*out|timeout)\b/i.test(message);
        const classifiedError = timedOut
            ? Object.assign(new Error('Compatibility probe timed out; this stage needs another manual retest'), { status: 408 })
            : error;
        const temporary = timedOut
            ? {
                status: 408,
                retryAfterMs: null,
                message: classifiedError instanceof Error
                    ? classifiedError.message
                    : String(classifiedError ?? 'Compatibility probe timed out'),
                kind: 'timeout',
            }
            : temporaryProbeFailure(classifiedError);
        if (temporary) {
            const requestError = (classifiedError instanceof Error
                ? classifiedError
                : new Error(String(classifiedError)));
            requestError.compatibilityTemporary = temporary;
            requestError.compatibilityInitialFailure = true;
            context.temporaryFailure = temporary;
            throw requestError;
        }
        throw error;
    }
    finally {
        clearTimeout(timeout);
    }
}
function parseJsonResponse(probe) {
    const contentType = probe.response.headers.get('content-type') ?? '';
    if (!/\bjson\b/i.test(contentType)) {
        throw new Error('Compatibility probe expected an application/json response');
    }
    let parsed;
    try {
        parsed = JSON.parse(probe.body);
    }
    catch {
        throw new Error('Compatibility probe returned malformed JSON');
    }
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        throw new Error('Compatibility probe returned a non-object JSON response');
    }
    return parsed;
}
function assertCompletedResponse(payload) {
    if (payload.error != null || payload.status === 'failed') {
        throw new Error('Compatibility probe returned a failed Responses object');
    }
    if (typeof payload.id !== 'string' || !payload.id.trim()) {
        throw new Error('Responses object is missing an id');
    }
    if (payload.object !== 'response') {
        throw new Error('Responses object has an invalid object field');
    }
    if (payload.status !== 'completed') {
        throw new Error('Responses object did not reach completed status');
    }
    if (typeof payload.model !== 'string' || !payload.model.trim()) {
        throw new Error('Responses object is missing a model');
    }
    if (!Array.isArray(payload.output)) {
        throw new Error('Responses object is missing its output array');
    }
}
function assertCompactionResponse(payload) {
    if (payload.error != null) {
        throw new Error('Compaction endpoint returned an error object');
    }
    if (typeof payload.id !== 'string' || !payload.id.trim()) {
        throw new Error('Compaction response is missing an id');
    }
    if (!Array.isArray(payload.output)) {
        throw new Error('Compaction response is missing its output array');
    }
    const output = payload.output;
    const compacted = output.find((item) => (item
        && typeof item === 'object'
        && !Array.isArray(item)
        && (item.type === 'compaction'
            || item.type === 'context_compaction')
        && typeof item.encrypted_content === 'string'
        && Boolean(item.encrypted_content.trim())));
    if (!compacted) {
        throw new Error('Compaction response did not contain an opaque encrypted compaction item');
    }
    return output;
}
const KNOWN_SSE_EVENT_TYPES = new Set([
    'response.created',
    'response.in_progress',
    'response.output_item.added',
    'response.output_item.done',
    'response.content_part.added',
    'response.content_part.done',
    'response.output_text.delta',
    'response.output_text.done',
    'response.function_call_arguments.delta',
    'response.function_call_arguments.done',
    'response.reasoning_summary_part.added',
    'response.reasoning_summary_part.done',
    'response.reasoning_summary_text.delta',
    'response.reasoning_summary_text.done',
    'response.completed',
    'response.failed',
    'error',
]);
function parseSse(body, expectedContent) {
    const eventTypes = [];
    const payloads = [];
    let sawCreated = false;
    let sawCompleted = false;
    let sawTextDelta = false;
    let sawToolItemEvent = false;
    let sawToolArgumentsEvent = false;
    let terminalError = null;
    for (const frame of body.split(/\r?\n\r?\n/)) {
        if (!frame.trim())
            continue;
        let namedEvent = '';
        const dataLines = [];
        for (const line of frame.split(/\r?\n/)) {
            if (line.startsWith('event:'))
                namedEvent = line.slice(6).trim();
            if (line.startsWith('data:'))
                dataLines.push(line.slice(5).trimStart());
        }
        const data = dataLines.join('\n').trim();
        if (!data || data === '[DONE]')
            continue;
        let payload = null;
        try {
            const parsed = JSON.parse(data);
            if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
                payload = parsed;
            }
        }
        catch {
            throw new Error('Responses stream contained a malformed JSON data frame');
        }
        if (!payload || typeof payload.type !== 'string' || !payload.type.trim()) {
            throw new Error('Responses stream contained an untyped JSON data frame');
        }
        const type = payload.type;
        if (namedEvent && namedEvent !== type) {
            throw new Error('Responses stream event name did not match its typed payload');
        }
        payloads.push(payload);
        const safeType = KNOWN_SSE_EVENT_TYPES.has(type) ? type : '[unknown-event]';
        if (!eventTypes.includes(safeType) && eventTypes.length < 32)
            eventTypes.push(safeType);
        if (type === 'response.created') {
            const response = payload?.response;
            sawCreated = Boolean(response
                && typeof response === 'object'
                && typeof response.id === 'string'
                && response.id.trim());
        }
        if (type === 'response.completed') {
            const response = payload?.response;
            sawCompleted = Boolean(response
                && typeof response === 'object'
                && response.status === 'completed');
        }
        if (type === 'error' || type === 'response.failed') {
            const response = payload.response && typeof payload.response === 'object'
                ? payload.response
                : null;
            const errorPayload = payload.error && typeof payload.error === 'object'
                ? payload.error
                : response?.error && typeof response.error === 'object'
                    ? response.error
                    : null;
            const details = responsePayloadErrorDetails(payload)
                ?? (response ? responsePayloadErrorDetails(response) : null);
            const message = typeof details?.message === 'string' && details.message.trim()
                ? details.message.trim()
                : 'Responses stream ended with an error event';
            const error = new Error(message);
            const status = Number(errorPayload?.status ?? payload.status ?? response?.status);
            if (Number.isInteger(status) && status >= 400 && status <= 599)
                error.status = status;
            if (typeof details?.code === 'string')
                error.upstreamCode = details.code;
            if (typeof details?.type === 'string')
                error.upstreamType = details.type;
            terminalError = error;
        }
        if (type === 'response.output_text.delta'
            && typeof payload?.delta === 'string'
            && payload.delta.length > 0) {
            sawTextDelta = true;
        }
        if ((type === 'response.output_item.added' || type === 'response.output_item.done')
            && payload?.item
            && typeof payload.item === 'object'
            && payload.item.type === 'function_call') {
            sawToolItemEvent = true;
        }
        if ((type === 'response.function_call_arguments.delta'
            && typeof payload?.delta === 'string'
            && payload.delta.length > 0)
            || (type === 'response.function_call_arguments.done'
                && typeof payload?.arguments === 'string')) {
            sawToolArgumentsEvent = true;
        }
    }
    if (terminalError)
        throw terminalError;
    if (!sawCreated)
        throw new Error('Responses stream did not emit response.created');
    if (expectedContent === 'text' && !sawTextDelta) {
        throw new Error('Responses stream emitted no non-empty output_text delta');
    }
    if (expectedContent === 'tool' && (!sawToolItemEvent || !sawToolArgumentsEvent)) {
        throw new Error('Responses tool stream omitted standard function-call item or argument events');
    }
    if (!sawCompleted)
        throw new Error('Responses stream did not emit response.completed');
    return { eventTypes, payloads };
}
function findFunctionCall(payload) {
    const output = Array.isArray(payload.output) ? payload.output : [];
    const item = output.find((candidate) => (candidate
        && typeof candidate === 'object'
        && candidate.type === 'function_call'));
    if (!item)
        throw new Error('Tool probe returned no function_call output item');
    if (typeof item.call_id !== 'string' || !item.call_id.trim()) {
        throw new Error('Tool probe function_call is missing call_id');
    }
    if (item.name !== TOOL_NAME)
        throw new Error('Tool probe called an unexpected function');
    if (typeof item.arguments !== 'string') {
        throw new Error('Tool probe function_call arguments are not a JSON string');
    }
    let parsedArguments;
    try {
        parsedArguments = JSON.parse(item.arguments);
    }
    catch {
        throw new Error('Tool probe function_call arguments contain malformed JSON');
    }
    if (!parsedArguments
        || typeof parsedArguments !== 'object'
        || Array.isArray(parsedArguments)
        || parsedArguments.value !== 'COMPAT_TOOL') {
        throw new Error('Tool probe function_call arguments did not preserve the requested value');
    }
    return item;
}
function functionCallFromSse(payloads) {
    const outputItems = [];
    const argumentDeltas = [];
    let completedArguments = '';
    for (const payload of payloads) {
        if ((payload.type === 'response.output_item.added' || payload.type === 'response.output_item.done')
            && payload.item
            && typeof payload.item === 'object'
            && !Array.isArray(payload.item)) {
            outputItems.push(payload.item);
        }
        if (payload.type === 'response.function_call_arguments.delta'
            && typeof payload.delta === 'string') {
            argumentDeltas.push(payload.delta);
        }
        if (payload.type === 'response.function_call_arguments.done'
            && typeof payload.arguments === 'string') {
            completedArguments = payload.arguments;
        }
        if (payload.type === 'response.completed' && payload.response && typeof payload.response === 'object') {
            const completedOutput = payload.response.output;
            if (Array.isArray(completedOutput)) {
                for (const item of completedOutput) {
                    if (item && typeof item === 'object' && !Array.isArray(item)) {
                        outputItems.push(item);
                    }
                }
            }
        }
    }
    const deduplicatedItems = new Map();
    for (const [index, item] of outputItems.entries()) {
        const id = typeof item.id === 'string' && item.id.trim()
            ? item.id
            : `index-${index}`;
        deduplicatedItems.set(`${String(item.type)}:${id}`, item);
    }
    const finalItems = [...deduplicatedItems.values()];
    const rawCall = [...finalItems].reverse().find((item) => item.type === 'function_call');
    if (!rawCall)
        throw new Error('Tool stream returned no function_call output item');
    const functionCallPayload = {
        ...rawCall,
        arguments: completedArguments || argumentDeltas.join('') || rawCall.arguments,
    };
    const functionCall = findFunctionCall({ output: [functionCallPayload] });
    const reasoningItems = finalItems.filter((item) => item.type === 'reasoning');
    const reusableOutput = reusableManualContext([
        ...reasoningItems,
        functionCallPayload,
    ], false);
    return {
        functionCall,
        reusableOutput,
        missingEncryptedReasoning: reasoningItems.length > 0
            && !reusableOutput.some((item) => item.type === 'reasoning'),
    };
}
function outputText(payload) {
    const output = Array.isArray(payload.output) ? payload.output : [];
    return output.flatMap((item) => {
        if (!item || typeof item !== 'object')
            return [];
        const content = Array.isArray(item.content)
            ? item.content
            : [];
        return content.flatMap((part) => (part
            && typeof part === 'object'
            && part.type === 'output_text'
            && typeof part.text === 'string'
            ? [part.text]
            : []));
    }).join('');
}
function reusableManualContext(output, includeMessages) {
    return output.filter((item) => {
        if (!item || typeof item !== 'object')
            return false;
        const typed = item;
        if (includeMessages && typed.type === 'message')
            return true;
        if (typed.type === 'function_call')
            return true;
        // With store:false, stateless reasoning models require the opaque encrypted
        // reasoning item. A summary-only reasoning item is not reusable context.
        return typed.type === 'reasoning'
            && typeof typed.encrypted_content === 'string'
            && typed.encrypted_content.length > 0;
    });
}
function usageStage(payload) {
    if (!payload) {
        return {
            id: 'usage',
            label: 'Usage counters',
            status: 'skipped',
            latency_ms: 0,
            message: '基础请求失败，未检查 usage。',
        };
    }
    const usage = payload.usage;
    if (!usage || typeof usage !== 'object' || Array.isArray(usage)) {
        return {
            id: 'usage',
            label: 'Usage 统计',
            status: 'warning',
            latency_ms: 0,
            message: '上游未返回 usage；本站将使用安全的 Token 估算兜底。',
        };
    }
    const typed = usage;
    const input = typed.input_tokens;
    const output = typed.output_tokens;
    const total = typed.total_tokens;
    const valid = [input, output, total].every((value) => typeof value === 'number'
        && Number.isSafeInteger(value)
        && value >= 0);
    if (!valid) {
        return {
            id: 'usage',
            label: 'Usage 统计',
            status: 'warning',
            latency_ms: 0,
            message: '上游 usage 字段不完整；本站将对缺失部分使用 Token 估算兜底。',
        };
    }
    const inputDetails = typed.input_tokens_details;
    const cached = inputDetails && typeof inputDetails === 'object'
        ? inputDetails.cached_tokens
        : undefined;
    if (typeof cached !== 'number'
        || !Number.isFinite(cached)
        || cached < 0
        || cached > input) {
        return {
            id: 'usage',
            label: 'Usage 统计',
            status: 'warning',
            latency_ms: 0,
            message: '上游未返回可信的 cached_tokens；本站会按安全值处理，但无法验证缓存折扣。',
            details: {
                input_tokens: input,
                output_tokens: output,
                total_tokens: total,
            },
        };
    }
    if (total !== input + output) {
        return {
            id: 'usage',
            label: 'Usage 统计',
            status: 'warning',
            latency_ms: 0,
            message: 'Upstream usage total_tokens does not equal input_tokens plus output_tokens; safe token estimation will be used.',
            details: {
                input_tokens: input,
                output_tokens: output,
                total_tokens: total,
            },
        };
    }
    return {
        id: 'usage',
        label: 'Usage 统计',
        status: 'passed',
        latency_ms: 0,
        message: '上游返回了完整的输入、输出和总 Token。',
        details: {
            input_tokens: input,
            output_tokens: output,
            total_tokens: total,
            cached_tokens: cached,
        },
    };
}
function skippedStage(id, label, message) {
    return { id, label, status: 'skipped', latency_ms: 0, message };
}
function modelScopeStage(source, model) {
    const untested = Math.max(0, source.enabled_mapping_count - 1);
    return {
        id: 'model_scope',
        label: '模型覆盖范围',
        status: untested > 0 ? 'warning' : 'passed',
        latency_ms: 0,
        message: untested > 0
            ? `为控制费用与超时，本次只验收 1 个模型；另有 ${untested} 个启用映射未覆盖。`
            : '该上游只有 1 个启用模型映射，本次已覆盖。',
        details: {
            tested_public_model: source.public_model_id?.slice(0, 200) ?? null,
            tested_model: model.slice(0, 300),
            enabled_mapping_count: source.enabled_mapping_count,
            untested_mapping_count: untested,
        },
    };
}
function failedStage(id, label, error, secret, latencyMs) {
    const temporary = temporaryProbeFailure(error);
    const requestError = error && typeof error === 'object'
        ? error
        : null;
    if (temporary) {
        if (requestError?.compatibilityInitialFailure === false) {
            return skippedStage(id, label, 'A temporary upstream problem stopped this manual test before this stage. Run the full test again later.');
        }
        const retryAfterSeconds = temporary.retryAfterMs == null
            ? null
            : Math.max(0, Math.ceil(temporary.retryAfterMs / 1_000));
        return {
            id,
            label,
            status: 'warning',
            latency_ms: Math.max(0, latencyMs),
            message: temporary.kind === 'rate_limit'
                ? 'Temporary upstream rate limit. This result does not prove that the capability is unsupported; run the test again after the limit resets.'
                : 'Temporary upstream availability problem. This result does not prove that the capability is unsupported; run the test again later.',
            details: {
                temporary_upstream_problem: true,
                problem_kind: temporary.kind,
                rate_limit_scope: temporary.rateLimitScope ?? null,
                http_status: temporary.status,
                retry_after_seconds: retryAfterSeconds,
                upstream_message: safeErrorMessage(error, secret),
            },
        };
    }
    return {
        id,
        label,
        status: 'failed',
        latency_ms: Math.max(0, latencyMs),
        message: safeErrorMessage(error, secret),
    };
}
function failedProbeStage(context, id, label, error, secret, latencyMs) {
    const temporary = temporaryProbeFailure(error);
    if (temporary && !context.temporaryFailure) {
        const requestError = (error instanceof Error ? error : new Error(String(error)));
        requestError.compatibilityTemporary = temporary;
        requestError.compatibilityInitialFailure = true;
        context.temporaryFailure = temporary;
        return failedStage(id, label, requestError, secret, latencyMs);
    }
    return failedStage(id, label, error, secret, latencyMs);
}
function compatibilitySource(db, id, requestedApiKeyId, requestedPublicModelId) {
    return db.prepare(`
    SELECT
      s.id,
      s.protocol,
      selected_key.api_key_id,
      selected_key.credential_revision AS api_key_credential_revision,
      selected_key.label AS api_key_label,
      COALESCE(NULLIF(TRIM(s.base_url), ''), k.base_url) AS base_url,
      k.encrypted_key,
      k.iv,
      k.auth_tag,
      sm.public_model_id,
      sm.upstream_model_id,
      sm.supports_tools,
      sm.supports_vision,
      s.compatibility_config_revision,
      (
        SELECT COUNT(*) FROM codex_relay_source_models enabled_mapping
        WHERE enabled_mapping.source_id = s.id AND enabled_mapping.enabled = 1
      ) AS enabled_mapping_count
    FROM codex_relay_sources s
    LEFT JOIN codex_relay_source_keys selected_key
      ON selected_key.api_key_id = (
        SELECT candidate.api_key_id
        FROM codex_relay_source_keys candidate
        JOIN api_keys candidate_key
         ON candidate_key.id = candidate.api_key_id
         AND candidate_key.role = 'codex_relay'
         AND candidate_key.platform = 'custom'
         AND candidate_key.enabled = 1
        WHERE candidate.source_id = s.id
          AND (@apiKeyId IS NULL OR candidate.api_key_id = @apiKeyId)
          AND candidate.enabled = 1
          AND candidate.status IN ('healthy', 'unknown')
          AND (
            candidate.cooldown_until IS NULL
            OR datetime(candidate.cooldown_until) <= datetime('now')
          )
        ORDER BY candidate.priority ASC,
                 COALESCE(candidate.last_used_at, '1970-01-01') ASC,
                 candidate.api_key_id ASC
        LIMIT 1
      )
    LEFT JOIN api_keys k
     ON k.id = selected_key.api_key_id
     AND k.role = 'codex_relay'
     AND k.platform = 'custom'
    LEFT JOIN codex_relay_source_models sm
      ON sm.source_id = s.id
     AND sm.enabled = 1
     AND sm.public_model_id = (
       SELECT selected_mapping.public_model_id
       FROM codex_relay_source_models selected_mapping
       WHERE selected_mapping.source_id = s.id
         AND selected_mapping.enabled = 1
         AND (
           @publicModelId IS NULL
           OR selected_mapping.public_model_id = @publicModelId
         )
       ORDER BY
         CASE
           WHEN LOWER(selected_mapping.public_model_id) LIKE 'gpt-5.6%' THEN 0
           WHEN LOWER(selected_mapping.upstream_model_id) LIKE 'gpt-5.6%' THEN 1
           WHEN LOWER(selected_mapping.public_model_id) LIKE '%5.6%' THEN 2
           WHEN LOWER(selected_mapping.upstream_model_id) LIKE '%5.6%' THEN 3
           ELSE 4
         END ASC,
         selected_mapping.public_model_id ASC
       LIMIT 1
     )
    WHERE s.id = @sourceId
  `).get({
        sourceId: id,
        apiKeyId: requestedApiKeyId ?? null,
        publicModelId: requestedPublicModelId ?? null,
    }) ?? null;
}
function persistReport(db, sourceId, expectedRevision, expectedApiKeyId, expectedApiKeyCredentialRevision, report) {
    const persistedStatus = report.overall_status === 'needs_retest'
        ? 'partial'
        : report.overall_status;
    const needsRetest = report.overall_status === 'needs_retest' ? 1 : 0;
    let serialized = JSON.stringify(report);
    if (serialized.length > MAX_STORED_REPORT_CHARS) {
        const compact = {
            ...report,
            stages: report.stages.map(({ details: _details, ...stage }) => ({
                ...stage,
                message: stage.message.replace(/\s+/g, ' ').trim().slice(0, 160),
            })),
        };
        serialized = JSON.stringify(compact);
        if (serialized.length > MAX_STORED_REPORT_CHARS) {
            throw new Error('Compatibility report exceeded the persistence safety limit');
        }
    }
    db.transaction(() => {
        const persistedKey = db.prepare(`
      UPDATE codex_relay_source_keys
      SET compatibility_status = ?,
          compatibility_needs_retest = ?,
          compatibility_checked_at = ?,
          compatibility_report = ?,
          updated_at = datetime('now')
      WHERE source_id = ?
        AND api_key_id = ?
        AND credential_revision = ?
        AND EXISTS (
          SELECT 1
          FROM codex_relay_sources current_source
          WHERE current_source.id = codex_relay_source_keys.source_id
            AND current_source.compatibility_config_revision = ?
        )
    `).run(persistedStatus, needsRetest, report.completed_at, serialized, sourceId, expectedApiKeyId, expectedApiKeyCredentialRevision, expectedRevision);
        if (persistedKey.changes !== 1) {
            throw new Error('Relay configuration changed during the compatibility test; result was discarded');
        }
        // Keep the source fields as a backwards-compatible latest-run summary.
        // The authoritative capability evidence now remains on every tested key.
        const persistedSource = db.prepare(`
      UPDATE codex_relay_sources
      SET compatibility_status = ?,
          compatibility_needs_retest = ?,
          compatibility_checked_at = ?,
          compatibility_report = ?,
          updated_at = datetime('now')
      WHERE id = ?
        AND compatibility_config_revision = ?
        AND EXISTS (
          SELECT 1
          FROM codex_relay_source_keys current_key
          WHERE current_key.source_id = codex_relay_sources.id
            AND current_key.api_key_id = ?
            AND current_key.credential_revision = ?
        )
    `).run(persistedStatus, needsRetest, report.completed_at, serialized, sourceId, expectedRevision, expectedApiKeyId, expectedApiKeyCredentialRevision);
        if (persistedSource.changes !== 1) {
            throw new Error('Relay configuration changed during the compatibility test; result was discarded');
        }
    })();
}
/**
 * Run a bounded native Responses capability smoke test against one mapped
 * upstream model. This is evidence of protocol acceptance at the time of the
 * run, not a guarantee that every future prompt or vendor-specific feature is
 * compatible.
 */
export async function testCodexRelaySourceCompatibility(db, sourceId, options = {}) {
    const requestedPublicModelId = options.publicModelId?.trim() || undefined;
    const source = compatibilitySource(db, sourceId, options.apiKeyId, requestedPublicModelId);
    if (!source)
        throw new Error('Codex relay source not found');
    if (source.protocol !== 'responses') {
        throw new Error('Full compatibility testing requires the native Responses protocol');
    }
    const model = source.upstream_model_id?.trim();
    if (!model) {
        throw new Error(requestedPublicModelId
            ? 'Compatibility testing requires the selected enabled model mapping'
            : 'Compatibility testing requires an enabled model mapping');
    }
    if (source.api_key_id === null
        || source.api_key_credential_revision === null
        || source.base_url === null
        || source.encrypted_key === null
        || source.iv === null
        || source.auth_tag === null) {
        throw new Error('Compatibility testing requires an available relay API key');
    }
    if (runningTests.has(sourceId))
        throw new Error('A compatibility test is already running for this source');
    if (runningTests.size >= MAX_CONCURRENT_TESTS) {
        throw new Error('Compatibility test concurrency limit reached; try again shortly');
    }
    runningTests.add(sourceId);
    const startedAt = new Date().toISOString();
    const stages = [modelScopeStage(source, model)];
    let context = null;
    try {
        const apiKey = decrypt(source.encrypted_key, source.iv, source.auth_tag);
        context = {
            endpoint: relayResponsesUrl(source.base_url),
            apiKey,
            requestsSent: 0,
            deadlineAt: Date.now() + OVERALL_TIMEOUT_MS,
            temporaryFailure: null,
        };
        let basicPayload = null;
        const basicStarted = Date.now();
        try {
            const probe = await postResponses(context, {
                model,
                input: 'Remember verification code BLUE-731 and reply exactly READY.',
                include: ['reasoning.encrypted_content'],
                max_output_tokens: 32,
            }, false);
            const parsedBasic = parseJsonResponse(probe);
            assertCompletedResponse(parsedBasic);
            if (!outputText(parsedBasic).includes('READY')) {
                throw new Error('Basic Responses probe did not return the expected READY text');
            }
            basicPayload = parsedBasic;
            const returnedModel = String(parsedBasic.model);
            const aliasMismatch = returnedModel !== model;
            stages.push({
                id: 'basic_response',
                label: '基础非流式 Responses',
                status: aliasMismatch ? 'warning' : 'passed',
                latency_ms: probe.latencyMs,
                message: aliasMismatch
                    ? 'Responses 对象有效，但上游返回了不同的规范化/快照模型 ID。'
                    : '原生非流式 Responses 对象有效。',
                details: {
                    requested_model: safeReportString(model, apiKey),
                    returned_model: safeReportString(returnedModel, apiKey),
                },
            });
        }
        catch (error) {
            stages.push(failedProbeStage(context, 'basic_response', '基础非流式 Responses', error, apiKey, Date.now() - basicStarted));
        }
        if (!basicPayload) {
            stages.push(skippedStage('compaction', 'Standalone Responses compact', 'Basic Responses did not pass; the compact endpoint was not probed.'));
            stages.push(skippedStage('streaming_sse', '流式 SSE', '基础 Responses 未通过，已停止后续真实请求。'));
            stages.push(skippedStage('multi_turn', '无状态多轮上下文', '基础 Responses 未通过，已停止后续真实请求。'));
            stages.push(skippedStage('tool_call', '工具调用', '基础 Responses 未通过，已停止后续真实请求。'));
            stages.push(skippedStage('tool_roundtrip', '工具结果回传', '基础 Responses 未通过，已停止后续真实请求。'));
            stages.push(usageStage(null));
            stages.push(skippedStage('vision', '图片输入', '基础 Responses 未通过，已停止后续真实请求。'));
        }
        else {
            const compactionStarted = Date.now();
            try {
                const compactProbe = await postResponses(context, {
                    model,
                    input: [{
                            type: 'message',
                            role: 'user',
                            content: [{
                                    type: 'input_text',
                                    text: 'Compact this compatibility context and preserve the marker COMPACT_CONTEXT.',
                                }],
                        }],
                }, false, 'responses/compact');
                const compactPayload = parseJsonResponse(compactProbe);
                const compactOutput = assertCompactionResponse(compactPayload);
                const followUp = await postResponses(context, {
                    model,
                    input: [
                        ...compactOutput,
                        {
                            type: 'message',
                            role: 'user',
                            content: [{
                                    type: 'input_text',
                                    text: 'Reply with the preserved compatibility marker exactly. Do not guess if it was not retained.',
                                }],
                        },
                    ],
                    max_output_tokens: 32,
                }, false);
                const followPayload = parseJsonResponse(followUp);
                assertCompletedResponse(followPayload);
                if (outputText(followPayload).trim() !== 'COMPACT_CONTEXT') {
                    throw new Error('Compaction follow-up did not preserve the expected context marker');
                }
                stages.push({
                    id: 'compaction',
                    label: 'Standalone Responses compact',
                    status: 'passed',
                    latency_ms: Date.now() - compactionStarted,
                    message: 'The upstream accepted /responses/compact and its opaque output was accepted unchanged by a follow-up /responses call.',
                    details: {
                        compact_output_items: compactOutput.length,
                        follow_up_completed: true,
                    },
                });
            }
            catch (error) {
                stages.push(failedProbeStage(context, 'compaction', 'Standalone Responses compact', error, apiKey, Date.now() - compactionStarted));
            }
            const streamStarted = Date.now();
            try {
                const probe = await postResponses(context, {
                    model,
                    input: 'Reply exactly STREAM_OK.',
                    max_output_tokens: 32,
                }, true);
                const contentType = probe.response.headers.get('content-type') ?? '';
                if (!/^text\/event-stream\b/i.test(contentType)) {
                    throw new Error('Streaming probe did not return text/event-stream');
                }
                const parsed = parseSse(probe.body, 'text');
                stages.push({
                    id: 'streaming_sse',
                    label: '流式 SSE',
                    status: 'passed',
                    latency_ms: probe.latencyMs,
                    message: '流式响应包含 created、内容增量和 completed 事件。',
                    details: { event_types: parsed.eventTypes },
                });
            }
            catch (error) {
                stages.push(failedProbeStage(context, 'streaming_sse', '流式 SSE', error, apiKey, Date.now() - streamStarted));
            }
            const multiTurnStarted = Date.now();
            try {
                const originalTurn = {
                    role: 'user',
                    content: [{
                            type: 'input_text',
                            text: 'Remember verification code BLUE-731 and reply exactly READY.',
                        }],
                };
                const reusableOutput = reusableManualContext(basicPayload.output, true);
                if (!reusableOutput.some((item) => item.type === 'message')) {
                    throw new Error('Basic response supplied no reusable assistant message for manual context');
                }
                const probe = await postResponses(context, {
                    model,
                    input: [
                        originalTurn,
                        ...reusableOutput,
                        {
                            role: 'user',
                            content: [{ type: 'input_text', text: 'What verification code did I give you?' }],
                        },
                    ],
                    include: ['reasoning.encrypted_content'],
                    max_output_tokens: 48,
                }, false);
                const multiTurn = parseJsonResponse(probe);
                assertCompletedResponse(multiTurn);
                if (!outputText(multiTurn).includes('BLUE-731')) {
                    throw new Error('Manual-context follow-up did not retain the verification code');
                }
                stages.push({
                    id: 'multi_turn',
                    label: '无状态多轮上下文',
                    status: 'passed',
                    latency_ms: probe.latencyMs,
                    message: 'store:false 下手工回传上下文后，多轮验证信息保持正确。',
                    details: { preserved_context_items: reusableOutput.length },
                });
            }
            catch (error) {
                stages.push(failedProbeStage(context, 'multi_turn', '无状态多轮上下文', error, apiKey, Date.now() - multiTurnStarted));
            }
            let toolReusableOutput = null;
            let functionCall = null;
            if (source.supports_tools === 1) {
                const toolStarted = Date.now();
                try {
                    const probe = await postResponses(context, {
                        model,
                        input: 'Call the compatibility echo function once with value COMPAT_TOOL.',
                        tools: [TOOL_DEFINITION],
                        tool_choice: 'required',
                        include: ['reasoning.encrypted_content'],
                        max_output_tokens: 128,
                    }, true);
                    const contentType = probe.response.headers.get('content-type') ?? '';
                    if (!/^text\/event-stream\b/i.test(contentType)) {
                        throw new Error('Streaming tool probe did not return text/event-stream');
                    }
                    const parsed = parseSse(probe.body, 'tool');
                    const streamedTool = functionCallFromSse(parsed.payloads);
                    functionCall = streamedTool.functionCall;
                    toolReusableOutput = streamedTool.reusableOutput;
                    stages.push({
                        id: 'tool_call',
                        label: '流式工具调用',
                        status: streamedTool.missingEncryptedReasoning ? 'warning' : 'passed',
                        latency_ms: probe.latencyMs,
                        message: streamedTool.missingEncryptedReasoning
                            ? '流式工具事件有效，但 reasoning item 缺少 encrypted_content，无状态推理回放可能降级。'
                            : '流式上游返回了标准 function_call、call_id 和可重建 JSON arguments。',
                        details: {
                            tool_name: functionCall.name,
                            event_types: parsed.eventTypes,
                            encrypted_reasoning: !streamedTool.missingEncryptedReasoning,
                        },
                    });
                }
                catch (error) {
                    stages.push(failedProbeStage(context, 'tool_call', '工具调用', error, apiKey, Date.now() - toolStarted));
                }
                if (toolReusableOutput && functionCall) {
                    const roundtripStarted = Date.now();
                    try {
                        const reusableOutput = toolReusableOutput;
                        const probe = await postResponses(context, {
                            model,
                            input: [
                                {
                                    role: 'user',
                                    content: [{
                                            type: 'input_text',
                                            text: 'Call the compatibility echo function once with value COMPAT_TOOL.',
                                        }],
                                },
                                ...reusableOutput,
                                {
                                    type: 'function_call_output',
                                    call_id: functionCall.call_id,
                                    output: JSON.stringify({
                                        value: 'COMPAT_TOOL',
                                        result: 'TOOL_OK',
                                        instruction: 'Reply exactly TOOL_OK.',
                                    }),
                                },
                            ],
                            tools: [TOOL_DEFINITION],
                            max_output_tokens: 64,
                        }, false);
                        const roundtrip = parseJsonResponse(probe);
                        assertCompletedResponse(roundtrip);
                        const returnedAnotherCall = roundtrip.output.some((item) => (item
                            && typeof item === 'object'
                            && item.type === 'function_call'));
                        const roundtripText = outputText(roundtrip);
                        if (returnedAnotherCall || !/(?:TOOL_OK|COMPAT_TOOL)/.test(roundtripText)) {
                            throw new Error('Tool-result follow-up did not produce the expected assistant text');
                        }
                        stages.push({
                            id: 'tool_roundtrip',
                            label: '工具结果回传',
                            status: 'passed',
                            latency_ms: probe.latencyMs,
                            message: '上游接受了 matching call_id 的函数结果和手工上下文。',
                            details: { preserved_context_items: reusableOutput.length },
                        });
                    }
                    catch (error) {
                        stages.push(failedProbeStage(context, 'tool_roundtrip', '工具结果回传', error, apiKey, Date.now() - roundtripStarted));
                    }
                }
                else {
                    stages.push(skippedStage('tool_roundtrip', '工具结果回传', '未获得有效 function_call，无法回传工具结果。'));
                }
            }
            else {
                stages.push(skippedStage('tool_call', '工具调用', '该模型映射未声明支持工具调用。'));
                stages.push(skippedStage('tool_roundtrip', '工具结果回传', '该模型映射未声明支持工具调用。'));
            }
            stages.push(usageStage(basicPayload));
            if (source.supports_vision === 1) {
                const visionStarted = Date.now();
                try {
                    const probe = await postResponses(context, {
                        model,
                        input: [{
                                role: 'user',
                                content: [
                                    { type: 'input_text', text: 'Describe this test image in one word.' },
                                    {
                                        type: 'input_image',
                                        image_url: `data:image/png;base64,${ONE_PIXEL_PNG}`,
                                        detail: 'low',
                                    },
                                ],
                            }],
                        max_output_tokens: 32,
                    }, false);
                    const visionPayload = parseJsonResponse(probe);
                    assertCompletedResponse(visionPayload);
                    if (!outputText(visionPayload).trim()) {
                        throw new Error('Vision probe returned no assistant output text');
                    }
                    stages.push({
                        id: 'vision',
                        label: '图片输入',
                        status: 'passed',
                        latency_ms: probe.latencyMs,
                        message: '上游接受了标准 Responses input_image 数据。',
                    });
                }
                catch (error) {
                    stages.push(failedProbeStage(context, 'vision', '图片输入', error, apiKey, Date.now() - visionStarted));
                }
            }
            else {
                stages.push(skippedStage('vision', '图片输入', '该模型映射未声明支持图片输入（可选能力）。'));
            }
        }
        const hasFailure = stages.some((stage) => stage.status === 'failed');
        // A successful basic Responses request proves that the source can serve
        // ordinary traffic. Optional capabilities (compact, tools, vision, SSE,
        // multi-turn and usage details) are routed independently, so their
        // failures must be reported as partial rather than making the whole source
        // look unusable. Only a failed model-scope/basic gate is a full
        // incompatibility.
        const baseGateFailed = stages.some((stage) => ((stage.id === 'model_scope' || stage.id === 'basic_response')
            && stage.status === 'failed'));
        const hasWarning = stages.some((stage) => stage.status === 'warning');
        const toolsSkipped = stages.some((stage) => stage.id === 'tool_call' && stage.status === 'skipped');
        const overallStatus = context.temporaryFailure
            ? 'needs_retest'
            : baseGateFailed
                ? 'incompatible'
                : hasFailure || hasWarning || toolsSkipped
                    ? 'partial'
                    : 'compatible';
        const report = {
            version: 2,
            suite_version: CODEX_RELAY_COMPATIBILITY_SUITE_VERSION,
            protocol: 'responses',
            api_key_id: source.api_key_id,
            api_key_label: (source.api_key_label ?? '').slice(0, 120),
            masked_key: compatibilityKeyMarker(apiKey),
            api_key_credential_revision: source.api_key_credential_revision,
            public_model_id: source.public_model_id?.slice(0, 200),
            model: model.slice(0, 300),
            started_at: startedAt,
            completed_at: new Date().toISOString(),
            overall_status: overallStatus,
            requests_sent: context.requestsSent,
            stages,
            ...(context.temporaryFailure
                ? {
                    temporary_failure: {
                        ...context.temporaryFailure,
                        message: safeReportString(context.temporaryFailure.message, apiKey),
                    },
                }
                : {}),
        };
        persistReport(db, sourceId, source.compatibility_config_revision, source.api_key_id, source.api_key_credential_revision, report);
        return report;
    }
    catch (error) {
        // Credential decryption is part of the base acceptance gate too. Persist a
        // useful incompatible report instead of leaving the old result visible.
        // Errors after a probe context exists are programming/persistence failures
        // and should still surface to the route rather than being misclassified as
        // an upstream compatibility result.
        if (context)
            throw error;
        const failureStages = [
            ...stages,
            skippedStage('compaction', 'Standalone Responses compact', 'Basic Responses was not available, so the compact endpoint was not probed.'),
            failedStage('basic_response', '基础非流式 Responses', error, '', 0),
            skippedStage('streaming_sse', '流式 SSE', '基础 Responses 未通过，已停止后续真实请求。'),
            skippedStage('multi_turn', '无状态多轮上下文', '基础 Responses 未通过，已停止后续真实请求。'),
            skippedStage('tool_call', '工具调用', '基础 Responses 未通过，已停止后续真实请求。'),
            skippedStage('tool_roundtrip', '工具结果回传', '基础 Responses 未通过，已停止后续真实请求。'),
            usageStage(null),
            skippedStage('vision', '图片输入', '基础 Responses 未通过，已停止后续真实请求。'),
        ];
        const report = {
            version: 2,
            suite_version: CODEX_RELAY_COMPATIBILITY_SUITE_VERSION,
            protocol: 'responses',
            api_key_id: source.api_key_id,
            api_key_label: (source.api_key_label ?? '').slice(0, 120),
            masked_key: '[decrypt failed]',
            api_key_credential_revision: source.api_key_credential_revision,
            public_model_id: source.public_model_id?.slice(0, 200),
            model: model.slice(0, 300),
            started_at: startedAt,
            completed_at: new Date().toISOString(),
            overall_status: 'incompatible',
            requests_sent: 0,
            stages: failureStages,
        };
        persistReport(db, sourceId, source.compatibility_config_revision, source.api_key_id, source.api_key_credential_revision, report);
        return report;
    }
    finally {
        runningTests.delete(sourceId);
    }
}
//# sourceMappingURL=codex-relay-compatibility.js.map