import type { Db } from "../db/types.js";
export declare function listPublishedResourceProducts(db: Db): unknown[];
export declare function getPublishedResourceProduct(db: Db, productId: number): {} | null;
export declare function listUserResourceOrders(db: Db, userId: number): unknown[];
export declare function listUserResourceSubscriptions(db: Db, userId: number): unknown[];
export declare function listUserResourceUsage(db: Db, userId: number, limit?: number): unknown[];
export declare function getUserResourceSubscriptionDetail(db: Db, userId: number, subpoolId: number): {
    subscription: Record<string, unknown>;
    members: {
        userId: undefined;
        label: string;
        isCurrentUser: boolean;
        email: string;
    }[];
} | null;
export declare function getUserResourceUsageAnalytics(db: Db, userId: number): {
    summary: unknown;
    models: unknown[];
    timeline: unknown[];
    recent: unknown[];
};
export declare function getUserSubscriptionAccountId(db: Db, userId: number, subpoolId: number): number | null;
//# sourceMappingURL=resource-user.d.ts.map