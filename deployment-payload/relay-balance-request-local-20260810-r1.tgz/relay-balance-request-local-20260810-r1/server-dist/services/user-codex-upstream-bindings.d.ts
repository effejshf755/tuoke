import type { Db } from '../db/types.js';
export type UserCodexUpstreamTargetType = 'oauth' | 'relay';
export interface UserCodexUpstreamBinding {
    userId: number;
    codexGroupId: number;
    codexGroupName: string;
    targetType: UserCodexUpstreamTargetType;
    targetId: number;
    targetLabel: string;
    targetEnabled: boolean;
    targetStatus: string;
    updatedAt: string;
}
export interface UserCodexUpstreamOption {
    targetType: UserCodexUpstreamTargetType;
    targetId: number;
    label: string;
    status: string;
    enabled: boolean;
    protocol: string | null;
    modelIds: string[];
}
export interface UserCodexBindingGroup {
    id: number;
    name: string;
    binding: UserCodexUpstreamBinding | null;
    options: UserCodexUpstreamOption[];
}
export declare class UserCodexUpstreamBindingError extends Error {
    readonly status: number;
    readonly code: string;
    constructor(message: string, status?: number, code?: string);
}
export declare function getUserCodexUpstreamBinding(db: Db, userId: number | null | undefined, codexGroupId: number | null | undefined): UserCodexUpstreamBinding | null;
export declare function listUserCodexBindingGroups(db: Db, userId: number): {
    user: {
        id: number;
        email: string;
    } | null;
    groups: UserCodexBindingGroup[];
};
export declare function setUserCodexUpstreamBinding(db: Db, input: {
    userId: number;
    codexGroupId: number;
    targetType: UserCodexUpstreamTargetType;
    targetId: number;
}): UserCodexUpstreamBinding;
export declare function clearUserCodexUpstreamBinding(db: Db, userId: number, codexGroupId: number): boolean;
//# sourceMappingURL=user-codex-upstream-bindings.d.ts.map