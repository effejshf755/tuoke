import { settingNumber } from '../lib/platform-settings.js';
const activeByAccount = new Map();
const waitersByAccount = new Map();
// `codex_groups.max_concurrency` is a per-user allowance. Keep the group in
// the key as the same user can own keys in more than one Codex group, and keep
// the user (rather than API key) in the key so sibling keys share one limit.
const activeByGroupUser = new Map();
const waitersByGroupUser = new Map();
const limitByGroup = new Map();
function groupUserKey(groupId, userId) {
    return `${groupId}:${userId}`;
}
function groupIdFromGroupUserKey(key) {
    return Number(key.slice(0, key.indexOf(':')));
}
function aggregateGroupCounts(counts) {
    const totals = {};
    for (const [key, count] of counts) {
        const groupId = groupIdFromGroupUserKey(key);
        totals[groupId] = (totals[groupId] ?? 0) + count;
    }
    return totals;
}
function maxConcurrency() {
    return Math.max(1, Math.min(20, Math.trunc(settingNumber('codex_account_max_concurrency'))));
}
function queueTimeoutMs() {
    const seconds = Math.max(1, Math.min(300, settingNumber('codex_queue_timeout_seconds')));
    return Math.trunc(seconds * 1_000);
}
export class CodexConcurrencyError extends Error {
    status = 503;
    skipBench = true;
    code = 'codex_concurrency_queue_timeout';
    accountId;
    constructor(accountId) {
        super('Codex request queue is full. Please try again shortly.');
        this.name = 'CodexConcurrencyError';
        this.accountId = accountId;
    }
}
export class CodexGroupConcurrencyError extends Error {
    status = 503;
    skipBench = true;
    code = 'codex_group_concurrency_queue_timeout';
    groupId;
    userId;
    constructor(groupId, userId) {
        super('You are at the concurrency limit for this Codex group. Please try again shortly.');
        this.name = 'CodexGroupConcurrencyError';
        this.groupId = groupId;
        this.userId = userId;
    }
}
export class CodexGroupConcurrencyAbortError extends Error {
    code = 'codex_group_concurrency_aborted';
    groupId;
    userId;
    constructor(groupId, userId) {
        super('Codex user concurrency wait was aborted.');
        this.name = 'AbortError';
        this.groupId = groupId;
        this.userId = userId;
    }
}
function createRelease(accountId) {
    let released = false;
    return () => {
        if (released)
            return;
        released = true;
        const nextCount = Math.max(0, (activeByAccount.get(accountId) ?? 0) - 1);
        if (nextCount === 0)
            activeByAccount.delete(accountId);
        else
            activeByAccount.set(accountId, nextCount);
        drainQueue(accountId);
    };
}
function grantSlot(accountId) {
    activeByAccount.set(accountId, (activeByAccount.get(accountId) ?? 0) + 1);
    return createRelease(accountId);
}
function drainQueue(accountId) {
    const queue = waitersByAccount.get(accountId);
    if (!queue?.length)
        return;
    while (queue.length > 0 && (activeByAccount.get(accountId) ?? 0) < maxConcurrency()) {
        const waiter = queue.shift();
        clearTimeout(waiter.timer);
        waiter.resolve(grantSlot(accountId));
    }
    if (queue.length === 0)
        waitersByAccount.delete(accountId);
}
function normalizeGroupLimit(limit) {
    return Math.max(1, Math.min(1_000, Math.trunc(limit)));
}
function createGroupRelease(groupId, userId) {
    const key = groupUserKey(groupId, userId);
    let released = false;
    return () => {
        if (released)
            return;
        released = true;
        const nextCount = Math.max(0, (activeByGroupUser.get(key) ?? 0) - 1);
        if (nextCount === 0)
            activeByGroupUser.delete(key);
        else
            activeByGroupUser.set(key, nextCount);
        drainGroupUserQueue(groupId, userId);
    };
}
function grantGroupSlot(groupId, userId) {
    const key = groupUserKey(groupId, userId);
    activeByGroupUser.set(key, (activeByGroupUser.get(key) ?? 0) + 1);
    return createGroupRelease(groupId, userId);
}
function grantAbortableGroupSlot(groupId, userId, signal) {
    const releaseSlot = grantGroupSlot(groupId, userId);
    if (!signal)
        return releaseSlot;
    let released = false;
    const release = () => {
        if (released)
            return;
        released = true;
        signal.removeEventListener('abort', release);
        releaseSlot();
    };
    signal.addEventListener('abort', release, { once: true });
    if (signal.aborted)
        release();
    return release;
}
function removeGroupWaiter(groupId, userId, waiter) {
    const key = groupUserKey(groupId, userId);
    const queue = waitersByGroupUser.get(key);
    if (!queue)
        return;
    const index = queue.indexOf(waiter);
    if (index >= 0)
        queue.splice(index, 1);
    if (queue.length === 0)
        waitersByGroupUser.delete(key);
}
function cleanupGroupWaiter(waiter) {
    if (waiter.timer !== null) {
        clearTimeout(waiter.timer);
        waiter.timer = null;
    }
    if (waiter.signal && waiter.onAbort) {
        waiter.signal.removeEventListener('abort', waiter.onAbort);
    }
}
function grantGroupWaiter(groupId, userId, waiter) {
    if (waiter.settled)
        return;
    waiter.settled = true;
    cleanupGroupWaiter(waiter);
    waiter.resolve(grantAbortableGroupSlot(groupId, userId, waiter.signal));
}
function drainGroupUserQueue(groupId, userId) {
    const key = groupUserKey(groupId, userId);
    const queue = waitersByGroupUser.get(key);
    if (!queue?.length)
        return;
    const configuredLimit = limitByGroup.get(groupId);
    if (configuredLimit === undefined)
        return;
    const limit = configuredLimit === null ? Number.POSITIVE_INFINITY : configuredLimit;
    while (queue.length > 0
        && (activeByGroupUser.get(key) ?? 0) < limit) {
        const waiter = queue.shift();
        grantGroupWaiter(groupId, userId, waiter);
    }
    if (queue.length === 0)
        waitersByGroupUser.delete(key);
}
/** Update every user's live gate after an administrator changes a group limit. */
export function updateCodexGroupConcurrencyLimit(groupId, configuredLimit) {
    limitByGroup.set(groupId, configuredLimit === null ? null : normalizeGroupLimit(configuredLimit));
    for (const key of waitersByGroupUser.keys()) {
        if (groupIdFromGroupUserKey(key) !== groupId)
            continue;
        const userId = Number(key.slice(key.indexOf(':') + 1));
        drainGroupUserQueue(groupId, userId);
    }
}
export function getCodexAccountActiveCount(accountId) {
    return activeByAccount.get(accountId) ?? 0;
}
export function getCodexGroupActiveCount(groupId, userId) {
    if (userId !== undefined) {
        return activeByGroupUser.get(groupUserKey(groupId, userId)) ?? 0;
    }
    let total = 0;
    for (const [key, count] of activeByGroupUser) {
        if (groupIdFromGroupUserKey(key) === groupId)
            total += count;
    }
    return total;
}
export function getCodexConcurrencySnapshot() {
    return {
        activeByAccount: Object.fromEntries(activeByAccount),
        queuedByAccount: Object.fromEntries([...waitersByAccount].map(([accountId, waiters]) => [accountId, waiters.length])),
        activeByGroup: aggregateGroupCounts(activeByGroupUser),
        queuedByGroup: aggregateGroupCounts(new Map([...waitersByGroupUser].map(([key, waiters]) => [key, waiters.length]))),
        activeByGroupUser: Object.fromEntries(activeByGroupUser),
        queuedByGroupUser: Object.fromEntries([...waitersByGroupUser].map(([key, waiters]) => [key, waiters.length])),
        maxConcurrency: maxConcurrency(),
        queueTimeoutSeconds: queueTimeoutMs() / 1_000,
    };
}
export function acquireCodexAccountSlot(accountId) {
    // If the administrator raised the limit while requests were queued, let the
    // oldest waiters take the newly available slots before a new request.
    drainQueue(accountId);
    if ((activeByAccount.get(accountId) ?? 0) < maxConcurrency()) {
        return Promise.resolve(grantSlot(accountId));
    }
    return new Promise((resolve, reject) => {
        const waiter = {
            resolve,
            reject,
            timer: setTimeout(() => {
                const queue = waitersByAccount.get(accountId);
                if (queue) {
                    const index = queue.indexOf(waiter);
                    if (index >= 0)
                        queue.splice(index, 1);
                    if (queue.length === 0)
                        waitersByAccount.delete(accountId);
                }
                reject(new CodexConcurrencyError(accountId));
            }, queueTimeoutMs()),
        };
        const queue = waitersByAccount.get(accountId) ?? [];
        queue.push(waiter);
        waitersByAccount.set(accountId, queue);
    });
}
export function acquireCodexGroupSlot(groupId, userId, configuredLimit, signal) {
    const key = groupUserKey(groupId, userId);
    const limit = normalizeGroupLimit(configuredLimit);
    updateCodexGroupConcurrencyLimit(groupId, limit);
    if (signal?.aborted) {
        return Promise.reject(new CodexGroupConcurrencyAbortError(groupId, userId));
    }
    if ((activeByGroupUser.get(key) ?? 0) < limit) {
        return Promise.resolve(grantAbortableGroupSlot(groupId, userId, signal));
    }
    return new Promise((resolve, reject) => {
        const waiter = {
            resolve,
            reject,
            timer: null,
            signal,
            settled: false,
        };
        waiter.onAbort = () => {
            if (waiter.settled)
                return;
            waiter.settled = true;
            removeGroupWaiter(groupId, userId, waiter);
            cleanupGroupWaiter(waiter);
            reject(new CodexGroupConcurrencyAbortError(groupId, userId));
            drainGroupUserQueue(groupId, userId);
        };
        waiter.timer = setTimeout(() => {
            if (waiter.settled)
                return;
            waiter.settled = true;
            removeGroupWaiter(groupId, userId, waiter);
            cleanupGroupWaiter(waiter);
            reject(new CodexGroupConcurrencyError(groupId, userId));
            drainGroupUserQueue(groupId, userId);
        }, queueTimeoutMs());
        if (signal) {
            signal.addEventListener('abort', waiter.onAbort, { once: true });
            if (signal.aborted) {
                waiter.onAbort();
                return;
            }
        }
        if (!waiter.settled) {
            const queue = waitersByGroupUser.get(key) ?? [];
            queue.push(waiter);
            waitersByGroupUser.set(key, queue);
        }
    });
}
export function resetCodexConcurrencyForTests() {
    for (const waiters of waitersByAccount.values()) {
        for (const waiter of waiters)
            clearTimeout(waiter.timer);
    }
    for (const waiters of waitersByGroupUser.values()) {
        for (const waiter of waiters) {
            if (waiter.timer !== null)
                clearTimeout(waiter.timer);
        }
    }
    activeByAccount.clear();
    waitersByAccount.clear();
    activeByGroupUser.clear();
    waitersByGroupUser.clear();
    limitByGroup.clear();
}
//# sourceMappingURL=codex-concurrency.js.map