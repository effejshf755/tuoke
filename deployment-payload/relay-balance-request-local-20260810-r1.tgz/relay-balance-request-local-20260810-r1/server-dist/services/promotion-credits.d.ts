import type { Db } from '../db/types.js';
export type PromotionCreditGrantStatus = 'active' | 'exhausted' | 'expired' | 'revoked';
export interface PromotionCreditGrant {
    id: number;
    userId: number;
    offerId: number | null;
    purchaseId: number | null;
    rechargeOrderId: number | null;
    grantedMicro: number;
    usedMicro: number;
    remainingMicro: number;
    reservedMicro: number;
    availableMicro: number;
    expiresAt: string;
    status: PromotionCreditGrantStatus;
    createdAt: string;
}
export interface PromotionCreditSummary {
    grantedMicro: number;
    usedMicro: number;
    remainingMicro: number;
    reservedMicro: number;
    availableMicro: number;
    nextExpiresAt: string | null;
    grantCount: number;
    detailsTruncated: boolean;
    grants: PromotionCreditGrant[];
}
export declare function createPromotionCreditGrant(db: Db, input: {
    userId: number;
    offerId: number | null;
    purchaseId?: number | null;
    rechargeOrderId?: number | null;
    grantedMicro: number;
    validitySeconds: number;
}): {
    grant: PromotionCreditGrant;
    alreadyCreated: boolean;
};
export declare function getAvailablePromotionCreditMicro(db: Db, userId: number): number;
export declare function getReservedPromotionCreditMicro(db: Db, walletReservationId: number): number;
export declare function getPromotionCreditReservationExpiryBreakdown(db: Db, walletReservationId: number): {
    activeReservedMicro: number;
    expiredReservedMicro: number;
};
export declare function getPromotionCreditSummary(db: Db, userId: number, detailLimit?: number): PromotionCreditSummary;
export declare function ensurePromotionCreditReservation(db: Db, input: {
    userId: number;
    walletReservationId: number;
    targetMicro: number;
}): {
    totalReservedMicro: number;
    newlyReservedMicro: number;
    availableAfterMicro: number;
};
export declare function settlePromotionCreditReservation(db: Db, input: {
    userId: number;
    walletReservationId: number;
    requestId: number;
    chargeMicro: number;
}): {
    consumedMicro: number;
    uncoveredMicro: number;
    releasedMicro: number;
};
export declare function releasePromotionCreditReservation(db: Db, walletReservationId: number): {
    releasedMicro: number;
};
export declare function expirePromotionCreditGrants(db: Db): {
    grantsExpired: number;
    microExpired: number;
};
//# sourceMappingURL=promotion-credits.d.ts.map