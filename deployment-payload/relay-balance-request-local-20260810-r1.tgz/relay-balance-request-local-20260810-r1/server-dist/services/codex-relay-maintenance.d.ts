import type { Db } from '../db/types.js';
import type { Scheduler } from '../lib/scheduler.js';
import { type CodexRelayHealthCheckResult } from './codex-relay-sources.js';
export interface CodexRelayHealthPassResult {
    checked: number;
    healthy: number;
    unhealthy: number;
    errors: number;
}
export interface CodexRelaySourceOperationalStats {
    sourceId: number;
    sourceName: string;
    statisticsStartedAt: string | null;
    requests: number;
    successfulRequests: number;
    failedRequests: number;
    partialRequests: number;
    inputTokens: number;
    cachedInputTokens: number;
    cacheWriteTokens: number;
    outputTokens: number;
    billedMicro: number;
    averageLatencyMs: number;
    lastRequestAt: string | null;
}
export interface CodexRelayOperationalStats {
    scope: 'lifetime' | 'window';
    windowHours: number | null;
    requests: number;
    successfulRequests: number;
    failedRequests: number;
    partialRequests: number;
    inputTokens: number;
    cachedInputTokens: number;
    cacheWriteTokens: number;
    outputTokens: number;
    billedMicro: number;
    sources: CodexRelaySourceOperationalStats[];
}
export declare function resetCodexRelayOperationalStats(db: Db, sourceId: number, nowMs?: number): CodexRelaySourceOperationalStats | null;
type HealthProbe = (db: Db, id: number) => Promise<CodexRelayHealthCheckResult>;
export declare function codexRelayHealthIntervalMs(): number;
export declare function codexRelayHealthBootDelayMs(): number;
export declare function codexRelayHealthConcurrency(): number;
export declare function listDueCodexRelaySourceIds(db: Db, options?: {
    nowMs?: number;
    intervalMs?: number;
    limit?: number;
}): number[];
export declare function checkDueCodexRelaySources(db: Db, options?: {
    nowMs?: number;
    intervalMs?: number;
    concurrency?: number;
    limit?: number;
    probe?: HealthProbe;
}): Promise<CodexRelayHealthPassResult>;
export declare function startCodexRelayHealthScheduler(db: Db, scheduler: Scheduler): (() => void) | null;
export declare function getCodexRelayOperationalStats(db: Db, requestedWindowHours?: number | null): CodexRelayOperationalStats;
export {};
//# sourceMappingURL=codex-relay-maintenance.d.ts.map