import crypto from 'node:crypto';
export function normalizePem(value) {
    const text = value.replace(/\\n/g, '\n').replace(/\\r/g, '').trim();
    const match = text.match(/-----BEGIN ([^-]+)-----([\s\S]*?)-----END \1-----/);
    if (!match)
        return text;
    // Docker env files are often edited with a quoted `\\n` separator. If it
    // was double-escaped, the first replacement above leaves one backslash at
    // the start of the PEM body. Ignore that separator artifact only; the key
    // material itself remains strict base64 and OpenSSL still validates it.
    const body = match[2].replace(/^\s*\\/, '').replace(/\s+/g, '');
    const lines = body.match(/.{1,64}/g)?.join('\n') ?? body;
    return `-----BEGIN ${match[1]}-----\n${lines}\n-----END ${match[1]}-----`;
}
function cfg() {
    const appId = process.env.ALIPAY_APP_ID?.trim();
    const privateKey = process.env.ALIPAY_PRIVATE_KEY ? normalizePem(process.env.ALIPAY_PRIVATE_KEY) : undefined;
    const publicKey = process.env.ALIPAY_PUBLIC_KEY ? normalizePem(process.env.ALIPAY_PUBLIC_KEY) : undefined;
    if (!appId || !privateKey || !publicKey)
        return null;
    return {
        appId,
        sellerId: process.env.ALIPAY_SELLER_ID?.trim() || null,
        privateKey,
        publicKey,
        gateway: process.env.ALIPAY_GATEWAY?.trim() || 'https://openapi.alipay.com/gateway.do',
        notifyUrl: process.env.ALIPAY_NOTIFY_URL?.trim() || '',
        returnUrl: process.env.ALIPAY_RETURN_URL?.trim() || '',
    };
}
function sign(params, privateKey) {
    const content = Object.keys(params).filter((key) => key !== 'sign' && params[key] !== '').sort().map((key) => `${key}=${params[key]}`).join('&');
    return crypto.createSign('RSA-SHA256').update(content, 'utf8').sign(privateKey, 'base64');
}
export function verifyNotify(params) {
    const config = cfg();
    if (!config || !params.sign)
        return false;
    // Alipay's public key validates notifications for every merchant. Bind the
    // signed payload to this application (and, when configured, this seller) so
    // a valid same-amount transaction from another merchant cannot settle one
    // of our recharge orders.
    if (params.app_id !== config.appId)
        return false;
    if (config.sellerId && params.seller_id !== config.sellerId)
        return false;
    const content = Object.keys(params).filter((key) => key !== 'sign' && key !== 'sign_type' && params[key] !== '').sort().map((key) => `${key}=${params[key]}`).join('&');
    return crypto.createVerify('RSA-SHA256').update(content, 'utf8').verify(config.publicKey, params.sign, 'base64');
}
export function isAlipayConfigured() { return cfg() !== null; }
function buildRequest(method, bizContent, options = {}) {
    const config = cfg();
    if (!config)
        throw new Error('Alipay is not configured');
    const params = {
        app_id: config.appId,
        method,
        format: 'JSON',
        charset: 'UTF-8',
        sign_type: 'RSA2',
        timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
        version: '1.0',
        biz_content: JSON.stringify(bizContent),
    };
    if (options.notify && config.notifyUrl)
        params.notify_url = config.notifyUrl;
    if (options.returnUrl && config.returnUrl)
        params.return_url = config.returnUrl;
    params.sign = sign(params, config.privateKey);
    const gateway = new URL(config.gateway);
    gateway.searchParams.set('charset', 'UTF-8');
    return { gateway: gateway.toString(), params };
}
export function createPagePayment(orderNo, amountMicro, subject) {
    return buildRequest('alipay.trade.page.pay', { out_trade_no: orderNo, product_code: 'FAST_INSTANT_TRADE_PAY', total_amount: (amountMicro / 1_000_000).toFixed(2), subject }, { notify: true, returnUrl: true });
}
/** Atomically credits a paid recharge. Safe to call repeatedly for one order. */
export function settleAlipayOrder(db, orderNo, tradeNo, note = 'Alipay payment') {
    return db.transaction(() => {
        const order = db.prepare(`
      SELECT id, user_id AS userId, amount_micro AS amountMicro,
        wallet_credit_micro AS walletCreditMicro, payment_method AS paymentMethod, status
      FROM recharge_orders WHERE order_no = ?
    `).get(orderNo);
        if (!order)
            return { status: 'not_found' };
        if (order.status === 'paid')
            return { status: 'already_paid' };
        if (order.paymentMethod !== 'alipay' && order.paymentMethod !== 'alipay_page') {
            return { status: 'invalid_state', currentStatus: order.status };
        }
        const user = db.prepare('SELECT balance_micro balanceMicro FROM users WHERE id = ?').get(order.userId);
        if (!user)
            throw new Error('Recharge order user not found');
        const creditedMicro = order.walletCreditMicro ?? order.amountMicro;
        const balance = user.balanceMicro + creditedMicro;
        if (!Number.isSafeInteger(balance))
            throw new Error('Wallet balance exceeds safe integer range');
        const updated = db.prepare(`
      UPDATE recharge_orders
      SET status = 'paid', payment_provider = 'alipay', provider_trade_no = ?,
        note = ?, paid_at = datetime('now'), updated_at = datetime('now')
      WHERE id = ? AND status IN ('pending','cancelled','expired')
        AND payment_method IN ('alipay','alipay_page')
    `).run(tradeNo, note, order.id);
        if (updated.changes !== 1)
            return { status: 'already_paid' };
        db.prepare('UPDATE users SET balance_micro = ? WHERE id = ?').run(balance, order.userId);
        db.prepare(`
      INSERT INTO wallet_transactions (
        user_id, type, delta_micro, balance_after_micro, recharge_order_id, note
      ) VALUES (?, 'recharge', ?, ?, ?, ?)
    `).run(order.userId, creditedMicro, balance, order.id, `Alipay recharge ${orderNo}`);
        return {
            status: 'paid',
            amountMicro: order.amountMicro,
            creditedMicro,
            balanceAfterMicro: balance,
        };
    })();
}
//# sourceMappingURL=alipay.js.map