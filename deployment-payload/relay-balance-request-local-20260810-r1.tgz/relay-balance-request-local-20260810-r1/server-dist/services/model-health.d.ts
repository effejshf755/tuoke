import type { Scheduler } from '../lib/scheduler.js';
export type ModelHealthResult = {
    status: 'success' | 'failed';
    lastCheckedAt: string;
    error: string | null;
    latencyMs: number;
};
type StoredModelHealth = Record<string, ModelHealthResult>;
export declare function getModelHealthMap(db?: import("../db/types.js").Db): StoredModelHealth;
export declare function checkModelHealth(modelDbId: number): Promise<ModelHealthResult>;
export declare function checkAllModelsHealth(concurrency?: number): Promise<{
    total: number;
    success: number;
    failed: number;
}>;
export declare function startModelHealthScheduler(scheduler: Scheduler): void;
export declare function stopModelHealthScheduler(): void;
export {};
//# sourceMappingURL=model-health.d.ts.map