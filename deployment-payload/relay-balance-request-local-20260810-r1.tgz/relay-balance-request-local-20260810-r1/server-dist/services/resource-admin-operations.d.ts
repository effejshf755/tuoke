import type { Db } from '../db/types.js';
export declare function listResourceProductStats(db: Db): unknown[];
export declare function listResourceSubpools(db: Db, status?: string): unknown[];
export declare function getResourceSubpoolDetail(db: Db, subpoolId: number): {
    pool: {};
    members: {
        apiKeys: (Record<string, unknown> & {
            memberId: number;
        })[];
        id: number;
    }[];
} | null;
export declare function listAvailableCodexAccounts(db: Db): unknown[];
export declare function getResourceMemberQuota(db: Db, subpoolId: number, memberId: number): {} | null;
export declare function listResourceUsageRecords(db: Db, input: {
    subpoolId: number;
    memberId?: number;
    limit?: number;
}): unknown[];
export declare function adjustResourceMemberQuota(db: Db, input: {
    subpoolId: number;
    memberId: number;
    deltaUnits: number;
    reason: string;
    adminId: number;
}): {
    memberId: number;
    allocationUnits: any;
    remainingUnits: number;
    ledgerId: number;
};
//# sourceMappingURL=resource-admin-operations.d.ts.map