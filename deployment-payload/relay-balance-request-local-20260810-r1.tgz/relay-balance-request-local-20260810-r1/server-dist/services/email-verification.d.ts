export declare function isEmailRegistered(email: string): boolean;
export declare function createRegistrationCode(email: string): string;
export declare function verifyRegistrationCode(email: string, code: string): boolean;
//# sourceMappingURL=email-verification.d.ts.map