export declare const AGENT_TOOL_DEFINITIONS: readonly [{
    readonly type: "function";
    readonly function: {
        readonly name: "read_file";
        readonly description: "Read a UTF-8 text file inside the workspace.";
        readonly parameters: {
            readonly type: "object";
            readonly properties: {
                readonly path: {
                    readonly type: "string";
                };
            };
            readonly required: readonly ["path"];
            readonly additionalProperties: false;
        };
    };
}, {
    readonly type: "function";
    readonly function: {
        readonly name: "write_file";
        readonly description: "Write a UTF-8 text file inside the workspace.";
        readonly parameters: {
            readonly type: "object";
            readonly properties: {
                readonly path: {
                    readonly type: "string";
                };
                readonly content: {
                    readonly type: "string";
                };
            };
            readonly required: readonly ["path", "content"];
            readonly additionalProperties: false;
        };
    };
}, {
    readonly type: "function";
    readonly function: {
        readonly name: "git_diff";
        readonly description: "Show the current Git diff inside the workspace.";
        readonly parameters: {
            readonly type: "object";
            readonly properties: {};
            readonly additionalProperties: false;
        };
    };
}, {
    readonly type: "function";
    readonly function: {
        readonly name: "run_command";
        readonly description: "Run a short, non-interactive development command inside the workspace.";
        readonly parameters: {
            readonly type: "object";
            readonly properties: {
                readonly command: {
                    readonly type: "string";
                };
            };
            readonly required: readonly ["command"];
            readonly additionalProperties: false;
        };
    };
}];
export declare function agentWorkspace(): string;
export declare function executeAgentTool(name: string, rawArguments: string): Promise<string>;
//# sourceMappingURL=agent-tools.d.ts.map