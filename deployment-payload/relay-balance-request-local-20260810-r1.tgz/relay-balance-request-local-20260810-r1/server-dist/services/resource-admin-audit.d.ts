import type { Db } from '../db/types.js';
export declare function recordResourceAdminAudit(db: Db, input: {
    adminUserId: number;
    action: string;
    targetType: string;
    targetId?: string | number | null;
    subpoolId?: number | null;
    details?: Record<string, unknown>;
}): number;
export declare function listResourceAdminAuditLogs(db: Db, input?: {
    subpoolId?: number;
    limit?: number;
}): unknown[];
//# sourceMappingURL=resource-admin-audit.d.ts.map