import type { Db } from '../db/types.js';
export declare const OFFICIAL_QUOTA_FULL_SCALE_UNITS = 1000000;
export interface ActivatedSubpoolResult {
    subpoolId: number;
    accountId: number;
    quotaPeriodId: number;
    allocationUnits: number;
    memberAllocations: Array<{
        memberId: number;
        allocationUnits: number;
    }>;
    status: 'active';
}
export declare function stageSubpoolCodexAccount(db: Db, subpoolId: number, accountId: number, adminId?: number): void;
export declare function clearStagedSubpoolCodexAccount(db: Db, subpoolId: number, adminId: number): void;
export declare function activateSubpool(subpoolId: number, adminId: number): ActivatedSubpoolResult;
export declare function activateSubpool(db: Db, subpoolId: number, adminId: number): ActivatedSubpoolResult;
//# sourceMappingURL=resource-subpool-activation.d.ts.map