import { getUserBillingMultiplierMilli } from "./billing.js";
import { releasePromotionCreditReservation } from "./promotion-credits.js";
function findReservationLockConflict(db, userId, requestedExclusive) {
    return db.prepare(`
    SELECT exclusive_wallet_lock AS exclusiveWalletLock
    FROM wallet_reservations
    WHERE user_id = ?
      AND status = 'reserved'
      AND (? = 1 OR exclusive_wallet_lock = 1)
    ORDER BY exclusive_wallet_lock DESC, id
    LIMIT 1
  `).get(userId, requestedExclusive ? 1 : 0);
}
function concurrencyConflict(requestedExclusive, conflict) {
    return {
        status: "concurrency_conflict",
        requestedExclusive,
        conflictingExclusive: conflict ? conflict.exclusiveWalletLock === 1 : null,
    };
}
function isReservationLockConstraint(error) {
    return error instanceof Error
        && error.message.includes("wallet_exclusive_lock_conflict");
}
export function getAvailableBalanceMicro(db, userId) {
    const row = db
        .prepare(`
      SELECT
        balance_micro AS balanceMicro,
        reserved_balance_micro
          AS reservedBalanceMicro
      FROM users
      WHERE id = ?
    `)
        .get(userId);
    if (!row) {
        return 0;
    }
    return Math.max(0, row.balanceMicro - row.reservedBalanceMicro);
}
/**
 * Atomically reserves part of a prepaid wallet.
 *
 * balance_micro stays unchanged.
 * reserved_balance_micro increases.
 *
 * Available balance:
 * balance_micro - reserved_balance_micro
 */
export function reserveWalletBalance(db, userId, consumerApiKeyId, requestedModel, requestedReserveMicro, options = {}) {
    const requestedMicro = Math.max(0, Math.trunc(requestedReserveMicro));
    const reserveMicro = requestedMicro === 0
        ? 0
        : Math.max(1, Math.ceil((requestedMicro * getUserBillingMultiplierMilli(db, userId)) /
            1_000));
    if (!Number.isSafeInteger(reserveMicro)) {
        throw new Error("Reservation amount exceeds safe integer range");
    }
    const requestedExclusive = options.exclusiveWalletLock === true;
    const transaction = db.transaction(() => {
        const lockConflict = findReservationLockConflict(db, userId, requestedExclusive);
        if (lockConflict) {
            return concurrencyConflict(requestedExclusive, lockConflict);
        }
        const wallet = db
            .prepare(`
            SELECT
              balance_micro AS balanceMicro,
              reserved_balance_micro
                AS reservedBalanceMicro
            FROM users
            WHERE id = ?
          `)
            .get(userId);
        if (!wallet) {
            return {
                status: "user_not_found",
                availableMicro: 0,
            };
        }
        const availableMicro = Math.max(0, wallet.balanceMicro - wallet.reservedBalanceMicro);
        if (availableMicro < reserveMicro) {
            return {
                status: "insufficient_balance",
                availableMicro,
            };
        }
        /*
         * Atomic concurrency guard.
         *
         * Two simultaneous requests cannot reserve
         * the same available wallet balance.
         */
        const updated = db
            .prepare(`
            UPDATE users
            SET
              reserved_balance_micro =
                reserved_balance_micro + ?
            WHERE id = ?
              AND (
                balance_micro -
                reserved_balance_micro
              ) >= ?
          `)
            .run(reserveMicro, userId, reserveMicro);
        if (updated.changes !== 1) {
            const latestAvailable = getAvailableBalanceMicro(db, userId);
            return {
                status: "insufficient_balance",
                availableMicro: latestAvailable,
            };
        }
        const inserted = db
            .prepare(`
            INSERT INTO wallet_reservations (
              user_id,
              consumer_api_key_id,
              requested_model,
              reserved_micro,
              exclusive_wallet_lock,
              status
            )
            VALUES (
              ?,
              ?,
              ?,
              ?,
              ?,
              'reserved'
            )
          `)
            .run(userId, consumerApiKeyId, requestedModel, reserveMicro, requestedExclusive ? 1 : 0);
        return {
            status: "reserved",
            reservationId: Number(inserted.lastInsertRowid),
            reservedMicro: reserveMicro,
            availableAfterMicro: availableMicro - reserveMicro,
            exclusiveWalletLock: requestedExclusive,
        };
    });
    try {
        return transaction();
    }
    catch (error) {
        // The database trigger is the cross-connection safety net.  Let the
        // transaction wrapper roll back any balance change before translating the
        // named constraint into the same result as the optimistic pre-check.
        if (isReservationLockConstraint(error)) {
            return concurrencyConflict(requestedExclusive, findReservationLockConflict(db, userId, requestedExclusive));
        }
        throw error;
    }
}
/**
 * Releases a reservation without charging the user.
 *
 * Used when:
 * - request is rejected before provider usage
 * - all provider attempts fail
 * - connection closes before successful settlement
 */
export function releaseWalletReservation(db, reservationId, finalStatus = "released") {
    const transaction = db.transaction(() => {
        const reservation = db
            .prepare(`
            SELECT
              id,
              user_id AS userId,
              reserved_micro
                AS reservedMicro,
              status
            FROM wallet_reservations
            WHERE id = ?
          `)
            .get(reservationId);
        if (!reservation) {
            return {
                status: "reservation_not_found",
                releasedMicro: 0,
            };
        }
        /*
         * Idempotent:
         * finish + close may both fire.
         */
        if (reservation.status !== "reserved") {
            return {
                status: "already_finalized",
                releasedMicro: 0,
            };
        }
        // Promotion allocations share the wallet reservation as their request
        // lifecycle anchor. Release them in the same transaction so a failed,
        // disconnected, or stale request can never strand expiring credit.
        releasePromotionCreditReservation(db, reservation.id);
        db.prepare(`
          UPDATE users
          SET
            reserved_balance_micro =
              CASE
                WHEN reserved_balance_micro >= ?
                THEN
                  reserved_balance_micro - ?
                ELSE 0
              END
          WHERE id = ?
        `).run(reservation.reservedMicro, reservation.reservedMicro, reservation.userId);
        const updated = db
            .prepare(`
            UPDATE wallet_reservations
            SET
              status = ?,
              settled_at =
                datetime('now')
            WHERE id = ?
              AND status = 'reserved'
          `)
            .run(finalStatus, reservation.id);
        if (updated.changes !== 1) {
            throw new Error("Reservation state changed during release");
        }
        return {
            status: "released",
            releasedMicro: reservation.reservedMicro,
        };
    });
    return transaction();
}
export function getWalletReservation(db, reservationId) {
    const row = db
        .prepare(`
      SELECT
        id,
        user_id AS userId,
        consumer_api_key_id
          AS consumerApiKeyId,
        request_id AS requestId,
        requested_model
          AS requestedModel,
        reserved_micro
          AS reservedMicro,
        exclusive_wallet_lock AS exclusiveWalletLock,
        actual_micro AS actualMicro,
        status,
        created_at AS createdAt,
        settled_at AS settledAt
      FROM wallet_reservations
      WHERE id = ?
    `)
        .get(reservationId);
    return row ?? null;
}
export function cleanupStaleWalletReservations(db, staleAfterMinutes = 30) {
    const safeMinutes = Math.max(1, Math.trunc(staleAfterMinutes));
    const stale = db
        .prepare(`
    SELECT id FROM wallet_reservations
    WHERE status = 'reserved'
      AND datetime(created_at) <= datetime('now', ?)
    ORDER BY id
  `)
        .all(`-${safeMinutes} minutes`);
    let releasedReservations = 0;
    let releasedMicro = 0;
    for (const row of stale) {
        const released = releaseWalletReservation(db, row.id, "failed");
        if (released.status === "released") {
            releasedReservations += 1;
            releasedMicro += released.releasedMicro;
        }
    }
    const reconciled = db
        .prepare(`
    UPDATE users
    SET reserved_balance_micro = COALESCE((
      SELECT SUM(reserved_micro)
      FROM wallet_reservations
      WHERE user_id = users.id AND status = 'reserved'
    ), 0)
    WHERE reserved_balance_micro != COALESCE((
      SELECT SUM(reserved_micro)
      FROM wallet_reservations
      WHERE user_id = users.id AND status = 'reserved'
    ), 0)
  `)
        .run();
    return {
        releasedReservations,
        releasedMicro,
        reconciledUsers: reconciled.changes,
    };
}
export function startWalletReservationCleanup(db, scheduler) {
    const run = () => {
        try {
            const result = cleanupStaleWalletReservations(db);
            if (result.releasedReservations > 0 || result.reconciledUsers > 0) {
                console.log(`[wallet-reservation-cleanup] released ${result.releasedReservations} stale reservations ` +
                    `(${result.releasedMicro} micro), reconciled ${result.reconciledUsers} users`);
            }
        }
        catch (error) {
            console.error("[wallet-reservation-cleanup] failed:", error);
        }
    };
    run();
    scheduler.every(5 * 60 * 1000, run, { name: "wallet-reservation-cleanup" });
}
//# sourceMappingURL=wallet-reservations.js.map