import type { Db } from '../db/types.js';
import { type PromotionCreditGrant } from './promotion-credits.js';
export type PromotionPurchaseErrorCode = 'invalid_idempotency_key' | 'purchase_conflict' | 'insufficient_balance' | 'wallet_busy' | 'offer_not_available';
export declare class PromotionPurchaseError extends Error {
    readonly code: PromotionPurchaseErrorCode;
    constructor(code: PromotionPurchaseErrorCode, message: string);
}
export interface PromotionPurchase {
    id: number;
    purchaseNo: string;
    userId: number;
    offerId: number | null;
    offerCode: string;
    priceMicro: number;
    permanentCreditMicro: number;
    limitedCreditMicro: number;
    validitySeconds: number;
    status: 'paid' | 'refunded' | 'reversed';
    walletTransactionId: number | null;
    createdAt: string;
    paidAt: string;
    refundedAt: string | null;
}
export declare function getPromotionPurchase(db: Db, purchaseId: number): PromotionPurchase | null;
export declare function listUserPromotionPurchases(db: Db, userId: number, limit?: number): PromotionPurchase[];
export declare function purchaseWalletPromotionOffer(db: Db, input: {
    userId: number;
    offerCode: string;
    idempotencyKey: string;
}): {
    purchase: PromotionPurchase;
    grant: PromotionCreditGrant;
    balanceAfterMicro: number;
    alreadyProcessed: boolean;
};
//# sourceMappingURL=promotion-purchases.d.ts.map