import { getDb, getSetting, setSetting } from '../db/index.js';
import { createHash } from 'node:crypto';
import { getProvider, hasProvider, resolveProvider } from '../providers/index.js';
import { OpenAICodexProvider } from '../providers/openai-codex.js';
import { decrypt } from '../lib/crypto.js';
import { getClientContext, getCodexPolicyScope, setResourceDispatchId, } from '../lib/client-context.js';
import { selectCodexExecution, ResourceDispatchError } from './resource-scheduler.js';
import { canMakeRequest, canUseTokens, isOnCooldown, canUseProvider, canUseProviderTokens, getSoonestCooldownExpiry, } from './ratelimit.js';
import { BANDIT_PRESETS, DEFAULT_STRATEGY, reliabilityPosterior, expectedReliability, sampleBeta, speedScore, intelligenceScore, headroomFactor, rateLimitFactor, combineScore, } from './scoring.js';
import { parseBudget } from '../lib/budget.js';
import { platformDropsResponseFormat } from '../lib/sampling-params.js';
import { isUnifyEnabled, getModelGroups, resolveRequestedIdToMembers } from './model-groups.js';
import { getActiveProfileId } from './profile-models.js';
import { getModelBillingRule } from './billing.js';
import { getCodexAccountActiveCount } from './codex-concurrency.js';
import { getCustomEndpointBaseUrl } from '../lib/custom-provider-pool.js';
import { isPromptCacheCertificationCurrent, relayMappingRequiresExplicitPromptCache, requiresExplicitPromptCache, } from '../lib/codex-prompt-cache.js';
import { decryptCodexRelaySourceApiKey, listEligibleCodexRelayCandidates, recordCodexRelaySourceFailure, } from './codex-relay-sources.js';
import { getUserCodexUpstreamBinding } from './user-codex-upstream-bindings.js';
class RouteError extends Error {
    status;
    // Per-model disposition of the chain at the moment routing gave up: one line
    // per considered model with the reason it could not serve (no key, cooldown,
    // provider cap, rpm/rpd, tpm/tpd, context too small, …). Populated only on the
    // synchronous "all exhausted" throw, where NO upstream was tried and nothing
    // else logs WHY the pool was empty (issue _1: opaque routing_error 429).
    diagnostics;
    constructor(message, status, diagnostics) {
        super(message);
        this.status = status;
        this.diagnostics = diagnostics;
    }
}
// Human-readable retry ETA from a cooldown expiry timestamp (#423). Null when
// nothing is cooling down or it already lapsed.
export function formatResetEta(soonestResetMs, now = Date.now()) {
    if (soonestResetMs == null)
        return null;
    const deltaMs = soonestResetMs - now;
    if (deltaMs <= 0)
        return null;
    const secs = Math.round(deltaMs / 1000);
    if (secs < 90)
        return `~${secs}s`;
    const mins = Math.round(secs / 60);
    if (mins < 90)
        return `~${mins}m`;
    return `~${Math.round(mins / 60)}h`;
}
const EXHAUSTION_ADVICE = 'Add more API keys or wait for rate limits to reset.';
// Roll the per-model diagnostics (see RouteError.diagnostics) up into a short,
// client-safe summary so an exhausted caller learns WHY the pool was empty
// instead of a bare "All models exhausted" (#423). Buckets are aggregate
// counts only — no key material, no per-key detail. Classifies off the whole
// line (model ids can contain ':' so splitting label from reason is unsafe).
export function summarizeExhaustion(diag, soonestResetMs, now = Date.now()) {
    const eta = formatResetEta(soonestResetMs, now);
    const etaSuffix = eta ? ` Soonest reset ${eta}.` : '';
    if (!diag || diag.length === 0) {
        return `All models exhausted. ${EXHAUSTION_ADVICE}${etaSuffix}`;
    }
    const counts = {};
    const bump = (bucket) => { counts[bucket] = (counts[bucket] ?? 0) + 1; };
    for (const line of diag) {
        const l = line.toLowerCase();
        if (l.includes('no provider registered'))
            bump('unsupported provider');
        else if (/no enabled\+healthy key|no usable key|decrypt-error/.test(l))
            bump('no usable key configured');
        else if (l.includes('< estimated'))
            bump('prompt too large for the model');
        else if (l.includes('no vision support'))
            bump('model lacks vision');
        else if (l.includes('no tool-calling support'))
            bump('model lacks tool-calling');
        else if (l.includes('drops response_format'))
            bump('platform cannot honor response_format');
        else if (/ruled out|already-failed/.test(l))
            bump('failed earlier this request');
        else if (/cooldown|rpm|rpd|tpm|tpd|provider-daily-cap/.test(l))
            bump('rate-limited or on cooldown');
        else
            bump('unavailable');
    }
    // Most actionable buckets first.
    const order = [
        'rate-limited or on cooldown',
        'no usable key configured',
        'prompt too large for the model',
        'model lacks vision',
        'model lacks tool-calling',
        'platform cannot honor response_format',
        'failed earlier this request',
        'unsupported provider',
        'unavailable',
    ];
    const parts = order.filter(b => counts[b]).map(b => `${counts[b]} ${b}`);
    const total = diag.length;
    return `All models exhausted: ${total} route${total === 1 ? '' : 's'} checked (${parts.join(', ')}). ${EXHAUSTION_ADVICE}${etaSuffix}`;
}
// ── Routing token estimate: cap the reserved OUTPUT, not the full max_tokens ──
// A client can request a huge max_tokens (e.g. 32000) it will never actually
// emit. Reserving that full amount against every model's context window and TPM
// budget falsely excludes the entire free pool (TPM 6k-30k) and returns a bogus
// "all models exhausted" 429 with ZERO upstream calls (#470). Providers meter
// ACTUAL tokens, so under-reserving only risks an upstream 429/413 the retry
// loop already handles, whereas over-reserving starves routing. For routing and
// the context-window / TPM filters we therefore reserve at most this many output
// tokens; the INPUT estimate is still counted in full so a genuinely large
// prompt still (correctly) skips a too-small model.
export const OUTPUT_RESERVE_CAP = 2000;
/**
 * Output tokens to reserve for routing/filter purposes: the requested max_tokens
 * clamped to OUTPUT_RESERVE_CAP (default 1000 when the client omitted it, matching
 * the historical fallback). Callers add this to their INPUT estimate before
 * calling routeRequest / routePinnedModel.
 */
export function routingReserveTokens(requestedMaxTokens) {
    const requested = requestedMaxTokens != null && requestedMaxTokens > 0 ? requestedMaxTokens : 1000;
    return Math.min(requested, OUTPUT_RESERVE_CAP);
}
// Round-robin index per platform
const roundRobinIndex = new Map();
// Shared Codex rotation is scoped to the actual pool boundary.  Keeping one
// global cursor made traffic in another group (or another model/protocol)
// consume turns from this group and could make a mixed OAuth/relay pool look
// uneven even though its candidates were otherwise eligible.
const codexPoolRoundRobinIndex = new Map();
const codexRelayKeyRoundRobinIndex = new Map();
const rateLimitPenalties = new Map();
// Penalty decays over time so models recover
const PENALTY_PER_429 = 3; // each 429 adds this many priority positions
const MAX_PENALTY = 10; // cap so a model doesn't sink forever
const DECAY_INTERVAL_MS = 2 * 60 * 1000; // penalty decays every 2 minutes
const DECAY_AMOUNT = 1; // remove this much penalty per decay interval
/**
 * Record a 429 for a model — increases its penalty so it sinks in priority.
 */
function penaltyKey(modelDbId, platform) {
    const scope = platform === 'openai-codex'
        ? getCodexPolicyScope()
        : 'ordinary';
    return `${scope}\u0000${modelDbId}`;
}
export function recordRateLimitHit(modelDbId, platform) {
    const key = penaltyKey(modelDbId, platform);
    const existing = rateLimitPenalties.get(key);
    const now = Date.now();
    if (existing) {
        const decaySteps = Math.floor((now - existing.lastHit) / DECAY_INTERVAL_MS);
        existing.penalty = Math.max(0, existing.penalty - decaySteps * DECAY_AMOUNT);
        existing.count++;
        existing.lastHit = now;
        existing.penalty = Math.min(existing.penalty + PENALTY_PER_429, MAX_PENALTY);
    }
    else {
        rateLimitPenalties.set(key, {
            modelDbId,
            count: 1,
            lastHit: now,
            penalty: PENALTY_PER_429,
        });
    }
}
/**
 * Record a success for a model — reduces its penalty so it rises back up.
 */
export function recordSuccess(modelDbId, platform) {
    const key = penaltyKey(modelDbId, platform);
    const existing = rateLimitPenalties.get(key);
    if (existing) {
        existing.penalty = Math.max(0, existing.penalty - 1);
        if (existing.penalty === 0) {
            rateLimitPenalties.delete(key);
        }
    }
}
/**
 * Get the current penalty for a model (with time-based decay).
 * Pure read — does not mutate the entry; decay is applied lazily only when
 * recording a new hit (recordRateLimitHit) so the clock isn't reset on every
 * routing call.
 */
function getPenalty(modelDbId, platform) {
    const key = penaltyKey(modelDbId, platform);
    const entry = rateLimitPenalties.get(key);
    if (!entry)
        return 0;
    const elapsed = Date.now() - entry.lastHit;
    const decaySteps = Math.floor(elapsed / DECAY_INTERVAL_MS);
    const decayed = Math.max(0, entry.penalty - decaySteps * DECAY_AMOUNT);
    if (decayed === 0) {
        rateLimitPenalties.delete(key);
        return 0;
    }
    return decayed;
}
/**
 * Get current penalties for all models (for the API/dashboard).
 */
export function getAllPenalties() {
    const result = new Map();
    const now = Date.now();
    for (const [key, entry] of rateLimitPenalties) {
        const decaySteps = Math.floor((now - entry.lastHit) / DECAY_INTERVAL_MS);
        const penalty = Math.max(0, entry.penalty - decaySteps * DECAY_AMOUNT);
        if (penalty === 0) {
            rateLimitPenalties.delete(key);
            continue;
        }
        const aggregate = result.get(entry.modelDbId);
        if (aggregate) {
            aggregate.count += entry.count;
            aggregate.penalty = Math.max(aggregate.penalty, penalty);
        }
        else {
            result.set(entry.modelDbId, {
                modelDbId: entry.modelDbId,
                count: entry.count,
                penalty,
            });
        }
    }
    return [...result.values()].sort((a, b) => b.penalty - a.penalty);
}
// ── Routing strategy (persisted) ────────────────────────────────────────────
const STRATEGY_KEY = 'routing_strategy';
const CUSTOM_WEIGHTS_KEY = 'routing_custom_weights';
const VALID_STRATEGIES = ['priority', 'balanced', 'smartest', 'fastest', 'reliable', 'custom'];
function userSettingKey(key, userId) {
    const resolvedUserId = userId === undefined ? getClientContext().consumerUserId : userId;
    return resolvedUserId == null ? key : `${key}_user_${resolvedUserId}`;
}
export function getRoutingStrategy(userId) {
    const raw = getSetting(userSettingKey(STRATEGY_KEY, userId));
    return (raw && VALID_STRATEGIES.includes(raw))
        ? raw
        : DEFAULT_STRATEGY;
}
export function setRoutingStrategy(strategy, userId) {
    if (!VALID_STRATEGIES.includes(strategy)) {
        throw new Error(`Unknown routing strategy: ${strategy}`);
    }
    setSetting(userSettingKey(STRATEGY_KEY, userId), strategy);
}
// ── Custom weights (persisted) ──────────────────────────────────────────────
// User-tuned weight vector for the 'custom' strategy. Stored normalized (sums
// to 1) so the dashboard percentages read cleanly; combineScore would tolerate
// any non-negative vector regardless. Falls back to the balanced preset until
// the user has saved their own.
export function getCustomWeights(userId) {
    const raw = getSetting(userSettingKey(CUSTOM_WEIGHTS_KEY, userId));
    if (raw) {
        try {
            const w = JSON.parse(raw);
            if ([w.reliability, w.speed, w.intelligence].every(v => Number.isFinite(v) && v >= 0) &&
                w.reliability + w.speed + w.intelligence > 0) {
                return { reliability: w.reliability, speed: w.speed, intelligence: w.intelligence };
            }
        }
        catch { /* corrupt setting → fall through to default */ }
    }
    return { ...BANDIT_PRESETS.balanced };
}
export function setCustomWeights(weights, userId) {
    const { reliability, speed, intelligence } = weights;
    if (![reliability, speed, intelligence].every(v => Number.isFinite(v) && v >= 0)) {
        throw new Error('Custom weights must be non-negative numbers');
    }
    const sum = reliability + speed + intelligence;
    if (sum <= 0) {
        throw new Error('Custom weights must not all be zero');
    }
    setSetting(userSettingKey(CUSTOM_WEIGHTS_KEY, userId), JSON.stringify({
        reliability: reliability / sum,
        speed: speed / sum,
        intelligence: intelligence / sum,
    }));
}
function weightsFor(strategy, userId) {
    if (strategy === 'priority')
        return null;
    if (strategy === 'custom')
        return getCustomWeights(userId);
    return BANDIT_PRESETS[strategy];
}
// ── Analytics stats cache (decay-weighted) ──────────────────────────────────
// Instead of the fork's flat 7-day window (where a model that degrades today
// keeps a stale week-long average), each request is weighted by an exponential
// decay so recent behavior dominates while older data still stabilizes the
// estimate. We aggregate by (model, integer day age) in SQL — at most ~7 rows
// per model — then apply the per-bucket decay weight in JS.
const WINDOW_MS = 7 * 24 * 60 * 60 * 1000;
const HALF_LIFE_DAYS = 2; // a 2-day-old request counts half as much as a fresh one
const CACHE_TTL_MS = 60 * 1000;
let statsCache = null;
let statsCacheTime = 0;
function decayWeight(ageDays) {
    return Math.pow(0.5, Math.max(0, ageDays) / HALF_LIFE_DAYS);
}
export function refreshStatsCache(db, force = false) {
    if (!force && statsCache && Date.now() - statsCacheTime < CACHE_TTL_MS)
        return;
    const since = new Date(Date.now() - WINDOW_MS).toISOString();
    const buckets = db.prepare(`
    SELECT platform, model_id,
      CAST((julianday('now') - julianday(created_at)) AS INTEGER) AS age_days,
      COUNT(*) AS total,
      SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) AS successes,
      SUM(CASE WHEN status = 'success' THEN output_tokens ELSE 0 END) AS succ_out,
      SUM(CASE WHEN status = 'success' THEN latency_ms ELSE 0 END) AS succ_lat,
      SUM(CASE WHEN status = 'success' AND ttfb_ms IS NOT NULL THEN ttfb_ms ELSE 0 END) AS succ_ttfb_sum,
      SUM(CASE WHEN status = 'success' AND ttfb_ms IS NOT NULL THEN 1 ELSE 0 END) AS succ_ttfb_cnt
    FROM requests
    WHERE created_at >= ?
    GROUP BY platform, model_id, age_days
  `).all(since);
    // Accumulate decay-weighted sums per model.
    const acc = new Map();
    for (const b of buckets) {
        const key = `${b.platform}:${b.model_id}`;
        const w = decayWeight(b.age_days);
        const a = acc.get(key) ?? { wSucc: 0, wFail: 0, wOut: 0, wLat: 0, wTtfbSum: 0, wTtfbCnt: 0 };
        a.wSucc += w * b.successes;
        a.wFail += w * (b.total - b.successes);
        a.wOut += w * b.succ_out;
        a.wLat += w * b.succ_lat;
        a.wTtfbSum += w * b.succ_ttfb_sum;
        a.wTtfbCnt += w * b.succ_ttfb_cnt;
        acc.set(key, a);
    }
    // Calendar-month token usage per model, for the headroom guardrail.
    const usageRows = db.prepare(`
    SELECT platform, model_id, COALESCE(SUM(input_tokens + output_tokens), 0) AS used
    FROM requests
    WHERE created_at >= datetime('now', 'start of month')
      AND request_type = 'chat'
    GROUP BY platform, model_id
  `).all();
    const usageMap = new Map(usageRows.map(r => [`${r.platform}:${r.model_id}`, r.used]));
    const next = new Map();
    for (const [key, a] of acc) {
        next.set(key, {
            successes: a.wSucc,
            failures: a.wFail,
            tokPerSec: a.wLat > 0 ? (a.wOut * 1000) / a.wLat : 0,
            avgTtfbMs: a.wTtfbCnt > 0 ? a.wTtfbSum / a.wTtfbCnt : null,
            monthlyUsedTokens: usageMap.get(key) ?? 0,
        });
    }
    // Models with month usage but no recent window data still need a headroom number.
    for (const [key, used] of usageMap) {
        if (!next.has(key)) {
            next.set(key, { successes: 0, failures: 0, tokPerSec: 0, avgTtfbMs: null, monthlyUsedTokens: used });
        }
    }
    statsCache = next;
    statsCacheTime = Date.now();
}
// Composite intelligence: size_label is the cross-provider capability tier
// (issue #135 — intelligence_rank is only meaningful within one provider), so
// tier dominates and intelligence_rank breaks ties inside a tier.
const TIER_VALUE = { Frontier: 4, Large: 3, Medium: 2, Small: 1 };
function intelligenceComposite(sizeLabel, intelligenceRank) {
    const tier = TIER_VALUE[sizeLabel] ?? 0;
    // tier*1000 keeps tiers strictly separated; -rank prefers lower rank in-tier.
    return tier * 1000 - intelligenceRank;
}
// Enabled + healthy/unknown key count per platform, for pooled-budget scaling.
// This is the SAME filter both /api/fallback endpoints use (issue #456): the
// monthly budget is a PER-KEY free-tier allowance, so N usable keys pool N× the
// capacity. `monthlyUsedTokens` is already summed across all keys, so budget
// must scale to match or the headroom guardrail damps a multi-key model to the
// floor after just one account's worth of tokens.
function usableKeyCountsByPlatform(db) {
    const rows = db.prepare("SELECT platform, COUNT(*) AS count FROM api_keys WHERE role = 'provider' AND enabled = 1 AND status IN ('healthy', 'unknown') GROUP BY platform").all();
    return new Map(rows.map(r => [r.platform, r.count]));
}
function scoreChainEntry(entry, weights, intelMin, intelMax, sampled, keyCounts) {
    const stats = statsCache?.get(`${entry.platform}:${entry.model_id}`);
    const successes = stats?.successes ?? 0;
    const failures = stats?.failures ?? 0;
    let reliability;
    if (sampled) {
        const { alpha, beta } = reliabilityPosterior(successes, failures);
        reliability = sampleBeta(alpha, beta);
    }
    else {
        reliability = expectedReliability(successes, failures);
    }
    const speed = speedScore(stats?.tokPerSec ?? 0, stats?.avgTtfbMs ?? null);
    const intelligence = intelligenceScore(intelligenceComposite(entry.size_label, entry.intelligence_rank), intelMin, intelMax);
    // Scale the per-key monthly budget by the usable key count for this platform,
    // matching the pooled `monthlyUsedTokens` aggregate (#456). Math.max(1, …) so a
    // model whose platform currently has no usable key isn't handed a 0 budget.
    const budget = parseBudget(entry.monthly_token_budget) * Math.max(1, keyCounts.get(entry.platform) ?? 1);
    const headroom = headroomFactor(stats?.monthlyUsedTokens ?? 0, budget);
    const rl = rateLimitFactor(getPenalty(entry.model_db_id, entry.platform));
    const score = combineScore({ reliability, speed, intelligence, headroom, rateLimit: rl }, weights);
    return { axes: { reliability, speed, intelligence }, headroom, rateLimit: rl, score };
}
/**
 * Order the enabled fallback chain for routing.
 *  - 'priority' strategy → legacy manual order + 429 penalty (unchanged).
 *  - bandit strategy      → convex score, manual priority as the deterministic
 *                           tiebreaker for (near-)equal scores.
 *
 * `sampled` controls the bandit branch: Thompson sampling (the default) for
 * live routing, where per-call randomness is the exploration the bandit needs;
 * the deterministic expected score (`sampled = false`) for callers that want a
 * STABLE ranking under the chosen strategy — the fusion panel, which should be a
 * faithful reflection of the user's picked strategy, not a re-sampled draw each
 * request. Priority mode is deterministic either way.
 */
function orderChain(chain, strategy, sampled = true) {
    const weights = weightsFor(strategy);
    if (!weights) {
        // Legacy priority mode: base priority + 429 penalty, ascending.
        return chain
            .map(e => ({ e, eff: e.priority + getPenalty(e.model_db_id, e.platform) }))
            .sort((a, b) => a.eff - b.eff || a.e.priority - b.e.priority)
            .map(x => x.e);
    }
    const composites = chain.map(e => intelligenceComposite(e.size_label, e.intelligence_rank));
    const intelMin = composites.length ? Math.min(...composites) : 0;
    const intelMax = composites.length ? Math.max(...composites) : 0;
    const keyCounts = usableKeyCountsByPlatform(getDb());
    return chain
        .map(e => ({ e, s: scoreChainEntry(e, weights, intelMin, intelMax, sampled, keyCounts).score }))
        // Higher score first; manual priority breaks ties so the chain still matters.
        .sort((a, b) => b.s - a.s || a.e.priority - b.e.priority)
        .map(x => x.e);
}
// A stopped billing rule also disables the route. This keeps explicit model
// selection from reaching a provider route that the admin has turned off.
function isBillingRouteEnabled(db, entry) {
    const rule = getModelBillingRule(db, entry.platform, entry.model_id);
    return !rule || rule.billingEnabled === 1;
}
const GLOBAL_SORT_ALIASES = {
    smart: 'smart', smartest: 'smart', intelligence: 'smart',
    fast: 'fast', fastest: 'fast', speed: 'fast',
    cheap: 'cheap', cheapest: 'cheap', price: 'cheap', budget: 'cheap',
    reliable: 'reliable', reliability: 'reliable',
    balanced: 'balanced',
};
function getActiveChain(db) {
    const profileId = getActiveProfileId(db);
    if (profileId != null) {
        const chain = db.prepare(`
      SELECT pm.model_db_id, pm.priority, pm.enabled,
             m.platform, m.model_id, m.upstream_model_id, m.display_name, m.intelligence_rank,
             m.size_label, m.monthly_token_budget,
             m.rpm_limit, m.rpd_limit, m.tpm_limit, m.tpd_limit, m.supports_vision,
             m.supports_tools, m.context_window, m.key_id
      FROM profile_models pm
      JOIN models m ON m.id = pm.model_db_id AND m.enabled = 1
      WHERE pm.profile_id = ?
      ORDER BY pm.priority ASC
    `).all(profileId);
        if (chain.length > 0)
            return chain;
    }
    return db.prepare(`
    SELECT fc.model_db_id, fc.priority, fc.enabled,
           m.platform, m.model_id, m.upstream_model_id, m.display_name, m.intelligence_rank,
           m.size_label, m.monthly_token_budget,
           m.rpm_limit, m.rpd_limit, m.tpm_limit, m.tpd_limit, m.supports_vision,
           m.supports_tools, m.context_window, m.key_id
    FROM fallback_config fc
    JOIN models m ON m.id = fc.model_db_id AND m.enabled = 1
    ORDER BY fc.priority ASC
  `).all();
}
function getChainByProfileName(db, name) {
    const profile = db.prepare("SELECT id FROM profiles WHERE LOWER(name) = ?").get(name.toLowerCase());
    if (!profile)
        return null;
    return db.prepare(`
    SELECT pm.model_db_id, pm.priority, pm.enabled,
           m.platform, m.model_id, m.upstream_model_id, m.display_name, m.intelligence_rank,
           m.size_label, m.monthly_token_budget,
           m.rpm_limit, m.rpd_limit, m.tpm_limit, m.tpd_limit, m.supports_vision,
           m.supports_tools, m.context_window, m.key_id
    FROM profile_models pm
    JOIN models m ON m.id = pm.model_db_id AND m.enabled = 1
    WHERE pm.profile_id = ?
    ORDER BY pm.priority ASC
  `).all(profile.id);
}
function getChainByGlobalSort(db, globalAxis) {
    const allEnabled = db.prepare(`
    SELECT m.id as model_db_id, 0 as priority, 1 as enabled,
           m.platform, m.model_id, m.upstream_model_id, m.display_name, m.intelligence_rank,
           m.size_label, m.monthly_token_budget,
           m.rpm_limit, m.rpd_limit, m.tpm_limit, m.tpd_limit, m.supports_vision,
           m.supports_tools, m.context_window, m.key_id
    FROM models m
    WHERE m.enabled = 1
  `).all();
    const strategyMap = {
        'smart': 'smartest',
        'fast': 'fastest',
        'cheap': 'balanced',
        'reliable': 'reliable',
        'balanced': 'balanced'
    };
    const strat = strategyMap[globalAxis] || 'balanced';
    return orderChain(allEnabled, strat);
}
export function resolveRoutingChain(modelString) {
    const db = getDb();
    if (!modelString || modelString.toLowerCase() === 'auto') {
        return { chain: getActiveChain(db), strategyKey: 'auto' };
    }
    const lower = modelString.toLowerCase();
    if (!lower.startsWith('auto:')) {
        return { chain: getActiveChain(db), strategyKey: 'auto' };
    }
    const suffix = lower.slice('auto:'.length).trim();
    if (!suffix) {
        return { chain: getActiveChain(db), strategyKey: 'auto' };
    }
    const globalAxis = GLOBAL_SORT_ALIASES[suffix];
    if (globalAxis) {
        const chain = getChainByGlobalSort(db, globalAxis);
        if (chain.length === 0) {
            const err = new Error(`No enabled models available for global sort '${suffix}'`);
            err.status = 400;
            throw err;
        }
        return { chain, strategyKey: `auto:${globalAxis}` };
    }
    const chain = getChainByProfileName(db, suffix);
    if (!chain) {
        const err = new Error(`Profile '${suffix}' not found. Use 'auto' for the default profile, or call /v1/models for available options.`);
        err.status = 400;
        throw err;
    }
    const enabledModels = chain.filter(e => e.enabled);
    if (enabledModels.length === 0) {
        const err = new Error(`Profile '${suffix}' has no enabled models. Add models to this profile in the dashboard.`);
        err.status = 400;
        throw err;
    }
    return { chain, strategyKey: `auto:${suffix}` };
}
/**
 * Pick a usable key for ONE model and build its RouteResult, or return null if
 * the model has no key that can serve the request right now (all cooled down,
 * over quota, undecryptable, or no provider). This is the per-model key
 * round-robin previously inlined in routeRequest, factored out so the fusion
 * panel can HARD-PIN a model: rotate across that model's keys without ever
 * falling through to a different model (issue #326 — soft preference collapses
 * panel diversity under rate limits). Request-level filters (vision/tools/
 * context window) stay in the caller; this only does key selection + accounting
 * pre-checks.
 */
function selectKeyForModel(entry, estimatedTokens, skipKeys, diag, requirements = {}) {
    const db = getDb();
    const label = `${entry.platform}/${entry.model_id}`;
    const providerModelId = entry.upstream_model_id?.trim() || entry.model_id;
    const clientContext = getClientContext();
    const consumerKeyType = clientContext.consumerApiKeyType;
    // A universal consumer's virtual `auto` model is the existing free-model
    // product.  The administrator can still keep priced models in the global
    // fallback chain for dashboard/unified-key traffic, but those candidates
    // must never become an unreserved free response for a consumer key.
    if (clientContext.consumerFreeOnly) {
        const zeroPricedRule = db.prepare(`
      SELECT 1
      FROM model_billing_rules
      WHERE platform = ?
        AND model_id = ?
        AND billing_enabled = 1
        AND input_price_micro_per_million = 0
        AND output_price_micro_per_million = 0
      LIMIT 1
    `).get(entry.platform, entry.model_id);
        if (!zeroPricedRule) {
            diag?.push(`${label}: excluded from the consumer free-model pool`);
            return null;
        }
    }
    if ((consumerKeyType === 'codex_pool' || consumerKeyType === 'resource_subpool') && entry.platform !== 'openai-codex') {
        diag?.push(`${label}: Codex pool API key cannot use ordinary providers`);
        return null;
    }
    if (!hasProvider(entry.platform)) {
        diag?.push(`${label}: no provider registered`);
        return null;
    }
    const provider = getProvider(entry.platform);
    // Codex is a dynamic account/model pool. Select one enabled capability from
    // a healthy account and pass only the database account id to the provider;
    // the provider still owns token decryption. upstream_model_id remains
    // available for ordinary providers but no longer pins the Codex alias.
    if (entry.platform === 'openai-codex') {
        if (consumerKeyType && consumerKeyType !== 'codex_pool' && consumerKeyType !== 'resource_subpool') {
            diag?.push(`${label}: consumer API key does not have Codex pool access`);
            return null;
        }
        if (consumerKeyType === 'resource_subpool') {
            const context = getClientContext();
            if (context.resourceSubpoolId === null || context.resourceQuotaReservationId === null || !context.resourceRequestCorrelationId) {
                diag?.push(`${label}: resource entitlement and quota reservation required`);
                return null;
            }
            let resourceModelId = entry.model_id;
            if (resourceModelId === 'codex') {
                // The virtual alias previously let the dedicated scheduler pick any
                // account capability, including an uncertified GPT-5.6+ OAuth model.
                // Resolve it to the first older capability before creating a dispatch;
                // relay capacity is intentionally unavailable to resource subpools.
                const resourceCapabilities = db.prepare(`
          SELECT DISTINCT am.model_id
          FROM resource_subpool_bindings b
          JOIN codex_oauth_accounts a ON a.id = b.codex_account_id
          JOIN codex_oauth_account_models am ON am.account_id = a.id AND am.enabled = 1
          JOIN model_billing_rules br
            ON br.platform = 'openai-codex'
           AND br.model_id = am.model_id
           AND br.billing_enabled = 1
          WHERE b.subpool_id = ?
            AND b.status = 'active'
            AND a.enabled = 1
            AND a.resource_scope = 'resource_subpool'
            AND a.status IN ('healthy', 'unknown')
            AND (a.cooldown_until IS NULL OR a.cooldown_until <= datetime('now'))
          ORDER BY am.model_id
        `).all(context.resourceSubpoolId);
                const safeCapability = resourceCapabilities.find((candidate) => !requiresExplicitPromptCache(candidate.model_id));
                if (!safeCapability) {
                    diag?.push(`${label}: dedicated OAuth pool has no pre-5.6 capability`);
                    return null;
                }
                resourceModelId = safeCapability.model_id;
            }
            else if (requiresExplicitPromptCache(resourceModelId)) {
                diag?.push(`${label}: GPT-5.6+ requires a certified Responses relay unavailable to resource subpools`);
                return null;
            }
            const skippedAccounts = new Set();
            for (const key of skipKeys ?? []) {
                const match = /^openai-codex:.*:-(\d+)$/.exec(key);
                if (match)
                    skippedAccounts.add(Number(match[1]));
            }
            try {
                const execution = selectCodexExecution(db, {
                    subpoolId: context.resourceSubpoolId,
                    reservationId: context.resourceQuotaReservationId,
                    correlationId: context.resourceRequestCorrelationId,
                    modelId: resourceModelId,
                    skipAccountIds: skippedAccounts,
                });
                setResourceDispatchId(execution.dispatchId);
                return {
                    provider,
                    modelId: execution.modelId,
                    modelDbId: entry.model_db_id,
                    apiKey: `codex-account:${execution.accountId}`,
                    keyId: -execution.accountId,
                    platform: entry.platform,
                    displayName: entry.display_name,
                    rpdLimit: entry.rpd_limit,
                    tpdLimit: entry.tpd_limit,
                };
            }
            catch (error) {
                const reason = error instanceof ResourceDispatchError ? error.code : 'resource_dispatch_failed';
                diag?.push(`${label}: ${reason}`);
                return null;
            }
        }
        if (consumerKeyType !== 'codex_pool') {
            diag?.push(`${label}: a scoped consumer API key is required`);
            return null;
        }
        const upstreamBinding = getUserCodexUpstreamBinding(db, clientContext.consumerUserId, clientContext.consumerCodexGroupId);
        const compactionPin = requirements.codexUpstreamPin;
        if (compactionPin && compactionPin.publicModelId !== entry.model_id) {
            diag?.push(`${label}: compacted conversation belongs to model ${compactionPin.publicModelId}`);
            return null;
        }
        if (compactionPin
            && upstreamBinding
            && (upstreamBinding.targetType !== compactionPin.sourceType
                || upstreamBinding.targetId !== compactionPin.targetId)) {
            throw new RouteError('This conversation was compacted by a different upstream than the administrator binding currently allows. Start a new conversation or restore the previous binding.', 409, [`${label}: compacted upstream conflicts with administrator binding`]);
        }
        const boundTargetUnavailable = () => {
            const targetKind = upstreamBinding?.targetType === 'relay'
                ? 'third-party Responses upstream'
                : 'OAuth account';
            throw new RouteError(`This Codex key is bound by the administrator to a specific ${targetKind}, but that target is unavailable or does not support model "${entry.model_id}" with the requested protocol and capabilities. Ask the administrator to change or clear the binding.`, 503, [`${label}: administrator-bound ${targetKind} is unavailable or incompatible`]);
        };
        // Shared OAuth accounts remain directly testable for every capability,
        // including GPT-5.6+. Prompt-cache certification is a relay-only gate;
        // resource-subpool OAuth keeps its separate fail-closed branch above.
        const allCapabilities = db.prepare(`
      SELECT a.id AS account_id, am.model_id
      FROM codex_oauth_accounts a
      JOIN codex_oauth_account_models am ON am.account_id = a.id
      JOIN model_billing_rules b
        ON b.platform = 'openai-codex'
       AND b.model_id = am.model_id
       AND b.billing_enabled = 1
      WHERE a.enabled = 1
        AND a.resource_scope = 'codex_pool'
        AND (SELECT codex_group_id FROM consumer_api_keys WHERE id = ?) IS NOT NULL
        AND a.codex_group_id = (SELECT codex_group_id FROM consumer_api_keys WHERE id = ?)
        AND EXISTS (
          SELECT 1
          FROM codex_groups enabled_group
          JOIN codex_group_models gm ON gm.group_id = enabled_group.id
          WHERE enabled_group.id = a.codex_group_id
            AND enabled_group.enabled = 1
            AND gm.model_id = am.model_id
        )
        AND a.status IN ('healthy', 'unknown')
        AND (a.cooldown_until IS NULL OR a.cooldown_until <= datetime('now'))
        AND (
          a.quota_remaining_percent IS NULL
          OR a.quota_remaining_percent > 0
          OR (a.quota_reset_at IS NOT NULL AND datetime(a.quota_reset_at) <= datetime('now'))
        )
        AND am.enabled = 1
        AND (? = 'codex' OR am.model_id = ?)
      ORDER BY
        CASE WHEN am.model_id LIKE 'gpt-%' THEN 0 ELSE 1 END,
        COALESCE(a.last_used_at, '1970-01-01') ASC,
        a.id ASC,
        am.model_id ASC
    `).all(clientContext.consumerApiKeyId, clientContext.consumerApiKeyId, entry.model_id, entry.model_id);
        const boundCapabilities = upstreamBinding
            ? upstreamBinding.targetType === 'oauth'
                ? allCapabilities.filter((candidate) => candidate.account_id === upstreamBinding.targetId)
                : []
            : allCapabilities;
        const capabilities = compactionPin
            ? compactionPin.sourceType === 'oauth'
                ? boundCapabilities.filter((candidate) => (candidate.account_id === compactionPin.targetId
                    && candidate.model_id === compactionPin.upstreamModelId))
                : []
            : boundCapabilities;
        // Relay credentials deliberately live outside `codex_oauth_accounts`.
        // They are only ever searched for a shared Codex-pool key (the service
        // itself repeats that key-scope guard) and must map the caller-visible
        // Codex model to a confirmed upstream model explicitly.
        const inboundRelayProtocol = requirements.codexRelayProtocol ?? 'chat_completions';
        // OAuth accounts and relay suppliers in the same group deliberately share
        // one cursor.  The group is the isolation boundary; the model and inbound
        // protocol keep unrelated pools from affecting one another.  A native
        // Responses relay can therefore rotate with OAuth for Responses callers,
        // while an older Chat Completions mapping remains isolated by protocol.
        const codexPoolRotationKey = [
            clientContext.consumerCodexGroupId ?? 'unbound',
            entry.model_id,
            inboundRelayProtocol,
            requirements.requireTools ? 'tools' : 'no-tools',
            requirements.requireVision ? 'vision' : 'no-vision',
            requirements.codexRequireStreaming ? 'stream' : 'buffered',
            requirements.codexRequireMultiTurn ? 'multi-turn' : 'single-turn',
        ].join(':');
        const nextCodexPoolIndex = (length) => {
            const cursor = codexPoolRoundRobinIndex.get(codexPoolRotationKey) ?? 0;
            codexPoolRoundRobinIndex.set(codexPoolRotationKey, cursor + 1);
            return cursor % length;
        };
        const relayCandidates = listEligibleCodexRelayCandidates(db, {
            consumerApiKeyId: clientContext.consumerApiKeyId,
            modelId: entry.model_id,
            requireCompaction: requirements.codexRequireCompaction === true,
            requireTools: requirements.requireTools === true,
            requireStreaming: requirements.codexRequireStreaming === true,
            requireMultiTurn: requirements.codexRequireMultiTurn === true,
        }).filter((candidate) => {
            if (requirements.skipRelaySources?.has(candidate.sourceId)) {
                diag?.push(`${label}: relay source already policy-rejected this request`);
                return false;
            }
            if (upstreamBinding) {
                if (upstreamBinding.targetType !== 'relay')
                    return false;
                if (candidate.sourceId !== upstreamBinding.targetId)
                    return false;
            }
            if (compactionPin) {
                if (compactionPin.sourceType !== 'relay')
                    return false;
                if (candidate.sourceId !== compactionPin.targetId)
                    return false;
                if (candidate.upstreamModelId !== compactionPin.upstreamModelId)
                    return false;
                // New compact envelopes pin the exact credential that produced the
                // opaque state. Older signed envelopes do not contain this field and
                // retain the legacy source-level behaviour until their next compact.
                if (compactionPin.relayApiKeyId !== undefined
                    && candidate.apiKeyId !== compactionPin.relayApiKeyId)
                    return false;
            }
            // Do not bridge protocols implicitly. A native Responses request can
            // only use a Responses upstream, while /chat/completions can only use a
            // Chat Completions upstream. Mixing them changes tool and stream wire
            // semantics and is a common source of gateway-only failures.
            if (candidate.protocol !== inboundRelayProtocol)
                return false;
            return true;
        });
        const relaysBySource = new Map();
        for (const relay of relayCandidates) {
            const siblings = relaysBySource.get(relay.sourceId) ?? [];
            siblings.push(relay);
            relaysBySource.set(relay.sourceId, siblings);
        }
        for (const siblings of relaysBySource.values()) {
            siblings.sort((left, right) => (left.keyPriority - right.keyPriority
                || String(left.keyLastUsedAt ?? '').localeCompare(String(right.keyLastUsedAt ?? ''))
                || left.apiKeyId - right.apiKeyId));
        }
        const candidates = [
            ...capabilities.map((candidate) => ({
                kind: 'oauth',
                accountId: candidate.account_id,
                modelId: candidate.model_id,
                // Existing OAuth accounts remain the neutral priority tier. An admin
                // can explicitly put a relay before/after that tier through its own
                // priority without changing account or group semantics.
                priority: 100,
            })),
            ...[...relaysBySource.entries()].map(([sourceId, relays]) => ({
                kind: 'relay',
                sourceId,
                relays,
                priority: relays[0].priority,
            })),
        ];
        if (candidates.length === 0) {
            if (compactionPin) {
                throw new RouteError('The upstream that owns this compacted conversation is unavailable. Retry later or start a new conversation.', 503, [`${label}: compacted conversation upstream unavailable`]);
            }
            if (upstreamBinding)
                boundTargetUnavailable();
            diag?.push(`${label}: no enabled Codex OAuth account or compatible relay mapping`);
            return null;
        }
        // Walk priority tiers rather than stopping at a failed preferred source.
        // This gives an administrator a predictable preference while retaining the
        // pool's automatic failover behaviour within the same request.
        const priorities = [...new Set(candidates.map((candidate) => candidate.priority))].sort((a, b) => a - b);
        for (const priority of priorities) {
            const tier = candidates.filter((candidate) => candidate.priority === priority && (candidate.kind === 'oauth'
                ? !skipKeys?.has(`${entry.platform}:${candidate.modelId}:${-candidate.accountId}`)
                : candidate.relays.some((relay) => (!skipKeys?.has(`${entry.platform}:${relay.upstreamModelId}:${relay.apiKeyId}`)))));
            if (tier.length === 0)
                continue;
            // Keep the previous least-concurrent OAuth choice whenever a tier has
            // only OAuth accounts. Mixed tiers use a stable round-robin so a relay is
            // a genuine peer rather than silently winning every request at active=0.
            let selected;
            const partiallyAttemptedRelay = tier.find((candidate) => (candidate.kind === 'relay'
                && candidate.relays.some((relay) => (skipKeys?.has(`${entry.platform}:${relay.upstreamModelId}:${relay.apiKeyId}`)))
                && candidate.relays.some((relay) => (!skipKeys?.has(`${entry.platform}:${relay.upstreamModelId}:${relay.apiKeyId}`)))));
            if (partiallyAttemptedRelay) {
                // Finish the selected supplier's healthy sibling keys before moving to
                // another supplier or OAuth account. A single bad credential therefore
                // cannot eject an otherwise healthy supplier from this request.
                selected = partiallyAttemptedRelay;
            }
            else if (tier.every((candidate) => candidate.kind === 'oauth')) {
                const oauthTier = tier;
                const cacheSensitiveConversation = oauthTier.some((candidate) => requiresExplicitPromptCache(candidate.modelId)) && (inboundRelayProtocol === 'responses'
                    || Boolean(requirements.codexRelayAffinityKey?.trim()));
                if (cacheSensitiveConversation) {
                    // Prompt caches are account/organization-local. Keep a growing
                    // GPT-5.6+ Chat or Responses conversation on one OAuth account, while HRW
                    // hashing still distributes different conversations across the pool.
                    // skipKeys has already removed a failed/cooling account from this
                    // tier, so the same hash deterministically selects its fallback.
                    const affinity = requirements.codexRelayAffinityKey?.trim()
                        || `${clientContext.consumerApiKeyId ?? 'operator'}:${entry.model_id}`;
                    let bestScore = -1n;
                    selected = oauthTier[0];
                    for (const candidate of oauthTier) {
                        const digest = createHash('sha256')
                            .update(`${affinity}:oauth:${candidate.accountId}:${candidate.modelId}`)
                            .digest('hex')
                            .slice(0, 16);
                        const score = BigInt(`0x${digest}`);
                        if (score > bestScore) {
                            bestScore = score;
                            selected = candidate;
                        }
                    }
                }
                else {
                    const minimumActive = Math.min(...oauthTier.map((candidate) => getCodexAccountActiveCount(candidate.accountId)));
                    const leastLoaded = oauthTier.filter((candidate) => getCodexAccountActiveCount(candidate.accountId) === minimumActive);
                    selected = leastLoaded[nextCodexPoolIndex(leastLoaded.length)];
                }
            }
            else {
                const explicitCacheTier = tier.some((candidate) => candidate.kind === 'relay'
                    && relayMappingRequiresExplicitPromptCache(candidate.relays[0].publicModelId, candidate.relays[0].upstreamModelId));
                if (explicitCacheTier) {
                    // Cache domains are source-local. Consistent hashing keeps every
                    // growing conversation on one source while skipKeys still
                    // permits immediate failover when that source actually fails.
                    const affinity = requirements.codexRelayAffinityKey?.trim()
                        || `${clientContext.consumerApiKeyId ?? 'operator'}:${entry.model_id}`;
                    const bucket = Number.parseInt(createHash('sha256').update(affinity).digest('hex').slice(0, 8), 16);
                    selected = tier[bucket % tier.length];
                }
                else {
                    selected = tier[nextCodexPoolIndex(tier.length)];
                }
            }
            // A mixed priority tier can contain several relay credentials. If one
            // cannot be decrypted or its endpoint no longer resolves, walk the rest
            // of the same tier before conceding it to a lower priority source.
            const orderedTier = tier.every((candidate) => candidate.kind === 'oauth')
                ? [selected]
                : [
                    selected,
                    ...tier.filter((candidate) => candidate !== selected),
                ];
            for (const candidate of orderedTier) {
                if (candidate.kind === 'oauth') {
                    return {
                        provider,
                        modelId: candidate.modelId,
                        modelDbId: entry.model_db_id,
                        apiKey: `codex-account:${candidate.accountId}`,
                        // Negative ids distinguish OAuth accounts from ordinary api_keys
                        // while keeping RouteResult.keyId numeric for the fallback loop.
                        keyId: -candidate.accountId,
                        platform: entry.platform,
                        codexSource: 'oauth',
                        displayName: entry.display_name,
                        rpdLimit: entry.rpd_limit,
                        tpdLimit: entry.tpd_limit,
                    };
                }
                let boundPreferredRelay;
                if (upstreamBinding?.targetType === 'relay') {
                    // Pick a stable preferred credential for an administrator-bound
                    // source. A fresh stateless request may still walk healthy sibling
                    // Keys; once upstream-owned state exists, the pool is narrowed to
                    // this exact Key and must not cross account boundaries.
                    const preferredPriority = Math.min(...candidate.relays.map((relay) => relay.keyPriority));
                    const affinity = [
                        clientContext.consumerApiKeyId ?? 'operator',
                        entry.model_id,
                        candidate.sourceId,
                    ].join(':');
                    let bestScore = -1n;
                    for (const relay of candidate.relays.filter((item) => item.keyPriority === preferredPriority)) {
                        const digest = createHash('sha256')
                            .update(`${affinity}:bound-relay-key:${relay.sourceId}:${relay.apiKeyId}`)
                            .digest('hex')
                            .slice(0, 16);
                        const score = BigInt(`0x${digest}`);
                        if (score > bestScore) {
                            bestScore = score;
                            boundPreferredRelay = relay;
                        }
                    }
                }
                const relayPool = boundPreferredRelay && requirements.codexRelayHasUpstreamState === true
                    ? [boundPreferredRelay]
                    : candidate.relays;
                const usableRelays = relayPool.filter((relay) => (!skipKeys?.has(`${entry.platform}:${relay.upstreamModelId}:${relay.apiKeyId}`)));
                if (usableRelays.length === 0)
                    continue;
                const preferredKeyPriority = Math.min(...usableRelays.map((relay) => relay.keyPriority));
                const availableRelays = usableRelays.filter((relay) => relay.keyPriority === preferredKeyPriority);
                const explicitCache = relayMappingRequiresExplicitPromptCache(availableRelays[0].publicModelId, availableRelays[0].upstreamModelId);
                let selectedRelay;
                if (boundPreferredRelay && availableRelays.includes(boundPreferredRelay)) {
                    selectedRelay = boundPreferredRelay;
                }
                else if (explicitCache) {
                    // Rendezvous hashing makes the same conversation prefer the same Key
                    // while moving only the affected conversations when a Key is added,
                    // disabled or cooling down.
                    const affinity = requirements.codexRelayAffinityKey?.trim()
                        || `${clientContext.consumerApiKeyId ?? 'operator'}:${entry.model_id}`;
                    let bestScore = -1n;
                    selectedRelay = availableRelays[0];
                    for (const relay of availableRelays) {
                        const digest = createHash('sha256')
                            .update(`${affinity}:${relay.sourceId}:${relay.apiKeyId}`)
                            .digest('hex')
                            .slice(0, 16);
                        const score = BigInt(`0x${digest}`);
                        if (score > bestScore) {
                            bestScore = score;
                            selectedRelay = relay;
                        }
                    }
                }
                else {
                    const index = codexRelayKeyRoundRobinIndex.get(candidate.sourceId) ?? 0;
                    selectedRelay = availableRelays[index % availableRelays.length];
                    codexRelayKeyRoundRobinIndex.set(candidate.sourceId, index + 1);
                }
                const orderedRelays = [
                    selectedRelay,
                    ...availableRelays.filter((relay) => relay !== selectedRelay),
                ];
                for (const relay of orderedRelays) {
                    let relayApiKey;
                    try {
                        relayApiKey = decryptCodexRelaySourceApiKey(relay.source);
                    }
                    catch (error) {
                        recordCodexRelaySourceFailure(db, relay.sourceId, relay.apiKeyId, {
                            error,
                            authenticationFailure: true,
                        });
                        diag?.push(`${label}: relay credential could not be decrypted`);
                        continue;
                    }
                    const promptCacheCertified = isPromptCacheCertificationCurrent(relay.promptCacheStatus, relay.promptCacheCheckedAt);
                    // This flag is an explicit safety override for callers that know an
                    // upstream's usage report cannot be trusted. Native Responses cache
                    // discounts still apply a separate per-model certification gate in
                    // the Responses accounting path; keeping this route flag true lets
                    // Chat-compatible relays record their provider usage directly.
                    const cacheUsageTrusted = true;
                    const relayProvider = relay.protocol === 'responses'
                        ? new OpenAICodexProvider({
                            relayBaseUrl: relay.baseUrl,
                            relayPromptCacheCertified: promptCacheCertified,
                        })
                        : resolveProvider('custom', relay.baseUrl);
                    if (!relayProvider) {
                        // A local provider-resolution/configuration miss applies only to
                        // this routing pass. Do not persist a credential cooldown: the
                        // administrator may correct provider support without having to
                        // clear runtime health state afterward.
                        diag?.push(`${label}: relay endpoint could not be resolved`);
                        continue;
                    }
                    const relayIdentity = db.prepare(`
            SELECT source.name AS source_name, source_key.label AS key_label
            FROM codex_relay_sources source
            JOIN codex_relay_source_keys source_key
              ON source_key.source_id = source.id
             AND source_key.api_key_id = ?
            WHERE source.id = ?
          `).get(relay.apiKeyId, relay.sourceId);
                    return {
                        provider: relayProvider,
                        modelId: relay.upstreamModelId,
                        billingModelId: relay.publicModelId,
                        modelDbId: entry.model_db_id,
                        apiKey: relayApiKey,
                        keyId: relay.apiKeyId,
                        platform: entry.platform,
                        codexSource: 'relay',
                        codexRelaySourceId: relay.sourceId,
                        codexRelaySourceName: relayIdentity?.source_name,
                        codexRelayKeyLabel: relayIdentity?.key_label,
                        codexRelaySwitchRestriction: compactionPin?.sourceType === 'relay'
                            ? 'compaction_upstream_pin'
                            : upstreamBinding?.targetType === 'relay'
                                ? 'administrator_binding'
                                : undefined,
                        codexRelayPublicModelId: relay.publicModelId,
                        codexRelayProtocol: relay.protocol,
                        codexRelayBaseUrl: relay.baseUrl,
                        codexRelayPromptCacheCertified: promptCacheCertified,
                        codexRequireCompaction: requirements.codexRequireCompaction === true,
                        codexRelayPreserveUpstreamState: upstreamBinding?.targetType === 'relay'
                            || compactionPin?.sourceType === 'relay',
                        codexRelayCacheUsageTrusted: cacheUsageTrusted,
                        displayName: `${entry.display_name} via relay`,
                        rpdLimit: entry.rpd_limit,
                        tpdLimit: entry.tpd_limit,
                    };
                }
            }
        }
        if (upstreamBinding)
            boundTargetUnavailable();
        diag?.push(`${label}: all eligible Codex accounts and relays already failed this request`);
        return null;
    }
    const keys = entry.platform === 'custom' && entry.key_id != null
        ? db.prepare(`
        SELECT candidate.*
        FROM api_keys candidate
        JOIN api_keys anchor
          ON anchor.id = ?
         AND anchor.platform = 'custom'
         AND anchor.role = 'provider'
         AND candidate.base_url = anchor.base_url
        WHERE candidate.platform = 'custom'
          AND candidate.role = 'provider'
          AND candidate.enabled = 1
          AND candidate.status IN ('healthy', 'unknown')
        ORDER BY candidate.id ASC
      `).all(entry.key_id)
        : db.prepare("SELECT * FROM api_keys WHERE platform = ? AND role = 'provider' AND enabled = 1 AND status IN ('healthy', 'unknown') ORDER BY id ASC").all(entry.platform);
    if (keys.length === 0) {
        diag?.push(`${label}: no enabled+healthy key for platform`);
        return null;
    }
    // Tally the gate that rejected each key, so the exhaustion diagnostic can say
    // *why* a model with keys still couldn't serve (all on cooldown vs over quota).
    const skipTally = {};
    const note = (reason) => { skipTally[reason] = (skipTally[reason] ?? 0) + 1; };
    const limits = {
        rpm: entry.rpm_limit,
        rpd: entry.rpd_limit,
        tpm: entry.tpm_limit,
        tpd: entry.tpd_limit,
    };
    const rrKey = `${entry.platform}:${entry.model_id}`;
    let idx = roundRobinIndex.get(rrKey) ?? 0;
    for (let attempt = 0; attempt < keys.length; attempt++) {
        const key = keys[idx % keys.length];
        idx++;
        const skipId = `${entry.platform}:${entry.model_id}:${key.id}`;
        if (skipKeys?.has(skipId)) {
            note('already-failed-this-request');
            continue;
        }
        if (isOnCooldown(entry.platform, entry.model_id, key.id)) {
            note('cooldown');
            continue;
        }
        if (!canUseProvider(entry.platform, key.id)) {
            note('provider-daily-cap');
            continue;
        }
        if (!canMakeRequest(entry.platform, entry.model_id, key.id, limits)) {
            note('rpm/rpd-limit');
            continue;
        }
        if (!canUseTokens(entry.platform, entry.model_id, key.id, estimatedTokens, limits)) {
            note('tpm/tpd-limit');
            continue;
        }
        if (!canUseProviderTokens(entry.platform, key.id, entry.model_id, estimatedTokens)) {
            note('provider-daily-token-cap');
            continue;
        }
        let decryptedKey;
        try {
            decryptedKey = decrypt(key.encrypted_key, key.iv, key.auth_tag);
        }
        catch {
            db.prepare("UPDATE api_keys SET status = 'error', last_checked_at = datetime('now') WHERE id = ?")
                .run(key.id);
            note('decrypt-error');
            continue;
        }
        const resolvedProvider = entry.platform === 'custom'
            ? resolveProvider('custom', key.base_url)
            : provider;
        if (!resolvedProvider) {
            note('no-resolved-provider');
            continue;
        }
        roundRobinIndex.set(rrKey, idx);
        return {
            provider: resolvedProvider,
            modelId: providerModelId,
            modelDbId: entry.model_db_id,
            apiKey: decryptedKey,
            keyId: key.id,
            platform: entry.platform,
            displayName: entry.display_name,
            rpdLimit: limits.rpd,
            tpdLimit: limits.tpd,
        };
    }
    // No usable key for this model. Advance the round-robin index anyway so we
    // don't get stuck re-trying the same exhausted key first next time.
    roundRobinIndex.set(rrKey, idx);
    const summary = Object.entries(skipTally).map(([r, n]) => `${r}:${n}`).join(', ') || 'no usable key';
    diag?.push(`${label}: ${keys.length} key(s) — ${summary}`);
    return null;
}
/**
 * Whether the model still has ANOTHER key that could serve it right now, given
 * the key that just failed (excludingKeyId) and any keys already ruled out this
 * request (skipKeys, in the "platform:modelId:keyId" form). Applies the same
 * gates selectKeyForModel uses — enabled + healthy status, not on cooldown,
 * under the provider daily cap, and under rpm/rpd/tpm/tpd — so the answer means
 * "a real, dispatchable alternative exists".
 *
 * Used by the retry loops to decide whether a single key's 429 should demote the
 * WHOLE model (the model-level 429 penalty). It should not: the per-key cooldown
 * already isolates the failing key, so demoting the model while a sibling key can
 * still serve it wrongly sinks a healthy model in the scorer (#454). We only
 * record the model-level hit when this returns false — i.e. the 429 exhausted the
 * model, not just one of its keys.
 */
export function hasOtherUsableKey(modelDbId, excludingKeyId, skipKeys) {
    const db = getDb();
    const m = db.prepare(`
    SELECT platform, model_id, rpm_limit, rpd_limit, tpm_limit, tpd_limit, key_id
      FROM models WHERE id = ?
  `).get(modelDbId);
    if (!m)
        return false;
    if (m.platform === 'openai-codex') {
        const context = getClientContext();
        const consumerKeyId = context.consumerApiKeyId;
        const consumerKeyType = context.consumerApiKeyType;
        if (consumerKeyId == null
            || (consumerKeyType !== 'codex_pool' && consumerKeyType !== 'resource_subpool')) {
            return false;
        }
        const upstreamBinding = consumerKeyType === 'codex_pool'
            ? getUserCodexUpstreamBinding(db, context.consumerUserId, context.consumerCodexGroupId)
            : null;
        const scopePredicate = consumerKeyType === 'codex_pool'
            ? `
        a.resource_scope = 'codex_pool'
        AND (SELECT codex_group_id FROM consumer_api_keys WHERE id = ?) IS NOT NULL
        AND a.codex_group_id = (
          SELECT codex_group_id FROM consumer_api_keys WHERE id = ?
        )
        AND EXISTS (
          SELECT 1
          FROM codex_groups enabled_group
          JOIN codex_group_models gm ON gm.group_id = enabled_group.id
          WHERE enabled_group.id = a.codex_group_id
            AND enabled_group.enabled = 1
            AND gm.model_id = am.model_id
        )`
            : `
        a.resource_scope = 'resource_subpool'
        AND EXISTS (
          SELECT 1
          FROM resource_subpool_members sm
          JOIN resource_member_api_keys mk ON mk.member_id = sm.id
          JOIN resource_subpools ss
            ON ss.id = sm.subpool_id
           AND ss.status = 'active'
          JOIN resource_subpool_bindings sb
            ON sb.subpool_id = ss.id
           AND sb.status = 'active'
          WHERE mk.consumer_api_key_id = ?
            AND sb.codex_account_id = a.id
        )`;
        const params = consumerKeyType === 'codex_pool'
            ? [consumerKeyId, consumerKeyId, m.model_id, m.model_id]
            : [consumerKeyId, m.model_id, m.model_id];
        const accounts = db.prepare(`
      SELECT DISTINCT a.id, am.model_id
      FROM codex_oauth_accounts a
      JOIN codex_oauth_account_models am
        ON am.account_id = a.id AND am.enabled = 1
      JOIN model_billing_rules b
        ON b.platform = 'openai-codex'
       AND b.model_id = am.model_id
       AND b.billing_enabled = 1
      WHERE a.enabled = 1
        AND a.deleted_at IS NULL
        AND ${scopePredicate}
        AND a.status IN ('healthy', 'unknown')
        AND (a.cooldown_until IS NULL OR a.cooldown_until <= datetime('now'))
        AND (
          a.quota_remaining_percent IS NULL
          OR a.quota_remaining_percent > 0
          OR (a.quota_reset_at IS NOT NULL AND datetime(a.quota_reset_at) <= datetime('now'))
        )
        AND (? = 'codex' OR am.model_id = ?)
    `).all(...params);
        if (accounts.some((account) => {
            if (upstreamBinding && (upstreamBinding.targetType !== 'oauth'
                || upstreamBinding.targetId !== account.id))
                return false;
            const routeKeyId = -account.id;
            return routeKeyId !== excludingKeyId
                && !skipKeys?.has(`${m.platform}:${account.model_id}:${routeKeyId}`);
        })) {
            return true;
        }
        if (consumerKeyType !== 'codex_pool')
            return false;
        const relays = listEligibleCodexRelayCandidates(db, {
            consumerApiKeyId: consumerKeyId,
            modelId: m.model_id,
        });
        return relays.some((relay) => (!upstreamBinding || (upstreamBinding.targetType === 'relay'
            && upstreamBinding.targetId === relay.sourceId))
            &&
                relay.apiKeyId !== excludingKeyId
            && !skipKeys?.has(`${m.platform}:${relay.upstreamModelId}:${relay.apiKeyId}`)
            && !isOnCooldown(m.platform, relay.upstreamModelId, relay.apiKeyId));
    }
    const limits = { rpm: m.rpm_limit, rpd: m.rpd_limit, tpm: m.tpm_limit, tpd: m.tpd_limit };
    const keys = m.platform === 'custom' && m.key_id != null
        ? db.prepare(`
        SELECT candidate.id
        FROM api_keys candidate
        JOIN api_keys anchor
          ON anchor.id = ?
         AND anchor.platform = 'custom'
         AND anchor.role = 'provider'
         AND candidate.base_url = anchor.base_url
        WHERE candidate.platform = 'custom'
          AND candidate.role = 'provider'
          AND candidate.enabled = 1
          AND candidate.status IN ('healthy', 'unknown')
        ORDER BY candidate.id ASC
      `).all(m.key_id)
        : db.prepare("SELECT id FROM api_keys WHERE platform = ? AND role = 'provider' AND enabled = 1 AND status IN ('healthy', 'unknown') ORDER BY id ASC").all(m.platform);
    for (const k of keys) {
        if (k.id === excludingKeyId)
            continue;
        if (skipKeys?.has(`${m.platform}:${m.model_id}:${k.id}`))
            continue;
        if (isOnCooldown(m.platform, m.model_id, k.id))
            continue;
        if (!canUseProvider(m.platform, k.id))
            continue;
        if (!canMakeRequest(m.platform, m.model_id, k.id, limits))
            continue;
        // A per-minute token spike on the failed key doesn't mean a fresh key lacks
        // headroom; a nominal 1-token probe only rules out a key already at its
        // TPM/TPD ceiling.
        if (!canUseTokens(m.platform, m.model_id, k.id, 1, limits))
            continue;
        if (!canUseProviderTokens(m.platform, k.id, m.model_id, 1))
            continue;
        return true;
    }
    return false;
}
/**
 * Fetch a single enabled model's chain row by its db id.
 */
function getModelChainRow(db, modelDbId) {
    return db.prepare(`
    SELECT m.id as model_db_id, 0 as priority, 1 as enabled,
           m.platform, m.model_id, m.upstream_model_id, m.display_name, m.intelligence_rank,
           m.size_label, m.monthly_token_budget,
           m.rpm_limit, m.rpd_limit, m.tpm_limit, m.tpd_limit, m.supports_vision,
           m.supports_tools, m.context_window, m.key_id
    FROM models m
    WHERE m.id = ? AND m.enabled = 1
  `).get(modelDbId);
}
/**
 * Route to ONE specific model, hard-pinned. Rotates across that model's keys
 * (cooldowns, quotas, decryption all honored) but NEVER substitutes a different
 * model — returns null if the pinned model can't serve right now. This is what
 * makes a fusion panel genuinely diverse: a rate-limited slot is dropped, not
 * silently collapsed onto whatever else is available. `skipKeys` lets a slot
 * exclude keys it already failed on this request; `skipRelaySources` excludes
 * every credential owned by a relay source that rejected this request, while
 * `requireTools` applies both the catalog capability and Relay certification.
 */
export function routePinnedModel(modelDbId, estimatedTokens = 1000, skipKeys, skipRelaySources, requireTools = false) {
    const db = getDb();
    const entry = getModelChainRow(db, modelDbId);
    if (!entry)
        return null;
    if (!isBillingRouteEnabled(db, entry))
        return null;
    if (requireTools && !entry.supports_tools && entry.platform !== 'openai-codex')
        return null;
    if (entry.context_window != null && estimatedTokens > entry.context_window)
        return null;
    if (entry.tpm_limit != null && estimatedTokens > entry.tpm_limit)
        return null;
    return selectKeyForModel(entry, estimatedTokens, skipKeys, undefined, {
        skipRelaySources,
        requireTools,
    });
}
/**
 * Resolve a logical model group's member db ids to an ordered ChainRow[] for
 * strict group-pin routing (the "unify" feature). Each catalog-enabled member
 * is hydrated as a ChainRow carrying its active-profile/manual priority, then
 * ordered by the active strategy via orderChain. Auto-chain enabled/disabled is
 * intentionally ignored here because an explicit model request should still be
 * able to use a direct model that the user removed from auto routing.
 *
 * Pass the result to routeRequest() as `prefetchedChain` and DO NOT pass a
 * `preferredModelDbId` that isn't already one of these rows — otherwise the
 * preferred-model injection in routeRequest would unshift an off-group model and
 * the pin would no longer be strict (it could answer with a different model).
 */
export function resolveModelGroupCandidates(memberDbIds) {
    const db = getDb();
    const strategy = getRoutingStrategy();
    if (strategy !== 'priority')
        refreshStatsCache(db);
    const activeProfileId = getActiveProfileId(db);
    const selectMember = activeProfileId == null
        ? db.prepare(`
      SELECT m.id as model_db_id, COALESCE(fc.priority, 0) as priority,
             1 as enabled,
             m.platform, m.model_id, m.upstream_model_id, m.display_name, m.intelligence_rank,
             m.size_label, m.monthly_token_budget,
             m.rpm_limit, m.rpd_limit, m.tpm_limit, m.tpd_limit, m.supports_vision,
             m.supports_tools, m.context_window, m.key_id
      FROM models m
      LEFT JOIN fallback_config fc ON fc.model_db_id = m.id
      WHERE m.id = ? AND m.enabled = 1
    `)
        : db.prepare(`
      SELECT m.id as model_db_id, COALESCE(pm.priority, fc.priority, 0) as priority,
             1 as enabled,
             m.platform, m.model_id, m.upstream_model_id, m.display_name, m.intelligence_rank,
             m.size_label, m.monthly_token_budget,
             m.rpm_limit, m.rpd_limit, m.tpm_limit, m.tpd_limit, m.supports_vision,
             m.supports_tools, m.context_window, m.key_id
      FROM models m
      LEFT JOIN profile_models pm ON pm.profile_id = ? AND pm.model_db_id = m.id
      LEFT JOIN fallback_config fc ON fc.model_db_id = m.id
      WHERE m.id = ? AND m.enabled = 1
    `);
    const rows = [];
    for (const id of memberDbIds) {
        const row = (activeProfileId == null ? selectMember.get(id) : selectMember.get(activeProfileId, id));
        if (row)
            rows.push(row);
    }
    return orderChain(rows, strategy);
}
/**
 * The active fallback chain ordered by the current routing strategy, surfaced
 * for fusion panel selection. Same ordering the normal auto-router would walk,
 * so the panel's auto-pick draws from the highest-scored models first and the
 * fusion layer just needs to apply provider-diversity on top.
 */
export function getOrderedFusionChain() {
    const db = getDb();
    const strategy = getRoutingStrategy();
    if (strategy !== 'priority')
        refreshStatsCache(db);
    const chain = getActiveChain(db).filter(e => e.enabled);
    // Only consider models that can ACTUALLY be served RIGHT NOW — applying the
    // same gate selectKeyForModel uses when the router walks the chain: the model
    // must have a key that is enabled + healthy, NOT on cooldown (e.g. a
    // HuggingFace key benched for a day after a 402 "Payment Required"), within
    // the provider's daily request cap, and under its per-minute/day request
    // limits. Without this, a high-strategy-ranked model whose only key is
    // currently cooled down (huggingface/Kimi-K2.6) would claim a panel slot it
    // can't fill — surfacing as "no available key" and pushing out a usable model,
    // which also makes the panel look like it's ignoring the routing strategy.
    const usableKeys = db.prepare("SELECT id, platform, base_url FROM api_keys WHERE role = 'provider' AND enabled = 1 AND status IN ('healthy', 'unknown')").all();
    const keysByPlatform = new Map();
    for (const k of usableKeys) {
        const arr = keysByPlatform.get(k.platform);
        if (arr)
            arr.push(k);
        else
            keysByPlatform.set(k.platform, [k]);
    }
    const servable = chain.filter(e => {
        const keys = keysByPlatform.get(e.platform);
        if (!keys)
            return false;
        const limits = { rpm: e.rpm_limit, rpd: e.rpd_limit, tpm: e.tpm_limit, tpd: e.tpd_limit };
        const anchorBaseUrl = e.platform === 'custom'
            ? getCustomEndpointBaseUrl(db, e.key_id)
            : null;
        return keys.some(key => {
            const endpointMatches = e.key_id == null
                || key.id === e.key_id
                || (e.platform === 'custom' && anchorBaseUrl != null && key.base_url === anchorBaseUrl);
            return endpointMatches
                && !isOnCooldown(e.platform, e.model_id, key.id)
                && canUseProvider(e.platform, key.id)
                && canMakeRequest(e.platform, e.model_id, key.id, limits)
                && canUseProviderTokens(e.platform, key.id, e.model_id, 1);
        });
    });
    // Deterministic (expected-score) ordering so the panel faithfully follows the
    // user's picked routing strategy instead of re-sampling a fresh draw each call.
    const ordered = orderChain(servable, strategy, false);
    return ordered.map(e => ({
        modelDbId: e.model_db_id,
        platform: e.platform,
        modelId: e.model_id,
        displayName: e.display_name,
        sizeLabel: e.size_label,
        supportsVision: e.supports_vision,
        supportsTools: e.supports_tools,
    }));
}
/**
 * Resolve an explicit model id (as a client would type it) to a fusion
 * candidate, or null when it isn't a known enabled model. Prefers an enabled
 * row; dedupes a model id that exists on multiple platforms by intelligence
 * rank, matching how /v1/models picks a representative row.
 */
export function resolveFusionCandidate(modelId) {
    const db = getDb();
    const row = db.prepare(`
    SELECT m.id as model_db_id, m.platform, m.model_id, m.display_name,
           m.size_label, m.supports_vision, m.supports_tools
    FROM models m
    WHERE m.model_id = ? AND m.enabled = 1
    ORDER BY m.intelligence_rank ASC, m.id ASC
    LIMIT 1
  `).get(modelId);
    if (row) {
        return {
            modelDbId: row.model_db_id,
            platform: row.platform,
            modelId: row.model_id,
            displayName: row.display_name,
            sizeLabel: row.size_label,
            supportsVision: row.supports_vision,
            supportsTools: row.supports_tools,
        };
    }
    // Unify ON: a fusion picker value may be a canonical GROUP id rather than a
    // raw model_id. Resolve it to the group's best-ordered enabled member so
    // saved fusion configs that use canonical ids keep working. Exact model_id
    // match above always wins first, so OFF mode and legacy configs are untouched.
    if (isUnifyEnabled()) {
        const members = resolveRequestedIdToMembers(modelId, getModelGroups());
        if (members && members.length > 0) {
            const top = resolveModelGroupCandidates(members)[0];
            if (top) {
                return {
                    modelDbId: top.model_db_id,
                    platform: top.platform,
                    modelId: top.model_id,
                    displayName: top.display_name,
                    sizeLabel: top.size_label,
                    supportsVision: top.supports_vision,
                    supportsTools: top.supports_tools,
                };
            }
        }
    }
    return null;
}
/**
 * Conservatively detect requests that replay earlier conversational turns.
 * System/developer instructions plus one user message are still single-turn;
 * assistant/tool history or a second user message require multi-turn support.
 */
export function requiresCodexMultiTurnCapability(messages) {
    let userTurns = 0;
    for (const message of messages) {
        if (message.role === 'assistant' || message.role === 'tool')
            return true;
        if (message.role === 'user' && ++userTurns >= 2)
            return true;
    }
    return false;
}
export function routeRequest(estimatedTokens = 1000, skipKeys, preferredModelDbId, requireVision = false, requireTools = false, skipModels, prefetchedChain, requireStructured = false, codexRelayProtocol = 'chat_completions', codexRelayAffinityKey, codexUpstreamPin, codexRequireCompaction = false, skipRelaySources, codexRequireStreaming = false, codexRequireMultiTurn = false, codexRelayHasUpstreamState = false) {
    const db = getDb();
    const strategy = getRoutingStrategy();
    if (strategy !== 'priority')
        refreshStatsCache(db);
    const chain = (prefetchedChain ?? getActiveChain(db))
        .filter(e => e.enabled && isBillingRouteEnabled(db, e));
    const sortedChain = orderChain(chain, strategy);
    // Sticky session / Explicit pinning: move preferred model to front of chain
    if (preferredModelDbId) {
        const idx = sortedChain.findIndex(e => e.model_db_id === preferredModelDbId);
        if (idx >= 0) {
            if (idx > 0) {
                const [preferred] = sortedChain.splice(idx, 1);
                sortedChain.unshift(preferred);
            }
        }
        else {
            // The requested model is not in the current routing chain (e.g. it's a
            // custom model or not added to the active profile). We must fulfill the
            // explicit request by injecting it at the front.
            const pinnedRow = db.prepare(`
        SELECT m.id as model_db_id, 0 as priority, 1 as enabled,
               m.platform, m.model_id, m.upstream_model_id, m.display_name, m.intelligence_rank,
               m.size_label, m.monthly_token_budget,
               m.rpm_limit, m.rpd_limit, m.tpm_limit, m.tpd_limit, m.supports_vision,
               m.supports_tools, m.context_window, m.key_id
        FROM models m
        WHERE m.id = ? AND m.enabled = 1
      `).get(preferredModelDbId);
            if (pinnedRow && isBillingRouteEnabled(db, pinnedRow)) {
                sortedChain.unshift(pinnedRow);
            }
        }
    }
    // Per-model disposition, attached to the exhaustion error when the loop falls
    // through with no route — the only record of WHY the pool was empty on the
    // synchronous "all exhausted" path (nothing downstream logs it). See issue _1.
    const diag = [];
    for (const entry of sortedChain) {
        const label = `${entry.platform}/${entry.model_id}`;
        // Models the caller has ruled out for this request — e.g. a 404
        // "model removed upstream" already seen this request: trying the same
        // model again on a different key would just burn another attempt on the
        // same dead route (PR #111, credits @barbotkonv).
        if (skipModels?.has(entry.model_db_id)) {
            diag.push(`${label}: ruled out earlier this request`);
            continue;
        }
        // Ordinary providers honor the catalog's vision declaration. Codex-pool
        // Relay declarations are diagnostic only, so runtime fallback decides
        // whether the enabled upstream accepts the image.
        const pureRelayVisionAttempt = entry.platform === 'openai-codex'
            && getClientContext().consumerApiKeyType === 'codex_pool';
        if (requireVision && !entry.supports_vision && !pureRelayVisionAttempt) {
            diag.push(`${label}: no vision support`);
            continue;
        }
        // Tool-bearing requests skip models that can't emit structured tool_calls.
        // A model that "answers" a tool request with the call serialized as text
        // looks successful at the transport level while the client's harness sees
        // nothing — worse than a failover. Applies to sticky models too, same
        // reasoning as vision above.
        if (requireTools && !entry.supports_tools && entry.platform !== 'openai-codex') {
            diag.push(`${label}: no tool-calling support`);
            continue;
        }
        // Structured-output routing (#514 follow-up): when the request carries a
        // response_format, skip platforms whose param policy can't even receive it
        // (the param would be dropped before send, so the model would answer in
        // prose and burn a failover hop). Platform-level fast path — model-level
        // capability isn't in the catalog; models that accept the param but ignore
        // it are caught by the non-stream JSON enforcement downstream.
        if (requireStructured && platformDropsResponseFormat(entry.platform)) {
            diag.push(`${label}: platform drops response_format`);
            continue;
        }
        // Context-aware routing: skip a model whose context window can't hold the
        // request, so a large prompt never selects a small-context model and burns
        // a failover hop on a 413 "request too large" (#167). Only enforced when we
        // know the model's window; estimatedTokens is the INPUT estimate plus a
        // CAPPED output reserve (routingReserveTokens, #470), so a huge client-set
        // max_tokens no longer excludes the model — the input must fit, not
        // input+full max_tokens. A 413 that slips through is still retryable
        // downstream, and the failed model is put on cooldown — so this is a
        // fast-path, not the only guard. If every model is too small, the loop falls
        // through and the caller gets the normal "all models exhausted" error rather
        // than a wasted sweep.
        if (entry.context_window != null && estimatedTokens > entry.context_window) {
            diag.push(`${label}: context ${entry.context_window} < estimated ${estimatedTokens}`);
            continue;
        }
        // Same guard for a model with a small per-minute token budget: a request
        // whose input alone exceeds tpm_limit can never fit one minute of quota and
        // returns a guaranteed 413 (e.g. Groq gpt-oss-120b: 131k context but 8k TPM).
        // estimatedTokens carries the same capped output reserve, mirroring the
        // check above (#470).
        if (entry.tpm_limit != null && estimatedTokens > entry.tpm_limit) {
            diag.push(`${label}: tpm_limit ${entry.tpm_limit} < estimated ${estimatedTokens}`);
            continue;
        }
        // Key selection + accounting pre-checks for this one model. Returns the
        // first usable key's RouteResult, or null when the model has no key that
        // can serve right now — in which case we fall through to the next model in
        // the sorted chain for THIS request (no explicit penalty needed).
        const route = selectKeyForModel(entry, estimatedTokens, skipKeys, diag, {
            requireVision,
            requireTools,
            skipRelaySources,
            codexRelayProtocol,
            codexRelayAffinityKey,
            codexUpstreamPin,
            codexRequireCompaction,
            codexRequireStreaming,
            codexRequireMultiTurn,
            codexRelayHasUpstreamState,
        });
        if (route)
            return route;
    }
    throw new RouteError(summarizeExhaustion(diag, getSoonestCooldownExpiry()), 429, diag);
}
export function getRoutingScores(userId) {
    const db = getDb();
    const strategy = getRoutingStrategy(userId);
    refreshStatsCache(db);
    const chain = getActiveChain(db);
    // For display we score under 'balanced' weights when in priority mode, so the
    // table still shows a meaningful ranking even with the bandit turned off.
    const weights = weightsFor(strategy, userId) ?? BANDIT_PRESETS.balanced;
    const composites = chain.map(e => intelligenceComposite(e.size_label, e.intelligence_rank));
    const intelMin = composites.length ? Math.min(...composites) : 0;
    const intelMax = composites.length ? Math.max(...composites) : 0;
    const keyCounts = usableKeyCountsByPlatform(db);
    const scores = chain.map(entry => {
        const scored = scoreChainEntry(entry, weights, intelMin, intelMax, false, keyCounts);
        const stats = statsCache?.get(`${entry.platform}:${entry.model_id}`);
        return {
            modelDbId: entry.model_db_id,
            platform: entry.platform,
            modelId: entry.model_id,
            displayName: entry.display_name,
            enabled: entry.enabled === 1,
            reliability: scored.axes.reliability,
            speed: scored.axes.speed,
            intelligence: scored.axes.intelligence,
            headroom: scored.headroom,
            rateLimit: scored.rateLimit,
            score: scored.score,
            totalRequests: Math.round((stats?.successes ?? 0) + (stats?.failures ?? 0)),
        };
    }).sort((a, b) => b.score - a.score);
    // customWeights is always present (the saved vector, or the balanced default)
    // so the dashboard's custom-weight sliders can render even before the user
    // has saved their own — distinct from `weights`, which is null in priority
    // mode and the active preset otherwise.
    return { strategy, weights: weightsFor(strategy, userId), customWeights: getCustomWeights(userId), scores };
}
// Give ordinary traffic a clear error when no declared vision model is enabled.
// Codex-pool Relay traffic is attempted at runtime even when its diagnostic
// mapping flag is false.
export function hasEnabledVisionModel() {
    const db = getDb();
    const pureRelayVisionAttempt = getClientContext().consumerApiKeyType === 'codex_pool';
    return getActiveChain(db).some(entry => (entry.enabled === 1
        && (entry.supports_vision === 1
            || (pureRelayVisionAttempt && entry.platform === 'openai-codex'))));
}
// Whether at least one tool-capable model is enabled in the fallback chain.
// Same role as hasEnabledVisionModel: a clear up-front error for tool-bearing
// requests beats routing them to a model that mangles the tool call.
export function hasEnabledToolsModel() {
    const db = getDb();
    return getActiveChain(db).some(entry => (entry.enabled === 1
        && (entry.supports_tools === 1 || entry.platform === 'openai-codex')));
}
//# sourceMappingURL=router.js.map