type CodexAuthPayload = {
    tokens?: {
        access_token?: unknown;
        refresh_token?: unknown;
        account_id?: unknown;
    };
};
export declare function importCodexAuthPayload(auth: CodexAuthPayload): Promise<{
    account_id: string | null;
    access_token_encrypted: string;
    access_token_iv: string;
    access_token_auth_tag: string;
    refresh_token_encrypted: string;
    refresh_token_iv: string;
    refresh_token_auth_tag: string;
    model_ids: string[];
    model_discovery_error: string | null;
}>;
export declare function importLocalCodexAuth(): Promise<{
    account_id: string | null;
    access_token_encrypted: string;
    access_token_iv: string;
    access_token_auth_tag: string;
    refresh_token_encrypted: string;
    refresh_token_iv: string;
    refresh_token_auth_tag: string;
    model_ids: string[];
    model_discovery_error: string | null;
}>;
export {};
//# sourceMappingURL=codex-import.d.ts.map