import type { Db } from '../db/types.js';
export interface ResourceOrderRow {
    id: number;
    orderNo: string;
    userId: number;
    productId: number;
    subpoolId: number | null;
    productKey: string;
    productVersion: number;
    productName: string;
    priceMicro: number;
    memberLimit: number;
    durationValue: number;
    durationUnit: 'day' | 'month';
    totalQuotaUnits: number;
    memberQuotaUnits: number;
    orderStatus: string;
    refundableUntil: string | null;
}
export declare function getResourceOrder(db: Db, orderId: number): ResourceOrderRow | null;
export declare function createResourceOrder(db: Db, userId: number, productId: number): ResourceOrderRow;
export declare function linkResourceOrderToSubpoolMember(db: Db, input: {
    orderId: number;
    subpoolId: number;
    memberId: number;
}): ResourceOrderRow;
//# sourceMappingURL=resource-orders.d.ts.map