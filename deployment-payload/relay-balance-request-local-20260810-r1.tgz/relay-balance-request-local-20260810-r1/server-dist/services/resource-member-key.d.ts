import type { Db } from '../db/types.js';
/** Attach one unused, active Codex key to an existing resource member. */
export declare function bindAvailableCodexPoolKey(db: Db, memberId: number, userId: number): number | null;
/** Bind every new Codex resource key to the user's best current entitlement. */
export declare function bindNewCodexPoolKey(db: Db, userId: number, keyId: number): number | null;
//# sourceMappingURL=resource-member-key.d.ts.map