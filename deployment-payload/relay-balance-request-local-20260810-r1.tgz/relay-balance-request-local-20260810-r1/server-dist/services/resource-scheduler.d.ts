import type { Db } from '../db/types.js';
export declare class ResourceDispatchError extends Error {
    readonly code: 'resource_binding_unavailable' | 'scheduled_not_enabled';
    constructor(code: 'resource_binding_unavailable' | 'scheduled_not_enabled', message: string);
}
export declare function selectCodexExecution(db: Db, input: {
    subpoolId: number;
    reservationId: number;
    correlationId: string;
    modelId?: string;
    skipAccountIds?: Set<number>;
}): {
    dispatchId: number;
    accountId: number;
    modelId: string;
};
export declare function finalizeResourceDispatch(db: Db, dispatchId: number, succeeded: boolean, error?: string | null): void;
//# sourceMappingURL=resource-scheduler.d.ts.map