export const CODEX_RELAY_LEDGER_CURRENCIES = ['USD', 'CNY'];
export const MAX_CODEX_RELAY_LEDGER_AMOUNT = 1_000_000;
export const MAX_CODEX_RELAY_LEDGER_AMOUNT_MICRO = MAX_CODEX_RELAY_LEDGER_AMOUNT * 1_000_000;
export const MAX_CODEX_RELAY_LEDGER_NOTE_LENGTH = 500;
function sourceExists(db, sourceId) {
    return Boolean(db.prepare('SELECT 1 FROM codex_relay_sources WHERE id = ?').get(sourceId));
}
function mapLedgerRow(row) {
    return {
        id: Number(row.id),
        sourceId: Number(row.source_id),
        amountMicro: Number(row.amount_micro),
        currency: row.currency,
        note: row.note,
        occurredAt: row.occurred_at,
        createdAt: row.created_at,
        createdByUserId: row.created_by_user_id == null
            ? null
            : Number(row.created_by_user_id),
    };
}
/**
 * Convert a JSON decimal amount to exact integer micro-units. Numeric and
 * string inputs are accepted, but rounding is never performed: more than six
 * fractional digits, exponent notation, unsafe values, zero, and values above
 * the per-entry ceiling are rejected.
 */
export function decimalRelayLedgerAmountToMicro(value) {
    if (typeof value !== 'number' && typeof value !== 'string')
        return null;
    if (typeof value === 'number' && (!Number.isFinite(value) || value <= 0))
        return null;
    const raw = String(value).trim();
    const match = /^(0|[1-9]\d*)(?:\.(\d{1,6}))?$/.exec(raw);
    if (!match)
        return null;
    const whole = BigInt(match[1]);
    const fractional = BigInt((match[2] ?? '').padEnd(6, '0') || '0');
    const micro = whole * 1000000n + fractional;
    if (micro <= 0n || micro > BigInt(MAX_CODEX_RELAY_LEDGER_AMOUNT_MICRO))
        return null;
    const numeric = Number(micro);
    return Number.isSafeInteger(numeric) ? numeric : null;
}
export function listCodexRelayRechargeLedger(db, sourceId) {
    if (!sourceExists(db, sourceId))
        return null;
    const rows = db.prepare(`
    SELECT id, source_id, amount_micro, currency, note, occurred_at,
           created_at, created_by_user_id
    FROM codex_relay_recharge_ledger_entries
    WHERE source_id = ?
    ORDER BY datetime(occurred_at) DESC, id DESC
  `).all(sourceId);
    const totals = {
        USD: { amountMicro: 0 },
        CNY: { amountMicro: 0 },
    };
    const entries = rows.map(mapLedgerRow);
    for (const entry of entries)
        totals[entry.currency].amountMicro += entry.amountMicro;
    return { sourceId, entries, totals };
}
export function createCodexRelayRechargeLedgerEntry(db, input) {
    if (!sourceExists(db, input.sourceId))
        return null;
    if (!Number.isSafeInteger(input.amountMicro)
        || input.amountMicro <= 0
        || input.amountMicro > MAX_CODEX_RELAY_LEDGER_AMOUNT_MICRO)
        throw new Error('Invalid Relay recharge ledger amount');
    if (!CODEX_RELAY_LEDGER_CURRENCIES.includes(input.currency)) {
        throw new Error('Invalid Relay recharge ledger currency');
    }
    const note = input.note?.trim() || null;
    if (note && note.length > MAX_CODEX_RELAY_LEDGER_NOTE_LENGTH) {
        throw new Error('Relay recharge ledger note is too long');
    }
    const occurredAtMs = Date.parse(input.occurredAt);
    if (!Number.isFinite(occurredAtMs))
        throw new Error('Invalid Relay recharge occurrence time');
    if (occurredAtMs > Date.now()) {
        throw new Error('Relay recharge occurrence time cannot be in the future');
    }
    const result = db.prepare(`
    INSERT INTO codex_relay_recharge_ledger_entries (
      source_id, amount_micro, currency, note, occurred_at, created_by_user_id
    ) VALUES (?, ?, ?, ?, ?, ?)
  `).run(input.sourceId, input.amountMicro, input.currency, note, new Date(occurredAtMs).toISOString(), input.createdByUserId ?? null);
    const row = db.prepare(`
    SELECT id, source_id, amount_micro, currency, note, occurred_at,
           created_at, created_by_user_id
    FROM codex_relay_recharge_ledger_entries
    WHERE id = ?
  `).get(result.lastInsertRowid);
    return mapLedgerRow(row);
}
export function deleteCodexRelayRechargeLedgerEntry(db, sourceId, entryId) {
    if (!sourceExists(db, sourceId))
        return 'source_not_found';
    const result = db.prepare(`
    DELETE FROM codex_relay_recharge_ledger_entries
    WHERE id = ? AND source_id = ?
  `).run(entryId, sourceId);
    return result.changes === 1 ? 'deleted' : 'entry_not_found';
}
//# sourceMappingURL=codex-relay-recharge-ledger.js.map