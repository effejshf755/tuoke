import type { Db } from '../db/types.js';
import type { Scheduler } from '../lib/scheduler.js';
export interface CodexOAuthAccount {
    id: number;
    label: string;
    account_id: string | null;
    enabled: number;
    status: string;
    last_used_at: string | null;
    last_error: string | null;
    models: string[];
    quota_used_percent: number | null;
    quota_remaining_percent: number | null;
    quota_reset_at: string | null;
    quota_synced_at: string | null;
    plan_type: string | null;
    resource_scope: 'codex_pool' | 'resource_subpool';
    codex_group_id: number | null;
    codex_group_name: string | null;
}
export declare function listCodexAccounts(db: Db): CodexOAuthAccount[];
export declare function createCodexAccount(db: Db, data: {
    label: string;
    account_id?: string;
    access_token_encrypted: string;
    access_token_iv: string;
    access_token_auth_tag: string;
    refresh_token_encrypted: string;
    refresh_token_iv: string;
    refresh_token_auth_tag: string;
    token_expires_at?: string;
}): number;
export declare function setCodexAccountScope(db: Db, id: number, scope: 'codex_pool' | 'resource_subpool'): boolean;
export declare function setCodexAccountGroup(db: Db, id: number, groupId: number): boolean;
export declare function deleteCodexAccount(db: Db, id: number): boolean;
export declare function setCodexAccountEnabled(db: Db, id: number, enabled: boolean): boolean;
export declare function checkCodexAccountHealth(db: Db, id: number): Promise<CodexOAuthAccount>;
export declare function syncEnabledCodexAccountQuotas(db: Db, check?: (db: Db, id: number) => Promise<unknown>): Promise<number>;
export declare function startCodexAccountQuotaSync(scheduler: Scheduler): void;
//# sourceMappingURL=codex-oauth.d.ts.map