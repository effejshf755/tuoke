/**
 * 发送注册验证码
 */
export declare function sendRegistrationCode(to: string, code: string): Promise<void>;
/**
 * 发送找回密码验证码
 */
export declare function sendPasswordResetCode(to: string, code: string): Promise<void>;
//# sourceMappingURL=mailer.d.ts.map