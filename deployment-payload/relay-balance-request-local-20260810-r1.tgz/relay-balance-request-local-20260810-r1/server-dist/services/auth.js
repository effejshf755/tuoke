import crypto from 'crypto';
import { getDb } from '../db/index.js';
import { hashPassword, verifyPassword } from '../lib/password.js';
// Dashboard authentication: email + password accounts with opaque session
// tokens. Distinct from the unified API key, which authenticates the /v1 proxy
// for apps — this gates the /api/* admin surface for the human operator (#35).
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000; // 30 days
const DEFAULT_USER_BILLING_MULTIPLIER_MILLI = 1000;
const DEFAULT_ADMIN_BILLING_MULTIPLIER_MILLI = 1000;
function sha256(s) {
    return crypto.createHash('sha256').update(s).digest('hex');
}
function normalizeEmail(email) {
    return email.trim().toLowerCase();
}
export function userCount() {
    const row = getDb().prepare('SELECT COUNT(*) AS c FROM users').get();
    return row.c;
}
/** Create a user. Throws { code: 'email_taken' } if the email already exists. */
export function createUser(email, password) {
    const db = getDb();
    const normalized = normalizeEmail(email);
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(normalized);
    if (existing) {
        const err = new Error('An account with that email already exists');
        err.code = 'email_taken';
        throw err;
    }
    const role = userCount() === 0 ? 'admin' : 'user';
    const billingMultiplierMilli = role === 'user'
        ? DEFAULT_USER_BILLING_MULTIPLIER_MILLI
        : DEFAULT_ADMIN_BILLING_MULTIPLIER_MILLI;
    const create = db.transaction(() => {
        const result = db.prepare(`
      INSERT INTO users (email, password_hash, role, billing_multiplier_milli)
      VALUES (?, ?, ?, ?)
    `).run(normalized, hashPassword(password), role, billingMultiplierMilli);
        const setting = db.prepare("SELECT value FROM settings WHERE key = 'new_user_bonus_micro'").get();
        const bonus = Number(setting?.value ?? 0);
        if (role === 'user' && bonus > 0) {
            const updated = db.prepare('UPDATE users SET balance_micro = balance_micro + ? WHERE id = ?').run(bonus, result.lastInsertRowid);
            if (updated.changes !== 1)
                throw new Error('Failed to grant registration bonus');
            db.prepare("INSERT INTO wallet_transactions (user_id, type, delta_micro, balance_after_micro, note) VALUES (?, 'bonus', ?, ?, 'New user registration bonus')").run(result.lastInsertRowid, bonus, bonus);
        }
        return Number(result.lastInsertRowid);
    });
    const userId = create();
    return { userId, email: normalized, role };
}
/** Verify credentials. Returns the user on success, null on failure. */
export function verifyCredentials(email, password) {
    const db = getDb();
    const row = db.prepare("SELECT id, email, password_hash, role, status FROM users WHERE email = ? AND status = 'active'")
        .get(normalizeEmail(email));
    if (!row)
        return null;
    if (!verifyPassword(password, row.password_hash))
        return null;
    return { userId: row.id, email: row.email, role: row.role };
}
/** Mint a session and return the raw token (only the hash is persisted). */
export function createSession(userId) {
    const token = crypto.randomBytes(32).toString('hex');
    getDb().prepare('INSERT INTO sessions (token_hash, user_id, expires_at_ms) VALUES (?, ?, ?)')
        .run(sha256(token), userId, Date.now() + SESSION_TTL_MS);
    return token;
}
/** Resolve a session token to its user, or null if missing/expired. */
export function validateSession(token) {
    if (!token)
        return null;
    const db = getDb();
    const row = db.prepare(`
    SELECT s.user_id, s.expires_at_ms, u.email, u.role, u.status
    FROM sessions s JOIN users u ON u.id = s.user_id
    WHERE s.token_hash = ?
  `).get(sha256(token));
    if (!row)
        return null;
    if (row.status === 'disabled')
        return null;
    if (row.expires_at_ms < Date.now()) {
        db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
        return null;
    }
    return { userId: row.user_id, email: row.email, role: row.role };
}
export function deleteSession(token) {
    if (!token)
        return;
    getDb().prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(token));
}
//# sourceMappingURL=auth.js.map