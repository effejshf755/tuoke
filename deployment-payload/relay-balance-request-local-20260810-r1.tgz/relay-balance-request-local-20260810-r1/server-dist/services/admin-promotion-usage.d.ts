import type { Db } from '../db/types.js';
export type AdminSprintStatus = 'active' | 'exhausted' | 'expired' | 'expired_settling' | 'revoked' | 'refunded' | 'reversed' | 'missing';
export interface AdminSprintUserSummary {
    user_id: number;
    email: string;
    purchase_count: number;
    active_count: number;
    granted_micro: number;
    used_micro: number;
    remaining_micro: number;
    reserved_micro: number;
    total_input_tokens: number;
    total_output_tokens: number;
    available_micro: number;
    forfeited_micro: number;
    next_expires_at: string | null;
    last_purchased_at: string;
}
export interface AdminSprintPurchaseItem {
    purchase_id: number;
    purchase_no: string;
    price_micro: number;
    granted_micro: number;
    used_micro: number;
    remaining_micro: number;
    reserved_micro: number;
    available_micro: number;
    forfeited_micro: number;
    purchase_status: 'paid' | 'refunded' | 'reversed';
    credit_status: string | null;
    status: AdminSprintStatus;
    purchased_at: string;
    expires_at: string | null;
}
export declare class AdminSprintMutationError extends Error {
    readonly code: 'not_found' | 'in_flight' | 'nothing_to_extend';
    constructor(code: 'not_found' | 'in_flight' | 'nothing_to_extend', message: string);
}
export declare function listAdminSprintUsers(db: Db, input: {
    q: string;
    page: number;
    limit: number;
}): {
    users: AdminSprintUserSummary[];
    pagination: {
        page: number;
        limit: number;
        total: number;
        total_pages: number;
    };
};
export declare function listAdminSprintPurchases(db: Db, input: {
    userId: number;
    limit: number;
    beforeId?: number;
}): {
    user: {
        id: number;
        email: string;
    } | null;
    items: AdminSprintPurchaseItem[];
    next_before_id: number | null;
    has_more: boolean;
};
export declare function extendAdminSprintUserCredits(db: Db, input: {
    userId: number;
    hours: number;
}): {
    extended_count: number;
    extended_seconds: number;
    next_expires_at: string | null;
};
export declare function revokeAdminSprintPurchase(db: Db, input: {
    userId: number;
    purchaseId: number;
    adminUserId: number;
}): {
    purchase_id: number;
    revoked: true;
    already_deleted: boolean;
};
//# sourceMappingURL=admin-promotion-usage.d.ts.map