import type { Db } from '../db/types.js';
import type { Scheduler } from '../lib/scheduler.js';
export interface ResourceMaintenanceResult {
    releasedReservations: number;
    resetPeriods: number;
    refundedOrders: number;
    expiredSubpools: number;
}
export declare function releaseExpiredResourceReservations(db: Db): number;
export declare function resetDueResourceQuotaPeriods(db: Db): number;
export declare function refundTimedOutResourceGroups(db: Db): number;
export declare function expireEndedResourceSubpools(db: Db): number;
export declare function runResourceMaintenance(db: Db): ResourceMaintenanceResult;
export declare function startResourceMaintenance(scheduler: Scheduler): void;
//# sourceMappingURL=resource-maintenance.d.ts.map