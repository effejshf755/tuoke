/**
 * 生成找回密码验证码。
 *
 * 返回：
 * - string：邮箱存在，需要发送该验证码
 * - null：邮箱不存在
 *
 * 路由层不要把“邮箱是否存在”告诉客户端，
 * 防止别人通过接口批量查询注册用户。
 */
export declare function createPasswordResetCode(email: string): string | null;
/**
 * 验证验证码并修改密码。
 *
 * 成功后：
 * 1. 验证码立即失效
 * 2. 修改密码
 * 3. 删除该用户所有旧 Session
 *
 * 返回：
 * true  = 修改成功
 * false = 验证码错误、过期、已使用或尝试次数过多
 */
export declare function resetPasswordWithCode(email: string, code: string, newPassword: string): boolean;
//# sourceMappingURL=password-reset.d.ts.map