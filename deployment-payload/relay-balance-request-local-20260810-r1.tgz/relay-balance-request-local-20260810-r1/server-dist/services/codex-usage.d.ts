import type { Db } from '../db/types.js';
export interface CodexUsageResult {
    accountDbId: number;
    modelId: string;
    success: boolean;
    inputTokens?: number;
    cachedInputTokens?: number;
    cacheWriteTokens?: number;
    outputTokens?: number;
    error?: string | null;
    authenticationFailure?: boolean;
    quotaExhausted?: boolean;
}
interface CodexUsageTokens {
    inputTokens: number;
    cachedInputTokens: number;
    cacheWriteTokens: number;
    outputTokens: number;
}
/**
 * Record the provider-side Codex attempt before the generic request logger
 * runs. The row id is stored in AsyncLocalStorage so the request, wallet
 * settlement and OAuth account can be linked without exposing OAuth tokens.
 */
export declare function recordCodexUsage(result: CodexUsageResult): number;
/** Use upstream-reported token counts for Codex billing and request logs. */
export declare function getCodexUsageTokens(db: Db, recordId: number): CodexUsageTokens | null;
/**
 * Copy the generic wallet settlement result and the exact price snapshot onto
 * the Codex ledger. This does not charge again; it only links both ledgers.
 */
export declare function finalizeCodexUsageRecord(db: Db, recordId: number, requestId: number): void;
export declare function getCodexUsageStats(): {
    summary: {
        billed_micro: number;
    };
    accounts: unknown[];
    models: unknown[];
    relaySources: import("./codex-relay-maintenance.js").CodexRelaySourceOperationalStats[];
    errors: unknown[];
    recent: unknown[];
};
export {};
//# sourceMappingURL=codex-usage.d.ts.map