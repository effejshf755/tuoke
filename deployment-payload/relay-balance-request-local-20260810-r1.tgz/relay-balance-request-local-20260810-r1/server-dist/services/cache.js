// Opt-in exact-match response cache.
//
// A free-tier-stacking proxy lives or dies by how far it stretches scarce
// quota. Re-asking a model the *same* prompt burns a free-tier slot for an
// answer we already have, which is pure waste. This cache stores successful
// completions keyed by a canonical hash of the request and serves an identical
// later request straight from memory, without touching any provider: zero quota
// cost, near-zero latency, and one fewer 429 on the way to the daily reset.
//
// Design choices that keep it SAFE:
//   - Exact match only. No embeddings / fuzzy matching, so a near-miss can never
//     return a different prompt's answer. The key is a SHA-256 over the
//     canonicalized request, so a single token of difference is a miss.
//   - The key is the REQUEST plus its upstream-policy namespace, not the
//     concrete route. Any model allowed inside that same policy boundary may
//     satisfy an identical prompt, while operator, free, Codex-group, and
//     resource-subpool traffic can never collide. platform/model_id/key_id are
//     stored for attribution and savings accounting only.
//   - Opt-in. Off unless enabled via the RESPONSE_CACHE env var or the
//     response_cache_enabled setting, so existing installs see no behavior
//     change. A per-request header overrides either way.
//   - Temperature-gated. High-temperature requests are asking for variety, so
//     replaying one frozen answer would defeat that. Cached only when the
//     temperature is omitted or at/below RESPONSE_CACHE_MAX_TEMPERATURE.
//   - In-memory and bounded. Entries live in a size-capped LRU map (oldest use
//     evicted first), so the cache can never grow without bound and a restart
//     simply flushes it. No schema, no migration, no persisted response blobs.
//   - Fail-safe reads. The settings lookup that decides the master switch is
//     wrapped, so a not-yet-initialized DB disables the cache rather than
//     throwing in the proxy hot path (mirrors services/ratelimit.ts).
import crypto from 'crypto';
import { getDb, getSetting } from '../db/index.js';
import { getClientContext } from '../lib/client-context.js';
import { getCodexConsumerCallableModelIds, normalizeCodexModelId, } from './model-listing.js';
// ── Config (read on each call so tests and the dashboard can toggle live) ──
function envFlag(name, fallback) {
    const raw = process.env[name];
    if (raw === undefined || raw.trim() === '')
        return fallback;
    return /^(1|true|on|yes)$/i.test(raw.trim());
}
function envNum(name, fallback) {
    const raw = process.env[name];
    if (raw === undefined || raw.trim() === '')
        return fallback;
    const n = Number(raw);
    return Number.isFinite(n) && n >= 0 ? n : fallback;
}
// DB-absent-safe settings read: a not-yet-initialized DB (or any read error)
// must not throw on the proxy hot path, so it degrades to "no setting stored".
function readSetting(key) {
    try {
        return getSetting(key);
    }
    catch {
        return undefined;
    }
}
// Setting key that lets the dashboard toggle the cache at runtime, no restart.
export const CACHE_ENABLED_SETTING = 'response_cache_enabled';
/**
 * Master switch. Default off so adopting the cache is an explicit choice. The
 * settings-table value wins when present (dashboard toggle, no restart), then
 * the RESPONSE_CACHE env var, then off.
 */
export function isCacheEnabled() {
    const stored = readSetting(CACHE_ENABLED_SETTING);
    if (stored !== undefined && stored.trim() !== '') {
        return /^(1|true|on|yes)$/i.test(stored.trim());
    }
    return envFlag('RESPONSE_CACHE', false);
}
/** Entry lifetime. Default 1h: long enough to absorb retries and agent re-runs,
 *  short enough that a refreshed catalog or key changes answers soon after. */
export function cacheTtlMs() {
    return envNum('RESPONSE_CACHE_TTL_SECONDS', 3600) * 1000;
}
/** Above this temperature a request wants variety, so it is never cached.
 *  Default 1.0 caches everything when enabled (max quota savings); lower it to
 *  restrict caching to (near-)deterministic calls. */
export function cacheMaxTemperature() {
    return envNum('RESPONSE_CACHE_MAX_TEMPERATURE', 1.0);
}
/** Hard cap on stored entries; least-recently-used are evicted past this.
 *  Bounds memory use. */
export function cacheMaxEntries() {
    return Math.floor(envNum('RESPONSE_CACHE_MAX_ENTRIES', 5000));
}
// A request is cacheable only when its temperature is omitted (caller accepts
// the provider default and is fine with a stable answer) or at/below the cap.
export function isCacheableTemperature(temperature) {
    if (temperature === undefined || temperature === null)
        return true;
    return temperature <= cacheMaxTemperature();
}
export function parseCacheDirective(header, cacheControl) {
    const cc = (Array.isArray(cacheControl) ? cacheControl[0] : cacheControl)?.toLowerCase() ?? '';
    if (cc.includes('no-store') || cc.includes('no-cache'))
        return 'off';
    const raw = (Array.isArray(header) ? header[0] : header)?.trim().toLowerCase();
    if (!raw)
        return 'default';
    if (/^(off|no|0|false|bypass|skip)$/.test(raw))
        return 'off';
    if (/^(on|yes|1|true|force)$/.test(raw))
        return 'on';
    return 'default';
}
/** Resolve the global switch + per-request directive into a single yes/no. */
export function cacheActive(directive) {
    if (directive === 'off')
        return false;
    if (directive === 'on')
        return true;
    return isCacheEnabled();
}
function positiveInteger(value) {
    return Number.isSafeInteger(value) && value !== null && value > 0 ? value : null;
}
/**
 * Resolve the current request's authoritative cache-sharing boundary.
 *
 * `null` is fail-closed: the caller must bypass both cache lookup and store.
 * Codex group membership is read from the key row instead of inferred from the
 * requested model. Resource middleware attaches its reserved subpool before
 * the proxy handler runs, so a missing subpool also disables caching.
 */
export function resolveResponseCachePolicyNamespace(context = getClientContext()) {
    switch (context.consumerApiKeyType) {
        case null:
            return 'operator/global';
        case 'universal':
            // Dashboard/operator requests may carry a universal key identity while
            // retaining paid routing. External universal keys are marked free-only
            // by consumerQuota before this route executes.
            return context.consumerFreeOnly ? 'universal-free' : 'operator/global';
        case 'resource_subpool': {
            const subpoolId = positiveInteger(context.resourceSubpoolId);
            return subpoolId === null ? null : `resource_subpool:${subpoolId}`;
        }
        case 'codex_pool': {
            const keyId = positiveInteger(context.consumerApiKeyId);
            const contextGroupId = positiveInteger(context.consumerCodexGroupId);
            if (keyId === null || contextGroupId === null)
                return null;
            try {
                const row = getDb().prepare(`
          SELECT k.codex_group_id AS codexGroupId
          FROM consumer_api_keys k
          JOIN codex_groups g
            ON g.id = k.codex_group_id
           AND g.enabled = 1
          WHERE k.id = ?
            AND k.enabled = 1
            AND k.status = 'active'
            AND k.key_scope = 'codex_pool'
          LIMIT 1
        `).get(keyId);
                const persistedGroupId = positiveInteger(row?.codexGroupId ?? null);
                // The identity captured during authentication and the current key row
                // must agree. A reassignment during the request therefore fails closed
                // instead of reading from or writing to the wrong group's namespace.
                return persistedGroupId === contextGroupId
                    ? `codex_group:${contextGroupId}`
                    : null;
            }
            catch {
                // Missing/unmigrated DB state must never collapse a scoped request into
                // a broader namespace. Cache bypass is safer than a cross-scope hit.
                return null;
            }
        }
    }
}
function modelIsCallable(modelIds, requestedModel) {
    if (!requestedModel || requestedModel === 'auto' || requestedModel.startsWith('auto:')) {
        return modelIds.size > 0;
    }
    const normalized = normalizeCodexModelId(requestedModel);
    // `codex` is the public wildcard for the scoped pool. It remains callable
    // only while that pool has at least one concrete model-capable upstream.
    return normalized === 'codex' ? modelIds.size > 0 : modelIds.has(normalized);
}
/**
 * Revalidate a scoped caller immediately before a cache HIT is returned.
 *
 * A cache namespace prevents cross-pool sharing, but it is not an
 * authorization snapshot: administrators can disable a group, remove one of
 * its models, or release a purchased subpool binding while an entry is still
 * inside its TTL. Scoped hits therefore repeat the current lightweight
 * callability lookup used by model discovery. Any missing/migrating DB state
 * fails closed and lets the normal router produce the canonical error.
 */
export function isResponseCacheLookupAuthorized(requestedModel, context = getClientContext()) {
    if (resolveResponseCachePolicyNamespace(context) === null)
        return false;
    if (context.consumerApiKeyType !== 'codex_pool'
        && context.consumerApiKeyType !== 'resource_subpool') {
        return true;
    }
    const keyId = positiveInteger(context.consumerApiKeyId);
    if (keyId === null)
        return false;
    try {
        if (context.consumerApiKeyType === 'resource_subpool') {
            const subpoolId = positiveInteger(context.resourceSubpoolId);
            if (subpoolId === null)
                return false;
            // Keep the request-scoped subpool identity tied to the current key row.
            // The callable-model query below verifies the active OAuth binding; this
            // exact membership check prevents a reassignment from authorizing an old
            // subpool namespace during the same request.
            const currentMembership = getDb().prepare(`
        SELECT 1
        FROM consumer_api_keys consumer
        JOIN resource_member_api_keys member_key
          ON member_key.consumer_api_key_id = consumer.id
        JOIN resource_subpool_members member
          ON member.id = member_key.member_id
         AND member.status = 'active'
        JOIN resource_subpools subpool
          ON subpool.id = member.subpool_id
         AND subpool.status = 'active'
        WHERE consumer.id = ?
          AND consumer.enabled = 1
          AND consumer.status = 'active'
          AND consumer.key_scope = 'resource_subpool'
          AND subpool.id = ?
        LIMIT 1
      `).get(keyId, subpoolId);
            if (!currentMembership)
                return false;
        }
        const callableModels = getCodexConsumerCallableModelIds(context.consumerApiKeyType, keyId);
        return modelIsCallable(callableModels, requestedModel);
    }
    catch {
        return false;
    }
}
// Deterministic JSON: object keys sorted recursively and undefined dropped, so
// two requests that differ only in key order or omitted-vs-undefined fields
// hash identically. (JSON.stringify alone preserves insertion order, which
// varies between clients and would scatter otherwise-identical requests.)
function stableStringify(value) {
    if (value === null || typeof value !== 'object')
        return JSON.stringify(value) ?? 'null';
    if (Array.isArray(value))
        return `[${value.map(stableStringify).join(',')}]`;
    const obj = value;
    const parts = Object.keys(obj)
        .sort()
        .filter(k => obj[k] !== undefined)
        .map(k => `${JSON.stringify(k)}:${stableStringify(obj[k])}`);
    return `{${parts.join(',')}}`;
}
function normModel(model) {
    // Omitted and the explicit "auto" sentinel mean the same thing (let the router
    // decide), so they must share a cache bucket.
    return !model || model === 'auto' ? 'auto' : model;
}
export function computeCacheKey(input) {
    const canonical = stableStringify({
        v: 3, // v3 adds the mandatory upstream-policy security namespace
        policy_namespace: input.policyNamespace,
        model: normModel(input.model),
        messages: input.messages,
        temperature: input.temperature,
        top_p: input.top_p,
        max_tokens: input.max_tokens,
        // tools/tool_choice are part of the key so a request with a different tool
        // set never collides with (or is served) another's cached answer.
        tools: input.tools,
        tool_choice: input.tool_choice,
        // Remaining knobs (see CacheKeyInput). Absent/undefined fields are dropped
        // by stableStringify, so requests without them keep hashing identically.
        stop: input.stop,
        response_format: input.response_format,
        n: input.n,
        seed: input.seed,
        presence_penalty: input.presence_penalty,
        frequency_penalty: input.frequency_penalty,
        logit_bias: input.logit_bias,
        logprobs: input.logprobs,
        top_logprobs: input.top_logprobs,
    });
    return crypto.createHash('sha256').update(canonical).digest('hex');
}
// Insertion-ordered map used as an LRU: the first key is the least-recently
// used, the last is the most-recently used. A read or write re-inserts its key
// at the end (delete + set), so eviction from the front drops the coldest entry.
const store = new Map();
/**
 * Look up a cached completion. Returns null on a miss or when the entry has aged
 * past the TTL (expired entries are deleted lazily on read). A hit bumps the
 * entry's hit_count and moves it to most-recently-used.
 */
export function getCachedResponse(cacheKey, now = Date.now()) {
    const entry = store.get(cacheKey);
    if (!entry)
        return null;
    if (now - entry.createdAtMs > cacheTtlMs()) {
        store.delete(cacheKey);
        return null;
    }
    entry.hitCount += 1;
    entry.lastHitAtMs = now;
    // Move to most-recently-used.
    store.delete(cacheKey);
    store.set(cacheKey, entry);
    return {
        body: entry.body,
        platform: entry.platform,
        modelId: entry.modelId,
        keyId: entry.keyId,
        promptTokens: entry.promptTokens,
        completionTokens: entry.completionTokens,
    };
}
/**
 * Store a successful completion. Overwrites any existing entry for the key (a
 * re-generation refreshes the cached answer, its TTL, and its hit count).
 * Enforces the entry cap by evicting the least-recently-used entries. Best-
 * effort: an unserializable body is skipped so caching can never break a
 * request that already succeeded.
 */
export function storeCachedResponse(cacheKey, input, now = Date.now()) {
    // Reject bodies that can't be JSON-serialized; a hit must be replayable.
    try {
        JSON.stringify(input.body);
    }
    catch {
        return;
    }
    // Delete-then-set so an overwrite also refreshes recency order.
    store.delete(cacheKey);
    store.set(cacheKey, {
        body: input.body,
        platform: input.platform,
        modelId: input.modelId,
        keyId: input.keyId,
        promptTokens: input.promptTokens,
        completionTokens: input.completionTokens,
        hitCount: 0,
        createdAtMs: now,
        lastHitAtMs: null,
    });
    // Evict least-recently-used beyond the cap. The count only drifts by one per
    // insert, so at most one entry is removed per call in steady state.
    const cap = cacheMaxEntries();
    while (store.size > cap) {
        const oldest = store.keys().next().value;
        if (oldest === undefined)
            break;
        store.delete(oldest);
    }
}
/**
 * Aggregate cache stats for the dashboard. "saved" tokens are the provider
 * tokens that hits avoided spending: hit_count x the entry's token counts,
 * summed, i.e. the free-tier quota the cache gave back.
 */
export function getCacheStats() {
    let totalHits = 0;
    let savedPromptTokens = 0;
    let savedCompletionTokens = 0;
    for (const entry of store.values()) {
        totalHits += entry.hitCount;
        savedPromptTokens += entry.hitCount * entry.promptTokens;
        savedCompletionTokens += entry.hitCount * entry.completionTokens;
    }
    return { entries: store.size, totalHits, savedPromptTokens, savedCompletionTokens };
}
/** Drop every cached entry. Returns the number removed. */
export function clearCache() {
    const removed = store.size;
    store.clear();
    return removed;
}
//# sourceMappingURL=cache.js.map