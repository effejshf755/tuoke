import type { ChatMessage, ChatCompletionResponse, ChatCompletionChunk, ChatToolDefinition, ChatToolChoice, Platform } from '@freellmapi/shared/types.js';
import type { QuotaObservationContext } from '../services/provider-quota.js';
import type { ExtendedSamplingOptions } from '../lib/sampling-params.js';
/** A provider HTTP error carrying the upstream status and, when the response
 *  included a Retry-After header, the parsed delay so the router can bench the
 *  key for at least that long. */
export interface ProviderHttpError extends Error {
    status?: number;
    retryAfterMs?: number;
    upstreamCode?: string;
    upstreamType?: string;
}
export declare const UPSTREAM_HEADER_TIMEOUT_CODE = "upstream_header_timeout";
export declare const UPSTREAM_CALLER_ABORT_CODE = "upstream_caller_abort";
/** Parse an HTTP `Retry-After` header (delta-seconds or an HTTP-date) into a
 *  millisecond delay. Returns undefined when absent or unparseable. */
export declare function parseRetryAfterMs(value: string | null | undefined): number | undefined;
/** Build an error for a non-OK upstream response, capturing the status and any
 *  Retry-After hint. Used by every provider adapter so the proxy can honor a
 *  provider's explicit back-off when it sets the cooldown. */
export declare function providerHttpError(res: Response, message: string, metadata?: {
    code?: unknown;
    type?: unknown;
}): ProviderHttpError;
export interface CompletionOptions extends ExtendedSamplingOptions {
    model?: string;
    temperature?: number;
    max_tokens?: number;
    top_p?: number;
    stop?: string | string[];
    tools?: ChatToolDefinition[];
    tool_choice?: ChatToolChoice;
    parallel_tool_calls?: boolean;
    /** Internal copy of Chat Completions stream_options.include_usage. Provider
     * adapters may use it to emit a final usage-only chunk; it is never sent as
     * a standalone upstream parameter. */
    includeUsage?: boolean;
    /** GPT-5.6 prompt-cache controls. Provider adapters must capability-gate
     * these fields because older models reject them. */
    prompt_cache_key?: string;
    prompt_cache_options?: {
        mode?: 'implicit' | 'explicit';
        ttl?: '30m';
    };
    /** Internal tenant namespace used to hash prompt_cache_key safely. */
    promptCacheNamespace?: string;
    /** Internal stable session identity used when the client omitted a key. */
    promptCacheSessionId?: string;
    /** Internal opt-in for gateway-generated per-user-turn cache breakpoints. */
    autoPromptCacheBreakpoints?: boolean;
    /** Internal capability asserted only after a third-party Responses mapping
     * passes the gateway's explicit prompt-cache certification. This must never
     * be enabled for the ChatGPT OAuth backend, which rejects the public cache
     * options/breakpoint fields. */
    forceExplicitPromptCache?: boolean;
    /** Internal opt-out used by an uncertified third-party Responses relay. It
     * prevents gateway-generated cache fields while leaving the request usable. */
    disablePromptCache?: boolean;
    /** Internal marker for a public Responses relay. Public-only parameters such
     * as max_output_tokens are independent from prompt-cache certification. */
    publicResponsesRelay?: boolean;
    /** Per-call HTTP timeout override. Not part of the OpenAI wire format (it is
     * stripped before the request body is built); used by the probe script so
     * NVIDIA's 15-60s serverless cold starts don't read as failures. */
    timeoutMs?: number;
}
export declare abstract class BaseProvider {
    abstract readonly platform: Platform;
    abstract readonly name: string;
    /** Providers whose free tier needs no API key (e.g. Kilo's anonymous gateway).
     * When true, the gateway stores a sentinel key row so routing still considers
     * the platform "configured", and the provider omits the Authorization header
     * on outgoing requests. Defaults to false; set by subclasses. */
    keyless: boolean;
    abstract chatCompletion(apiKey: string, messages: ChatMessage[], modelId: string, options?: CompletionOptions, quotaContext?: QuotaObservationContext): Promise<ChatCompletionResponse>;
    abstract streamChatCompletion(apiKey: string, messages: ChatMessage[], modelId: string, options?: CompletionOptions, quotaContext?: QuotaObservationContext): AsyncGenerator<ChatCompletionChunk>;
    abstract validateKey(apiKey: string, quotaContext?: QuotaObservationContext): Promise<boolean>;
    protected fetchWithTimeout(url: string, init: RequestInit, timeoutMs?: number): Promise<Response>;
    protected makeId(): string;
    /**
     * Shared SSE reader for OpenAI-wire streaming endpoints (#231 audit).
     *
     * Hardened against the upstream failure modes observed live:
     *  - Inactivity timeout: fetchWithTimeout's abort timer dies the moment
     *    response HEADERS arrive, so a provider that stalls mid-body used to
     *    hang the client forever. Each read now has its own deadline.
     *  - Abrupt EOF: a stream that ends without `[DONE]` AND without any
     *    `finish_reason` is a truncated generation, not a completion. It used
     *    to end the generator silently (truncation logged as success); it now
     *    throws a retryable error so the proxy can fail over or report it.
     *    Providers that skip `[DONE]` but do send a terminal finish_reason
     *    (several compat shims) still complete normally.
     *
     * Malformed data lines are skipped, matching previous behavior.
     */
    protected readSseStream(res: Response, inactivityTimeoutMs?: number): AsyncGenerator<ChatCompletionChunk>;
}
//# sourceMappingURL=base.d.ts.map