import { requiresExplicitPromptCache } from '../lib/codex-prompt-cache.js';
import type { ChatMessage, ChatCompletionResponse, ChatCompletionChunk, TokenUsage } from '@freellmapi/shared/types.js';
import { BaseProvider, type CompletionOptions } from './base.js';
export declare function codexCachedInputTokens(usage: any): number;
export declare function codexCacheWriteTokens(usage: any): number | undefined;
export declare function codexChatTokenUsage(usage: any, fallbackInputTokens: number, fallbackOutputTokens: number): TokenUsage;
type PromptCacheBreakpoint = {
    mode: 'explicit';
};
type CodexInputContentPart = {
    type: 'input_text';
    text: string;
    prompt_cache_breakpoint?: PromptCacheBreakpoint;
} | {
    type: 'output_text';
    text: string;
} | {
    type: 'input_image';
    image_url: string;
    detail?: string;
    prompt_cache_breakpoint?: PromptCacheBreakpoint;
};
type CodexResponsesInputItem = {
    role: 'system' | 'user' | 'assistant';
    content: string | CodexInputContentPart[];
} | {
    type: 'function_call';
    call_id: string;
    name: string;
    arguments: string;
} | {
    type: 'function_call_output';
    call_id: string;
    output: string;
};
interface CodexInputTransformOptions {
    preservePromptCacheBreakpoints?: boolean;
    autoPromptCacheBreakpoints?: boolean;
}
/** Backward-compatible export retained for existing callers/tests. The
 * implementation now covers the actual "5.6 and newer" requirement. */
export declare const isGpt56Model: typeof requiresExplicitPromptCache;
export declare function codexPromptCacheKey(messages: ChatMessage[], modelId: string, options?: CompletionOptions): string;
/**
 * Translate OpenAI Chat Completions history into Responses API input items.
 * Assistant tool-call turns legitimately use content=null, but the Codex
 * Responses endpoint rejects null content and expects tool calls/results as
 * dedicated function_call and function_call_output items.
 */
export declare function toCodexResponsesInput(messages: ChatMessage[], options?: CodexInputTransformOptions): CodexResponsesInputItem[];
export declare function toCodexResponsesBody(messages: ChatMessage[], modelId: string, options?: CompletionOptions): Record<string, unknown>;
export declare function toNativeCodexResponsesBody(requestBody: Record<string, unknown>, modelId: string): Record<string, unknown>;
export declare function codexOutputText(response: any): string;
export interface OpenAICodexProviderOptions {
    /** When present, Chat Completions are bridged directly to this
     * public /v1/responses relay instead of selecting a ChatGPT OAuth account. */
    relayBaseUrl?: string;
    /** Enables gateway-generated explicit cache fields after an optional
     * compatibility probe. It never controls whether the relay is callable. */
    relayPromptCacheCertified?: boolean;
}
export declare class OpenAICodexProvider extends BaseProvider {
    platform: any;
    name: string;
    private readonly relayBaseUrl;
    private readonly relayPromptCacheCertified;
    constructor(options?: OpenAICodexProviderOptions);
    /**
     * Forward a Codex Desktop Responses request without translating it through
     * Chat Completions. The caller owns relaying/parsing the returned SSE body.
     */
    nativeResponses(routeToken: string, modelId: string, requestBody: Record<string, unknown>): Promise<{
        response: Response;
        accountDbId: number;
        releaseSlot: () => void;
    }>;
    /** Forward the standalone Responses compaction call without translating it. */
    nativeResponsesCompact(routeToken: string, modelId: string, requestBody: Record<string, unknown>): Promise<{
        response: Response;
        accountDbId: number | null;
        releaseSlot: () => void;
    }>;
    recordNativeResponsesUsage(args: {
        accountDbId: number;
        modelId: string;
        success: boolean;
        usage?: any;
        error?: string;
    }): void;
    private requestResponses;
    chatCompletion(_apiKey: string, _messages: ChatMessage[], _modelId: string, _options?: CompletionOptions, _quotaContext?: any): Promise<ChatCompletionResponse>;
    streamChatCompletion(_apiKey: string, _messages: ChatMessage[], _modelId: string, _options?: CompletionOptions, _quotaContext?: any): AsyncGenerator<ChatCompletionChunk>;
    validateKey(): Promise<boolean>;
}
export {};
//# sourceMappingURL=openai-codex.d.ts.map