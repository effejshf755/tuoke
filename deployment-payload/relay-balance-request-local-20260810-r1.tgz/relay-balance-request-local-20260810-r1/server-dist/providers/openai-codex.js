import { createHash } from 'node:crypto';
const CODEX_BASE_URL = 'https://chatgpt.com/backend-api/codex';
const CODEX_RESPONSES_URL = `${CODEX_BASE_URL}/responses`;
const CODEX_COMPACT_URL = `${CODEX_RESPONSES_URL}/compact`;
import { getDb } from '../db/index.js';
import { contentToString } from '../lib/content.js';
import { decrypt } from '../lib/crypto.js';
import { proxyFetch } from '../lib/proxy.js';
import { requestNativeResponsesCompactRelay, requestNativeResponsesRelay, } from '../lib/native-responses-relay.js';
import { requiresExplicitPromptCache } from '../lib/codex-prompt-cache.js';
import { codexCachedInputTokensFromUsage, codexCacheWriteTokensFromUsage, normalizeCodexPromptCacheUsage, } from '../lib/codex-cache-usage.js';
import { recordCodexUsage } from '../services/codex-usage.js';
import { acquireCodexAccountSlot } from '../services/codex-concurrency.js';
import { BaseProvider } from './base.js';
function redactSensitiveText(value) {
    return value
        .replace(/Bearer\s+\S+/gi, 'Bearer [REDACTED]')
        .replace(/("?(?:access_token|refresh_token)"?\s*[:=]\s*")([^"]+)(")/gi, '$1[REDACTED]$3')
        .slice(0, 2_000);
}
function describeFetchError(error) {
    const topLevel = error instanceof Error ? error.message : String(error);
    const cause = error instanceof Error
        ? error.cause
        : undefined;
    const causeMessage = cause instanceof Error ? cause.message : cause ? String(cause) : '';
    const causeCode = cause && typeof cause === 'object' && 'code' in cause
        ? String(cause.code ?? '')
        : '';
    return redactSensitiveText([topLevel, causeCode && `code=${causeCode}`, causeMessage]
        .filter(Boolean)
        .join(' | '));
}
function trackedError(error, accountDbId, status) {
    const tracked = error;
    tracked.codexAccountDbId = accountDbId;
    tracked.codexStatus = status;
    return tracked;
}
function authenticationFailure(error) {
    const tracked = error;
    return tracked?.codexStatus === 401 || tracked?.codexStatus === 403
        || /unauthori[sz]ed|authentication|invalid token|expired token/i.test(tracked?.message ?? '');
}
function quotaExhaustionFailure(error) {
    const tracked = error;
    return tracked?.codexStatus === 429
        && /usage_limit_reached|usage limit has been reached|quota|limit reached/i.test(tracked?.message ?? '');
}
function estimatedInputTokens(messages) {
    return Math.ceil(JSON.stringify(messages).length / 4);
}
export function codexCachedInputTokens(usage) {
    return codexCachedInputTokensFromUsage(usage) ?? 0;
}
export function codexCacheWriteTokens(usage) {
    return codexCacheWriteTokensFromUsage(usage);
}
function codexTokenCount(value, fallback) {
    const number = Number(value);
    return Number.isFinite(number) && number >= 0
        ? Math.trunc(number)
        : Math.max(0, Math.trunc(fallback));
}
export function codexChatTokenUsage(usage, fallbackInputTokens, fallbackOutputTokens) {
    const promptTokens = codexTokenCount(usage?.input_tokens ?? usage?.prompt_tokens, fallbackInputTokens);
    const completionTokens = codexTokenCount(usage?.output_tokens ?? usage?.completion_tokens, fallbackOutputTokens);
    const totalTokens = codexTokenCount(usage?.total_tokens, promptTokens + completionTokens);
    const normalizedUsage = normalizeCodexPromptCacheUsage(usage && typeof usage === 'object' ? usage : {}, 'prompt_tokens_details');
    const inputDetails = normalizedUsage?.prompt_tokens_details;
    const outputDetails = usage?.output_tokens_details ?? usage?.completion_tokens_details;
    const reasoningTokens = codexTokenCount(outputDetails?.reasoning_tokens, 0);
    const cacheWriteTokens = codexCacheWriteTokens(usage);
    return {
        prompt_tokens: promptTokens,
        completion_tokens: completionTokens,
        total_tokens: totalTokens,
        prompt_tokens_details: {
            ...(inputDetails && typeof inputDetails === 'object' && !Array.isArray(inputDetails)
                ? inputDetails
                : {}),
            cached_tokens: Math.min(promptTokens, codexCachedInputTokens(usage)),
            ...(cacheWriteTokens != null
                ? { cache_write_tokens: Math.min(promptTokens, cacheWriteTokens) }
                : {}),
        },
        completion_tokens_details: {
            ...(outputDetails && typeof outputDetails === 'object' && !Array.isArray(outputDetails)
                ? outputDetails
                : {}),
            reasoning_tokens: reasoningTokens,
        },
    };
}
/** Backward-compatible export retained for existing callers/tests. The
 * implementation now covers the actual "5.6 and newer" requirement. */
export const isGpt56Model = requiresExplicitPromptCache;
function explicitPromptCacheBreakpoint(value) {
    return value
        && typeof value === 'object'
        && !Array.isArray(value)
        && value.mode === 'explicit'
        ? { mode: 'explicit' }
        : undefined;
}
function preservedPromptCacheBreakpoint(value, preserve) {
    const breakpoint = preserve ? explicitPromptCacheBreakpoint(value) : undefined;
    return breakpoint ? { prompt_cache_breakpoint: breakpoint } : {};
}
function messageHasPromptCacheBreakpoint(message) {
    return Array.isArray(message.content)
        && message.content.some((part) => part
            && typeof part === 'object'
            && explicitPromptCacheBreakpoint(part.prompt_cache_breakpoint) != null);
}
function messageHasCacheableUserContent(message) {
    if (message.role !== 'user')
        return false;
    if (typeof message.content === 'string')
        return message.content.length > 0;
    if (!Array.isArray(message.content))
        return false;
    return message.content.some((part) => {
        if (typeof part === 'string')
            return part.length > 0;
        if (!part || typeof part !== 'object')
            return false;
        if (typeof part.text === 'string' && part.text.length > 0)
            return true;
        const rawImage = part.image_url ?? part.image;
        const imageUrl = typeof rawImage === 'string'
            ? rawImage
            : rawImage && typeof rawImage === 'object' && 'url' in rawImage
                ? rawImage.url
                : undefined;
        return (part.type === 'image_url' || part.type === 'image') && typeof imageUrl === 'string';
    });
}
function markLastCacheablePart(parts) {
    for (let index = parts.length - 1; index >= 0; index -= 1) {
        const part = parts[index];
        if (part.type !== 'input_text' && part.type !== 'input_image')
            continue;
        parts[index] = { ...part, prompt_cache_breakpoint: { mode: 'explicit' } };
        break;
    }
    return parts;
}
export function codexPromptCacheKey(messages, modelId, options) {
    const clientKey = options?.prompt_cache_key?.trim();
    const sessionId = options?.promptCacheSessionId?.trim();
    const firstUserIndex = messages.findIndex((message) => message.role === 'user');
    const stableRoot = firstUserIndex >= 0
        ? messages.slice(0, firstUserIndex + 1)
        : messages.slice(0, 1);
    const identity = clientKey
        ? { clientKey }
        : sessionId
            ? { sessionId }
            : { stableRoot, tools: options?.tools ?? [] };
    const digest = createHash('sha256')
        .update(JSON.stringify({
        version: 1,
        namespace: options?.promptCacheNamespace ?? 'operator',
        model: modelId,
        identity,
    }))
        .digest('base64url');
    return `tuoke:v1:${digest}`;
}
/**
 * Translate OpenAI Chat Completions history into Responses API input items.
 * Assistant tool-call turns legitimately use content=null, but the Codex
 * Responses endpoint rejects null content and expects tool calls/results as
 * dedicated function_call and function_call_output items.
 */
export function toCodexResponsesInput(messages, options) {
    const input = [];
    const autoBreakpointMessageIndexes = new Set(options?.autoPromptCacheBreakpoints
        ? messages
            .map((message, index) => ({ message, index }))
            .filter(({ message }) => messageHasCacheableUserContent(message))
            .slice(-50)
            .map(({ index }) => index)
        : []);
    for (let messageIndex = 0; messageIndex < messages.length; messageIndex += 1) {
        const message = messages[messageIndex];
        const content = contentToString(message.content);
        if (message.role === 'tool') {
            if (message.tool_call_id) {
                input.push({
                    type: 'function_call_output',
                    call_id: message.tool_call_id,
                    output: content,
                });
            }
            continue;
        }
        const toolCalls = message.role === 'assistant' ? (message.tool_calls ?? []) : [];
        const textPartType = message.role === 'assistant' ? 'output_text' : 'input_text';
        let responseContent = Array.isArray(message.content)
            ? message.content.flatMap((part) => {
                if (typeof part === 'string')
                    return part ? [{ type: textPartType, text: part }] : [];
                if (!part || typeof part !== 'object')
                    return [];
                if (typeof part.text === 'string')
                    return [{
                            type: textPartType,
                            text: part.text,
                            ...(textPartType === 'input_text'
                                ? preservedPromptCacheBreakpoint(part.prompt_cache_breakpoint, options?.preservePromptCacheBreakpoints)
                                : {}),
                        }];
                const rawImage = part.image_url ?? part.image;
                const imageUrl = typeof rawImage === 'string'
                    ? rawImage
                    : rawImage && typeof rawImage === 'object' && 'url' in rawImage
                        ? rawImage.url
                        : undefined;
                if ((part.type === 'image_url' || part.type === 'image') && typeof imageUrl === 'string') {
                    const detail = rawImage && typeof rawImage === 'object' && 'detail' in rawImage
                        ? rawImage.detail
                        : undefined;
                    return [{
                            type: 'input_image',
                            image_url: imageUrl,
                            ...(typeof detail === 'string' ? { detail } : {}),
                            ...preservedPromptCacheBreakpoint(part.prompt_cache_breakpoint, options?.preservePromptCacheBreakpoints),
                        }];
                }
                return [];
            })
            : content;
        if (autoBreakpointMessageIndexes.has(messageIndex)) {
            responseContent = Array.isArray(responseContent)
                ? markLastCacheablePart(responseContent)
                : responseContent
                    ? [{ type: 'input_text', text: responseContent, prompt_cache_breakpoint: { mode: 'explicit' } }]
                    : responseContent;
        }
        if (content || toolCalls.length === 0) {
            input.push({
                role: message.role,
                content: responseContent,
            });
        }
        for (const call of toolCalls) {
            input.push({
                type: 'function_call',
                call_id: call.id,
                name: call.function.name,
                arguments: call.function.arguments,
            });
        }
    }
    return input;
}
export function toCodexResponsesBody(messages, modelId, options) {
    const promptCacheCapable = options?.disablePromptCache !== true
        && (options?.forceExplicitPromptCache === true || isGpt56Model(modelId));
    // chatgpt.com/backend-api/codex currently accepts prompt_cache_key but
    // rejects the public GPT-5.6 prompt_cache_options and breakpoint fields.
    // Keep explicit support behind a rollout flag so the safe production
    // default is key-only until a compatibility canary proves otherwise.
    const explicitPromptCacheEnabled = promptCacheCapable
        && (options?.forceExplicitPromptCache === true
            || process.env.CODEX_EXPLICIT_PROMPT_CACHE === 'true');
    const preservePromptCacheBreakpoints = explicitPromptCacheEnabled;
    const autoPromptCacheBreakpoints = explicitPromptCacheEnabled
        && options?.autoPromptCacheBreakpoints === true;
    const leadingSystemHasPromptCacheBreakpoint = preservePromptCacheBreakpoints
        && messages.some((message, index) => message.role === 'system'
            && messages.slice(0, index).every((prior) => prior.role === 'system')
            && messageHasPromptCacheBreakpoint(message));
    const instructionParts = [];
    let inputStart = 0;
    while (!leadingSystemHasPromptCacheBreakpoint
        && inputStart < messages.length
        && messages[inputStart]?.role === 'system') {
        const instruction = contentToString(messages[inputStart].content).trim();
        if (instruction)
            instructionParts.push(instruction);
        inputStart += 1;
    }
    const instructions = instructionParts.join('\n\n');
    const responseFormat = options?.response_format;
    const text = responseFormat
        ? {
            format: responseFormat.type === 'json_schema' && responseFormat.json_schema
                ? {
                    type: 'json_schema',
                    name: responseFormat.json_schema.name,
                    ...(responseFormat.json_schema.strict != null ? { strict: responseFormat.json_schema.strict } : {}),
                    schema: responseFormat.json_schema.schema,
                }
                : { type: responseFormat.type },
        }
        : undefined;
    const tools = options?.tools?.map((tool) => ({
        type: 'function',
        name: tool.function.name,
        ...(tool.function.description != null ? { description: tool.function.description } : {}),
        parameters: tool.function.parameters ?? {},
        ...(tool.function.strict != null ? { strict: tool.function.strict } : {}),
    }));
    const toolChoice = typeof options?.tool_choice === 'object'
        ? { type: 'function', name: options.tool_choice.function.name }
        : options?.tool_choice;
    const input = toCodexResponsesInput(messages.slice(inputStart), {
        preservePromptCacheBreakpoints,
        autoPromptCacheBreakpoints,
    });
    const hasPromptCacheBreakpoint = input.some((item) => 'content' in item
        && Array.isArray(item.content)
        && item.content.some((part) => part.type !== 'output_text'
            && part.prompt_cache_breakpoint?.mode === 'explicit'));
    const promptCacheOptions = explicitPromptCacheEnabled
        ? options?.prompt_cache_options
            ?? (autoPromptCacheBreakpoints && hasPromptCacheBreakpoint
                ? { mode: 'explicit', ttl: '30m' }
                : undefined)
        : undefined;
    return {
        model: modelId,
        input,
        ...(instructions ? { instructions } : {}),
        store: false,
        stream: true,
        ...(promptCacheCapable ? { prompt_cache_key: codexPromptCacheKey(messages, modelId, options) } : {}),
        ...(promptCacheOptions ? { prompt_cache_options: promptCacheOptions } : {}),
        // The public Responses relay contract supports this field. Keep it off
        // the ChatGPT OAuth backend, which historically rejected some public
        // Responses parameters, and apply it to public relays only.
        ...(options?.publicResponsesRelay === true
            && options.max_tokens != null
            && options.max_tokens > 0
            ? { max_output_tokens: Math.trunc(options.max_tokens) }
            : {}),
        ...(options?.top_p != null ? { top_p: options.top_p } : {}),
        ...(tools?.length ? { tools } : {}),
        ...(toolChoice != null ? { tool_choice: toolChoice } : {}),
        ...(options?.parallel_tool_calls != null ? { parallel_tool_calls: options.parallel_tool_calls } : {}),
        ...(text ? { text } : {}),
    };
}
export function toNativeCodexResponsesBody(requestBody, modelId) {
    const body = {
        ...requestBody,
        model: modelId,
        store: false,
        // The ChatGPT Codex backend is an SSE endpoint. Non-streaming clients
        // are assembled by routes/responses.ts after this native request.
        stream: true,
    };
    // The public Responses schema accepts temperature, but the ChatGPT Codex
    // OAuth backend rejects the field. Strip it only at this provider boundary
    // so ordinary providers and third-party native Responses relays keep their
    // own protocol semantics.
    delete body.temperature;
    return body;
}
function codexToolCalls(response) {
    return (response?.output ?? [])
        .filter((item) => item?.type === 'function_call')
        .map((item, index) => ({
        id: String(item.call_id ?? item.id ?? `call_${index + 1}`),
        type: 'function',
        function: {
            name: String(item.name ?? ''),
            arguments: typeof item.arguments === 'string' ? item.arguments : JSON.stringify(item.arguments ?? {}),
        },
    }));
}
export function codexOutputText(response) {
    if (typeof response?.output_text === 'string')
        return response.output_text;
    return (response?.output ?? [])
        .filter((item) => item?.type === 'message')
        .flatMap((item) => Array.isArray(item?.content) ? item.content : [])
        .filter((part) => part?.type === 'output_text' && typeof part?.text === 'string')
        .map((part) => part.text)
        .join('');
}
async function* readCodexSse(res) {
    const reader = res.body?.getReader();
    if (!reader)
        throw new Error('Codex API returned no response body');
    const decoder = new TextDecoder();
    let buffer = '';
    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            buffer += decoder.decode(value, { stream: true });
            buffer = buffer.replace(/\r\n/g, '\n');
            const blocks = buffer.split('\n\n');
            buffer = blocks.pop() ?? '';
            for (const block of blocks) {
                const lines = block.split('\n');
                const eventName = lines.find((line) => line.startsWith('event:'))?.slice(6).trim() ?? '';
                const rawData = lines
                    .filter((line) => line.startsWith('data:'))
                    .map((line) => line.slice(5).trimStart())
                    .join('\n');
                if (!rawData)
                    continue;
                if (rawData === '[DONE]')
                    return;
                try {
                    const data = JSON.parse(rawData);
                    yield { type: String(data?.type ?? eventName), data };
                }
                catch {
                    // Ignore non-JSON SSE keepalive events.
                }
            }
        }
    }
    finally {
        reader.cancel().catch(() => { });
    }
}
function getAvailableCodexAccount(routeToken, modelId) {
    const match = /^codex-account:(\d+)$/.exec(routeToken ?? '');
    if (!match) {
        throw new Error('Codex account was not selected by router');
    }
    const selectedAccountId = Number(match[1]);
    const row = getDb().prepare(`
      SELECT a.*
      FROM codex_oauth_accounts a
      WHERE a.enabled = 1
        AND a.status IN ('healthy', 'unknown')
        AND (a.cooldown_until IS NULL OR a.cooldown_until <= datetime('now'))
        AND (
          a.quota_remaining_percent IS NULL
          OR a.quota_remaining_percent > 0
          OR (a.quota_reset_at IS NOT NULL AND datetime(a.quota_reset_at) <= datetime('now'))
        )
        AND a.id = ?
        AND (
          ? IS NULL OR EXISTS (
            SELECT 1 FROM codex_oauth_account_models am
            WHERE am.account_id = a.id AND am.model_id = ? AND am.enabled = 1
          )
        )
      ORDER BY a.last_used_at ASC, a.id ASC
      LIMIT 1
    `).get(selectedAccountId, modelId ?? null, modelId ?? null);
    if (!row) {
        throw new Error('No Codex account available');
    }
    return row;
}
function getCodexAccessToken(routeToken, modelId) {
    const account = getAvailableCodexAccount(routeToken, modelId);
    let accessToken;
    try {
        accessToken = decrypt(account.access_token_encrypted, account.access_token_iv, account.access_token_auth_tag);
    }
    catch (error) {
        throw trackedError(error instanceof Error ? error : new Error(String(error)), account.id);
    }
    return {
        account,
        accessToken,
    };
}
export class OpenAICodexProvider extends BaseProvider {
    platform = 'openai-codex';
    name = 'OpenAI Codex';
    relayBaseUrl;
    relayPromptCacheCertified;
    constructor(options = {}) {
        super();
        const relayBaseUrl = options.relayBaseUrl?.trim().replace(/\/+$/, '');
        this.relayBaseUrl = relayBaseUrl || null;
        this.relayPromptCacheCertified = options.relayPromptCacheCertified === true;
        if (this.relayBaseUrl)
            this.name = 'Responses relay';
    }
    /**
     * Forward a Codex Desktop Responses request without translating it through
     * Chat Completions. The caller owns relaying/parsing the returned SSE body.
     */
    async nativeResponses(routeToken, modelId, requestBody) {
        const { account, accessToken } = getCodexAccessToken(routeToken, modelId);
        const headers = {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
            Accept: 'text/event-stream',
        };
        if (account.account_id)
            headers['ChatGPT-Account-Id'] = String(account.account_id);
        const body = toNativeCodexResponsesBody(requestBody, modelId);
        const releaseSlot = await acquireCodexAccountSlot(account.id);
        let response;
        try {
            response = await proxyFetch(CODEX_RESPONSES_URL, {
                method: 'POST',
                headers,
                body: JSON.stringify(body),
            }, this.platform, 'chat');
        }
        catch (error) {
            releaseSlot();
            const message = describeFetchError(error);
            throw trackedError(new Error(`Codex network error at ${CODEX_RESPONSES_URL}: ${message}`), account.id);
        }
        if (!response.ok) {
            const message = redactSensitiveText(await response.text()) || response.statusText || 'Unknown upstream error';
            releaseSlot();
            throw trackedError(new Error(`Codex API error ${response.status} at ${CODEX_RESPONSES_URL}: ${message}`), account.id, response.status);
        }
        return { response, accountDbId: account.id, releaseSlot };
    }
    /** Forward the standalone Responses compaction call without translating it. */
    async nativeResponsesCompact(routeToken, modelId, requestBody) {
        const body = structuredClone(requestBody);
        body.model = modelId;
        delete body.stream;
        delete body.store;
        if (this.relayBaseUrl) {
            const response = await requestNativeResponsesCompactRelay({
                baseUrl: this.relayBaseUrl,
                apiKey: routeToken,
                body,
            });
            return { response, accountDbId: null, releaseSlot: () => undefined };
        }
        const { account, accessToken } = getCodexAccessToken(routeToken, modelId);
        const headers = {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
            Accept: 'application/json',
        };
        if (account.account_id)
            headers['ChatGPT-Account-Id'] = String(account.account_id);
        const releaseSlot = await acquireCodexAccountSlot(account.id);
        let response;
        try {
            response = await proxyFetch(CODEX_COMPACT_URL, {
                method: 'POST',
                headers,
                body: JSON.stringify(body),
            }, this.platform, 'chat');
        }
        catch (error) {
            releaseSlot();
            const message = describeFetchError(error);
            throw trackedError(new Error(`Codex compact network error at ${CODEX_COMPACT_URL}: ${message}`), account.id);
        }
        if (!response.ok) {
            const message = redactSensitiveText(await response.text()) || response.statusText || 'Unknown upstream error';
            releaseSlot();
            throw trackedError(new Error(`Codex compact API error ${response.status} at ${CODEX_COMPACT_URL}: ${message}`), account.id, response.status);
        }
        return { response, accountDbId: account.id, releaseSlot };
    }
    recordNativeResponsesUsage(args) {
        const usage = args.usage;
        recordCodexUsage({
            accountDbId: args.accountDbId,
            modelId: args.modelId,
            success: args.success,
            inputTokens: usage?.input_tokens ?? usage?.prompt_tokens,
            cachedInputTokens: codexCachedInputTokens(usage),
            cacheWriteTokens: codexCacheWriteTokens(usage),
            outputTokens: usage?.output_tokens ?? usage?.completion_tokens,
            error: args.error ? redactSensitiveText(args.error) : undefined,
            authenticationFailure: !args.success && /unauthori[sz]ed|authentication|invalid token|expired token/i.test(args.error ?? ''),
            quotaExhausted: !args.success && /usage_limit_reached|quota|limit reached/i.test(args.error ?? ''),
        });
    }
    async requestResponses(messages, modelId, routeToken, options) {
        if (this.relayBaseUrl) {
            const response = await requestNativeResponsesRelay({
                baseUrl: this.relayBaseUrl,
                apiKey: routeToken ?? '',
                body: toCodexResponsesBody(messages, modelId, {
                    ...options,
                    publicResponsesRelay: true,
                    disablePromptCache: !this.relayPromptCacheCertified,
                    forceExplicitPromptCache: this.relayPromptCacheCertified,
                    autoPromptCacheBreakpoints: this.relayPromptCacheCertified,
                }),
            });
            return { response, accountDbId: null, releaseSlot: () => undefined };
        }
        const { account, accessToken } = getCodexAccessToken(routeToken, modelId);
        const headers = {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json',
            Accept: 'text/event-stream',
        };
        if (account.account_id) {
            headers['ChatGPT-Account-Id'] = String(account.account_id);
        }
        console.info(`[OpenAICodexProvider] request url=${CODEX_RESPONSES_URL}`);
        const releaseSlot = await acquireCodexAccountSlot(account.id);
        let res;
        try {
            res = await proxyFetch(CODEX_RESPONSES_URL, {
                method: 'POST',
                headers,
                body: JSON.stringify(toCodexResponsesBody(messages, modelId, options)),
            }, this.platform, 'chat');
        }
        catch (error) {
            releaseSlot();
            const message = describeFetchError(error);
            console.error(`[OpenAICodexProvider] request failed url=${CODEX_RESPONSES_URL} status=network_error error=${message}`);
            throw trackedError(new Error(`Codex network error at ${CODEX_RESPONSES_URL}: ${message}`), account.id);
        }
        if (!res.ok) {
            const err = redactSensitiveText(await res.text());
            const message = err || res.statusText || 'Unknown upstream error';
            releaseSlot();
            console.error(`[OpenAICodexProvider] upstream error url=${CODEX_RESPONSES_URL} status=${res.status} error=${message}`);
            throw trackedError(new Error(`Codex API error ${res.status} at ${CODEX_RESPONSES_URL}: ${message}`), account.id, res.status);
        }
        return { response: res, accountDbId: account.id, releaseSlot };
    }
    async chatCompletion(_apiKey, _messages, _modelId, _options, _quotaContext) {
        let accountDbId = null;
        let releaseSlot;
        try {
            const requested = await this.requestResponses(_messages, _modelId, _apiKey, _options);
            const res = requested.response;
            accountDbId = requested.accountDbId;
            releaseSlot = requested.releaseSlot;
            let responseId = `codex-${Date.now()}`;
            let outputText = '';
            let finalResponse;
            let sawCompleted = false;
            const streamedToolCalls = new Map();
            for await (const event of readCodexSse(res)) {
                if (event.type === 'response.created' && event.data?.response?.id) {
                    responseId = String(event.data.response.id);
                }
                else if (event.type === 'response.output_text.delta' && typeof event.data?.delta === 'string') {
                    outputText += event.data.delta;
                }
                else if (event.type === 'response.output_item.added' && event.data?.item?.type === 'function_call') {
                    const item = event.data.item;
                    const key = String(item.id ?? item.call_id ?? streamedToolCalls.size);
                    streamedToolCalls.set(key, {
                        id: String(item.call_id ?? item.id ?? ('call_' + (streamedToolCalls.size + 1))),
                        name: String(item.name ?? ''),
                        arguments: typeof item.arguments === 'string' ? item.arguments : '',
                    });
                }
                else if (event.type === 'response.function_call_arguments.delta' && typeof event.data?.delta === 'string') {
                    const key = String(event.data.item_id ?? '');
                    const call = streamedToolCalls.get(key);
                    if (call)
                        call.arguments += event.data.delta;
                }
                else if (event.type === 'response.completed') {
                    sawCompleted = true;
                    finalResponse = event.data?.response ?? event.data;
                    if (finalResponse?.id)
                        responseId = String(finalResponse.id);
                }
                else if (event.type === 'response.failed' || event.type === 'error') {
                    const message = event.data?.response?.error?.message
                        ?? event.data?.error?.message
                        ?? event.data?.message
                        ?? 'Codex stream failed';
                    throw new Error(`Codex API stream error: ${redactSensitiveText(String(message))}`);
                }
            }
            if (!sawCompleted) {
                throw new Error('Codex API stream ended unexpectedly (missing response.completed)');
            }
            const usage = finalResponse?.usage;
            if (!outputText)
                outputText = codexOutputText(finalResponse);
            const fallbackInputTokens = estimatedInputTokens(_messages);
            const completedToolCalls = codexToolCalls(finalResponse);
            const toolCalls = completedToolCalls.length ? completedToolCalls : [...streamedToolCalls.values()].map((call) => ({
                id: call.id,
                type: 'function',
                function: { name: call.name, arguments: call.arguments },
            }));
            const fallbackOutputTokens = Math.ceil((outputText.length + toolCalls.reduce((n, call) => n + call.function.arguments.length, 0)) / 4);
            const completion = {
                id: responseId,
                object: 'chat.completion',
                created: Math.floor(Date.now() / 1000),
                model: _modelId,
                choices: [{
                        index: 0,
                        message: {
                            role: 'assistant',
                            content: outputText || (toolCalls.length ? null : ''),
                            ...(toolCalls.length ? { tool_calls: toolCalls } : {}),
                        },
                        finish_reason: toolCalls.length ? 'tool_calls' : 'stop',
                    }],
                usage: codexChatTokenUsage(usage, fallbackInputTokens, fallbackOutputTokens),
            };
            if (accountDbId !== null) {
                recordCodexUsage({
                    accountDbId,
                    modelId: _modelId,
                    success: true,
                    inputTokens: completion.usage.prompt_tokens,
                    cachedInputTokens: codexCachedInputTokens(usage),
                    cacheWriteTokens: codexCacheWriteTokens(usage),
                    outputTokens: completion.usage.completion_tokens,
                });
            }
            return completion;
        }
        catch (error) {
            const tracked = error;
            const id = accountDbId ?? tracked.codexAccountDbId;
            if (id)
                recordCodexUsage({
                    accountDbId: id,
                    modelId: _modelId,
                    success: false,
                    error: redactSensitiveText(tracked.message ?? String(error)),
                    authenticationFailure: authenticationFailure(error),
                    quotaExhausted: quotaExhaustionFailure(error),
                });
            throw error;
        }
        finally {
            releaseSlot?.();
        }
    }
    async *streamChatCompletion(_apiKey, _messages, _modelId, _options, _quotaContext) {
        let accountDbId = null;
        let releaseSlot;
        let recorded = false;
        let outputCharacters = 0;
        let finalUsage;
        let sawCompleted = false;
        let sawToolCall = false;
        const toolIndexes = new Map();
        try {
            const requested = await this.requestResponses(_messages, _modelId, _apiKey, _options);
            const res = requested.response;
            accountDbId = requested.accountDbId;
            releaseSlot = requested.releaseSlot;
            const created = Math.floor(Date.now() / 1000);
            let responseId = `codex-${Date.now()}`;
            yield {
                id: responseId,
                object: 'chat.completion.chunk',
                created,
                model: _modelId,
                choices: [{ index: 0, delta: { role: 'assistant' }, finish_reason: null }],
            };
            for await (const event of readCodexSse(res)) {
                if (event.type === 'response.created' && event.data?.response?.id) {
                    responseId = String(event.data.response.id);
                }
                else if (event.type === 'response.output_text.delta' && typeof event.data?.delta === 'string') {
                    outputCharacters += event.data.delta.length;
                    yield {
                        id: responseId,
                        object: 'chat.completion.chunk',
                        created,
                        model: _modelId,
                        choices: [{ index: 0, delta: { content: event.data.delta }, finish_reason: null }],
                    };
                }
                else if (event.type === 'response.output_item.added' && event.data?.item?.type === 'function_call') {
                    const item = event.data.item;
                    const callId = String(item.call_id ?? item.id ?? `call_${toolIndexes.size + 1}`);
                    const index = Number.isInteger(event.data.output_index) ? event.data.output_index : toolIndexes.size;
                    toolIndexes.set(String(item.id ?? callId), index);
                    sawToolCall = true;
                    yield {
                        id: responseId,
                        object: 'chat.completion.chunk',
                        created,
                        model: _modelId,
                        choices: [{ index: 0, delta: { tool_calls: [{
                                            index,
                                            id: callId,
                                            type: 'function',
                                            function: { name: String(item.name ?? ''), arguments: '' },
                                        }] }, finish_reason: null }],
                    };
                }
                else if (event.type === 'response.function_call_arguments.delta' && typeof event.data?.delta === 'string') {
                    sawToolCall = true;
                    const index = toolIndexes.get(String(event.data.item_id ?? '')) ?? Number(event.data.output_index ?? 0);
                    outputCharacters += event.data.delta.length;
                    yield {
                        id: responseId,
                        object: 'chat.completion.chunk',
                        created,
                        model: _modelId,
                        choices: [{ index: 0, delta: { tool_calls: [{
                                            index,
                                            type: 'function',
                                            function: { name: '', arguments: event.data.delta },
                                        }] }, finish_reason: null }],
                    };
                }
                else if (event.type === 'response.completed') {
                    sawCompleted = true;
                    const completedResponse = event.data?.response ?? event.data;
                    finalUsage = completedResponse?.usage;
                    if (outputCharacters === 0 && !sawToolCall) {
                        const finalText = codexOutputText(completedResponse);
                        if (finalText) {
                            outputCharacters += finalText.length;
                            yield {
                                id: responseId,
                                object: 'chat.completion.chunk',
                                created,
                                model: _modelId,
                                choices: [{ index: 0, delta: { content: finalText }, finish_reason: null }],
                            };
                        }
                    }
                }
                else if (event.type === 'response.failed' || event.type === 'error') {
                    const message = event.data?.response?.error?.message
                        ?? event.data?.error?.message
                        ?? event.data?.message
                        ?? 'Codex stream failed';
                    throw new Error(`Codex API stream error: ${redactSensitiveText(String(message))}`);
                }
            }
            if (!sawCompleted) {
                throw new Error('Codex API stream ended unexpectedly (missing response.completed)');
            }
            const streamUsage = codexChatTokenUsage(finalUsage, estimatedInputTokens(_messages), Math.ceil(outputCharacters / 4));
            if (accountDbId !== null) {
                recordCodexUsage({
                    accountDbId,
                    modelId: _modelId,
                    success: true,
                    inputTokens: streamUsage.prompt_tokens,
                    cachedInputTokens: streamUsage.prompt_tokens_details?.cached_tokens,
                    cacheWriteTokens: streamUsage.prompt_tokens_details?.cache_write_tokens,
                    outputTokens: streamUsage.completion_tokens,
                });
            }
            recorded = true;
            yield {
                id: responseId,
                object: 'chat.completion.chunk',
                created,
                model: _modelId,
                choices: [{ index: 0, delta: {}, finish_reason: sawToolCall ? 'tool_calls' : 'stop' }],
            };
            if (_options?.includeUsage) {
                yield {
                    id: responseId,
                    object: 'chat.completion.chunk',
                    created,
                    model: _modelId,
                    choices: [],
                    usage: streamUsage,
                };
            }
        }
        catch (error) {
            const tracked = error;
            const id = accountDbId ?? tracked.codexAccountDbId;
            if (id)
                recordCodexUsage({
                    accountDbId: id,
                    modelId: _modelId,
                    success: false,
                    inputTokens: outputCharacters > 0 ? estimatedInputTokens(_messages) : undefined,
                    outputTokens: outputCharacters > 0 ? Math.ceil(outputCharacters / 4) : undefined,
                    error: redactSensitiveText(tracked.message ?? String(error)),
                    authenticationFailure: authenticationFailure(error),
                    quotaExhausted: quotaExhaustionFailure(error),
                });
            recorded = true;
            throw error;
        }
        finally {
            releaseSlot?.();
            if (accountDbId && !recorded) {
                recordCodexUsage({
                    accountDbId,
                    modelId: _modelId,
                    success: false,
                    inputTokens: outputCharacters > 0 ? estimatedInputTokens(_messages) : undefined,
                    outputTokens: outputCharacters > 0 ? Math.ceil(outputCharacters / 4) : undefined,
                    error: 'Codex stream ended before completion',
                });
            }
        }
    }
    async validateKey() {
        return true;
    }
}
//# sourceMappingURL=openai-codex.js.map