import { BaseProvider, providerHttpError } from './base.js';
import { contentToString } from '../lib/content.js';
import { proxyFetch } from '../lib/proxy.js';
import { recordQuotaObservationsFromResponse } from '../services/provider-quota.js';
const API_BASE = 'https://generativelanguage.googleapis.com/v1beta';
// Gemini 3 REQUIRES the `thoughtSignature` that accompanied a function call to
// be echoed back whenever that call appears in conversation history, or it
// rejects the request with 400 "Function call is missing a thought_sig". But
// OpenAI-format clients (the API surface we expose) have no standard field to
// carry a provider-specific signature, so it can be dropped on the round-trip
// and multi-turn tool conversations through Gemini fail. Cache each signature
// we emit keyed by the tool-call id and by a stable name/arguments fingerprint;
// the latter keeps the Anthropic bridge resilient when an agent/client rewrites
// opaque tool ids. Strictly additive: a cache miss yields exactly the previous
// behavior (the request may 400 and fail over, as before). Bounded with a TTL so
// it can't grow unbounded.
const THOUGHT_SIG_TTL_MS = 30 * 60 * 1000; // 30 min — longer than any single tool loop
const THOUGHT_SIG_MAX = 5000;
const thoughtSigCache = new Map();
function canonicalThoughtSigArgs(args) {
    if (typeof args === 'string') {
        try {
            return JSON.stringify(JSON.parse(args));
        }
        catch {
            return args;
        }
    }
    return JSON.stringify(args ?? {});
}
function thoughtSigCallKey(name, args) {
    if (!name)
        return undefined;
    return `call:${name}:${canonicalThoughtSigArgs(args)}`;
}
function rememberThoughtSigKey(key, sig) {
    if (!key || !sig)
        return;
    // Cheap eviction: when full, drop the oldest insertion (Map preserves order).
    if (thoughtSigCache.size >= THOUGHT_SIG_MAX) {
        const oldest = thoughtSigCache.keys().next().value;
        if (oldest !== undefined)
            thoughtSigCache.delete(oldest);
    }
    thoughtSigCache.set(key, { sig, exp: Date.now() + THOUGHT_SIG_TTL_MS });
}
function rememberThoughtSig(callId, sig, name, args) {
    rememberThoughtSigKey(callId ? `id:${callId}` : undefined, sig);
    rememberThoughtSigKey(thoughtSigCallKey(name, args), sig);
}
function recallThoughtSigKey(key) {
    if (!key)
        return undefined;
    const hit = thoughtSigCache.get(key);
    if (!hit)
        return undefined;
    if (hit.exp < Date.now()) {
        thoughtSigCache.delete(key);
        return undefined;
    }
    return hit.sig;
}
function recallThoughtSig(callId, name, args) {
    return recallThoughtSigKey(callId ? `id:${callId}` : undefined)
        ?? recallThoughtSigKey(thoughtSigCallKey(name, args));
}
function isGemmaModel(modelId) {
    const normalized = modelId.toLowerCase().replace(/^models\//, '');
    return /(?:^|[/.:])gemma[-_]/.test(normalized);
}
function optionsForModel(modelId, options) {
    if (!isGemmaModel(modelId) || !options)
        return options;
    const { tools: _tools, tool_choice: _toolChoice, parallel_tool_calls: _parallelToolCalls, ...rest } = options;
    return rest;
}
function systemInstructionText(systemInstruction) {
    const text = systemInstruction?.parts
        ?.map(part => part.text ?? '')
        .join('\n\n')
        .trim();
    return text ? text : null;
}
function contentsForModel(modelId, contents, systemInstruction) {
    if (!isGemmaModel(modelId))
        return { contents, systemInstruction };
    const cleaned = contents
        .map((entry) => {
        const parts = entry.parts.filter(part => !part.functionCall && !part.functionResponse);
        if (parts.length === 0)
            return null;
        return { ...entry, parts };
    })
        .filter((entry) => entry !== null);
    const safeContents = cleaned.length > 0
        ? cleaned
        : [{ role: 'user', parts: [{ text: '' }] }];
    const systemText = systemInstructionText(systemInstruction);
    if (!systemText)
        return { contents: safeContents };
    return {
        contents: [
            { role: 'user', parts: [{ text: systemText }] },
            ...safeContents,
        ],
    };
}
function safeParseObject(raw) {
    try {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
            return parsed;
        }
        return { value: parsed };
    }
    catch {
        return { value: raw };
    }
}
function normalizeGeminiArgs(args) {
    if (typeof args === 'string')
        return args;
    return JSON.stringify(args ?? {});
}
function toGeminiFinishReason(finishReason) {
    const r = (finishReason ?? '').toUpperCase();
    if (!r)
        return 'stop';
    if (r === 'MAX_TOKENS')
        return 'length';
    if (r === 'SAFETY' || r === 'RECITATION' || r === 'BLOCKLIST' || r === 'PROHIBITED_CONTENT' || r === 'SPII') {
        return 'content_filter';
    }
    return 'stop';
}
// Google Gemini accepts only a subset of JSON Schema (~OpenAPI 3.0).
// Strip fields that opencode / other strict-JSON-Schema clients send but
// Google rejects with 400 "Unknown name '<field>'".
const GEMINI_UNSUPPORTED_SCHEMA_KEYS = new Set([
    '$schema', '$id', '$ref', '$defs', '$comment',
    'definitions',
    'exclusiveMinimum', 'exclusiveMaximum',
    'patternProperties', 'unevaluatedProperties', 'unevaluatedItems',
    'if', 'then', 'else',
    'contentEncoding', 'contentMediaType', 'contentSchema',
    'dependentRequired', 'dependentSchemas', 'dependencies',
    'additionalProperties',
    'examples', 'const', 'readOnly', 'writeOnly',
    'uniqueItems',
    'not', 'allOf', 'oneOf',
    'prefixItems',
    'contains', 'minContains', 'maxContains',
    'propertyNames',
    'multipleOf',
    'deprecated',
]);
const VENDOR_EXTENSION_SCHEMA_KEY = /^x-/i;
export function sanitizeForGemini(schema) {
    return sanitizeForGeminiSchema(schema, false);
}
function sanitizeForGeminiSchema(schema, insidePropertiesMap) {
    if (Array.isArray(schema)) {
        return schema.map(s => sanitizeForGeminiSchema(s, false));
    }
    if (schema && typeof schema === 'object') {
        const out = {};
        for (const [k, v] of Object.entries(schema)) {
            if (insidePropertiesMap) {
                out[k] = sanitizeForGeminiSchema(v, false);
                continue;
            }
            if (GEMINI_UNSUPPORTED_SCHEMA_KEYS.has(k) || VENDOR_EXTENSION_SCHEMA_KEY.test(k))
                continue;
            out[k] = sanitizeForGeminiSchema(v, k === 'properties');
        }
        return out;
    }
    return schema;
}
// OpenAI clients can't express Gemini's native Google Search grounding, so we
// treat a tool named `google_search` (a few spellings) as the signal to enable
// it. It maps to Gemini's `{ google_search: {} }` tool rather than a function
// declaration, and can ride alongside real function tools in the same array. (#59)
const GROUNDING_TOOL_NAMES = new Set(['google_search', 'googlesearch', 'google_search_retrieval']);
/**
 * Extended generationConfig knobs translated from the OpenAI wire: topK,
 * seed, penalties, and structured output. JSON output conflicts with function
 * calling on Gemini ("Function calling with a response mime type:
 * 'application/json' is unsupported"), so response_format is only applied on
 * tool-free requests. Params Gemini has no equivalent for (min_p, logit_bias,
 * logprobs…) are dropped by the platform policy in lib/sampling-params.ts and
 * are ignored here. Exported for tests.
 */
export function toGeminiExtendedConfig(options) {
    const out = {
        topK: options?.top_k,
        seed: options?.seed,
        presencePenalty: options?.presence_penalty,
        frequencyPenalty: options?.frequency_penalty,
    };
    const rf = options?.response_format;
    // Count only real function declarations, mirroring hasFunctionDeclarations:
    // grounding pseudo-tools (google_search etc.) are converted to a grounding
    // block by toGeminiTools and never conflict with responseMimeType — raw
    // tools.length was silently dropping structured output for grounding-only
    // requests.
    const hasTools = (options?.tools ?? []).some(t => !GROUNDING_TOOL_NAMES.has(t.function.name.toLowerCase()));
    if (rf && !hasTools) {
        out.responseMimeType = 'application/json';
        const schema = rf.type === 'json_schema' ? rf.json_schema?.schema : undefined;
        if (schema)
            out.responseSchema = sanitizeForGemini(schema);
    }
    return out;
}
function toGeminiTools(tools) {
    if (!tools || tools.length === 0)
        return undefined;
    const functionDeclarations = [];
    let grounding = false;
    for (const t of tools) {
        if (GROUNDING_TOOL_NAMES.has(t.function.name.toLowerCase())) {
            grounding = true;
            continue;
        }
        functionDeclarations.push({
            name: t.function.name,
            description: t.function.description,
            parameters: sanitizeForGemini(t.function.parameters),
        });
    }
    const out = [];
    if (grounding)
        out.push({ google_search: {} });
    if (functionDeclarations.length > 0)
        out.push({ functionDeclarations });
    return out.length > 0 ? out : undefined;
}
function hasFunctionDeclarations(tools) {
    return tools?.some(t => 'functionDeclarations' in t) ?? false;
}
function toGeminiToolConfig(toolChoice) {
    if (!toolChoice)
        return undefined;
    if (typeof toolChoice === 'string') {
        const mode = toolChoice === 'none'
            ? 'NONE'
            : toolChoice === 'required'
                ? 'ANY'
                : 'AUTO';
        return { functionCallingConfig: { mode } };
    }
    return {
        functionCallingConfig: {
            mode: 'ANY',
            allowedFunctionNames: [toolChoice.function.name],
        },
    };
}
const MAX_IMAGE_BYTES = 8 * 1024 * 1024; // 8 MB cap on fetched/inlined images
// Pull the URL out of an OpenAI image content block. Accepts both the object
// form `{ image_url: { url } }` and the shorthand `{ image_url: '...' }`.
function extractImageUrl(block) {
    const iu = block?.image_url;
    if (typeof iu === 'string')
        return iu;
    if (iu && typeof iu.url === 'string')
        return iu.url;
    return undefined;
}
// Convert an image URL to a Gemini inlineData part. Handles base64 `data:` URLs
// directly; for `http(s)` URLs we fetch and inline because the Gemini API does
// not fetch external URLs itself. Fetching a user-supplied URL is a minor SSRF
// surface, acceptable for a single-user self-hosted proxy; we still restrict to
// http/https and cap the size. Returns null (part skipped) on any failure.
async function imageUrlToInlineData(url) {
    const dataMatch = /^data:([^;,]+)?(;base64)?,(.*)$/s.exec(url);
    if (dataMatch) {
        const mimeType = dataMatch[1] || 'application/octet-stream';
        const isBase64 = Boolean(dataMatch[2]);
        const payload = dataMatch[3] ?? '';
        const data = isBase64
            ? payload
            : Buffer.from(decodeURIComponent(payload)).toString('base64');
        return { mimeType, data };
    }
    if (/^https?:\/\//i.test(url)) {
        try {
            // Internal helper that turns an image URL into inline data for the
            // Gemini request body. No formal timeout — relies on the platform's
            // own default. Use a 30s cap to avoid hanging the whole request when
            // an image host stalls; classify as `image` for triage.
            const res = await proxyFetch(url, { signal: AbortSignal.timeout(30_000) }, 'google', 'image', 30_000);
            if (!res.ok)
                return null;
            const buf = Buffer.from(await res.arrayBuffer());
            if (buf.length === 0 || buf.length > MAX_IMAGE_BYTES)
                return null;
            const mimeType = res.headers.get('content-type')?.split(';')[0]?.trim() || 'image/jpeg';
            return { mimeType, data: buf.toString('base64') };
        }
        catch {
            return null;
        }
    }
    return null;
}
// Build Gemini parts for a user message: joined text first, then any images as
// inlineData. Non-array content (string/null) collapses to a single text part.
async function userContentToParts(content) {
    const parts = [];
    const text = contentToString(content);
    if (text.length > 0)
        parts.push({ text });
    if (Array.isArray(content)) {
        for (const block of content) {
            const type = block?.type;
            if (type !== 'image_url' && type !== 'image')
                continue;
            const url = extractImageUrl(block);
            if (!url)
                continue;
            const inlineData = await imageUrlToInlineData(url);
            if (inlineData)
                parts.push({ inlineData });
        }
    }
    // Gemini rejects empty `parts`; keep at least one (possibly empty) text part.
    if (parts.length === 0)
        parts.push({ text: '' });
    return parts;
}
// Translate OpenAI messages to Gemini format. Content may arrive as a string,
// null, or the OpenAI multimodal array envelope. System/assistant/tool messages
// flatten to text; user messages additionally carry images as inlineData parts.
async function toGeminiContents(messages) {
    const systemMessages = messages
        .filter(m => m.role === 'system')
        .map(m => contentToString(m.content))
        .filter(s => s.length > 0);
    const toolNameByCallId = new Map();
    for (const m of messages) {
        for (const tc of m.tool_calls ?? []) {
            toolNameByCallId.set(tc.id, tc.function.name);
        }
    }
    const contents = (await Promise.all(messages
        .filter(m => m.role !== 'system')
        .map(async (m) => {
        if (m.role === 'assistant') {
            const parts = [];
            const assistantText = contentToString(m.content);
            if (assistantText.length > 0) {
                parts.push({ text: assistantText });
            }
            for (const call of m.tool_calls ?? []) {
                // Prefer a signature the client preserved; otherwise recover the one
                // we cached when this call was first produced (OpenAI-format clients
                // drop the field, so this is the common path for Gemini multi-turn).
                const sig = call.thought_signature ?? recallThoughtSig(call.id, call.function.name, call.function.arguments);
                parts.push({
                    thoughtSignature: sig,
                    functionCall: {
                        id: call.id,
                        name: call.function.name,
                        args: safeParseObject(call.function.arguments),
                    },
                });
            }
            if (parts.length === 0)
                return null;
            return {
                role: 'model',
                parts,
            };
        }
        if (m.role === 'tool') {
            const toolCallId = m.tool_call_id;
            if (!toolCallId)
                return null;
            const toolName = m.name ?? toolNameByCallId.get(toolCallId) ?? 'tool';
            const response = safeParseObject(contentToString(m.content));
            return {
                role: 'user',
                parts: [{
                        functionResponse: {
                            id: toolCallId,
                            name: toolName,
                            response,
                        },
                    }],
            };
        }
        return {
            role: 'user',
            parts: await userContentToParts(m.content),
        };
    })))
        .filter((entry) => entry !== null);
    return {
        contents,
        systemInstruction: systemMessages.length > 0
            ? { parts: [{ text: systemMessages.join('\n\n') }] }
            : undefined,
    };
}
function extractToolCalls(parts) {
    const calls = [];
    if (!parts)
        return calls;
    let fallbackIndex = 0;
    for (const part of parts) {
        if (!part.functionCall?.name)
            continue;
        const id = part.functionCall.id ?? `call_${Date.now()}_${fallbackIndex++}`;
        const args = normalizeGeminiArgs(part.functionCall.args);
        // Cache the signature keyed by the id we hand the client, so when the client
        // echoes this call back (without the signature, as OpenAI format requires)
        // we can re-attach it and Gemini accepts the history.
        rememberThoughtSig(id, part.thoughtSignature, part.functionCall.name, args);
        calls.push({
            id,
            type: 'function',
            function: {
                name: part.functionCall.name,
                arguments: args,
            },
            thought_signature: part.thoughtSignature,
        });
    }
    return calls;
}
function extractText(parts) {
    if (!parts)
        return null;
    const text = parts
        .filter(p => p.thought !== true)
        .map(p => p.text ?? '')
        .join('');
    return text.length > 0 ? text : null;
}
function extractReasoningContent(parts) {
    if (!parts)
        return null;
    const text = parts
        .filter(p => p.thought === true)
        .map(p => p.text ?? '')
        .join('');
    return text.length > 0 ? text : null;
}
function toGeminiStopSequences(stop) {
    if (!stop)
        return undefined;
    return Array.isArray(stop) ? stop : [stop];
}
export class GoogleProvider extends BaseProvider {
    platform = 'google';
    name = 'Google AI Studio';
    timeoutMs;
    constructor(opts = {}) {
        super();
        this.timeoutMs = opts.timeoutMs ?? 15000;
    }
    async chatCompletion(apiKey, messages, modelId, options, quotaContext) {
        const translated = await toGeminiContents(messages);
        const request = contentsForModel(modelId, translated.contents, translated.systemInstruction);
        const modelOptions = optionsForModel(modelId, options);
        const tools = toGeminiTools(modelOptions?.tools);
        const body = {
            contents: request.contents,
            generationConfig: {
                temperature: modelOptions?.temperature,
                maxOutputTokens: modelOptions?.max_tokens,
                topP: modelOptions?.top_p,
                stopSequences: toGeminiStopSequences(modelOptions?.stop),
                ...toGeminiExtendedConfig(modelOptions),
            },
            tools,
            // functionCallingConfig is only valid when real function tools are present;
            // a grounding-only request (just google_search) must omit it. (#59)
            toolConfig: hasFunctionDeclarations(tools) ? toGeminiToolConfig(modelOptions?.tool_choice) : undefined,
        };
        if (request.systemInstruction)
            body.systemInstruction = request.systemInstruction;
        const url = `${API_BASE}/models/${modelId}:generateContent?key=${apiKey}`;
        const res = await this.fetchWithTimeout(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        }, options?.timeoutMs ?? this.timeoutMs);
        recordQuotaObservationsFromResponse(res, {
            platform: this.platform,
            keyId: quotaContext?.keyId,
            providerAccountId: quotaContext?.providerAccountId,
            modelId,
            quotaPoolKey: quotaContext?.quotaPoolKey,
            endpoint: 'chat/completions',
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw providerHttpError(res, `Google API error ${res.status}: ${err.error?.message ?? res.statusText}`);
        }
        const data = await res.json();
        const candidate = data.candidates?.[0];
        const parts = candidate?.content?.parts;
        const toolCalls = extractToolCalls(parts);
        const text = extractText(parts);
        const reasoningContent = extractReasoningContent(parts);
        const usage = {
            prompt_tokens: data.usageMetadata?.promptTokenCount ?? 0,
            completion_tokens: data.usageMetadata?.candidatesTokenCount ?? 0,
            total_tokens: data.usageMetadata?.totalTokenCount ?? 0,
        };
        return {
            id: this.makeId(),
            object: 'chat.completion',
            created: Math.floor(Date.now() / 1000),
            model: modelId,
            choices: [{
                    index: 0,
                    message: {
                        role: 'assistant',
                        content: text,
                        ...(reasoningContent ? { reasoning_content: reasoningContent } : {}),
                        ...(toolCalls.length > 0 ? { tool_calls: toolCalls } : {}),
                    },
                    finish_reason: toolCalls.length > 0 ? 'tool_calls' : toGeminiFinishReason(candidate?.finishReason),
                }],
            usage,
            _routed_via: { platform: 'google', model: modelId },
        };
    }
    async *streamChatCompletion(apiKey, messages, modelId, options, quotaContext) {
        const translated = await toGeminiContents(messages);
        const request = contentsForModel(modelId, translated.contents, translated.systemInstruction);
        const modelOptions = optionsForModel(modelId, options);
        const tools = toGeminiTools(modelOptions?.tools);
        const body = {
            contents: request.contents,
            generationConfig: {
                temperature: modelOptions?.temperature,
                maxOutputTokens: modelOptions?.max_tokens,
                topP: modelOptions?.top_p,
                stopSequences: toGeminiStopSequences(modelOptions?.stop),
                ...toGeminiExtendedConfig(modelOptions),
            },
            tools,
            toolConfig: hasFunctionDeclarations(tools) ? toGeminiToolConfig(modelOptions?.tool_choice) : undefined,
        };
        if (request.systemInstruction)
            body.systemInstruction = request.systemInstruction;
        const url = `${API_BASE}/models/${modelId}:streamGenerateContent?alt=sse&key=${apiKey}`;
        const res = await this.fetchWithTimeout(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        }, options?.timeoutMs ?? this.timeoutMs);
        recordQuotaObservationsFromResponse(res, {
            platform: this.platform,
            keyId: quotaContext?.keyId,
            providerAccountId: quotaContext?.providerAccountId,
            modelId,
            quotaPoolKey: quotaContext?.quotaPoolKey,
            endpoint: 'chat/completions',
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw providerHttpError(res, `Google API error ${res.status}: ${err.error?.message ?? res.statusText}`);
        }
        const reader = res.body?.getReader();
        if (!reader)
            throw new Error('No response body');
        const decoder = new TextDecoder();
        const id = this.makeId();
        let buffer = '';
        let emittedFinish = false;
        let sawToolCalls = false;
        const seenToolCallKeys = new Set();
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() ?? '';
                for (const line of lines) {
                    const trimmed = line.trim();
                    if (!trimmed || !trimmed.startsWith('data: '))
                        continue;
                    const raw = trimmed.slice(6);
                    if (raw === '[DONE]') {
                        if (!emittedFinish) {
                            emittedFinish = true;
                            yield {
                                id,
                                object: 'chat.completion.chunk',
                                created: Math.floor(Date.now() / 1000),
                                model: modelId,
                                choices: [{
                                        index: 0,
                                        delta: {},
                                        finish_reason: sawToolCalls ? 'tool_calls' : 'stop',
                                    }],
                            };
                        }
                        return;
                    }
                    // Skip malformed SSE frames instead of aborting the whole stream.
                    // Matches the defensive parse in openai-compat / cohere / cloudflare:
                    // a single corrupt chunk shouldn't take down the rest of the response.
                    let chunk;
                    try {
                        chunk = JSON.parse(raw);
                    }
                    catch {
                        continue;
                    }
                    const candidate = chunk.candidates?.[0];
                    const parts = candidate?.content?.parts ?? [];
                    const text = extractText(parts);
                    const reasoningContent = extractReasoningContent(parts);
                    const toolCalls = extractToolCalls(parts).filter(call => {
                        const key = `${call.id}:${call.function.name}:${call.function.arguments}`;
                        if (seenToolCallKeys.has(key))
                            return false;
                        seenToolCallKeys.add(key);
                        return true;
                    });
                    if ((text && text.length > 0) || (reasoningContent && reasoningContent.length > 0) || toolCalls.length > 0) {
                        sawToolCalls = sawToolCalls || toolCalls.length > 0;
                        yield {
                            id,
                            object: 'chat.completion.chunk',
                            created: Math.floor(Date.now() / 1000),
                            model: modelId,
                            choices: [{
                                    index: 0,
                                    delta: {
                                        ...(text ? { content: text } : {}),
                                        ...(reasoningContent ? { reasoning_content: reasoningContent } : {}),
                                        ...(toolCalls.length > 0 ? { tool_calls: toolCalls } : {}),
                                    },
                                    finish_reason: null,
                                }],
                        };
                    }
                    if (candidate?.finishReason && !emittedFinish) {
                        emittedFinish = true;
                        yield {
                            id,
                            object: 'chat.completion.chunk',
                            created: Math.floor(Date.now() / 1000),
                            model: modelId,
                            choices: [{
                                    index: 0,
                                    delta: {},
                                    finish_reason: sawToolCalls ? 'tool_calls' : toGeminiFinishReason(candidate.finishReason),
                                }],
                        };
                        return;
                    }
                }
            }
        }
        finally {
            // Runs on normal completion, on the early returns above, AND when the
            // consumer abandons the generator mid-stream (a client disconnect breaks
            // the route pump's for-await, which calls gen.return() at the yield
            // point). Without it the Gemini generation kept running upstream —
            // quota burning with nobody reading — because this adapter reads the
            // body itself instead of going through readSseStream's shared cleanup.
            reader.cancel().catch(() => { });
        }
        if (!emittedFinish) {
            yield {
                id,
                object: 'chat.completion.chunk',
                created: Math.floor(Date.now() / 1000),
                model: modelId,
                choices: [{
                        index: 0,
                        delta: {},
                        finish_reason: sawToolCalls ? 'tool_calls' : 'stop',
                    }],
            };
        }
    }
    async validateKey(apiKey, quotaContext) {
        // Transport errors propagate — health.ts marks status='error' without
        // counting toward auto-disable.
        const res = await this.fetchWithTimeout(`${API_BASE}/models?key=${apiKey}`, { method: 'GET' }, 10000);
        recordQuotaObservationsFromResponse(res, {
            platform: this.platform,
            keyId: quotaContext?.keyId,
            providerAccountId: quotaContext?.providerAccountId,
            modelId: quotaContext?.modelId,
            quotaPoolKey: quotaContext?.quotaPoolKey,
            endpoint: 'models',
        });
        if (res.ok)
            return true;
        let body = null;
        try {
            body = (await res.json());
        }
        catch { /* non-JSON error body */ }
        const err = body?.error;
        const details = Array.isArray(err?.details) ? err.details : [];
        const reason = details.find(d => typeof d?.reason === 'string')?.reason;
        const message = typeof err?.message === 'string' ? err.message : '';
        const gStatus = typeof err?.status === 'string' ? err.status : undefined;
        const badCredentials = res.status === 401 ||
            reason === 'API_KEY_INVALID' ||
            /API key not valid|API key expired|API_KEY_INVALID/i.test(message);
        if (badCredentials) {
            console.warn(`[Google] validateKey: key rejected as invalid (HTTP ${res.status}${reason ? ` ${reason}` : ''})`);
            return false;
        }
        console.warn(`[Google] validateKey: inconclusive HTTP ${res.status} (${gStatus ?? 'UNKNOWN'}${reason ? `/${reason}` : ''}): ${message.slice(0, 200)} ` +
            `— treating as 'error', not auto-disabling (the key may be valid but blocked by region/permission/restriction on this host).`);
        throw new Error(`Google key validation inconclusive (HTTP ${res.status}${gStatus ? ` ${gStatus}` : ''})`);
    }
}
//# sourceMappingURL=google.js.map