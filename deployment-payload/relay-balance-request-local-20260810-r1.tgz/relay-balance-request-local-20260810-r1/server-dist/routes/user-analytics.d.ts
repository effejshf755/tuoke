export declare const userAnalyticsRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=user-analytics.d.ts.map