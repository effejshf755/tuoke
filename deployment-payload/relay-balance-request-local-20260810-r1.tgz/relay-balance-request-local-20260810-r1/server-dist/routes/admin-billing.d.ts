export declare const adminBillingRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=admin-billing.d.ts.map