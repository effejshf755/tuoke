export declare const adminWalletRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=admin-wallet.d.ts.map