import { Router } from 'express';
import { getDb } from '../db/index.js';
import { FINAL_REQUEST_RESULT_SQL, UNADJUSTED_NON_FINAL_FALLBACK_ATTEMPT_SQL, } from '../lib/request-log.js';
export const adminDashboardRouter = Router();
function since(range) { const days = range === 'today' ? 1 : range === '7d' ? 7 : range === '30d' ? 30 : 0; return days ? new Date(Date.now() - days * 86400000).toISOString().slice(0, 19).replace('T', ' ') : null; }
adminDashboardRouter.get('/summary', (req, res) => {
    const db = getDb();
    const range = typeof req.query.range === 'string' ? req.query.range : '30d';
    const cutoff = since(range);
    const args = cutoff ? [cutoff] : [];
    const requestWhere = ` WHERE ${FINAL_REQUEST_RESULT_SQL}${cutoff ? ' AND r.created_at >= ?' : ''}`;
    const users = db.prepare('SELECT COUNT(*) total, SUM(CASE WHEN status = \'active\' THEN 1 ELSE 0 END) enabled FROM users').get();
    const keys = db.prepare("SELECT COUNT(*) total, SUM(CASE WHEN status = 'active' AND enabled = 1 AND (expires_at IS NULL OR expires_at > datetime('now')) THEN 1 ELSE 0 END) active FROM consumer_api_keys").get();
    const stats = db.prepare(`SELECT COUNT(*) requests, SUM(CASE WHEN r.status='success' THEN 1 ELSE 0 END) success, SUM(CASE WHEN r.status='error' THEN 1 ELSE 0 END) failures, COALESCE(SUM(r.input_tokens),0) input, COALESCE(SUM(r.output_tokens),0) output, COALESCE(SUM(r.billing_amount_micro),0) revenue FROM requests r${requestWhere}`).get(...args);
    const cachedSince = cutoff ? `${cutoff.slice(0, 13)}:00:00` : null;
    const cachedAggregate = cutoff
        ? Number(db.prepare(`
        SELECT COALESCE(SUM(cached_input_tokens), 0) cached
        FROM request_hourly
        WHERE hour >= ?
      `).get(cachedSince).cached)
        : Number(db.prepare(`
        SELECT value FROM settings WHERE key = 'total_cached_input_tokens'
      `).get()?.value ?? 0) || 0;
    // A recovered fallback attempt remains in the raw table for diagnostics,
    // but its cache usage is not part of the final user request. Older rows may
    // predate the durable aggregate correction marker, so subtract only those
    // unadjusted attempts here. The marker makes this read-time compatibility
    // correction safe to repeat.
    const recoveredCached = db.prepare(`
    SELECT COALESCE(SUM(r.cached_input_tokens), 0) cached
    FROM requests r
    WHERE ${cachedSince ? 'r.created_at >= ? AND' : ''}
      ${UNADJUSTED_NON_FINAL_FALLBACK_ATTEMPT_SQL}
  `).get(...(cachedSince ? [cachedSince] : []));
    stats.cached = Math.max(0, cachedAggregate - Number(recoveredCached.cached ?? 0));
    const wallet = db.prepare('SELECT COALESCE(SUM(balance_micro),0) balance, COALESCE(SUM(reserved_balance_micro),0) reserved FROM users').get();
    const recharge = db.prepare("SELECT COALESCE(SUM(amount_micro),0) total FROM recharge_orders WHERE status = 'paid'").get();
    const models = db.prepare(`SELECT r.platform, r.model_id model, COUNT(*) requests, COALESCE(SUM(r.input_tokens+r.output_tokens),0) tokens, COALESCE(SUM(r.billing_amount_micro),0) revenue FROM requests r${requestWhere} GROUP BY r.platform, r.model_id ORDER BY requests DESC LIMIT 10`).all(...args);
    const providers = db.prepare(`SELECT r.platform, COUNT(*) requests, ROUND(100.0 * SUM(CASE WHEN r.status='success' THEN 1 ELSE 0 END) / COUNT(*), 1) success_rate FROM requests r${requestWhere} GROUP BY r.platform ORDER BY requests DESC`).all(...args);
    // Keep attempt-level errors in storage for routing diagnostics, while the
    // dashboard reports only final request outcomes. The routing trace is an
    // exact chain marker; a time-window heuristic can hide unrelated failures.
    const failures = db.prepare(`
    SELECT r.id, r.created_at created_at,
           CASE WHEN u.deleted_at IS NOT NULL THEN '已注销用户' ELSE u.email END AS email,
           r.model_id model,
           r.platform, r.status, substr(COALESCE(r.error,''),1,300) error
    FROM requests r
    LEFT JOIN users u ON u.id = r.consumer_user_id
    WHERE r.status = 'error'
      ${cutoff ? 'AND r.created_at >= ?' : ''}
      AND ${FINAL_REQUEST_RESULT_SQL}
    ORDER BY r.id DESC
    LIMIT 100
  `).all(...args);
    res.json({ users, keys, stats: { ...stats, successRate: stats.requests ? Math.round(stats.success / stats.requests * 1000) / 10 : 0 }, wallet, recharge, models, providers, failures });
});
//# sourceMappingURL=admin-dashboard.js.map