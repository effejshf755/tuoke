import { Router } from 'express';
import { z } from 'zod';
import multer from 'multer';
import path from 'path';
import { getDb } from '../db/index.js';
import { resolveProvider } from '../providers/index.js';
import { encrypt, decrypt, maskKey } from '../lib/crypto.js';
import { parseKeysFromFile, stripJsoncComments, stripTrailingCommas } from '../lib/key-parser.js';
import { assessProviderUrl } from '../lib/url-guard.js';
import { ensureModelInProfiles } from '../services/profile-models.js';
export const keysRouter = Router();
// Active providers — must match providers/index.ts registrations + shared/types.ts Platform.
// Moonshot and MiniMax direct integrations were dropped in V4. HuggingFace
// was dropped in V4 and re-added in V13 via the router.huggingface.co route.
// SambaNova was dropped in V23 (free tier permanently retired).
const PLATFORMS = [
    'google', 'groq', 'cerebras', 'nvidia', 'mistral', 'deepseek',
    'openrouter', 'github', 'cohere', 'cloudflare', 'zhipu', 'ollama',
    'kilo', 'pollinations', 'llm7', 'huggingface', 'opencode', 'ovh', 'agnes', 'reka', 'siliconflow',
    'routeway', 'bazaarlink', 'ainative', 'aion', 'requesty', 'navy', 'nara', 'sealion', 'aihorde', 'custom',
];
const ALLOWED_IMPORT_EXTENSIONS = new Set(['.env', '.json', '.jsonc', '.md', '.txt', '.csv']);
const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024, files: 10 },
    fileFilter: (_req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        if (!ALLOWED_IMPORT_EXTENSIONS.has(ext)) {
            cb(new Error('Unsupported file type'));
            return;
        }
        cb(null, true);
    },
});
// `key` is optional so keyless providers (Kilo's anonymous gateway) can be added
// without one; the handler enforces a non-empty key for everyone else.
const addKeySchema = z.object({
    platform: z.enum(PLATFORMS),
    key: z.string().optional(),
    label: z.string().optional(),
});
const updateKeySchema = z.object({
    enabled: z.boolean().optional(),
    label: z.string().optional(),
}).refine(data => data.enabled !== undefined || data.label !== undefined, {
    message: 'At least one of enabled or label must be provided',
});
const importKeySchema = z.object({
    keyName: z.string().optional(),
    keyValue: z.string().min(1),
    platform: z.enum(PLATFORMS),
});
function handleUploadError(err, res, next) {
    if (!err)
        return false;
    if (err.code === 'LIMIT_FILE_SIZE') {
        res.status(413).json({ error: { message: 'File too large. Maximum size is 5MB' } });
        return true;
    }
    if (err.code === 'LIMIT_FILE_COUNT') {
        res.status(413).json({ error: { message: 'Too many files. Maximum is 10' } });
        return true;
    }
    if (err.message?.includes('Unsupported file type')) {
        res.status(400).json({ error: { message: 'Unsupported file type' } });
        return true;
    }
    next(err);
    return true;
}
function parseUpload(file) {
    const content = file.buffer.toString('utf8');
    if (!content.trim()) {
        throw Object.assign(new Error('File contains no data'), { status: 400 });
    }
    if (/\.jsonc?$/i.test(file.originalname)) {
        try {
            JSON.parse(stripTrailingCommas(stripJsoncComments(content)));
        }
        catch {
            throw Object.assign(new Error('Invalid JSON format'), { status: 400 });
        }
    }
    return parseKeysFromFile(content, file.originalname);
}
function splitRawKey(rawKey) {
    const eqIndex = rawKey.indexOf('=');
    return {
        keyName: eqIndex === -1 ? rawKey : rawKey.slice(0, eqIndex),
        keyValue: eqIndex === -1 ? '' : rawKey.slice(eqIndex + 1),
    };
}
function insertImportedKey(platform, keyName, keyValue) {
    if (platform === 'custom') {
        throw new Error('Custom providers must be added with a base URL');
    }
    if (!resolveProvider(platform)) {
        throw new Error(`Unsupported platform: ${platform}`);
    }
    const db = getDb();
    const { encrypted, iv, authTag } = encrypt(keyValue.trim());
    db.prepare(`
    INSERT INTO api_keys (platform, label, encrypted_key, iv, auth_tag, status, enabled)
    VALUES (?, ?, ?, ?, ?, 'unknown', 1)
  `).run(platform, keyName, encrypted, iv, authTag);
}
// Count enabled catalog models for a platform. Used to warn when a key is
// added for a provider that has zero models in the operator's current catalog
// tier — the Agnes case (#438): the provider is registered and selectable, but
// its models ship in the premium/live catalog and only appear for free-tier
// installs once they age into the monthly catalog, so a fresh install adds the
// key and silently sees nothing.
function enabledModelCount(platform) {
    const db = getDb();
    const row = db.prepare('SELECT COUNT(*) AS c FROM models WHERE platform = ? AND enabled = 1').get(platform);
    return row.c;
}
// Non-null when the just-added key has no usable models yet, so the client can
// explain the silence instead of leaving the user staring at an empty list.
function noModelsNotice(platform) {
    if (enabledModelCount(platform) > 0)
        return undefined;
    return (`Key saved, but no ${platform} models are in your current catalog yet. ` +
        `Newer providers are published to the premium catalog first and appear ` +
        `for free-tier installs once they age into the monthly catalog. Add a ` +
        `Premium license key to use them now, or add ${platform} as a custom ` +
        `OpenAI-compatible provider with its base URL.`);
}
// List all keys (masked)
keysRouter.get('/', (_req, res) => {
    const db = getDb();
    const rows = db.prepare("SELECT * FROM api_keys WHERE role = 'provider' ORDER BY created_at DESC").all();
    const customModels = [
        ...db.prepare(`
      SELECT key_id, id, 'chat' AS kind, model_id, display_name, NULL AS family
        FROM models
       WHERE platform = 'custom' AND key_id IS NOT NULL
    `).all(),
        ...db.prepare(`
      SELECT key_id, id, 'embedding' AS kind, model_id, display_name, family
        FROM embedding_models
       WHERE platform = 'custom' AND key_id IS NOT NULL
    `).all(),
        ...db.prepare(`
      SELECT key_id, id, modality AS kind, model_id, display_name, NULL AS family
        FROM media_models
       WHERE platform = 'custom' AND key_id IS NOT NULL
    `).all(),
    ];
    const modelsByKeyId = new Map();
    for (const m of customModels) {
        const keyId = Number(m.key_id);
        if (!Number.isInteger(keyId))
            continue;
        const list = modelsByKeyId.get(keyId) ?? [];
        list.push({
            id: m.id,
            kind: m.kind,
            modelId: m.model_id,
            displayName: m.display_name,
            family: m.family ?? null,
        });
        modelsByKeyId.set(keyId, list);
    }
    for (const list of modelsByKeyId.values()) {
        list.sort((a, b) => {
            const ka = ['chat', 'embedding', 'image', 'audio'].indexOf(a.kind);
            const kb = ['chat', 'embedding', 'image', 'audio'].indexOf(b.kind);
            return (ka - kb) || String(a.displayName).localeCompare(String(b.displayName));
        });
    }
    const keys = rows.map(row => {
        let maskedKey = '****';
        try {
            const realKey = decrypt(row.encrypted_key, row.iv, row.auth_tag);
            maskedKey = maskKey(realKey);
        }
        catch {
            maskedKey = '[decrypt failed]';
        }
        return {
            id: row.id,
            platform: row.platform,
            label: row.label,
            maskedKey,
            baseUrl: row.base_url ?? null,
            status: row.status,
            enabled: row.enabled === 1,
            keyless: resolveProvider(row.platform)?.keyless === true,
            createdAt: row.created_at,
            lastCheckedAt: row.last_checked_at,
            models: row.platform === 'custom' ? (modelsByKeyId.get(row.id) ?? []) : undefined,
        };
    });
    res.json(keys);
});
// Export keys — returns plaintext keys in the requested format.
// GET /api/keys/export?format=json|env|csv&healthy=true
// The response is the raw file download (Content-Type varies by format).
keysRouter.get('/export', (req, res) => {
    const db = getDb();
    const format = req.query.format ?? 'json';
    const healthyOnly = req.query.healthy === 'true';
    let whereClause = "WHERE role = 'provider'";
    if (healthyOnly) {
        whereClause += " AND status = 'healthy'";
    }
    const rows = db.prepare(`SELECT * FROM api_keys ${whereClause} ORDER BY platform, created_at ASC`).all();
    // Decrypt and filter — only export keys with a real value
    const decryptedKeys = rows
        .map(row => {
        let key = '';
        try {
            key = decrypt(row.encrypted_key, row.iv, row.auth_tag);
        }
        catch {
            key = '';
        }
        return {
            platform: row.platform,
            key,
            label: row.label || '',
            baseUrl: row.base_url || undefined,
        };
    })
        .filter(k => {
        const v = k.key.trim();
        return v.length > 0 && v !== 'no-key';
    });
    if (decryptedKeys.length === 0) {
        res.status(404).json({ error: { message: 'No keys to export' } });
        return;
    }
    if (format === 'env') {
        // .env format: GOOGLE_KEY=xxx\nGROQ_KEY=yyy
        const lines = decryptedKeys.map(k => {
            const envKey = `${k.platform.toUpperCase()}_KEY=${k.key}`;
            return k.label ? `# ${k.label}\n${envKey}` : envKey;
        });
        const content = lines.join('\n\n') + '\n';
        res.setHeader('Content-Type', 'text/plain; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment; filename="freellmapi-keys.env"');
        res.send(content);
        return;
    }
    if (format === 'csv') {
        // CSV format: platform,key,label
        const escCsv = (v) => `"${v.replace(/"/g, '""')}"`;
        // CSV formula-injection guard: a spreadsheet treats a cell that starts with
        // =, +, -, @, tab or CR as a live formula, so a label like `=HYPERLINK(...)`
        // would execute on open. Prefix such cells with a single quote to force them
        // to be read as text. Applied only to free-text fields the user controls
        // (labels); the key value must round-trip verbatim for re-import, and the
        // platform is one of our own fixed enum values.
        const neutralize = (v) => (/^[=+\-@\t\r]/.test(v) ? `'${v}` : v);
        const header = 'platform,key,label';
        const lines = decryptedKeys.map(k => [escCsv(k.platform), escCsv(k.key), escCsv(neutralize(k.label))].join(','));
        const content = [header, ...lines].join('\n') + '\n';
        res.setHeader('Content-Type', 'text/csv; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment; filename="freellmapi-keys.csv"');
        res.send(content);
        return;
    }
    // Default: JSON format (round-trip safe — can be imported directly)
    const jsonExport = {
        version: 1,
        exportedAt: new Date().toISOString(),
        source: 'freellmapi',
        keys: decryptedKeys,
    };
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="freellmapi-keys.json"');
    res.json(jsonExport);
});
// Add a key
keysRouter.post('/', (req, res) => {
    const parsed = addKeySchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: parsed.error.errors.map(e => e.message).join(', ') } });
        return;
    }
    const { platform, label } = parsed.data;
    const isKeyless = resolveProvider(platform)?.keyless === true;
    const rawKey = parsed.data.key?.trim() ?? '';
    if (!isKeyless && !rawKey) {
        res.status(400).json({ error: { message: 'key is required' } });
        return;
    }
    // Keyless providers (Kilo anon) store a sentinel so routing sees the platform
    // as configured; the provider omits the auth header on outgoing calls.
    const keyToStore = isKeyless ? (rawKey || 'no-key') : rawKey;
    const db = getDb();
    // A keyless provider needs only one sentinel row — re-enable an existing one
    // instead of piling up duplicates each time the user clicks "Add".
    if (isKeyless) {
        const existing = db.prepare("SELECT id FROM api_keys WHERE platform = ? AND role = 'provider' LIMIT 1").get(platform);
        if (existing) {
            db.prepare("UPDATE api_keys SET enabled = 1, status = 'unknown' WHERE id = ?").run(existing.id);
            res.status(200).json({
                id: existing.id,
                platform,
                label: label ?? '',
                maskedKey: maskKey(keyToStore),
                status: 'unknown',
                enabled: true,
                modelsAvailable: enabledModelCount(platform),
                notice: noModelsNotice(platform),
            });
            return;
        }
    }
    const { encrypted, iv, authTag } = encrypt(keyToStore);
    const result = db.prepare(`
    INSERT INTO api_keys (platform, label, encrypted_key, iv, auth_tag, status, enabled)
    VALUES (?, ?, ?, ?, ?, 'unknown', 1)
  `).run(platform, label ?? '', encrypted, iv, authTag);
    res.status(201).json({
        id: result.lastInsertRowid,
        platform,
        label: label ?? '',
        maskedKey: maskKey(keyToStore),
        status: 'unknown',
        enabled: true,
        modelsAvailable: enabledModelCount(platform),
        notice: noModelsNotice(platform),
    });
});
// ── Custom OpenAI-compatible providers (#117, #212) ───────────────────────
// User-configured endpoints (llama.cpp / LM Studio / vLLM / Ollama / any
// OpenAI-compatible base_url). Each DISTINCT base_url gets its own 'custom'
// api_keys row, and every registered model binds to its endpoint's key via
// models.key_id — so several custom providers coexist without overwriting
// each other (#212). Re-submitting an existing base_url updates its key/label;
// re-registering an existing model id re-binds it to the submitted endpoint.
// A model can be given as a bare id ("qwen3:4b") or as {model, displayName}.
// `model`/`displayName` (singular) stay supported for older clients; `models`
// (plural) lets one submit bind several model ids to the same endpoint. (#281)
// A custom model can declare its capabilities at registration. `supportsTools`
// defaults to 1 (modern OpenAI-compatible servers — Ollama, vLLM, LM Studio —
// all emit tool calls), `supportsVision` defaults to 0 unless declared. Leaving
// a flag unset keeps the DB default on insert and preserves the stored value on
// re-registration, so a capability the user later toggled isn't clobbered. (#470)
const modelEntrySchema = z.union([
    z.string().min(1),
    z.object({
        model: z.string().min(1),
        displayName: z.string().optional(),
        supportsTools: z.boolean().optional(),
        supportsVision: z.boolean().optional(),
    }),
]);
const customProviderSchema = z.object({
    baseUrl: z.string().url('baseUrl must be a valid URL'),
    model: z.string().optional(),
    models: z.array(modelEntrySchema).optional(),
    displayName: z.string().optional(),
    apiKey: z.string().optional(),
    label: z.string().optional(),
    poolOnly: z.boolean().optional(),
    // Top-level defaults applied to every model in this submit; a per-entry flag
    // (object form) overrides them for that one model.
    supportsTools: z.boolean().optional(),
    supportsVision: z.boolean().optional(),
}).refine(d => d.poolOnly === true || (d.model && d.model.trim().length > 0) || (d.models && d.models.length > 0), { message: 'model or models is required unless poolOnly is true' }).refine(d => d.poolOnly !== true || Boolean(d.apiKey?.trim()), { message: 'apiKey is required when poolOnly is true' });
keysRouter.post('/custom', async (req, res) => {
    const parsed = customProviderSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: parsed.error.errors.map(e => e.message).join(', ') } });
        return;
    }
    const baseUrl = parsed.data.baseUrl.trim().replace(/\/+$/, '');
    // SSRF guard (#440): a base_url is the one user-controlled outbound target.
    // Cloud metadata / link-local addresses are rejected outright; private
    // ranges too when FREEAPI_BLOCK_PRIVATE_PROVIDER_URLS is set. Re-checked
    // at request time in proxyFetch for URLs already in the DB.
    const verdict = await assessProviderUrl(baseUrl);
    if (!verdict.allowed) {
        res.status(400).json({ error: { message: `baseUrl rejected: ${verdict.reason}` } });
        return;
    }
    // Local servers often need no key; keep a sentinel so there's always a bearer.
    const providedKey = parsed.data.apiKey?.trim() || undefined;
    const label = parsed.data.label?.trim() || undefined;
    const poolOnly = parsed.data.poolOnly === true;
    // Flatten singular + plural inputs into one list, dedupe by model id, drop
    // blanks. The singular `displayName` only applies to a lone `model` (it can't
    // sensibly fan out across many ids). Capability flags resolve per-entry first,
    // then fall back to the submit-level defaults, then to undefined (DB default).
    const topTools = parsed.data.supportsTools;
    const topVision = parsed.data.supportsVision;
    const entries = [];
    const seen = new Set();
    const addEntry = (rawId, rawDisplay, tools, vision) => {
        const modelId = rawId.trim();
        if (!modelId || seen.has(modelId))
            return;
        seen.add(modelId);
        entries.push({
            modelId,
            displayName: (rawDisplay?.trim() || modelId),
            supportsTools: tools ?? topTools,
            supportsVision: vision ?? topVision,
        });
    };
    if (parsed.data.model?.trim())
        addEntry(parsed.data.model, parsed.data.displayName);
    for (const m of parsed.data.models ?? []) {
        if (typeof m === 'string')
            addEntry(m);
        else
            addEntry(m.model, m.displayName, m.supportsTools, m.supportsVision);
    }
    if (!poolOnly && entries.length === 0) {
        res.status(400).json({ error: { message: 'model or models is required' } });
        return;
    }
    const db = getDb();
    const endpointExists = db.prepare("SELECT 1 FROM api_keys WHERE platform = 'custom' AND role = 'provider' AND base_url = ? LIMIT 1").get(baseUrl);
    if (poolOnly && !endpointExists) {
        res.status(404).json({ error: { message: 'Custom endpoint not found; register at least one model first' } });
        return;
    }
    const upsert = db.transaction(() => {
        // Every distinct base_url is one custom endpoint. Multiple credential rows
        // with that same base_url form its key pool. Supplying a new secret appends
        // it; re-submitting an identical secret only re-enables/renames that row.
        // A blank key keeps the legacy behaviour used by local keyless endpoints.
        const existingKeys = db.prepare(`
      SELECT id, label, encrypted_key, iv, auth_tag
      FROM api_keys
      WHERE platform = 'custom' AND role = 'provider' AND base_url = ?
      ORDER BY id ASC
    `).all(baseUrl);
        let keyId;
        let storedKeyForMask = providedKey ?? 'no-key';
        if (providedKey) {
            const duplicate = existingKeys.find((candidate) => {
                try {
                    return decrypt(candidate.encrypted_key, candidate.iv, candidate.auth_tag) === providedKey;
                }
                catch {
                    return false;
                }
            });
            if (duplicate) {
                keyId = duplicate.id;
                db.prepare(`
          UPDATE api_keys
          SET label = COALESCE(?, label), status = 'unknown', enabled = 1
          WHERE id = ?
        `).run(label ?? null, duplicate.id);
            }
            else {
                const { encrypted, iv, authTag } = encrypt(providedKey);
                const inheritedLabel = existingKeys[0]?.label || 'Custom';
                const inserted = db.prepare(`
          INSERT INTO api_keys (platform, label, encrypted_key, iv, auth_tag, status, enabled, base_url)
          VALUES ('custom', ?, ?, ?, ?, 'unknown', 1, ?)
        `).run(label ?? inheritedLabel, encrypted, iv, authTag, baseUrl);
                keyId = Number(inserted.lastInsertRowid);
            }
        }
        else if (existingKeys[0]) {
            keyId = existingKeys[0].id;
            try {
                storedKeyForMask = decrypt(existingKeys[0].encrypted_key, existingKeys[0].iv, existingKeys[0].auth_tag);
            }
            catch {
                storedKeyForMask = 'no-key';
            }
            db.prepare(`
        UPDATE api_keys
        SET label = COALESCE(?, label), status = 'unknown', enabled = 1
        WHERE id = ?
      `).run(label ?? null, keyId);
        }
        else {
            const keyToStore = providedKey ?? 'no-key';
            const { encrypted, iv, authTag } = encrypt(keyToStore);
            const r = db.prepare(`
        INSERT INTO api_keys (platform, label, encrypted_key, iv, auth_tag, status, enabled, base_url)
        VALUES ('custom', ?, ?, ?, ?, 'unknown', 1, ?)
      `).run(label ?? 'Custom', encrypted, iv, authTag, baseUrl);
            keyId = Number(r.lastInsertRowid);
            storedKeyForMask = keyToStore;
        }
        const anchor = db.prepare(`
      SELECT id
      FROM api_keys
      WHERE platform = 'custom' AND role = 'provider' AND base_url = ?
      ORDER BY id ASC
      LIMIT 1
    `).get(baseUrl);
        const anchorKeyId = anchor.id;
        const registered = [];
        for (const { modelId, displayName, supportsTools, supportsVision } of entries) {
            // Register each model bound to THIS endpoint's key. Custom models carry no
            // rate limits and sort last in the intelligence preset (size_label tier).
            // Re-registering an existing model id re-binds it (model ids are unique
            // per platform, so one id can't live on two endpoints at once).
            // Capability flags: an unset flag binds NULL so COALESCE picks the insert
            // default (tools 1, vision 0) on a new row and preserves the existing
            // value on re-registration. (#470)
            const toolsParam = supportsTools === undefined ? null : (supportsTools ? 1 : 0);
            const visionParam = supportsVision === undefined ? null : (supportsVision ? 1 : 0);
            db.prepare(`
        INSERT INTO models
          (platform, model_id, display_name, intelligence_rank, speed_rank, size_label,
           rpm_limit, rpd_limit, tpm_limit, tpd_limit, monthly_token_budget, context_window, enabled, key_id,
           supports_tools, supports_vision)
        VALUES ('custom', @modelId, @displayName, 50, 50, 'Custom', NULL, NULL, NULL, NULL, '', NULL, 1, @keyId,
           COALESCE(@tools, 1), COALESCE(@vision, 0))
        ON CONFLICT(platform, model_id)
        DO UPDATE SET
          display_name = excluded.display_name,
          key_id = excluded.key_id,
          enabled = 1,
          supports_tools = COALESCE(@tools, supports_tools),
          supports_vision = COALESCE(@vision, supports_vision)
      `).run({ modelId, displayName, keyId: anchorKeyId, tools: toolsParam, vision: visionParam });
            const modelRow = db.prepare("SELECT id, supports_tools, supports_vision FROM models WHERE platform = 'custom' AND model_id = ?").get(modelId);
            // Append to the fallback chain if not already present.
            const inChain = db.prepare('SELECT 1 FROM fallback_config WHERE model_db_id = ?').get(modelRow.id);
            if (!inChain) {
                const max = db.prepare('SELECT COALESCE(MAX(priority), 0) AS m FROM fallback_config').get();
                db.prepare('INSERT INTO fallback_config (model_db_id, priority, enabled) VALUES (?, ?, 1)').run(modelRow.id, max.m + 1);
            }
            ensureModelInProfiles(db, modelRow.id);
            registered.push({
                modelDbId: modelRow.id,
                model: modelId,
                displayName,
                supportsTools: modelRow.supports_tools === 1,
                supportsVision: modelRow.supports_vision === 1,
            });
        }
        return { keyId, anchorKeyId, registered, storedKeyForMask };
    });
    const { keyId, anchorKeyId, registered, storedKeyForMask } = upsert();
    // `model`/`displayName`/`modelDbId` echo the first model for older clients;
    // `models` carries the full set registered in this call.
    const first = registered[0];
    res.status(201).json({
        success: true,
        keyId,
        anchorKeyId,
        poolOnly,
        modelDbId: first?.modelDbId,
        platform: 'custom',
        baseUrl,
        model: first?.model,
        displayName: first?.displayName,
        supportsTools: first?.supportsTools,
        supportsVision: first?.supportsVision,
        models: registered,
        maskedKey: maskKey(storedKeyForMask),
    });
});
keysRouter.post('/import', (req, res, next) => {
    upload.single('file')(req, res, (err) => {
        if (handleUploadError(err, res, next))
            return;
        try {
            if (!req.file) {
                res.status(400).json({ error: { message: 'No file uploaded' } });
                return;
            }
            const result = parseUpload(req.file);
            const imported = [];
            const skipped = [...result.skipped];
            const errors = [];
            for (const parsedKey of result.keys) {
                const { keyName, keyValue } = splitRawKey(parsedKey.rawKey);
                if (!parsedKey.platform) {
                    skipped.push(keyName);
                    continue;
                }
                const platformParse = z.enum(PLATFORMS).safeParse(parsedKey.platform);
                if (!platformParse.success || platformParse.data === 'custom') {
                    skipped.push(keyName);
                    continue;
                }
                if (!keyValue.trim()) {
                    errors.push({ key: keyName, error: 'keyValue must be at least 1 character' });
                    continue;
                }
                try {
                    insertImportedKey(platformParse.data, keyName, keyValue);
                    imported.push({ keyName, platform: platformParse.data });
                }
                catch (insertErr) {
                    errors.push({ key: keyName, error: insertErr.message });
                }
            }
            res.json({
                imported: imported.length,
                skipped,
                errors,
                total: result.keys.length + result.skipped.length,
            });
        }
        catch (handlerErr) {
            res.status(handlerErr.status ?? 500).json({ error: { message: handlerErr.message } });
        }
    });
});
keysRouter.post('/preview', (req, res, next) => {
    upload.array('files', 10)(req, res, (err) => {
        if (handleUploadError(err, res, next))
            return;
        try {
            const files = req.files;
            if (!files || files.length === 0) {
                res.status(400).json({ error: { message: 'No files uploaded' } });
                return;
            }
            const keys = [];
            const skipped = [];
            // Build a set of existing decrypted key values for duplicate detection
            const db = getDb();
            const existingRows = db.prepare("SELECT encrypted_key, iv, auth_tag FROM api_keys WHERE role = 'provider'").all();
            const existingKeys = new Set();
            for (const row of existingRows) {
                try {
                    existingKeys.add(decrypt(row.encrypted_key, row.iv, row.auth_tag));
                }
                catch { /* skip undecryptable rows */ }
            }
            let duplicateCount = 0;
            for (const file of files) {
                const result = parseUpload(file);
                for (const parsedKey of result.keys) {
                    const { keyName, keyValue } = splitRawKey(parsedKey.rawKey);
                    const isDuplicate = existingKeys.has(keyValue.trim());
                    if (isDuplicate)
                        duplicateCount++;
                    keys.push({
                        keyName,
                        keyValue,
                        detectedPlatform: parsedKey.platform,
                        prefix: parsedKey.prefix,
                        isDuplicate,
                    });
                }
                skipped.push(...result.skipped);
            }
            res.json({ keys, total: keys.length, skipped, duplicates: duplicateCount });
        }
        catch (handlerErr) {
            res.status(handlerErr.status ?? 500).json({ error: { message: handlerErr.message } });
        }
    });
});
keysRouter.post('/import-selected', (req, res) => {
    const parsed = z.object({ keys: z.array(importKeySchema).max(100) }).safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: parsed.error.errors.map(e => e.message).join(', ') } });
        return;
    }
    let imported = 0;
    let duplicateSkipped = 0;
    const errors = [];
    // Build a set of existing decrypted key values for duplicate detection
    const db = getDb();
    const existingRows = db.prepare("SELECT encrypted_key, iv, auth_tag FROM api_keys WHERE role = 'provider'").all();
    const existingKeys = new Set();
    for (const row of existingRows) {
        try {
            existingKeys.add(decrypt(row.encrypted_key, row.iv, row.auth_tag));
        }
        catch { /* skip undecryptable rows */ }
    }
    for (const key of parsed.data.keys) {
        const keyName = key.keyName?.trim() || key.platform;
        if (key.platform === 'custom') {
            errors.push({ key: keyName, error: 'Custom providers must be added with a base URL' });
            continue;
        }
        if (existingKeys.has(key.keyValue.trim())) {
            duplicateSkipped++;
            errors.push({ key: keyName, error: 'Duplicate key — already exists' });
            continue;
        }
        try {
            insertImportedKey(key.platform, keyName, key.keyValue);
            imported++;
            existingKeys.add(key.keyValue.trim());
        }
        catch (err) {
            errors.push({ key: keyName, error: err.message });
        }
    }
    res.json({
        imported,
        skipped: [],
        errors,
        total: parsed.data.keys.length,
    });
});
function removeKeysByIds(ids) {
    const db = getDb();
    const uniqueIds = [...new Set(ids)];
    if (uniqueIds.length === 0)
        return 0;
    const remove = db.transaction(() => {
        let removed = 0;
        for (const id of uniqueIds) {
            const row = db.prepare("SELECT platform, base_url FROM api_keys WHERE id = ? AND role = 'provider'").get(id);
            if (!row)
                continue;
            // A custom endpoint may have several credentials. If this key is the
            // endpoint anchor, move its models to the oldest surviving sibling before
            // deleting it. The existing endpoint cleanup below then removes models
            // only when this was the endpoint's final credential.
            if (row.platform === 'custom' && row.base_url != null) {
                const sibling = db.prepare(`
        SELECT id
          FROM api_keys
         WHERE platform = 'custom'
           AND role = 'provider'
           AND base_url = ?
           AND id <> ?
         ORDER BY id ASC
         LIMIT 1
      `).get(row.base_url, id);
                if (sibling) {
                    db.prepare("UPDATE models SET key_id = ? WHERE platform = 'custom' AND key_id = ?")
                        .run(sibling.id, id);
                    db.prepare("UPDATE embedding_models SET key_id = ? WHERE platform = 'custom' AND key_id = ?")
                        .run(sibling.id, id);
                    db.prepare("UPDATE media_models SET key_id = ? WHERE platform = 'custom' AND key_id = ?")
                        .run(sibling.id, id);
                }
            }
            // Remove the live snapshot for this key, but keep provider_quota_observations
            // as historical monitoring data.
            db.prepare('DELETE FROM provider_quota_state WHERE key_id = ?').run(id);
            db.prepare('DELETE FROM api_keys WHERE id = ?').run(id);
            // Custom models exist only because POST /custom registered them alongside
            // their endpoint key (#117) — they can't route without it. Cascade away
            // the models bound to THIS endpoint (#212); other custom providers keep
            // theirs. Legacy rows (key_id NULL) are swept once no custom keys remain,
            // so they never linger in the fallback chain forever (#189).
            if (row.platform === 'custom') {
                const defaultEmbedding = db.prepare("SELECT value FROM settings WHERE key = 'embeddings_default_family'").get();
                db.prepare("DELETE FROM fallback_config WHERE model_db_id IN (SELECT id FROM models WHERE platform = 'custom' AND key_id = ?)").run(id);
                db.prepare("DELETE FROM models WHERE platform = 'custom' AND key_id = ?").run(id);
                db.prepare("DELETE FROM embedding_models WHERE platform = 'custom' AND key_id = ?").run(id);
                db.prepare("DELETE FROM media_models WHERE platform = 'custom' AND key_id = ?").run(id);
                const remaining = db.prepare("SELECT COUNT(*) AS n FROM api_keys WHERE platform = 'custom' AND role = 'provider'").get();
                if (remaining.n === 0) {
                    db.prepare("DELETE FROM fallback_config WHERE model_db_id IN (SELECT id FROM models WHERE platform = 'custom')").run();
                    db.prepare("DELETE FROM models WHERE platform = 'custom'").run();
                    db.prepare("DELETE FROM embedding_models WHERE platform = 'custom'").run();
                    db.prepare("DELETE FROM media_models WHERE platform = 'custom'").run();
                }
                if (defaultEmbedding) {
                    const stillExists = db.prepare('SELECT 1 FROM embedding_models WHERE family = ? LIMIT 1').get(defaultEmbedding.value);
                    if (!stillExists) {
                        const replacement = db.prepare('SELECT family FROM embedding_models ORDER BY family, priority LIMIT 1').get();
                        if (replacement) {
                            db.prepare("UPDATE settings SET value = ? WHERE key = 'embeddings_default_family'").run(replacement.family);
                        }
                    }
                }
            }
            removed++;
        }
        return removed;
    });
    return remove();
}
// Delete every key belonging to one provider. Kept as a dedicated endpoint so
// the UI can do this atomically instead of issuing dozens of individual calls.
keysRouter.delete('/platform/:platform', (req, res) => {
    const platform = req.params.platform;
    if (!PLATFORMS.includes(platform)) {
        res.status(400).json({ error: { message: `Invalid platform '${platform}'` } });
        return;
    }
    const db = getDb();
    const rows = db.prepare("SELECT id FROM api_keys WHERE platform = ? AND role = 'provider'").all(platform);
    const deleted = removeKeysByIds(rows.map(row => row.id));
    res.json({ success: true, deleted });
});
// Delete a key
keysRouter.delete('/:id', (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
        res.status(400).json({ error: { message: 'Invalid key ID' } });
        return;
    }
    const db = getDb();
    const row = db.prepare("SELECT 1 FROM api_keys WHERE id = ? AND role = 'provider'").get(id);
    if (!row) {
        res.status(404).json({ error: { message: 'Key not found' } });
        return;
    }
    removeKeysByIds([id]);
    res.json({ success: true });
});
// Toggle all keys for a platform
keysRouter.patch('/platform/:platform', (req, res) => {
    const platform = req.params.platform;
    if (!PLATFORMS.includes(platform)) {
        res.status(400).json({ error: { message: `Invalid platform '${platform}'` } });
        return;
    }
    const { enabled } = req.body;
    if (typeof enabled !== 'boolean') {
        res.status(400).json({ error: { message: 'enabled must be a boolean' } });
        return;
    }
    const db = getDb();
    const result = db.prepare("UPDATE api_keys SET enabled = ? WHERE platform = ? AND role = 'provider'").run(enabled ? 1 : 0, platform);
    res.json({ success: true, enabled, updatedKeys: result.changes });
});
// Update key (toggle enable/disable or edit label)
keysRouter.patch('/:id', (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
        res.status(400).json({ error: { message: 'Invalid key ID' } });
        return;
    }
    const parsed = updateKeySchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: parsed.error.errors.map(e => e.message).join(', ') } });
        return;
    }
    const { enabled, label } = parsed.data;
    const updates = [];
    const values = [];
    if (enabled !== undefined) {
        updates.push('enabled = ?');
        values.push(enabled ? 1 : 0);
    }
    if (label !== undefined) {
        updates.push('label = ?');
        values.push(label);
    }
    values.push(id);
    const db = getDb();
    const result = db.prepare(`UPDATE api_keys SET ${updates.join(', ')} WHERE id = ? AND role = 'provider'`).run(...values);
    if (result.changes === 0) {
        res.status(404).json({ error: { message: 'Key not found' } });
        return;
    }
    const response = { success: true };
    if (enabled !== undefined)
        response.enabled = enabled;
    if (label !== undefined)
        response.label = label;
    res.json(response);
});
//# sourceMappingURL=keys.js.map