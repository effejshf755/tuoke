import { randomUUID } from 'node:crypto';
import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/index.js';
import { isPromptCacheCertificationCurrent, relayMappingRequiresExplicitPromptCache, } from '../lib/codex-prompt-cache.js';
import { assessProviderUrl } from '../lib/url-guard.js';
import { CODEX_RELAY_PROTOCOLS, checkCodexRelaySourceKeyHealth, checkCodexRelaySourceModelHealth, checkCodexRelaySourceHealth, createCodexRelaySource, createCodexRelaySourceKey, deleteCodexRelaySource, deleteCodexRelaySourceKey, discoverCodexRelayModelsWithCredentials, discoverCodexRelaySourceModels, getCodexRelaySource, listCodexRelaySources, rotateCodexRelaySourceKey, updateCodexRelaySource, updateCodexRelaySourceKey, } from '../services/codex-relay-sources.js';
import { getCodexRelayOperationalStats, resetCodexRelayOperationalStats, } from '../services/codex-relay-maintenance.js';
import { CODEX_RELAY_LEDGER_CURRENCIES, MAX_CODEX_RELAY_LEDGER_NOTE_LENGTH, createCodexRelayRechargeLedgerEntry, decimalRelayLedgerAmountToMicro, deleteCodexRelayRechargeLedgerEntry, listCodexRelayRechargeLedger, } from '../services/codex-relay-recharge-ledger.js';
import { testCodexRelaySourceCompatibility } from '../services/codex-relay-compatibility.js';
import { testCodexRelayPromptCacheCompatibility, } from '../services/codex-relay-prompt-cache.js';
export const codexRelaySourcesRouter = Router();
const relayProtocolSchema = z.enum(CODEX_RELAY_PROTOCOLS);
const modelMappingSchema = z.object({
    public_model_id: z.string().trim().min(1).max(200),
    upstream_model_id: z.string().trim().min(1).max(300),
    enabled: z.boolean().default(true),
    supports_tools: z.boolean().default(true),
    supports_vision: z.boolean().default(false),
}).strict();
const createSourceSchema = z.object({
    name: z.string().trim().min(1).max(120),
    base_url: z.string().trim().url('base_url must be a valid URL').max(2_000),
    api_key: z.string().trim().min(1).max(20_000),
    codex_group_id: z.number().int().positive(),
    protocol: relayProtocolSchema.optional().default('responses'),
    // Connection tests are optional diagnostics. A newly configured relay may
    // be enabled immediately and real traffic decides whether it can serve each
    // request.
    enabled: z.boolean().optional().default(true),
    priority: z.number().int().min(0).max(1_000_000).optional().default(100),
    model_mappings: z.array(modelMappingSchema).max(200).optional().default([]),
}).strict();
const updateSourceSchema = z.object({
    name: z.string().trim().min(1).max(120).optional(),
    base_url: z.string().trim().url('base_url must be a valid URL').max(2_000).optional(),
    api_key: z.string().trim().min(1).max(20_000).optional(),
    codex_group_id: z.number().int().positive().optional(),
    protocol: relayProtocolSchema.optional(),
    enabled: z.boolean().optional(),
    priority: z.number().int().min(0).max(1_000_000).optional(),
    model_mappings: z.array(modelMappingSchema).max(200).optional(),
}).strict().refine((value) => Object.keys(value).length > 0, {
    message: 'At least one field is required',
});
const createSourceKeySchema = z.object({
    api_key: z.string().trim().min(1).max(20_000),
    label: z.string().trim().min(1).max(120).optional(),
    priority: z.number().int().min(0).max(1_000_000).optional(),
}).strict();
const updateSourceKeySchema = z.object({
    label: z.string().trim().min(1).max(120).optional(),
    enabled: z.boolean().optional(),
    priority: z.number().int().min(0).max(1_000_000).optional(),
}).strict().refine((value) => Object.keys(value).length > 0, {
    message: 'At least one field is required',
});
const rotateSourceKeySchema = z.object({
    api_key: z.string().trim().min(1).max(20_000),
}).strict();
const promptCacheTestSchema = z.object({
    public_model_id: z.string().trim().min(1).max(200),
}).strict();
const compatibilityTestSchema = z.object({
    api_key_id: z.number().int().positive().optional(),
    public_model_id: z.string().trim().min(1).max(200).optional(),
}).strict();
const discoverModelsSchema = z.object({
    base_url: z.string().trim().url('base_url must be a valid URL').max(2_000),
    api_key: z.string().trim().min(1).max(20_000),
}).strict();
const createLedgerEntrySchema = z.object({
    amount: z.string().trim().min(1).max(40),
    currency: z.enum(CODEX_RELAY_LEDGER_CURRENCIES),
    note: z.string().trim().max(MAX_CODEX_RELAY_LEDGER_NOTE_LENGTH).optional(),
    occurred_at: z.string().datetime({ offset: true }).optional(),
}).strict();
const PROMPT_CACHE_TEST_LEASE_PREFIX = '{"test_state":"running",';
const PROMPT_CACHE_TEST_LEASE_TTL_MS = 5 * 60 * 1_000;
function parseSourceId(raw) {
    const id = Number(raw);
    return Number.isSafeInteger(id) && id > 0 ? id : null;
}
function parseApiKeyId(raw) {
    const id = Number(raw);
    return Number.isSafeInteger(id) && id > 0 ? id : null;
}
function adminUserId(req) {
    const userId = req.user?.userId;
    return Number.isSafeInteger(userId) && Number(userId) > 0 ? Number(userId) : null;
}
function ledgerResponse(ledger) {
    return {
        entries: ledger.entries.map((entry) => ({
            id: entry.id,
            source_id: entry.sourceId,
            amount_micro: entry.amountMicro,
            currency: entry.currency,
            note: entry.note,
            occurred_at: entry.occurredAt,
            created_at: entry.createdAt,
        })),
        totals: {
            USD: ledger.totals.USD.amountMicro,
            CNY: ledger.totals.CNY.amountMicro,
        },
    };
}
function normalizeBaseUrl(value) {
    return value.trim().replace(/\/+$/, '');
}
function mappingsFromRequest(mappings) {
    return mappings.map((mapping) => ({
        publicModelId: mapping.public_model_id,
        upstreamModelId: mapping.upstream_model_id,
        enabled: mapping.enabled,
        supportsTools: mapping.supports_tools,
        supportsVision: mapping.supports_vision,
    }));
}
/** Keep the isolated API convenient for the existing admin page without ever
 * serialising the encrypted key. Camel-case fields remain available to callers
 * that use the service-shaped response; snake-case aliases are compatibility
 * data for the dashboard form contract. */
function sourceKeyResponse(typed) {
    return {
        ...typed,
        source_id: typed.sourceId,
        api_key_id: typed.apiKeyId,
        masked_key: typed.maskedKey,
        last_used_at: typed.lastUsedAt,
        last_checked_at: typed.lastCheckedAt,
        last_health_check_at: typed.lastCheckedAt,
        last_error: typed.lastError,
        last_health_check_error: typed.lastError,
        failure_count: typed.failureCount,
        cooldown_until: typed.cooldownUntil,
        balance_currency: typed.balanceCurrency,
        balance_synced_at: typed.balanceSyncedAt,
        credential_revision: typed.credentialRevision,
        compatibility_status: typed.compatibilityStatus,
        compatibility_checked_at: typed.compatibilityCheckedAt,
        compatibility_report: typed.compatibilityReport,
        compatibility_current: typed.compatibilityCurrent,
        compatibility_stale_reason: typed.compatibilityStaleReason,
        created_at: typed.createdAt,
        updated_at: typed.updatedAt,
    };
}
function sourceResponse(typed) {
    const keys = typed.keys.map(sourceKeyResponse);
    return {
        ...typed,
        api_key_id: typed.apiKeyId,
        base_url: typed.baseUrl,
        codex_group_id: typed.codexGroupId,
        codex_group_name: typed.codexGroupName,
        health_status: typed.status,
        last_used_at: typed.lastUsedAt,
        last_health_check_at: typed.lastCheckedAt,
        last_health_check_error: typed.lastError,
        last_error: typed.lastError,
        compatibility_status: typed.compatibilityStatus,
        compatibility_checked_at: typed.compatibilityCheckedAt,
        compatibility_report: typed.compatibilityReport,
        compatibility_current: typed.compatibilityCurrent,
        compatibility_stale_reason: typed.compatibilityStaleReason,
        keys,
        keySummary: typed.keySummary,
        key_summary: typed.keySummary,
        model_mappings: typed.modelMappings.map((mapping) => ({
            source_id: mapping.sourceId,
            public_model_id: mapping.publicModelId,
            upstream_model_id: mapping.upstreamModelId,
            enabled: mapping.enabled,
            supports_tools: mapping.supportsTools,
            supports_vision: mapping.supportsVision,
            prompt_cache_status: mapping.promptCacheStatus,
            prompt_cache_checked_at: mapping.promptCacheCheckedAt,
            prompt_cache_report: mapping.promptCacheReport,
            prompt_cache_current: isPromptCacheCertificationCurrent(mapping.promptCacheStatus, mapping.promptCacheCheckedAt),
            runtime_status: mapping.runtimeStatus,
            runtime_consecutive_failures: mapping.runtimeConsecutiveFailures,
            runtime_cooldown_until: mapping.runtimeCooldownUntil,
            runtime_last_error: mapping.runtimeLastError,
            runtime_last_failure_at: mapping.runtimeLastFailureAt,
            runtime_last_success_at: mapping.runtimeLastSuccessAt,
        })),
    };
}
function relayKeyErrorResponse(error, fallback) {
    const message = error instanceof Error ? error.message : fallback;
    const conflict = /cannot be deleted|must pass|health check|requires|already|conflict/i.test(message);
    return {
        status: conflict ? 409 : 500,
        type: conflict ? 'source_conflict' : 'server_error',
        message,
    };
}
async function validateRelayBaseUrl(baseUrl) {
    const verdict = await assessProviderUrl(baseUrl);
    return verdict.allowed ? null : verdict.reason ?? 'not allowed';
}
function promptCacheTestSnapshot(db, sourceId, publicModelId) {
    return db.prepare(`
    SELECT
      s.compatibility_config_revision,
      s.protocol,
      s.status AS source_status,
      sm.upstream_model_id,
      sm.enabled AS mapping_enabled,
      sm.prompt_cache_status,
      sm.prompt_cache_checked_at,
      sm.prompt_cache_report
    FROM codex_relay_sources s
    JOIN codex_relay_source_models sm
      ON sm.source_id = s.id
     AND sm.public_model_id = ?
    WHERE s.id = ?
  `).get(publicModelId, sourceId) ?? null;
}
/**
 * Acquire a database-backed lease so two Node processes cannot certify the
 * same mapping concurrently and let the slower result overwrite the newer
 * one. The marker expires well after the probe's 110-second hard deadline so
 * a crashed worker cannot block future tests forever.
 */
function acquirePromptCacheTestLease(db, sourceId, publicModelId, snapshot) {
    const leaseStartedAt = new Date().toISOString();
    const staleBefore = new Date(Date.now() - PROMPT_CACHE_TEST_LEASE_TTL_MS).toISOString();
    const leaseReport = JSON.stringify({
        test_state: 'running',
        started_at: leaseStartedAt,
        test_run_id: randomUUID(),
    });
    const acquired = db.prepare(`
    UPDATE codex_relay_source_models
    SET prompt_cache_report = ?,
        updated_at = datetime('now')
    WHERE source_id = ?
      AND public_model_id = ?
      AND upstream_model_id = ?
      AND EXISTS (
        SELECT 1
        FROM codex_relay_sources source_revision
        WHERE source_revision.id = codex_relay_source_models.source_id
          AND source_revision.compatibility_config_revision = ?
      )
      AND CASE
        WHEN prompt_cache_report IS NULL THEN 1
        WHEN prompt_cache_report NOT LIKE ? THEN 1
        WHEN json_valid(prompt_cache_report) = 0 THEN 1
        ELSE COALESCE(json_extract(prompt_cache_report, '$.started_at'), '') < ?
      END
  `).run(leaseReport, sourceId, publicModelId, snapshot.upstream_model_id, snapshot.compatibility_config_revision, `${PROMPT_CACHE_TEST_LEASE_PREFIX}%`, staleBefore).changes === 1;
    return acquired
        ? {
            ...snapshot,
            lease_report: leaseReport,
        }
        : null;
}
function releasePromptCacheTestLease(db, sourceId, publicModelId, lease) {
    db.prepare(`
    UPDATE codex_relay_source_models
    SET prompt_cache_status = ?,
        prompt_cache_checked_at = ?,
        prompt_cache_report = ?,
        updated_at = datetime('now')
    WHERE source_id = ?
      AND public_model_id = ?
      AND upstream_model_id = ?
      AND prompt_cache_report = ?
  `).run(lease.prompt_cache_status, lease.prompt_cache_checked_at, lease.prompt_cache_report, sourceId, publicModelId, lease.upstream_model_id, lease.lease_report);
}
function persistPromptCacheTestReport(db, sourceId, publicModelId, lease, report) {
    const persist = db.transaction(() => db.prepare(`
    UPDATE codex_relay_source_models
    SET prompt_cache_status = ?,
        prompt_cache_checked_at = ?,
        prompt_cache_report = ?,
        updated_at = datetime('now')
    WHERE source_id = ?
      AND public_model_id = ?
      AND upstream_model_id = ?
      AND prompt_cache_report = ?
      AND EXISTS (
        SELECT 1
        FROM codex_relay_sources source_revision
        WHERE source_revision.id = codex_relay_source_models.source_id
          AND source_revision.compatibility_config_revision = ?
      )
  `).run(report.overall_status, report.completed_at, JSON.stringify(report), sourceId, publicModelId, lease.upstream_model_id, lease.lease_report, lease.compatibility_config_revision).changes === 1);
    return persist();
}
codexRelaySourcesRouter.get('/', (_req, res) => {
    res.json({ sources: listCodexRelaySources(getDb()).map(sourceResponse) });
});
codexRelaySourcesRouter.get('/stats', (req, res) => {
    if (req.query.hours === undefined) {
        res.json(getCodexRelayOperationalStats(getDb(), null));
        return;
    }
    const parsed = z.coerce.number().int().min(1).max(24 * 365).safeParse(req.query.hours);
    if (!parsed.success) {
        res.status(400).json({
            error: { message: 'hours must be between 1 and 8760', type: 'validation_error' },
        });
        return;
    }
    res.json(getCodexRelayOperationalStats(getDb(), parsed.data));
});
codexRelaySourcesRouter.post('/:id/stats/reset', (req, res) => {
    const sourceId = parseSourceId(req.params.id);
    if (sourceId == null) {
        res.status(400).json({
            error: { message: 'Invalid relay source id', type: 'validation_error' },
        });
        return;
    }
    const stats = resetCodexRelayOperationalStats(getDb(), sourceId);
    if (stats == null) {
        res.status(404).json({
            error: { message: 'Codex relay source not found', type: 'not_found' },
        });
        return;
    }
    res.json({ success: true, stats });
});
codexRelaySourcesRouter.get('/:id/ledger', (req, res) => {
    const sourceId = parseSourceId(req.params.id);
    if (sourceId == null) {
        res.status(400).json({
            error: { message: 'Invalid relay source id', type: 'validation_error' },
        });
        return;
    }
    const ledger = listCodexRelayRechargeLedger(getDb(), sourceId);
    if (ledger == null) {
        res.status(404).json({
            error: { message: 'Codex relay source not found', type: 'not_found' },
        });
        return;
    }
    res.json(ledgerResponse(ledger));
});
codexRelaySourcesRouter.post('/:id/ledger', (req, res) => {
    const sourceId = parseSourceId(req.params.id);
    if (sourceId == null) {
        res.status(400).json({
            error: {
                message: 'Invalid relay source id',
                type: 'validation_error',
            },
        });
        return;
    }
    const parsed = createLedgerEntrySchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({
            error: {
                message: parsed.error.errors.map((error) => error.message).join(', '),
                type: 'validation_error',
            },
        });
        return;
    }
    const amountMicro = decimalRelayLedgerAmountToMicro(parsed.data.amount);
    if (amountMicro == null) {
        res.status(400).json({
            error: {
                message: 'amount must be a positive decimal with at most 6 places and no more than 1000000',
                type: 'validation_error',
            },
        });
        return;
    }
    const occurredAt = parsed.data.occurred_at ?? new Date().toISOString();
    if (Date.parse(occurredAt) > Date.now()) {
        res.status(400).json({
            error: { message: 'occurred_at cannot be in the future', type: 'validation_error' },
        });
        return;
    }
    try {
        const db = getDb();
        const ledger = db.transaction(() => {
            const entry = createCodexRelayRechargeLedgerEntry(db, {
                sourceId,
                amountMicro,
                currency: parsed.data.currency,
                note: parsed.data.note,
                occurredAt,
                createdByUserId: adminUserId(req),
            });
            return entry == null ? null : listCodexRelayRechargeLedger(db, sourceId);
        })();
        if (ledger == null) {
            res.status(404).json({
                error: { message: 'Codex relay source not found', type: 'not_found' },
            });
            return;
        }
        res.status(201).json(ledgerResponse(ledger));
    }
    catch (error) {
        res.status(500).json({
            error: {
                message: error instanceof Error ? error.message : 'Failed to record relay recharge',
                type: 'server_error',
            },
        });
    }
});
codexRelaySourcesRouter.delete('/:id/ledger/:entryId', (req, res) => {
    const sourceId = parseSourceId(req.params.id);
    const entryId = parseApiKeyId(req.params.entryId);
    if (sourceId == null || entryId == null) {
        res.status(400).json({
            error: { message: 'Invalid relay source or ledger entry id', type: 'validation_error' },
        });
        return;
    }
    const result = deleteCodexRelayRechargeLedgerEntry(getDb(), sourceId, entryId);
    if (result !== 'deleted') {
        res.status(404).json({
            error: {
                message: result === 'source_not_found'
                    ? 'Codex relay source not found'
                    : 'Relay recharge ledger entry not found',
                type: 'not_found',
            },
        });
        return;
    }
    res.status(204).end();
});
codexRelaySourcesRouter.post('/discover-models', async (req, res) => {
    const parsed = discoverModelsSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({
            error: {
                message: parsed.error.errors.map((error) => error.message).join(', '),
                type: 'validation_error',
            },
        });
        return;
    }
    const baseUrl = normalizeBaseUrl(parsed.data.base_url);
    const rejected = await validateRelayBaseUrl(baseUrl);
    if (rejected) {
        res.status(400).json({
            error: { message: `base_url rejected: ${rejected}`, type: 'validation_error' },
        });
        return;
    }
    try {
        const models = await discoverCodexRelayModelsWithCredentials(baseUrl, parsed.data.api_key);
        res.json({ success: true, models });
    }
    catch (error) {
        res.status(502).json({
            error: {
                message: error instanceof Error ? error.message : 'Relay model discovery failed',
                type: 'upstream_error',
            },
        });
    }
});
codexRelaySourcesRouter.post('/:id/discover-models', async (req, res) => {
    const id = parseSourceId(req.params.id);
    if (id == null) {
        res.status(400).json({
            error: { message: 'Invalid relay source id', type: 'validation_error' },
        });
        return;
    }
    try {
        const result = await discoverCodexRelaySourceModels(getDb(), id);
        res.json({ success: true, models: result.models, api_key_id: result.apiKeyId });
    }
    catch (error) {
        const message = error instanceof Error ? error.message : 'Relay model discovery failed';
        const notFound = message === 'Codex relay source not found';
        res.status(notFound ? 404 : 502).json({
            error: { message, type: notFound ? 'not_found' : 'upstream_error' },
        });
    }
});
codexRelaySourcesRouter.post('/', async (req, res) => {
    const parsed = createSourceSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: parsed.error.errors.map((error) => error.message).join(', '), type: 'validation_error' } });
        return;
    }
    const baseUrl = normalizeBaseUrl(parsed.data.base_url);
    const rejected = await validateRelayBaseUrl(baseUrl);
    if (rejected) {
        res.status(400).json({ error: { message: `base_url rejected: ${rejected}`, type: 'validation_error' } });
        return;
    }
    let source;
    try {
        source = createCodexRelaySource(getDb(), {
            name: parsed.data.name,
            baseUrl,
            apiKey: parsed.data.api_key,
            codexGroupId: parsed.data.codex_group_id,
            protocol: parsed.data.protocol,
            enabled: parsed.data.enabled,
            priority: parsed.data.priority,
            modelMappings: mappingsFromRequest(parsed.data.model_mappings),
        });
    }
    catch (error) {
        res.status(409).json({ error: { message: error instanceof Error ? error.message : String(error), type: 'source_conflict' } });
        return;
    }
    // Saving a relay must not generate billable traffic or turn a transient
    // upstream response into a routing policy. Administrators can run the
    // optional connection test explicitly when they need diagnostics.
    res.status(201).json({
        success: true,
        source: sourceResponse(source),
    });
    return;
});
codexRelaySourcesRouter.put('/:id', async (req, res) => {
    const id = parseSourceId(req.params.id);
    const parsed = updateSourceSchema.safeParse(req.body);
    if (id == null || !parsed.success) {
        res.status(400).json({ error: { message: 'Invalid relay source update', type: 'validation_error' } });
        return;
    }
    const baseUrl = parsed.data.base_url === undefined ? undefined : normalizeBaseUrl(parsed.data.base_url);
    if (baseUrl !== undefined) {
        const rejected = await validateRelayBaseUrl(baseUrl);
        if (rejected) {
            res.status(400).json({ error: { message: `base_url rejected: ${rejected}`, type: 'validation_error' } });
            return;
        }
    }
    try {
        const source = updateCodexRelaySource(getDb(), id, {
            name: parsed.data.name,
            baseUrl,
            apiKey: parsed.data.api_key,
            codexGroupId: parsed.data.codex_group_id,
            protocol: parsed.data.protocol,
            enabled: parsed.data.enabled,
            priority: parsed.data.priority,
            modelMappings: parsed.data.model_mappings === undefined
                ? undefined
                : mappingsFromRequest(parsed.data.model_mappings),
        });
        if (!source) {
            res.status(404).json({ error: { message: 'Codex relay source not found', type: 'not_found' } });
            return;
        }
        res.json({ success: true, source: sourceResponse(source) });
    }
    catch (error) {
        res.status(409).json({ error: { message: error instanceof Error ? error.message : String(error), type: 'source_conflict' } });
    }
});
codexRelaySourcesRouter.post('/:id/keys', (req, res) => {
    const sourceId = parseSourceId(req.params.id);
    const parsed = createSourceKeySchema.safeParse(req.body);
    if (sourceId == null) {
        res.status(400).json({
            error: { message: 'Invalid relay source id', type: 'validation_error' },
        });
        return;
    }
    if (!parsed.success) {
        res.status(400).json({
            error: {
                message: parsed.error.errors.map((error) => error.message).join(', '),
                type: 'validation_error',
            },
        });
        return;
    }
    try {
        const source = createCodexRelaySourceKey(getDb(), sourceId, {
            apiKey: parsed.data.api_key,
            label: parsed.data.label,
            priority: parsed.data.priority,
        });
        if (!source) {
            res.status(404).json({ error: { message: 'Codex relay source not found', type: 'not_found' } });
            return;
        }
        res.status(201).json({
            success: true,
            source: sourceResponse(source),
            message: 'Relay API key added and available for routing',
        });
    }
    catch (error) {
        const mapped = relayKeyErrorResponse(error, 'Failed to add relay API key');
        res.status(mapped.status).json({ error: { message: mapped.message, type: mapped.type } });
    }
});
codexRelaySourcesRouter.put('/:id/keys/:apiKeyId', (req, res) => {
    const sourceId = parseSourceId(req.params.id);
    const apiKeyId = parseApiKeyId(req.params.apiKeyId);
    const parsed = updateSourceKeySchema.safeParse(req.body);
    if (sourceId == null || apiKeyId == null) {
        res.status(400).json({
            error: { message: 'Invalid relay source or API key id', type: 'validation_error' },
        });
        return;
    }
    if (!parsed.success) {
        res.status(400).json({
            error: {
                message: parsed.error.errors.map((error) => error.message).join(', '),
                type: 'validation_error',
            },
        });
        return;
    }
    try {
        const source = updateCodexRelaySourceKey(getDb(), sourceId, apiKeyId, parsed.data);
        if (!source) {
            res.status(404).json({ error: { message: 'Relay API key not found for this source', type: 'not_found' } });
            return;
        }
        res.json({ success: true, source: sourceResponse(source) });
    }
    catch (error) {
        const mapped = relayKeyErrorResponse(error, 'Failed to update relay API key');
        res.status(mapped.status).json({ error: { message: mapped.message, type: mapped.type } });
    }
});
codexRelaySourcesRouter.post('/:id/keys/:apiKeyId/rotate', (req, res) => {
    const sourceId = parseSourceId(req.params.id);
    const apiKeyId = parseApiKeyId(req.params.apiKeyId);
    const parsed = rotateSourceKeySchema.safeParse(req.body);
    if (sourceId == null || apiKeyId == null) {
        res.status(400).json({
            error: { message: 'Invalid relay source or API key id', type: 'validation_error' },
        });
        return;
    }
    if (!parsed.success) {
        res.status(400).json({
            error: {
                message: parsed.error.errors.map((error) => error.message).join(', '),
                type: 'validation_error',
            },
        });
        return;
    }
    try {
        const source = rotateCodexRelaySourceKey(getDb(), sourceId, apiKeyId, parsed.data.api_key);
        if (!source) {
            res.status(404).json({ error: { message: 'Relay API key not found for this source', type: 'not_found' } });
            return;
        }
        res.json({
            success: true,
            source: sourceResponse(source),
            message: 'Relay API key rotated; its previous enabled state was preserved',
        });
    }
    catch (error) {
        const mapped = relayKeyErrorResponse(error, 'Failed to rotate relay API key');
        res.status(mapped.status).json({ error: { message: mapped.message, type: mapped.type } });
    }
});
codexRelaySourcesRouter.delete('/:id/keys/:apiKeyId', (req, res) => {
    const sourceId = parseSourceId(req.params.id);
    const apiKeyId = parseApiKeyId(req.params.apiKeyId);
    if (sourceId == null || apiKeyId == null) {
        res.status(400).json({
            error: { message: 'Invalid relay source or API key id', type: 'validation_error' },
        });
        return;
    }
    try {
        const source = deleteCodexRelaySourceKey(getDb(), sourceId, apiKeyId);
        if (!source) {
            res.status(404).json({ error: { message: 'Relay API key not found for this source', type: 'not_found' } });
            return;
        }
        res.json({ success: true, source: sourceResponse(source) });
    }
    catch (error) {
        const mapped = relayKeyErrorResponse(error, 'Failed to delete relay API key');
        res.status(mapped.status).json({ error: { message: mapped.message, type: mapped.type } });
    }
});
codexRelaySourcesRouter.post('/:id/keys/:apiKeyId/health-check', async (req, res) => {
    const sourceId = parseSourceId(req.params.id);
    const apiKeyId = parseApiKeyId(req.params.apiKeyId);
    if (sourceId == null || apiKeyId == null) {
        res.status(400).json({
            error: { message: 'Invalid relay source or API key id', type: 'validation_error' },
        });
        return;
    }
    try {
        const result = await checkCodexRelaySourceKeyHealth(getDb(), sourceId, apiKeyId);
        const key = result.source.keys.find((candidate) => candidate.apiKeyId === apiKeyId);
        if (!key) {
            res.status(404).json({ error: { message: 'Relay API key not found for this source', type: 'not_found' } });
            return;
        }
        const success = key.status === 'healthy';
        res.json({
            success,
            source: sourceResponse(result.source),
            key: sourceKeyResponse(key),
            discovered_models: result.discoveredModels,
            message: success ? 'Relay API key health check passed' : key.lastError ?? 'Relay API key health check failed',
        });
    }
    catch (error) {
        const message = error instanceof Error ? error.message : 'Relay API key health check failed';
        const notFound = /not found/i.test(message);
        const conflict = /requires|must pass|configuration changed/i.test(message);
        res.status(notFound ? 404 : conflict ? 409 : 500).json({
            error: {
                message,
                type: notFound ? 'not_found' : conflict ? 'source_conflict' : 'server_error',
            },
        });
    }
});
codexRelaySourcesRouter.post('/:id/models/:publicModelId/health-check', async (req, res) => {
    const sourceId = parseSourceId(req.params.id);
    const publicModelId = String(req.params.publicModelId ?? '').trim();
    if (sourceId == null || !publicModelId || publicModelId.length > 200) {
        res.status(400).json({
            error: { message: 'A valid relay source id and public model id are required', type: 'validation_error' },
        });
        return;
    }
    try {
        const result = await checkCodexRelaySourceModelHealth(getDb(), sourceId, publicModelId);
        res.json({
            success: result.success,
            source: sourceResponse(result.source),
            model: {
                ...result.model,
                public_model_id: result.model.publicModelId,
                upstream_model_id: result.model.upstreamModelId,
                runtime_status: result.model.runtimeStatus,
                runtime_consecutive_failures: result.model.runtimeConsecutiveFailures,
                runtime_cooldown_until: result.model.runtimeCooldownUntil,
                runtime_last_error: result.model.runtimeLastError,
                runtime_last_failure_at: result.model.runtimeLastFailureAt,
                runtime_last_success_at: result.model.runtimeLastSuccessAt,
            },
            api_key_id: result.apiKeyId,
            message: result.message,
        });
    }
    catch (error) {
        const message = error instanceof Error ? error.message : 'Codex relay model health check failed';
        const notFound = /not found/i.test(message);
        res.status(notFound ? 404 : 500).json({
            error: {
                message,
                type: notFound ? 'not_found' : 'server_error',
            },
        });
    }
});
codexRelaySourcesRouter.delete('/:id', (req, res) => {
    const id = parseSourceId(req.params.id);
    if (id == null) {
        res.status(400).json({ error: { message: 'Invalid relay source id', type: 'validation_error' } });
        return;
    }
    if (!deleteCodexRelaySource(getDb(), id)) {
        res.status(404).json({ error: { message: 'Codex relay source not found', type: 'not_found' } });
        return;
    }
    res.json({ success: true });
});
codexRelaySourcesRouter.post('/:id/health-check', async (req, res) => {
    const id = parseSourceId(req.params.id);
    if (id == null) {
        res.status(400).json({ error: { message: 'Invalid relay source id', type: 'validation_error' } });
        return;
    }
    try {
        const result = await checkCodexRelaySourceHealth(getDb(), id);
        res.json({
            success: result.source.status === 'healthy',
            source: sourceResponse(result.source),
            discovered_models: result.discoveredModels,
        });
    }
    catch (error) {
        const message = error instanceof Error ? error.message : 'Codex relay health check failed';
        res.status(message === 'Codex relay source not found' ? 404 : 500).json({
            error: { message, type: message === 'Codex relay source not found' ? 'not_found' : 'server_error' },
        });
    }
});
codexRelaySourcesRouter.post('/:id/compatibility-test', async (req, res) => {
    const id = parseSourceId(req.params.id);
    const parsed = compatibilityTestSchema.safeParse(req.body ?? {});
    if (id == null || !parsed.success) {
        res.status(400).json({
            error: {
                message: 'A valid relay source id and optional api_key_id/public_model_id are required',
                type: 'validation_error',
            },
        });
        return;
    }
    try {
        const report = await testCodexRelaySourceCompatibility(getDb(), id, {
            apiKeyId: parsed.data.api_key_id,
            publicModelId: parsed.data.public_model_id,
        });
        const source = getCodexRelaySource(getDb(), id);
        if (!source) {
            res.status(409).json({
                error: {
                    message: 'Relay configuration changed during the compatibility test; result was discarded',
                    type: 'source_conflict',
                },
            });
            return;
        }
        res.json({
            success: report.overall_status === 'compatible',
            source: sourceResponse(source),
            report,
        });
    }
    catch (error) {
        const message = error instanceof Error ? error.message : 'Codex relay compatibility test failed';
        const notFound = message === 'Codex relay source not found';
        const conflict = /requires|already running|concurrency limit|configuration changed|result was discarded/i.test(message);
        res.status(notFound ? 404 : conflict ? 409 : 500).json({
            error: {
                message,
                type: notFound ? 'not_found' : conflict ? 'source_conflict' : 'server_error',
            },
        });
    }
});
codexRelaySourcesRouter.post('/:id/prompt-cache-test', async (req, res) => {
    const id = parseSourceId(req.params.id);
    const parsed = promptCacheTestSchema.safeParse(req.body);
    if (id == null || !parsed.success) {
        res.status(400).json({
            error: {
                message: 'A valid relay source id and public_model_id are required',
                type: 'validation_error',
            },
        });
        return;
    }
    const db = getDb();
    const publicModelId = parsed.data.public_model_id;
    const snapshot = promptCacheTestSnapshot(db, id, publicModelId);
    if (!snapshot) {
        res.status(404).json({
            error: { message: 'Codex relay model mapping not found', type: 'not_found' },
        });
        return;
    }
    if (snapshot.source_status !== 'healthy') {
        res.status(409).json({
            error: {
                message: 'Run the basic upstream health check successfully before the prompt-cache test',
                type: 'source_conflict',
            },
        });
        return;
    }
    if (snapshot.mapping_enabled !== 1) {
        res.status(409).json({
            error: { message: 'Enable and save this model mapping before the prompt-cache test', type: 'source_conflict' },
        });
        return;
    }
    if (snapshot.protocol !== 'responses') {
        res.status(409).json({
            error: { message: 'Prompt-cache testing requires a native Responses upstream', type: 'source_conflict' },
        });
        return;
    }
    if (!relayMappingRequiresExplicitPromptCache(publicModelId, snapshot.upstream_model_id)) {
        res.status(409).json({
            error: { message: 'Prompt-cache testing is limited to GPT-5.6+ mappings', type: 'source_conflict' },
        });
        return;
    }
    const lease = acquirePromptCacheTestLease(db, id, publicModelId, snapshot);
    if (!lease) {
        res.status(409).json({
            error: {
                message: 'A prompt-cache test is already running or the relay configuration changed',
                type: 'source_conflict',
            },
        });
        return;
    }
    try {
        const report = await testCodexRelayPromptCacheCompatibility(db, id, publicModelId);
        if (!persistPromptCacheTestReport(db, id, publicModelId, lease, report)) {
            res.status(409).json({
                error: {
                    message: 'Relay configuration or model mapping changed during the prompt-cache test; result was discarded',
                    type: 'source_conflict',
                },
            });
            return;
        }
        const source = getCodexRelaySource(db, id);
        if (!source) {
            res.status(409).json({
                error: {
                    message: 'Relay configuration changed during the prompt-cache test; result was discarded',
                    type: 'source_conflict',
                },
            });
            return;
        }
        res.json({
            success: report.overall_status === 'compatible',
            source: sourceResponse(source),
            report,
        });
    }
    catch (error) {
        const message = error instanceof Error ? error.message : 'Codex relay prompt-cache test failed';
        const notFound = /not found/i.test(message);
        const conflict = /requires|limited to|already running|concurrency limit|configuration changed|result was discarded/i.test(message);
        res.status(notFound ? 404 : conflict ? 409 : 500).json({
            error: {
                message,
                type: notFound ? 'not_found' : conflict ? 'source_conflict' : 'server_error',
            },
        });
    }
    finally {
        // Successful persistence replaces the marker, so this is a no-op on the
        // happy path. On failures it restores the last completed certification.
        releasePromptCacheTestLease(db, id, publicModelId, lease);
    }
});
// A small detail endpoint keeps the public route contract convenient for
// isolated admin views while still returning a strictly masked secret.
codexRelaySourcesRouter.get('/:id', (req, res) => {
    const id = parseSourceId(req.params.id);
    if (id == null) {
        res.status(400).json({ error: { message: 'Invalid relay source id', type: 'validation_error' } });
        return;
    }
    const source = getCodexRelaySource(getDb(), id);
    if (!source) {
        res.status(404).json({ error: { message: 'Codex relay source not found', type: 'not_found' } });
        return;
    }
    res.json({ source: sourceResponse(source) });
});
//# sourceMappingURL=codex-relay-sources.js.map