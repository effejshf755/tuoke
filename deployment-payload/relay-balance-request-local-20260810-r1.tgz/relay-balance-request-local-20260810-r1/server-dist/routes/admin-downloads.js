import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { Router } from 'express';
export const CODEX_CONNECTOR_FILE_NAME = 'Tuoke-Codex-Connector-windows-x64.exe';
export const CODEX_CONNECTOR_VERSION = '1.0.0';
function isMissingFileError(error) {
    const code = error?.code;
    return code === 'ENOENT' || code === 'ENOTDIR';
}
async function connectorFile(downloadDir) {
    if (!downloadDir)
        return null;
    const filePath = path.resolve(downloadDir, CODEX_CONNECTOR_FILE_NAME);
    try {
        const stat = await fs.promises.stat(filePath);
        if (!stat.isFile())
            return null;
        return { path: filePath, sizeBytes: stat.size };
    }
    catch (error) {
        if (isMissingFileError(error))
            return null;
        throw error;
    }
}
function sha256File(filePath) {
    return new Promise((resolve, reject) => {
        const hash = crypto.createHash('sha256');
        const stream = fs.createReadStream(filePath);
        stream.on('error', reject);
        stream.on('data', chunk => hash.update(chunk));
        stream.on('end', () => resolve(hash.digest('hex')));
    });
}
function setPrivateDownloadHeaders(res) {
    res.setHeader('Cache-Control', 'private, no-store, max-age=0');
    res.setHeader('Pragma', 'no-cache');
    res.vary('Authorization');
    res.vary('X-Dashboard-Token');
}
function sendDownloadNotFound(res) {
    res.status(404).json({
        error: {
            message: 'Codex connector download is not available',
            type: 'not_found',
        },
    });
}
function sendDownloadFailure(res, error) {
    console.error('[Admin Downloads] Failed to serve Codex connector:', error);
    res.status(500).json({
        error: {
            message: 'Failed to serve Codex connector download',
            type: 'server_error',
        },
    });
}
export function createAdminDownloadsRouter(downloadDir) {
    const router = Router();
    router.get('/codex-connector', async (_req, res) => {
        setPrivateDownloadHeaders(res);
        try {
            const file = await connectorFile(downloadDir);
            if (!file) {
                res.json({
                    connector: {
                        available: false,
                        fileName: CODEX_CONNECTOR_FILE_NAME,
                        version: CODEX_CONNECTOR_VERSION,
                        sizeBytes: null,
                        sha256: null,
                    },
                });
                return;
            }
            let sha256;
            try {
                sha256 = await sha256File(file.path);
            }
            catch (error) {
                // The release can be replaced between stat() and hashing. Treat that
                // race exactly like a not-yet-published artifact.
                if (isMissingFileError(error)) {
                    res.json({
                        connector: {
                            available: false,
                            fileName: CODEX_CONNECTOR_FILE_NAME,
                            version: CODEX_CONNECTOR_VERSION,
                            sizeBytes: null,
                            sha256: null,
                        },
                    });
                    return;
                }
                throw error;
            }
            res.json({
                connector: {
                    available: true,
                    fileName: CODEX_CONNECTOR_FILE_NAME,
                    version: CODEX_CONNECTOR_VERSION,
                    sizeBytes: file.sizeBytes,
                    sha256,
                },
            });
        }
        catch (error) {
            sendDownloadFailure(res, error);
        }
    });
    router.get('/codex-connector/windows-x64', async (_req, res, next) => {
        setPrivateDownloadHeaders(res);
        try {
            const file = await connectorFile(downloadDir);
            if (!file) {
                sendDownloadNotFound(res);
                return;
            }
            res.type('application/vnd.microsoft.portable-executable');
            res.download(file.path, CODEX_CONNECTOR_FILE_NAME, error => {
                if (!error)
                    return;
                if (res.headersSent) {
                    next(error);
                    return;
                }
                if (isMissingFileError(error)) {
                    sendDownloadNotFound(res);
                    return;
                }
                sendDownloadFailure(res, error);
            });
        }
        catch (error) {
            sendDownloadFailure(res, error);
        }
    });
    return router;
}
//# sourceMappingURL=admin-downloads.js.map