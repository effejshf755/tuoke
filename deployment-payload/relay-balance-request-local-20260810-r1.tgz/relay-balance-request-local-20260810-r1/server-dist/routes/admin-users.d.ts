export declare const adminUsersRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=admin-users.d.ts.map