import { Router } from 'express';
import { getDb } from '../db/index.js';
import { z } from 'zod';
import { listCodexAccounts, deleteCodexAccount, setCodexAccountEnabled, createCodexAccount, checkCodexAccountHealth, setCodexAccountScope, setCodexAccountGroup, } from '../services/codex-oauth.js';
import { importCodexAuthPayload, importLocalCodexAuth } from '../services/codex-import.js';
import { replaceCodexAccountModels } from '../services/codex-model-discovery.js';
import { getCodexUsageStats } from '../services/codex-usage.js';
import { updateCodexGroupConcurrencyLimit } from '../services/codex-concurrency.js';
export const codexOauthRouter = Router();
const updateAccountSchema = z.object({
    enabled: z.boolean().optional(),
    resource_scope: z.enum(['codex_pool', 'resource_subpool']).optional(),
    codex_group_id: z.number().int().positive().optional(),
}).strict().refine(value => value.enabled !== undefined || value.resource_scope !== undefined || value.codex_group_id !== undefined);
const groupSchema = z.object({
    name: z.string().trim().min(1).max(100),
    description: z.string().trim().max(500).default(''),
    model_ids: z.array(z.string().trim().min(1).max(200)).max(100).default([]),
    enabled: z.boolean().default(true),
    multiplier: z.number().finite().min(0).max(1000).default(1),
    max_concurrency: z.number().int().min(1).max(1000).nullable().optional(),
    apply_multiplier_to_models: z.boolean().optional(),
}).strict();
const groupModelBillingSchema = z.object({
    input_price_per_million: z.number().finite().min(0).max(1_000_000),
    output_price_per_million: z.number().finite().min(0).max(1_000_000),
    multiplier: z.number().finite().min(0).max(1_000),
    cached_input_multiplier: z.number().finite().min(0).max(1_000),
}).strict();
function listGroups() {
    const db = getDb();
    const groups = db.prepare(`SELECT g.id, g.name, g.description, g.enabled, g.multiplier_milli, g.max_concurrency, g.created_at, g.updated_at,
    (SELECT COUNT(*) FROM codex_oauth_accounts a WHERE a.codex_group_id = g.id AND a.deleted_at IS NULL) account_count,
    (SELECT COUNT(*) FROM codex_relay_sources rs WHERE rs.codex_group_id = g.id) relay_source_count,
    (SELECT COUNT(*) FROM consumer_api_keys k WHERE k.codex_group_id = g.id AND k.status = 'active') key_count
    FROM codex_groups g ORDER BY g.id DESC`).all();
    const rows = db.prepare(`
    SELECT
      gm.group_id,
      gm.model_id,
      gm.input_price_micro_per_million_override AS input_price_override,
      gm.output_price_micro_per_million_override AS output_price_override,
      gm.multiplier_milli_override AS multiplier_override,
      gm.cached_input_multiplier_milli_override AS cached_input_multiplier_override,
      COALESCE(gm.input_price_micro_per_million_override, b.input_price_micro_per_million, 0)
        AS effective_input_price,
      COALESCE(gm.output_price_micro_per_million_override, b.output_price_micro_per_million, 0)
        AS effective_output_price,
      COALESCE(gm.multiplier_milli_override, b.multiplier_milli, 1000)
        AS effective_multiplier,
      COALESCE(gm.cached_input_multiplier_milli_override, b.cached_input_multiplier_milli, 1000)
        AS effective_cached_input_multiplier,
      COALESCE(b.billing_enabled, 0) AS billing_enabled
    FROM codex_group_models gm
    LEFT JOIN model_billing_rules b
      ON b.platform = 'openai-codex'
     AND b.model_id = gm.model_id
    ORDER BY gm.model_id
  `).all();
    return groups.map((group) => {
        const modelRows = rows.filter((row) => row.group_id === group.id);
        return {
            ...group,
            enabled: Boolean(group.enabled),
            multiplier: Number(group.multiplier_milli) / 1000,
            model_ids: modelRows.map((row) => row.model_id),
            model_pricing: modelRows.map((row) => {
                const hasOverride = row.input_price_override !== null
                    || row.output_price_override !== null
                    || row.multiplier_override !== null
                    || row.cached_input_multiplier_override !== null;
                return {
                    model_id: row.model_id,
                    override: hasOverride
                        ? {
                            input_price_per_million: row.input_price_override === null
                                ? null
                                : microToCurrency(row.input_price_override),
                            output_price_per_million: row.output_price_override === null
                                ? null
                                : microToCurrency(row.output_price_override),
                            multiplier: row.multiplier_override === null
                                ? null
                                : milliToMultiplier(row.multiplier_override),
                            cached_input_multiplier: row.cached_input_multiplier_override === null
                                ? null
                                : milliToMultiplier(row.cached_input_multiplier_override),
                        }
                        : null,
                    effective: {
                        input_price_per_million: microToCurrency(row.effective_input_price),
                        output_price_per_million: microToCurrency(row.effective_output_price),
                        multiplier: milliToMultiplier(row.effective_multiplier),
                        cached_input_multiplier: milliToMultiplier(row.effective_cached_input_multiplier),
                    },
                    billing_enabled: Boolean(row.billing_enabled),
                    source: hasOverride ? 'group_override' : 'global',
                };
            }),
        };
    });
}
codexOauthRouter.get('/groups', (_req, res) => {
    const models = getDb().prepare(`
    SELECT DISTINCT model_id
    FROM (
      SELECT model_id FROM codex_oauth_account_models WHERE enabled = 1
      UNION
      SELECT sm.public_model_id AS model_id
      FROM codex_relay_sources s
      JOIN codex_relay_source_models sm ON sm.source_id = s.id
      WHERE s.enabled = 1
        AND sm.enabled = 1
        AND EXISTS (
          SELECT 1
          FROM codex_relay_source_keys source_key
          JOIN api_keys source_api_key
            ON source_api_key.id = source_key.api_key_id
           AND source_api_key.role = 'codex_relay'
           AND source_api_key.platform = 'custom'
           AND source_api_key.enabled = 1
          WHERE source_key.source_id = s.id
            AND source_key.enabled = 1
            AND source_key.status IN ('healthy', 'unknown')
            AND (
              source_key.cooldown_until IS NULL
              OR datetime(source_key.cooldown_until) <= datetime('now')
            )
        )
    )
    ORDER BY model_id
  `).all();
    res.json({ groups: listGroups(), available_models: models.map(row => row.model_id) });
});
codexOauthRouter.post('/groups', (req, res) => {
    const parsed = groupSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: '分组配置无效', type: 'validation_error' } });
        return;
    }
    try {
        const db = getDb();
        const id = db.transaction(() => {
            const multiplierMilli = Math.round(parsed.data.multiplier * 1000);
            const result = db.prepare('INSERT INTO codex_groups (name, description, enabled, multiplier_milli, max_concurrency) VALUES (?, ?, ?, ?, ?)')
                .run(parsed.data.name, parsed.data.description, parsed.data.enabled ? 1 : 0, multiplierMilli, parsed.data.max_concurrency ?? null);
            const groupId = Number(result.lastInsertRowid);
            const insert = db.prepare(`
        INSERT INTO codex_group_models (group_id, model_id, multiplier_milli_override)
        VALUES (?, ?, ?)
      `);
            for (const modelId of [...new Set(parsed.data.model_ids)]) {
                insert.run(groupId, modelId, multiplierMilli);
            }
            return groupId;
        })();
        res.status(201).json({ success: true, group: listGroups().find(group => group.id === id) });
    }
    catch (error) {
        res.status(409).json({ error: { message: error instanceof Error ? error.message : String(error), type: 'group_conflict' } });
    }
});
codexOauthRouter.put('/groups/:id', (req, res) => {
    const id = Number(req.params.id);
    const parsed = groupSchema.safeParse(req.body);
    if (!Number.isSafeInteger(id) || !parsed.success) {
        res.status(400).json({ error: { message: 'Invalid group', type: 'validation_error' } });
        return;
    }
    const db = getDb();
    const found = db.prepare(`
    SELECT multiplier_milli AS multiplierMilli, max_concurrency AS maxConcurrency
    FROM codex_groups WHERE id = ?
  `).get(id);
    if (!found) {
        res.status(404).json({ error: { message: 'Codex group not found', type: 'not_found' } });
        return;
    }
    db.transaction(() => {
        const multiplierMilli = Math.round(parsed.data.multiplier * 1000);
        const multiplierChanged = multiplierMilli !== found.multiplierMilli;
        const overwriteModelMultipliers = multiplierChanged
            || parsed.data.apply_multiplier_to_models === true;
        db.prepare(`UPDATE codex_groups SET name=?, description=?, enabled=?, multiplier_milli=?, max_concurrency=?, updated_at=datetime('now') WHERE id=?`)
            .run(parsed.data.name, parsed.data.description, parsed.data.enabled ? 1 : 0, multiplierMilli, parsed.data.max_concurrency === undefined ? found.maxConcurrency : parsed.data.max_concurrency, id);
        const selectedModelIds = [...new Set(parsed.data.model_ids)];
        const selected = new Set(selectedModelIds);
        const existing = db.prepare('SELECT model_id FROM codex_group_models WHERE group_id = ?')
            .all(id);
        const remove = db.prepare('DELETE FROM codex_group_models WHERE group_id = ? AND model_id = ?');
        for (const row of existing) {
            if (!selected.has(row.model_id))
                remove.run(id, row.model_id);
        }
        const insert = db.prepare(`
      INSERT OR IGNORE INTO codex_group_models (
        group_id, model_id, multiplier_milli_override
      ) VALUES (?, ?, ?)
    `);
        for (const modelId of selectedModelIds)
            insert.run(id, modelId, multiplierMilli);
        if (overwriteModelMultipliers) {
            db.prepare(`
        UPDATE codex_group_models
        SET multiplier_milli_override = ?
        WHERE group_id = ?
      `).run(multiplierMilli, id);
        }
    })();
    updateCodexGroupConcurrencyLimit(id, parsed.data.max_concurrency === undefined
        ? found.maxConcurrency
        : parsed.data.max_concurrency);
    res.json({ success: true, group: listGroups().find(group => group.id === id) });
});
codexOauthRouter.put('/groups/:groupId/models/:modelId/billing', (req, res) => {
    const groupId = Number(req.params.groupId);
    const modelId = String(req.params.modelId ?? '').trim();
    const parsed = groupModelBillingSchema.safeParse(req.body);
    if (!Number.isSafeInteger(groupId) || groupId <= 0 || !modelId || modelId.length > 200 || !parsed.success) {
        res.status(400).json({
            error: { message: 'Invalid Codex group model billing configuration', type: 'validation_error' },
        });
        return;
    }
    const db = getDb();
    const result = db.prepare(`
    UPDATE codex_group_models
    SET
      input_price_micro_per_million_override = ?,
      output_price_micro_per_million_override = ?,
      multiplier_milli_override = ?,
      cached_input_multiplier_milli_override = ?
    WHERE group_id = ? AND model_id = ?
  `).run(currencyToMicro(parsed.data.input_price_per_million), currencyToMicro(parsed.data.output_price_per_million), Math.round(parsed.data.multiplier * 1_000), Math.round(parsed.data.cached_input_multiplier * 1_000), groupId, modelId);
    if (!result.changes) {
        res.status(404).json({
            error: { message: 'Codex group model not found', type: 'not_found' },
        });
        return;
    }
    res.json({ success: true, group: listGroups().find((group) => group.id === groupId) });
});
codexOauthRouter.delete('/groups/:groupId/models/:modelId/billing', (req, res) => {
    const groupId = Number(req.params.groupId);
    const modelId = String(req.params.modelId ?? '').trim();
    if (!Number.isSafeInteger(groupId) || groupId <= 0 || !modelId || modelId.length > 200) {
        res.status(400).json({ error: { message: 'Invalid group model', type: 'validation_error' } });
        return;
    }
    const db = getDb();
    const found = db.prepare('SELECT 1 FROM codex_group_models WHERE group_id = ? AND model_id = ?')
        .get(groupId, modelId);
    if (!found) {
        res.status(404).json({ error: { message: 'Codex group model not found', type: 'not_found' } });
        return;
    }
    db.prepare(`
    UPDATE codex_group_models
    SET
      input_price_micro_per_million_override = NULL,
      output_price_micro_per_million_override = NULL,
      multiplier_milli_override = NULL,
      cached_input_multiplier_milli_override = NULL
    WHERE group_id = ? AND model_id = ?
  `).run(groupId, modelId);
    res.json({ success: true, group: listGroups().find((group) => group.id === groupId) });
});
codexOauthRouter.delete('/groups/:id', (req, res) => {
    const id = Number(req.params.id);
    const db = getDb();
    const usage = db.prepare(`
    SELECT
      (SELECT COUNT(*) FROM codex_oauth_accounts WHERE codex_group_id=? AND deleted_at IS NULL) AS accountCount,
      (SELECT COUNT(*) FROM codex_relay_sources WHERE codex_group_id=?) AS relaySourceCount,
      (SELECT COUNT(*) FROM consumer_api_keys WHERE codex_group_id=? AND status='active') AS keyCount
  `).get(id, id, id);
    if (usage.accountCount || usage.relaySourceCount || usage.keyCount) {
        const bindings = [
            usage.accountCount ? `${usage.accountCount} 个 OAuth` : '',
            usage.relaySourceCount ? `${usage.relaySourceCount} 个第三方 API` : '',
            usage.keyCount ? `${usage.keyCount} 把用户密钥` : '',
        ].filter(Boolean).join('、');
        res.status(409).json({
            error: {
                message: `分组仍绑定 ${bindings}。请先解绑或撤销后再删除。`,
                type: 'group_in_use',
                ...usage,
            },
        });
        return;
    }
    const result = db.prepare('DELETE FROM codex_groups WHERE id=?').run(id);
    if (!result.changes) {
        res.status(404).json({ error: { message: 'Codex group not found', type: 'not_found' } });
        return;
    }
    res.json({ success: true });
});
const updateCodexBillingSchema = z.object({
    model_id: z.string().trim().min(1).max(200),
    input_price_per_million: z.number().finite().min(0).max(1_000_000),
    output_price_per_million: z.number().finite().min(0).max(1_000_000),
    multiplier: z.number().finite().min(0).max(1_000),
    cached_input_multiplier: z.number().finite().min(0).max(1_000),
    user_display_multiplier: z.number().finite().min(0).max(1_000).optional(),
    billing_enabled: z.boolean(),
}).strict();
function microToCurrency(value) {
    return Number((Number(value || 0) / 1_000_000).toFixed(6));
}
function currencyToMicro(value) {
    return Math.round(value * 1_000_000);
}
function milliToMultiplier(value) {
    return Number((Number(value || 0) / 1_000).toFixed(3));
}
codexOauthRouter.get('/stats', (_req, res) => {
    res.json(getCodexUsageStats());
});
codexOauthRouter.get('/billing', (_req, res) => {
    const rows = getDb().prepare(`
    WITH capabilities AS (
      SELECT
        am.model_id AS model_id,
        'oauth' AS source_type,
        a.id AS source_id,
        CASE WHEN a.enabled = 1 AND am.enabled = 1 THEN 1 ELSE 0 END AS enabled
      FROM codex_oauth_account_models am
      JOIN codex_oauth_accounts a ON a.id = am.account_id
      WHERE a.resource_scope = 'codex_pool'

      UNION ALL

      SELECT
        sm.public_model_id AS model_id,
        'relay' AS source_type,
        s.id AS source_id,
        CASE
          WHEN s.enabled = 1
           AND sm.enabled = 1
           AND EXISTS (
             SELECT 1
             FROM codex_relay_source_keys source_key
             JOIN api_keys source_api_key
              ON source_api_key.id = source_key.api_key_id
              AND source_api_key.role = 'codex_relay'
              AND source_api_key.platform = 'custom'
              AND source_api_key.enabled = 1
             WHERE source_key.source_id = s.id
               AND source_key.enabled = 1
               AND source_key.status IN ('healthy', 'unknown')
               AND (
                 source_key.cooldown_until IS NULL
                 OR datetime(source_key.cooldown_until) <= datetime('now')
               )
           )
          THEN 1 ELSE 0
        END AS enabled
      FROM codex_relay_source_models sm
      JOIN codex_relay_sources s ON s.id = sm.source_id
    ),
    usage AS (
      SELECT
        model_id,
        SUM(total_tokens) AS total_tokens,
        MAX(created_at) AS last_used_at
      FROM codex_usage_records
      GROUP BY model_id
    )
    SELECT
      capability.model_id,
      COUNT(DISTINCT CASE
        WHEN capability.source_type = 'oauth' THEN capability.source_id
      END) AS account_count,
      COUNT(DISTINCT CASE
        WHEN capability.source_type = 'oauth' AND capability.enabled = 1
        THEN capability.source_id
      END) AS enabled_account_count,
      COUNT(DISTINCT CASE
        WHEN capability.source_type = 'relay' THEN capability.source_id
      END) AS relay_source_count,
      COUNT(DISTINCT CASE
        WHEN capability.source_type = 'relay' AND capability.enabled = 1
        THEN capability.source_id
      END) AS enabled_relay_source_count,
      COALESCE(b.input_price_micro_per_million, 0) AS input_price,
      COALESCE(b.output_price_micro_per_million, 0) AS output_price,
      COALESCE(b.multiplier_milli, 1000) AS multiplier,
      COALESCE(b.cached_input_multiplier_milli, 1000) AS cached_input_multiplier,
      b.user_display_multiplier_milli AS user_display_multiplier,
      COALESCE(b.billing_enabled, 1) AS billing_enabled,
      COALESCE(usage.total_tokens, 0) AS total_tokens,
      usage.last_used_at
    FROM capabilities capability
    LEFT JOIN model_billing_rules b
      ON b.platform = 'openai-codex'
     AND b.model_id = capability.model_id
    LEFT JOIN usage ON usage.model_id = capability.model_id
    GROUP BY capability.model_id
    ORDER BY CASE capability.model_id
      WHEN 'gpt-5.6-sol' THEN 1
      WHEN 'gpt-5.6-terra' THEN 2
      WHEN 'gpt-5.6-luna' THEN 3
      WHEN 'gpt-5.5' THEN 4
      WHEN 'gpt-5.4-mini' THEN 5
      WHEN 'gpt-5.4' THEN 6
      ELSE 999
    END, capability.model_id ASC
  `).all();
    res.json({
        models: rows.map((row) => ({
            model_id: row.model_id,
            account_count: Number(row.account_count || 0),
            enabled_account_count: Number(row.enabled_account_count || 0),
            relay_source_count: Number(row.relay_source_count || 0),
            enabled_relay_source_count: Number(row.enabled_relay_source_count || 0),
            input_price_per_million: microToCurrency(row.input_price),
            output_price_per_million: microToCurrency(row.output_price),
            multiplier: milliToMultiplier(row.multiplier),
            cached_input_multiplier: milliToMultiplier(row.cached_input_multiplier),
            user_display_multiplier: row.user_display_multiplier === null
                ? null
                : milliToMultiplier(row.user_display_multiplier),
            billing_enabled: Boolean(row.billing_enabled),
            total_tokens: Number(row.total_tokens || 0),
            last_used_at: row.last_used_at,
        })),
    });
});
codexOauthRouter.put('/billing', (req, res) => {
    const parsed = updateCodexBillingSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({
            error: { message: 'Invalid Codex billing configuration', type: 'validation_error' },
        });
        return;
    }
    const db = getDb();
    const capability = db.prepare(`
    SELECT 1
    FROM (
      SELECT am.model_id
      FROM codex_oauth_account_models am
      JOIN codex_oauth_accounts a ON a.id = am.account_id
      WHERE a.resource_scope = 'codex_pool'

      UNION

      SELECT sm.public_model_id AS model_id
      FROM codex_relay_source_models sm
      JOIN codex_relay_sources s ON s.id = sm.source_id
      WHERE EXISTS (
        SELECT 1
        FROM codex_relay_source_keys source_key
        JOIN api_keys source_api_key
          ON source_api_key.id = source_key.api_key_id
         AND source_api_key.role = 'codex_relay'
         AND source_api_key.platform = 'custom'
         AND source_api_key.enabled = 1
        WHERE source_key.source_id = s.id
          AND source_key.enabled = 1
          AND source_key.status IN ('healthy', 'unknown')
          AND (
            source_key.cooldown_until IS NULL
            OR datetime(source_key.cooldown_until) <= datetime('now')
          )
      )
    ) capability
    WHERE capability.model_id = ?
    LIMIT 1
  `).get(parsed.data.model_id);
    if (!capability) {
        res.status(404).json({
            error: { message: 'Codex model capability not found', type: 'not_found' },
        });
        return;
    }
    db.prepare(`
    INSERT INTO model_billing_rules (
      platform,
      model_id,
      input_price_micro_per_million,
      output_price_micro_per_million,
      multiplier_milli,
      cached_input_multiplier_milli,
      user_display_multiplier_milli,
      billing_enabled
    ) VALUES ('openai-codex', ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(platform, model_id) DO UPDATE SET
      input_price_micro_per_million = excluded.input_price_micro_per_million,
      output_price_micro_per_million = excluded.output_price_micro_per_million,
      multiplier_milli = excluded.multiplier_milli,
      cached_input_multiplier_milli = excluded.cached_input_multiplier_milli,
      user_display_multiplier_milli = COALESCE(
        excluded.user_display_multiplier_milli,
        model_billing_rules.user_display_multiplier_milli
      ),
      billing_enabled = excluded.billing_enabled,
      updated_at = datetime('now')
  `).run(parsed.data.model_id, currencyToMicro(parsed.data.input_price_per_million), currencyToMicro(parsed.data.output_price_per_million), Math.round(parsed.data.multiplier * 1_000), Math.round(parsed.data.cached_input_multiplier * 1_000), parsed.data.user_display_multiplier === undefined
        ? null
        : Math.round(parsed.data.user_display_multiplier * 1_000), parsed.data.billing_enabled ? 1 : 0);
    res.json({ success: true, model: parsed.data });
});
// Canonical administrator account-pool API.
codexOauthRouter.get('/accounts', (_req, res) => {
    res.json({ accounts: listCodexAccounts(getDb()) });
});
codexOauthRouter.put('/accounts/:id', (req, res) => {
    const id = Number(req.params.id);
    const parsed = updateAccountSchema.safeParse(req.body);
    if (!Number.isInteger(id) || id <= 0 || !parsed.success) {
        res.status(400).json({ error: { message: 'Invalid account update', type: 'validation_error' } });
        return;
    }
    try {
        if (parsed.data.enabled !== undefined && !setCodexAccountEnabled(getDb(), id, parsed.data.enabled)) {
            res.status(404).json({ error: { message: 'Codex OAuth account not found', type: 'not_found' } });
            return;
        }
        if (parsed.data.resource_scope !== undefined && !setCodexAccountScope(getDb(), id, parsed.data.resource_scope)) {
            res.status(404).json({ error: { message: 'Codex OAuth account not found', type: 'not_found' } });
            return;
        }
        if (parsed.data.resource_scope === 'resource_subpool') {
            getDb().prepare('UPDATE codex_oauth_accounts SET codex_group_id = NULL WHERE id = ?').run(id);
        }
        if (parsed.data.codex_group_id !== undefined && !setCodexAccountGroup(getDb(), id, parsed.data.codex_group_id)) {
            res.status(404).json({ error: { message: 'Codex OAuth account not found', type: 'not_found' } });
            return;
        }
    }
    catch (error) {
        res.status(409).json({ error: { message: error instanceof Error ? error.message : String(error), type: 'scope_conflict' } });
        return;
    }
    const account = listCodexAccounts(getDb()).find(item => item.id === id);
    res.json({ success: true, account });
});
codexOauthRouter.post('/accounts/:id/health-check', async (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
        res.status(400).json({ error: { message: 'Invalid account id', type: 'validation_error' } });
        return;
    }
    try {
        const account = await checkCodexAccountHealth(getDb(), id);
        res.json({ success: account.status === 'healthy', account });
    }
    catch (error) {
        const message = error instanceof Error ? error.message : 'Codex account health check failed';
        res.status(message === 'Codex OAuth account not found' ? 404 : 500).json({
            error: { message, type: message === 'Codex OAuth account not found' ? 'not_found' : 'server_error' },
        });
    }
});
codexOauthRouter.post('/import-auth-json', async (req, res) => {
    try {
        const data = await importCodexAuthPayload(req.body);
        const db = getDb();
        const accountDbId = createCodexAccount(db, {
            label: typeof req.body?.email === 'string' ? req.body.email : 'Codex OAuth',
            account_id: data.account_id ?? undefined,
            access_token_encrypted: data.access_token_encrypted,
            access_token_iv: data.access_token_iv,
            access_token_auth_tag: data.access_token_auth_tag,
            refresh_token_encrypted: data.refresh_token_encrypted,
            refresh_token_iv: data.refresh_token_iv,
            refresh_token_auth_tag: data.refresh_token_auth_tag,
        });
        if (data.model_ids.length > 0)
            replaceCodexAccountModels(db, accountDbId, data.model_ids);
        res.json({
            success: true,
            account_id: data.account_id,
            models: data.model_ids,
            model_discovery_error: data.model_discovery_error,
        });
    }
    catch (error) {
        res.status(400).json({
            error: {
                message: error instanceof Error ? error.message : 'Invalid Codex auth.json',
                type: 'validation_error',
            },
        });
    }
});
// 获取账号列表
codexOauthRouter.get('/', (_req, res) => {
    const accounts = listCodexAccounts(getDb());
    res.json({ accounts });
});
// 删除账号
const deleteAccountHandler = (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id)) {
        res.status(400).json({
            error: {
                message: 'Invalid id',
                type: 'validation_error',
            },
        });
        return;
    }
    try {
        if (!deleteCodexAccount(getDb(), id)) {
            res.status(404).json({ error: { message: 'Codex OAuth account not found', type: 'not_found' } });
            return;
        }
    }
    catch (error) {
        res.status(409).json({
            error: {
                message: error instanceof Error ? error.message : String(error),
                type: 'account_in_use',
            },
        });
        return;
    }
    res.json({
        success: true,
    });
};
codexOauthRouter.delete('/accounts/:id', deleteAccountHandler);
codexOauthRouter.delete('/:id', deleteAccountHandler);
// 启用/禁用账号
codexOauthRouter.patch('/:id/status', (req, res) => {
    const id = Number(req.params.id);
    const enabled = Boolean(req.body.enabled);
    if (!Number.isInteger(id)) {
        res.status(400).json({
            error: {
                message: 'Invalid id',
                type: 'validation_error',
            },
        });
        return;
    }
    setCodexAccountEnabled(getDb(), id, enabled);
    res.json({
        success: true,
    });
});
codexOauthRouter.post('/', (req, res) => {
    const { label, account_id, access_token_encrypted, access_token_iv, access_token_auth_tag, refresh_token_encrypted, refresh_token_iv, refresh_token_auth_tag, token_expires_at, } = req.body;
    if (!label ||
        !access_token_encrypted ||
        !access_token_iv ||
        !access_token_auth_tag ||
        !refresh_token_encrypted ||
        !refresh_token_iv ||
        !refresh_token_auth_tag) {
        res.status(400).json({
            error: {
                message: 'Missing required fields',
                type: 'validation_error',
            },
        });
        return;
    }
    getDb()
        .prepare(`
        INSERT INTO codex_oauth_accounts (
          label,
          account_id,
          access_token_encrypted,
          access_token_iv,
          access_token_auth_tag,
          refresh_token_encrypted,
          refresh_token_iv,
          refresh_token_auth_tag,
          token_expires_at,
          enabled
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
      `)
        .run(label, account_id ?? null, access_token_encrypted, access_token_iv, access_token_auth_tag, refresh_token_encrypted, refresh_token_iv, refresh_token_auth_tag, token_expires_at ?? null);
    res.json({
        success: true,
    });
});
codexOauthRouter.post('/import-local', async (_req, res) => {
    try {
        const data = await importLocalCodexAuth();
        const db = getDb();
        const accountDbId = createCodexAccount(db, {
            label: 'Local Codex',
            account_id: data.account_id ?? undefined,
            access_token_encrypted: data.access_token_encrypted,
            access_token_iv: data.access_token_iv,
            access_token_auth_tag: data.access_token_auth_tag,
            refresh_token_encrypted: data.refresh_token_encrypted,
            refresh_token_iv: data.refresh_token_iv,
            refresh_token_auth_tag: data.refresh_token_auth_tag,
        });
        if (data.model_ids.length > 0)
            replaceCodexAccountModels(db, accountDbId, data.model_ids);
        res.json({
            success: true,
            account_id: data.account_id,
            models: data.model_ids,
            model_discovery_error: data.model_discovery_error,
        });
    }
    catch (error) {
        res.status(500).json({
            error: {
                message: error instanceof Error ? error.message : 'Import failed',
                type: 'server_error',
            },
        });
    }
});
//# sourceMappingURL=codex-oauth.js.map