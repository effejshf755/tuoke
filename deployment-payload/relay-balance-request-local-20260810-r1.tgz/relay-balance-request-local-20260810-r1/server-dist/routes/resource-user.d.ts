export declare const resourceUserRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=resource-user.d.ts.map