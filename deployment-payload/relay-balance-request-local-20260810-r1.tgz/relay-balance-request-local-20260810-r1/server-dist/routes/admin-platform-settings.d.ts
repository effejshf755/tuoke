export declare const adminPlatformSettingsRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=admin-platform-settings.d.ts.map