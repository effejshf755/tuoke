export declare const consumerApiKeysRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=consumer-api-keys.d.ts.map