export declare const publicPlatformRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=public-platform.d.ts.map