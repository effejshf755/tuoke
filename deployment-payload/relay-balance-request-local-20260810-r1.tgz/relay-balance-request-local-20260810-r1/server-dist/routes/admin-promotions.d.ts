export declare const adminPromotionsRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=admin-promotions.d.ts.map