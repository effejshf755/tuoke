import { Router } from 'express';
import { z } from 'zod';
import { getUnifiedApiKey } from '../db/index.js';
import { AGENT_TOOL_DEFINITIONS, executeAgentTool, agentWorkspace } from '../services/agent-tools.js';
export const agentRouter = Router();
const requestSchema = z.object({
    model: z.string().optional(),
    messages: z.array(z.record(z.unknown())).min(1),
    max_turns: z.number().int().min(1).max(12).optional(),
});
agentRouter.post('/run', async (req, res) => {
    const parsed = requestSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: 'Invalid agent request', type: 'invalid_request_error' } });
        return;
    }
    try {
        agentWorkspace();
    }
    catch (error) {
        res.status(503).json({ error: { message: error.message, type: 'agent_not_configured' } });
        return;
    }
    const messages = [...parsed.data.messages];
    const maxTurns = parsed.data.max_turns ?? 8;
    const apiKey = getUnifiedApiKey();
    if (!apiKey) {
        res.status(503).json({ error: { message: 'Unified API key is not configured', type: 'agent_not_configured' } });
        return;
    }
    try {
        for (let turn = 0; turn < maxTurns; turn++) {
            const upstream = await fetch(`http://127.0.0.1:${process.env.PORT ?? 3001}/v1/chat/completions`, {
                method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${apiKey}` },
                body: JSON.stringify({ model: parsed.data.model ?? 'auto', messages, tools: AGENT_TOOL_DEFINITIONS, tool_choice: 'auto' }),
            });
            const body = await upstream.json();
            if (!upstream.ok) {
                res.status(upstream.status).json(body);
                return;
            }
            const message = body.choices?.[0]?.message;
            if (!message) {
                res.status(502).json({ error: { message: 'Model returned no message', type: 'agent_error' } });
                return;
            }
            messages.push(message);
            const calls = Array.isArray(message.tool_calls) ? message.tool_calls : [];
            if (calls.length === 0) {
                res.json({ ...body, agent: { turns: turn + 1, workspace: agentWorkspace() } });
                return;
            }
            for (const call of calls) {
                let output;
                try {
                    output = await executeAgentTool(String(call.function?.name), String(call.function?.arguments ?? '{}'));
                }
                catch (error) {
                    output = `Tool error: ${error.message}`;
                }
                messages.push({ role: 'tool', tool_call_id: String(call.id), content: output });
            }
        }
        res.status(409).json({ error: { message: `Agent exceeded max_turns (${maxTurns})`, type: 'agent_turn_limit' }, messages });
    }
    catch (error) {
        res.status(502).json({ error: { message: error.message, type: 'agent_error' } });
    }
});
//# sourceMappingURL=agent.js.map