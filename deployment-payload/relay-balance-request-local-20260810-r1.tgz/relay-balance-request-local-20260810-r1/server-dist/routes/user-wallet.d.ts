export declare const userWalletRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=user-wallet.d.ts.map