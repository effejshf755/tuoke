export declare const codexRelaySourcesRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=codex-relay-sources.d.ts.map