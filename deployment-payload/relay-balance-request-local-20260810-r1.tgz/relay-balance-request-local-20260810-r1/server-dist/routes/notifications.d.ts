export declare const notificationsRouter: import("express-serve-static-core").Router;
export declare const adminNotificationsRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=notifications.d.ts.map