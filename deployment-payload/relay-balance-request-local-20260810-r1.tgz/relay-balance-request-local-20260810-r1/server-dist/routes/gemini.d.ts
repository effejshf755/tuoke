export declare const geminiRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=gemini.d.ts.map