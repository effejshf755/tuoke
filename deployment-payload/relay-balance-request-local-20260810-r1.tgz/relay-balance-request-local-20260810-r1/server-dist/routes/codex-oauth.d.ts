export declare const codexOauthRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=codex-oauth.d.ts.map