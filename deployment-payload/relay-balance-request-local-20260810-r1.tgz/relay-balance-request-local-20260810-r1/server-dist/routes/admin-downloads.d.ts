import { Router } from 'express';
export declare const CODEX_CONNECTOR_FILE_NAME = "Tuoke-Codex-Connector-windows-x64.exe";
export declare const CODEX_CONNECTOR_VERSION = "1.0.0";
export declare function createAdminDownloadsRouter(downloadDir: string | null): Router;
//# sourceMappingURL=admin-downloads.d.ts.map