import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/index.js';
import { AdminSprintMutationError, extendAdminSprintUserCredits, listAdminSprintPurchases, listAdminSprintUsers, revokeAdminSprintPurchase, } from '../services/admin-promotion-usage.js';
import { clearUserCodexUpstreamBinding, listUserCodexBindingGroups, setUserCodexUpstreamBinding, UserCodexUpstreamBindingError, } from '../services/user-codex-upstream-bindings.js';
export const adminPromotionsRouter = Router();
const usersQuerySchema = z.object({
    q: z.string().trim().max(100).optional().default(''),
    page: z.coerce.number().int().min(1).max(100_000).optional().default(1),
    limit: z.coerce.number().int().min(1).max(50).optional().default(20),
}).strict();
const userParamsSchema = z.object({
    userId: z.coerce.number().int().positive(),
}).strict();
const purchasesQuerySchema = z.object({
    limit: z.coerce.number().int().min(1).max(100).optional().default(50),
    before_id: z.coerce.number().int().positive().optional(),
}).strict();
const extendBodySchema = z.object({
    hours: z.coerce.number().finite().positive().max(8_760).optional().default(24),
}).strict();
const purchaseParamsSchema = z.object({
    userId: z.coerce.number().int().positive(),
    purchaseId: z.coerce.number().int().positive(),
}).strict();
const upstreamBindingSchema = z.object({
    codex_group_id: z.number().int().positive(),
    target_type: z.enum(['oauth', 'relay']),
    target_id: z.number().int().positive(),
}).strict();
const upstreamBindingQuerySchema = z.object({
    codex_group_id: z.coerce.number().int().positive(),
}).strict();
function sendBindingError(res, error) {
    if (error instanceof UserCodexUpstreamBindingError) {
        res.status(error.status).json({ error: { type: error.code, message: error.message } });
        return;
    }
    res.status(500).json({
        error: {
            type: 'server_error',
            message: error instanceof Error ? error.message : 'Unable to update Codex upstream binding',
        },
    });
}
function adminId(req) {
    const id = req.user?.userId;
    if (!id)
        throw new Error('Authenticated administrator is required');
    return id;
}
function sendMutationError(res, error) {
    if (!(error instanceof AdminSprintMutationError))
        return false;
    res.status(error.code === 'not_found' ? 404 : 409).json({
        error: { type: error.code, message: error.message },
    });
    return true;
}
adminPromotionsRouter.get('/sprint-users', (req, res) => {
    const parsed = usersQuerySchema.safeParse(req.query);
    if (!parsed.success) {
        res.status(400).json({
            error: { type: 'invalid_request', message: 'Invalid sprint user list query' },
        });
        return;
    }
    res.json(listAdminSprintUsers(getDb(), parsed.data));
});
adminPromotionsRouter.get('/sprint-users/:userId/purchases', (req, res) => {
    const params = userParamsSchema.safeParse(req.params);
    const query = purchasesQuerySchema.safeParse(req.query);
    if (!params.success || !query.success) {
        res.status(400).json({
            error: { type: 'invalid_request', message: 'Invalid sprint purchase query' },
        });
        return;
    }
    const result = listAdminSprintPurchases(getDb(), {
        userId: params.data.userId,
        limit: query.data.limit,
        beforeId: query.data.before_id,
    });
    if (!result.user) {
        res.status(404).json({ error: { type: 'not_found', message: 'User not found' } });
        return;
    }
    res.json(result);
});
adminPromotionsRouter.post('/sprint-users/:userId/extend', (req, res) => {
    const params = userParamsSchema.safeParse(req.params);
    const body = extendBodySchema.safeParse(req.body ?? {});
    if (!params.success || !body.success) {
        res.status(400).json({
            error: { type: 'invalid_request', message: 'Extension hours must be a positive number' },
        });
        return;
    }
    try {
        res.json(extendAdminSprintUserCredits(getDb(), {
            userId: params.data.userId,
            hours: body.data.hours,
        }));
    }
    catch (error) {
        if (!sendMutationError(res, error))
            throw error;
    }
});
adminPromotionsRouter.delete('/sprint-users/:userId/purchases/:purchaseId', (req, res) => {
    const params = purchaseParamsSchema.safeParse(req.params);
    if (!params.success) {
        res.status(400).json({
            error: { type: 'invalid_request', message: 'Invalid sprint purchase id' },
        });
        return;
    }
    try {
        res.json(revokeAdminSprintPurchase(getDb(), {
            userId: params.data.userId,
            purchaseId: params.data.purchaseId,
            adminUserId: adminId(req),
        }));
    }
    catch (error) {
        if (!sendMutationError(res, error))
            throw error;
    }
});
adminPromotionsRouter.get('/sprint-users/:userId/upstream-binding', (req, res) => {
    const params = userParamsSchema.safeParse(req.params);
    if (!params.success) {
        res.status(400).json({ error: { type: 'invalid_request', message: 'Invalid user id' } });
        return;
    }
    const result = listUserCodexBindingGroups(getDb(), params.data.userId);
    if (!result.user) {
        res.status(404).json({ error: { type: 'not_found', message: 'User not found' } });
        return;
    }
    res.json(result);
});
adminPromotionsRouter.put('/sprint-users/:userId/upstream-binding', (req, res) => {
    const params = userParamsSchema.safeParse(req.params);
    const body = upstreamBindingSchema.safeParse(req.body);
    if (!params.success || !body.success) {
        res.status(400).json({ error: { type: 'invalid_request', message: 'Invalid Codex upstream binding' } });
        return;
    }
    try {
        const binding = setUserCodexUpstreamBinding(getDb(), {
            userId: params.data.userId,
            codexGroupId: body.data.codex_group_id,
            targetType: body.data.target_type,
            targetId: body.data.target_id,
        });
        res.json({ success: true, binding });
    }
    catch (error) {
        sendBindingError(res, error);
    }
});
adminPromotionsRouter.delete('/sprint-users/:userId/upstream-binding', (req, res) => {
    const params = userParamsSchema.safeParse(req.params);
    const query = upstreamBindingQuerySchema.safeParse(req.query);
    if (!params.success || !query.success) {
        res.status(400).json({ error: { type: 'invalid_request', message: 'Invalid Codex upstream binding' } });
        return;
    }
    const cleared = clearUserCodexUpstreamBinding(getDb(), params.data.userId, query.data.codex_group_id);
    res.json({ success: true, cleared });
});
//# sourceMappingURL=admin-promotions.js.map