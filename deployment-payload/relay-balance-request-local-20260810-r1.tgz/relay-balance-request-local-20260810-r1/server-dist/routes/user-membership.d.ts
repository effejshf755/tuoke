export declare const userMembershipRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=user-membership.d.ts.map