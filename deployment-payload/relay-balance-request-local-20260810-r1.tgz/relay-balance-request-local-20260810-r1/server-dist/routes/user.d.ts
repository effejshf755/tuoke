export declare const userRouter: import("express-serve-static-core").Router;
export declare function codexOfficialPriceMultiplier(modelId: string, inputPrice: number, outputPrice: number): number | null;
//# sourceMappingURL=user.d.ts.map