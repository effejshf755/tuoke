export declare const codexAuthRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=codex-auth.d.ts.map