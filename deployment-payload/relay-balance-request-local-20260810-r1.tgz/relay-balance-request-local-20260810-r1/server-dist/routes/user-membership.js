import { Router } from 'express';
import { getDb } from '../db/index.js';
import { FREE_DAILY_LIMIT, getFreeModelAccessStatus, MEMBER_DAILY_LIMIT, } from '../services/free-model-access.js';
import { FREE_MODEL_MEMBERSHIP_PERIOD_DAYS, FREE_MODEL_MEMBERSHIP_PRICE_MICRO, FreeModelMembershipPurchaseError, purchaseFreeModelMembership, } from '../services/free-model-membership.js';
export const userMembershipRouter = Router();
function requireOrdinaryUser(req, res, next) {
    const user = req.user;
    if (user?.role !== 'user') {
        res.status(403).json({
            error: {
                type: 'permission_error',
                message: 'Ordinary-user membership is unavailable for administrators',
            },
        });
        return;
    }
    next();
}
userMembershipRouter.use(requireOrdinaryUser);
function currentUserId(req) {
    return req.user.userId;
}
function toYuan(micro) {
    return Number((micro / 1_000_000).toFixed(6));
}
function membershipJson(status) {
    return {
        membership: {
            active: status.membershipActive,
            expires_at: status.membershipExpiresAt,
            remaining_seconds: status.membershipRemainingSeconds,
            price: toYuan(FREE_MODEL_MEMBERSHIP_PRICE_MICRO),
            price_micro: FREE_MODEL_MEMBERSHIP_PRICE_MICRO,
            period_days: FREE_MODEL_MEMBERSHIP_PERIOD_DAYS,
        },
        free_model: {
            usage_date: status.usageDate,
            reset_at: status.resetAt,
            daily_limit: status.dailyLimit,
            free_daily_limit: FREE_DAILY_LIMIT,
            member_daily_limit: MEMBER_DAILY_LIMIT,
            used_today: status.usedToday,
            remaining_today: status.remainingToday,
        },
    };
}
function purchaseJson(purchase) {
    return {
        id: purchase.id,
        purchase_no: purchase.purchaseNo,
        price: toYuan(purchase.priceMicro),
        price_micro: purchase.priceMicro,
        starts_at: purchase.startsAt,
        expires_at: purchase.expiresAt,
        created_at: purchase.createdAt,
    };
}
userMembershipRouter.get('/', (req, res) => {
    const db = getDb();
    const userId = currentUserId(req);
    const status = getFreeModelAccessStatus(db, userId);
    const wallet = db.prepare(`
    SELECT
      balance_micro AS balanceMicro,
      reserved_balance_micro AS reservedBalanceMicro
    FROM users
    WHERE id = ? AND status = 'active' AND deleted_at IS NULL
  `).get(userId);
    if (!status || !wallet) {
        res.status(404).json({ error: { type: 'not_found', message: 'User not found' } });
        return;
    }
    res.json({
        ...membershipJson(status),
        wallet: {
            balance: toYuan(wallet.balanceMicro),
            available_balance: toYuan(Math.max(0, wallet.balanceMicro - wallet.reservedBalanceMicro)),
        },
    });
});
userMembershipRouter.post('/purchase', (req, res) => {
    const headerKey = req.get('Idempotency-Key')?.trim();
    const bodyKey = typeof req.body?.idempotency_key === 'string'
        ? req.body.idempotency_key.trim()
        : typeof req.body?.idempotencyKey === 'string'
            ? req.body.idempotencyKey.trim()
            : '';
    try {
        const result = purchaseFreeModelMembership(getDb(), {
            userId: currentUserId(req),
            idempotencyKey: headerKey || bodyKey,
        });
        res.status(result.alreadyProcessed ? 200 : 201).json({
            purchase: purchaseJson(result.purchase),
            ...membershipJson(result.membership),
            wallet_balance: toYuan(result.balanceAfterMicro),
            wallet_balance_micro: result.balanceAfterMicro,
            already_processed: result.alreadyProcessed,
        });
    }
    catch (error) {
        if (!(error instanceof FreeModelMembershipPurchaseError)) {
            console.error('[Membership] Purchase failed:', error);
            res.status(500).json({
                error: {
                    type: 'membership_purchase_failed',
                    message: 'Failed to purchase membership',
                },
            });
            return;
        }
        res.status(error.code === 'invalid_idempotency_key' ? 400 : 409).json({
            error: {
                type: error.code,
                message: error.message,
            },
        });
    }
});
//# sourceMappingURL=user-membership.js.map