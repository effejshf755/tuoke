export declare const supportTicketsRouter: import("express-serve-static-core").Router;
export declare const adminSupportTicketsRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=support-tickets.d.ts.map