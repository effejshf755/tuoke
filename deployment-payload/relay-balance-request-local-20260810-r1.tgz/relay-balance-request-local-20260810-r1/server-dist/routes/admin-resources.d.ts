export declare const adminResourcesRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=admin-resources.d.ts.map