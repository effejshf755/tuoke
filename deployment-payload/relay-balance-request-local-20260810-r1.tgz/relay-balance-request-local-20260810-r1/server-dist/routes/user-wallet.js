import { Router } from 'express';
import { getDb } from '../db/index.js';
export const userWalletRouter = Router();
function getUserId(req) {
    return req.user.userId;
}
function microToYuan(value) {
    return value / 1_000_000;
}
/**
 * GET /api/user/wallet
 *
 * Current authenticated user's wallet summary.
 */
userWalletRouter.get('/', (req, res) => {
    const userId = getUserId(req);
    const db = getDb();
    const user = db.prepare(`
        SELECT
          id,
          email,

          balance_micro
            AS balanceMicro,

          reserved_balance_micro
            AS reservedBalanceMicro

        FROM users

        WHERE id = ?
      `).get(userId);
    if (!user) {
        res.status(404).json({
            error: {
                message: 'User not found',
                type: 'not_found',
            },
        });
        return;
    }
    const totals = db.prepare(`
        SELECT
          COALESCE(
            SUM(
              CASE
                WHEN delta_micro > 0
                THEN delta_micro
                ELSE 0
              END
            ),
            0
          ) AS totalAddedMicro,

          COALESCE(
            SUM(
              CASE
                WHEN type = 'usage'
                  AND delta_micro < 0
                THEN -delta_micro
                ELSE 0
              END
            ),
            0
          ) AS totalUsageMicro,

          COUNT(*) AS transactionCount

        FROM wallet_transactions

        WHERE user_id = ?
      `).get(userId);
    const availableMicro = Math.max(0, user.balanceMicro -
        user.reservedBalanceMicro);
    res.json({
        wallet: {
            user_id: user.id,
            email: user.email,
            balance: microToYuan(user.balanceMicro),
            reserved_balance: microToYuan(user.reservedBalanceMicro),
            available_balance: microToYuan(availableMicro),
            total_added: microToYuan(totals.totalAddedMicro),
            total_usage: microToYuan(totals.totalUsageMicro),
            transaction_count: totals.transactionCount,
        },
    });
});
/**
 * GET /api/user/wallet/transactions
 *
 * Current authenticated user's own wallet history.
 */
userWalletRouter.get('/transactions', (req, res) => {
    const userId = getUserId(req);
    const db = getDb();
    const rows = db.prepare(`
        SELECT
          wt.id,

          wt.type,

          wt.delta_micro
            AS deltaMicro,

          wt.balance_after_micro
            AS balanceAfterMicro,

          wt.request_id
            AS requestId,

          wt.platform,

          wt.model_id
            AS modelId,

          CASE
            WHEN COALESCE(r.compute_points_per_million_tokens, 0) > 0
              THEN COALESCE(r.input_compute_points, 0)
            ELSE COALESCE(wt.input_tokens, 0)
          END AS inputTokens,

          CASE
            WHEN COALESCE(r.compute_points_per_million_tokens, 0) > 0
              THEN CAST(ROUND(
                COALESCE(r.cached_input_tokens, 0) *
                r.compute_points_per_million_tokens / 1000000.0
              ) AS INTEGER)
            ELSE COALESCE(wt.cached_input_tokens, 0)
          END AS cachedInputTokens,

          CASE
            WHEN COALESCE(r.compute_points_per_million_tokens, 0) > 0
              THEN CAST(ROUND(
                COALESCE(r.cache_write_tokens, 0) *
                r.compute_points_per_million_tokens / 1000000.0
              ) AS INTEGER)
            ELSE COALESCE(wt.cache_write_tokens, 0)
          END AS cacheWriteTokens,

          CASE
            WHEN COALESCE(r.compute_points_per_million_tokens, 0) > 0
              THEN COALESCE(r.output_compute_points, 0)
            ELSE COALESCE(wt.output_tokens, 0)
          END AS outputTokens,

          wt.multiplier_milli
            AS multiplierMilli,

          wt.input_price_micro_per_million
            AS inputPriceMicroPerMillion,

          wt.output_price_micro_per_million
            AS outputPriceMicroPerMillion,

          g.name
            AS groupName,

          wt.note,

          wt.created_at
            AS createdAt

        FROM wallet_transactions wt

        LEFT JOIN requests r
          ON r.id = wt.request_id

        LEFT JOIN consumer_api_keys k
          ON k.id = r.consumer_api_key_id

        LEFT JOIN codex_groups g
          ON g.id = k.codex_group_id

        WHERE wt.user_id = ?

        ORDER BY wt.id DESC

        LIMIT 500
      `).all(userId);
    res.json({
        transactions: rows.map((row) => ({
            id: row.id,
            type: row.type,
            delta: microToYuan(row.deltaMicro),
            balance_after: microToYuan(row.balanceAfterMicro),
            request_id: row.requestId,
            platform: row.platform,
            model_id: row.modelId,
            input_tokens: row.inputTokens,
            cached_input_tokens: row.cachedInputTokens,
            cache_write_tokens: row.cacheWriteTokens,
            output_tokens: row.outputTokens,
            total_tokens: row.inputTokens +
                row.outputTokens,
            multiplier: row.multiplierMilli ===
                null
                ? null
                : row.multiplierMilli /
                    1000,
            input_price_per_million: row.inputPriceMicroPerMillion ===
                null
                ? null
                : microToYuan(row.inputPriceMicroPerMillion),
            output_price_per_million: row.outputPriceMicroPerMillion ===
                null
                ? null
                : microToYuan(row.outputPriceMicroPerMillion),
            group_name: row.groupName,
            note: row.note,
            created_at: row.createdAt,
        })),
    });
});
//# sourceMappingURL=user-wallet.js.map