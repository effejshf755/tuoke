export declare const userPromotionsRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=user-promotions.d.ts.map