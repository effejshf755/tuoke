export declare const userRedemptionCodesRouter: import("express-serve-static-core").Router;
export declare const adminRedemptionCodesRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=redemption-codes.d.ts.map