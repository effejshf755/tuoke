import { randomBytes } from 'crypto';
import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/index.js';
export const userRedemptionCodesRouter = Router();
export const adminRedemptionCodesRouter = Router();
const createSchema = z.object({
    amount: z.number().positive().max(1_000_000),
    max_redemptions: z.number().int().positive().max(1_000_000),
    expires_at: z.string().datetime().nullable().optional(),
});
const redeemSchema = z.object({
    code: z.string().trim().min(6).max(100),
});
function getUserId(req) {
    return req.user.userId;
}
function yuanToMicro(value) {
    return Math.round(value * 1_000_000);
}
function microToYuan(value) {
    return Number((value / 1_000_000).toFixed(6));
}
function generateCode() {
    const raw = randomBytes(12).toString('hex').toUpperCase();
    return `TUOKE-${raw.match(/.{1,6}/g)?.join('-') ?? raw}`;
}
adminRedemptionCodesRouter.get('/', (_req, res) => {
    const db = getDb();
    const codes = db.prepare(`
    SELECT
      rc.id,
      rc.code,
      rc.amount_micro AS amountMicro,
      rc.max_redemptions AS maxRedemptions,
      rc.redemption_count AS redemptionCount,
      rc.expires_at AS expiresAt,
      rc.created_at AS createdAt,
      rc.deleted_at AS deletedAt,
      u.email AS createdByEmail
    FROM redemption_codes rc
    JOIN users u ON u.id = rc.created_by
    ORDER BY rc.id DESC
  `).all();
    res.json({
        codes: codes.map((item) => ({
            id: item.id,
            code: item.code,
            amount: microToYuan(item.amountMicro),
            max_redemptions: item.maxRedemptions,
            redemption_count: item.redemptionCount,
            expires_at: item.expiresAt,
            created_at: item.createdAt,
            deleted_at: item.deletedAt,
            created_by_email: item.createdByEmail,
        })),
    });
});
adminRedemptionCodesRouter.post('/', (req, res) => {
    const parsed = createSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: 'Invalid redemption code settings', type: 'validation_error' } });
        return;
    }
    const amountMicro = yuanToMicro(parsed.data.amount);
    const expiresAt = parsed.data.expires_at ?? null;
    if (!Number.isSafeInteger(amountMicro) || amountMicro <= 0) {
        res.status(400).json({ error: { message: 'Invalid redemption amount', type: 'validation_error' } });
        return;
    }
    if (expiresAt && Date.parse(expiresAt) <= Date.now()) {
        res.status(400).json({ error: { message: 'Expiration time must be in the future', type: 'validation_error' } });
        return;
    }
    const db = getDb();
    const adminId = getUserId(req);
    let code = '';
    let id = 0;
    for (let attempt = 0; attempt < 5; attempt += 1) {
        code = generateCode();
        try {
            const result = db.prepare(`
        INSERT INTO redemption_codes
          (code, amount_micro, max_redemptions, expires_at, created_by)
        VALUES (?, ?, ?, ?, ?)
      `).run(code, amountMicro, parsed.data.max_redemptions, expiresAt, adminId);
            id = Number(result.lastInsertRowid);
            break;
        }
        catch (error) {
            if (!String(error).includes('UNIQUE'))
                throw error;
        }
    }
    if (!id) {
        res.status(500).json({ error: { message: 'Failed to generate a unique redemption code', type: 'internal_error' } });
        return;
    }
    res.status(201).json({
        code: {
            id,
            code,
            amount: microToYuan(amountMicro),
            max_redemptions: parsed.data.max_redemptions,
            redemption_count: 0,
            expires_at: expiresAt,
        },
    });
});
adminRedemptionCodesRouter.get('/:id/uses', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
        res.status(400).json({ error: { message: 'Invalid redemption code id', type: 'validation_error' } });
        return;
    }
    const db = getDb();
    const uses = db.prepare(`
    SELECT rcu.id, rcu.amount_micro AS amountMicro, rcu.redeemed_at AS redeemedAt,
           u.id AS userId, u.email
    FROM redemption_code_uses rcu
    JOIN users u ON u.id = rcu.user_id
    WHERE rcu.redemption_code_id = ?
    ORDER BY rcu.id DESC
  `).all(id);
    res.json({
        uses: uses.map((item) => ({
            id: item.id,
            user_id: item.userId,
            email: item.email,
            amount: microToYuan(item.amountMicro),
            redeemed_at: item.redeemedAt,
        })),
    });
});
adminRedemptionCodesRouter.delete('/:id', (req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
        res.status(400).json({ error: { message: 'Invalid redemption code id', type: 'validation_error' } });
        return;
    }
    const result = getDb().prepare(`
    UPDATE redemption_codes
    SET deleted_at = datetime('now')
    WHERE id = ? AND deleted_at IS NULL
  `).run(id);
    if (result.changes === 0) {
        res.status(404).json({ error: { message: 'Redemption code not found or already deleted', type: 'not_found' } });
        return;
    }
    res.json({ success: true });
});
userRedemptionCodesRouter.post('/redeem', (req, res) => {
    const parsed = redeemSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: 'Please enter a valid redemption code', type: 'validation_error' } });
        return;
    }
    const db = getDb();
    const userId = getUserId(req);
    const result = db.transaction(() => {
        const code = db.prepare(`
      SELECT id, code, amount_micro AS amountMicro,
             max_redemptions AS maxRedemptions, redemption_count AS redemptionCount,
             expires_at AS expiresAt, deleted_at AS deletedAt
      FROM redemption_codes
      WHERE code = ? COLLATE NOCASE
    `).get(parsed.data.code);
        if (!code || code.deletedAt)
            return { kind: 'invalid' };
        if (code.expiresAt && Date.parse(code.expiresAt) <= Date.now())
            return { kind: 'expired' };
        if (code.redemptionCount >= code.maxRedemptions)
            return { kind: 'exhausted' };
        const priorUse = db.prepare(`
      SELECT 1 FROM redemption_code_uses
      WHERE redemption_code_id = ? AND user_id = ?
    `).get(code.id, userId);
        if (priorUse)
            return { kind: 'already_used' };
        const user = db.prepare(`
      SELECT balance_micro AS balanceMicro FROM users
      WHERE id = ? AND deleted_at IS NULL
    `).get(userId);
        if (!user)
            return { kind: 'user_not_found' };
        const balanceAfterMicro = user.balanceMicro + code.amountMicro;
        if (!Number.isSafeInteger(balanceAfterMicro))
            throw new Error('Wallet balance exceeds safe integer range');
        const claimed = db.prepare(`
      UPDATE redemption_codes
      SET redemption_count = redemption_count + 1
      WHERE id = ? AND deleted_at IS NULL
        AND redemption_count < max_redemptions
        AND (expires_at IS NULL OR datetime(expires_at) > datetime('now'))
    `).run(code.id);
        if (claimed.changes !== 1)
            return { kind: 'unavailable' };
        db.prepare('UPDATE users SET balance_micro = ? WHERE id = ?').run(balanceAfterMicro, userId);
        db.prepare(`
      INSERT INTO redemption_code_uses (redemption_code_id, user_id, amount_micro)
      VALUES (?, ?, ?)
    `).run(code.id, userId, code.amountMicro);
        db.prepare(`
      INSERT INTO wallet_transactions
        (user_id, type, delta_micro, balance_after_micro, note)
      VALUES (?, 'redemption_code', ?, ?, ?)
    `).run(userId, code.amountMicro, balanceAfterMicro, `Redeemed code ${code.code}`);
        return { kind: 'success', amountMicro: code.amountMicro, balanceAfterMicro };
    })();
    const errors = {
        invalid: [404, 'Redemption code is invalid or has been deleted'],
        expired: [400, 'Redemption code has expired'],
        exhausted: [400, 'Redemption code has reached its usage limit'],
        already_used: [409, 'You have already used this redemption code'],
        user_not_found: [404, 'User not found'],
        unavailable: [409, 'Redemption code is no longer available'],
    };
    if (result.kind !== 'success') {
        const [status, message] = errors[result.kind];
        res.status(status).json({ error: { message, type: result.kind } });
        return;
    }
    res.json({
        success: true,
        amount: microToYuan(result.amountMicro),
        balance: microToYuan(result.balanceAfterMicro),
    });
});
//# sourceMappingURL=redemption-codes.js.map