import { Router } from 'express';
import { getDb } from '../db/index.js';
import { getPromotionCreditSummary, } from '../services/promotion-credits.js';
import { listPromotionOffers } from '../services/promotion-offers.js';
import { listUserPromotionPurchases, PromotionPurchaseError, purchaseWalletPromotionOffer, } from '../services/promotion-purchases.js';
export const userPromotionsRouter = Router();
function currentUserId(req) {
    return req.user.userId;
}
function toAmount(micro) {
    return Number((micro / 1_000_000).toFixed(6));
}
function offerJson(offer) {
    return {
        id: offer.id,
        code: offer.code,
        name: offer.name,
        description: offer.description,
        offer_kind: offer.offerKind,
        payment_source: offer.paymentSource,
        price: toAmount(offer.priceMicro),
        price_micro: offer.priceMicro,
        permanent_credit: toAmount(offer.permanentCreditMicro),
        permanent_credit_micro: offer.permanentCreditMicro,
        limited_credit: toAmount(offer.limitedCreditMicro),
        limited_credit_micro: offer.limitedCreditMicro,
        validity_seconds: offer.validitySeconds,
        enabled: offer.enabled,
    };
}
function grantJson(grant) {
    return {
        id: grant.id,
        purchase_id: grant.purchaseId,
        recharge_order_id: grant.rechargeOrderId,
        granted: toAmount(grant.grantedMicro),
        granted_micro: grant.grantedMicro,
        used: toAmount(grant.usedMicro),
        used_micro: grant.usedMicro,
        remaining: toAmount(grant.remainingMicro),
        remaining_micro: grant.remainingMicro,
        reserved: toAmount(grant.reservedMicro),
        reserved_micro: grant.reservedMicro,
        available: toAmount(grant.availableMicro),
        available_micro: grant.availableMicro,
        expires_at: grant.expiresAt,
        status: grant.status,
        created_at: grant.createdAt,
    };
}
function creditJson(summary) {
    return {
        granted: toAmount(summary.grantedMicro),
        granted_micro: summary.grantedMicro,
        used: toAmount(summary.usedMicro),
        used_micro: summary.usedMicro,
        remaining: toAmount(summary.remainingMicro),
        remaining_micro: summary.remainingMicro,
        reserved: toAmount(summary.reservedMicro),
        reserved_micro: summary.reservedMicro,
        available: toAmount(summary.availableMicro),
        available_micro: summary.availableMicro,
        next_expires_at: summary.nextExpiresAt,
        grant_count: summary.grantCount,
        details_truncated: summary.detailsTruncated,
        grants: summary.grants.map(grantJson),
    };
}
function purchaseJson(purchase) {
    return {
        id: purchase.id,
        purchase_no: purchase.purchaseNo,
        offer_code: purchase.offerCode,
        price: toAmount(purchase.priceMicro),
        price_micro: purchase.priceMicro,
        limited_credit: toAmount(purchase.limitedCreditMicro),
        limited_credit_micro: purchase.limitedCreditMicro,
        validity_seconds: purchase.validitySeconds,
        status: purchase.status,
        created_at: purchase.createdAt,
        paid_at: purchase.paidAt,
        refunded_at: purchase.refundedAt,
    };
}
userPromotionsRouter.get('/', (req, res) => {
    const db = getDb();
    const userId = currentUserId(req);
    const wallet = db.prepare(`
    SELECT balance_micro AS balanceMicro,
      reserved_balance_micro AS reservedBalanceMicro
    FROM users WHERE id = ?
  `).get(userId);
    if (!wallet) {
        res.status(404).json({ error: { type: 'not_found', message: 'User not found' } });
        return;
    }
    res.json({
        offers: listPromotionOffers(db).map(offerJson),
        credits: creditJson(getPromotionCreditSummary(db, userId)),
        purchases: listUserPromotionPurchases(db, userId, 100).map(purchaseJson),
        wallet: {
            balance: toAmount(wallet.balanceMicro),
            balance_micro: wallet.balanceMicro,
            available_balance: toAmount(Math.max(0, wallet.balanceMicro - wallet.reservedBalanceMicro)),
            available_balance_micro: Math.max(0, wallet.balanceMicro - wallet.reservedBalanceMicro),
        },
    });
});
userPromotionsRouter.get('/credits', (req, res) => {
    res.json({ credits: creditJson(getPromotionCreditSummary(getDb(), currentUserId(req))) });
});
userPromotionsRouter.get('/purchases', (req, res) => {
    const limit = Number(req.query.limit ?? 100);
    res.json({
        purchases: listUserPromotionPurchases(getDb(), currentUserId(req), limit).map(purchaseJson),
    });
});
userPromotionsRouter.post('/offers/:offerCode/purchase', (req, res) => {
    const headerKey = req.get('Idempotency-Key')?.trim();
    const bodyKey = typeof req.body?.idempotency_key === 'string'
        ? req.body.idempotency_key.trim()
        : typeof req.body?.idempotencyKey === 'string'
            ? req.body.idempotencyKey.trim()
            : '';
    const idempotencyKey = headerKey || bodyKey;
    try {
        const result = purchaseWalletPromotionOffer(getDb(), {
            userId: currentUserId(req),
            offerCode: String(req.params.offerCode ?? ''),
            idempotencyKey,
        });
        res.status(result.alreadyProcessed ? 200 : 201).json({
            purchase: purchaseJson(result.purchase),
            credit: grantJson(result.grant),
            wallet_balance: toAmount(result.balanceAfterMicro),
            wallet_balance_micro: result.balanceAfterMicro,
            already_processed: result.alreadyProcessed,
        });
    }
    catch (error) {
        if (!(error instanceof PromotionPurchaseError)) {
            console.error('[Promotions] Wallet purchase failed:', error);
            res.status(500).json({
                error: {
                    type: 'promotion_purchase_failed',
                    message: 'Failed to purchase promotion offer',
                },
            });
            return;
        }
        const type = error.code;
        const status = type === 'invalid_idempotency_key'
            ? 400
            : type === 'offer_not_available'
                ? 404
                : 409;
        res.status(status).json({
            error: {
                type,
                message: error instanceof Error ? error.message : String(error),
            },
        });
    }
});
//# sourceMappingURL=user-promotions.js.map