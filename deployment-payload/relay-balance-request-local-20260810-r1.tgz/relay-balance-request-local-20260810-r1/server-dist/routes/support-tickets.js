import { Router } from 'express';
import { z } from 'zod';
import { getDb } from '../db/index.js';
export const supportTicketsRouter = Router();
export const adminSupportTicketsRouter = Router();
const createSchema = z.object({
    subject: z.string().trim().min(2).max(120),
    content: z.string().trim().min(2).max(2000),
});
const messageSchema = z.object({ content: z.string().trim().min(1).max(2000) });
const statusSchema = z.object({ status: z.enum(['open', 'resolved']) });
function userId(req) {
    return req.user.userId;
}
function validId(value) {
    const id = Number(value);
    return Number.isInteger(id) && id > 0 ? id : null;
}
function tooSoon(ticketId, senderId) {
    return Boolean(getDb().prepare(`
    SELECT 1 FROM support_messages
    WHERE ticket_id = ? AND sender_id = ?
      AND created_at > datetime('now', '-5 seconds')
    LIMIT 1
  `).get(ticketId, senderId));
}
supportTicketsRouter.get('/', (req, res) => {
    const id = userId(req);
    const tickets = getDb().prepare(`
    SELECT t.id, t.subject, t.status, t.created_at createdAt, t.updated_at updatedAt,
      (SELECT content FROM support_messages WHERE ticket_id=t.id ORDER BY id DESC LIMIT 1) lastMessage,
      (SELECT COUNT(*) FROM support_messages WHERE ticket_id=t.id AND sender_role='admin' AND read_at IS NULL) unreadCount
    FROM support_tickets t WHERE t.user_id = ?
    ORDER BY t.updated_at DESC, t.id DESC LIMIT 100
  `).all(id);
    const unread = getDb().prepare(`
    SELECT COUNT(*) count FROM support_messages m
    JOIN support_tickets t ON t.id=m.ticket_id
    WHERE t.user_id=? AND m.sender_role='admin' AND m.read_at IS NULL
  `).get(id);
    res.json({ tickets, unreadCount: unread.count });
});
supportTicketsRouter.post('/', (req, res) => {
    const parsed = createSchema.safeParse(req.body);
    if (!parsed.success) {
        res.status(400).json({ error: { message: '标题需为 2-120 字，内容需为 2-2000 字', type: 'validation_error' } });
        return;
    }
    const id = userId(req);
    const open = getDb().prepare("SELECT COUNT(*) count FROM support_tickets WHERE user_id=? AND status<>'resolved'").get(id);
    if (open.count >= 5) {
        res.status(429).json({ error: { message: '你已有 5 个未解决问题，请先在原工单中继续沟通', type: 'support_ticket_limit' } });
        return;
    }
    const create = getDb().transaction(() => {
        const result = getDb().prepare('INSERT INTO support_tickets (user_id, subject) VALUES (?, ?)').run(id, parsed.data.subject);
        const ticketId = Number(result.lastInsertRowid);
        getDb().prepare("INSERT INTO support_messages (ticket_id, sender_id, sender_role, content) VALUES (?, ?, 'user', ?)").run(ticketId, id, parsed.data.content);
        return ticketId;
    });
    res.status(201).json({ id: create() });
});
supportTicketsRouter.get('/:id', (req, res) => {
    const ticketId = validId(req.params.id);
    const id = userId(req);
    const ticket = ticketId && getDb().prepare(`SELECT id, subject, status, created_at createdAt, updated_at updatedAt FROM support_tickets WHERE id=? AND user_id=?`).get(ticketId, id);
    if (!ticket) {
        res.status(404).json({ error: { message: '工单不存在', type: 'not_found' } });
        return;
    }
    getDb().prepare("UPDATE support_messages SET read_at=datetime('now') WHERE ticket_id=? AND sender_role='admin' AND read_at IS NULL").run(ticketId);
    const messages = getDb().prepare(`SELECT id, sender_role senderRole, content, created_at createdAt FROM support_messages WHERE ticket_id=? ORDER BY id ASC`).all(ticketId);
    res.json({ ticket, messages });
});
supportTicketsRouter.post('/:id/messages', (req, res) => {
    const ticketId = validId(req.params.id);
    const parsed = messageSchema.safeParse(req.body);
    const id = userId(req);
    const ticket = ticketId && getDb().prepare('SELECT id FROM support_tickets WHERE id=? AND user_id=?').get(ticketId, id);
    if (!ticket) {
        res.status(404).json({ error: { message: '工单不存在', type: 'not_found' } });
        return;
    }
    if (!parsed.success) {
        res.status(400).json({ error: { message: '消息需为 1-2000 字', type: 'validation_error' } });
        return;
    }
    if (tooSoon(ticketId, id)) {
        res.status(429).json({ error: { message: '发送过于频繁，请稍后再试', type: 'rate_limit' } });
        return;
    }
    getDb().transaction(() => {
        getDb().prepare("INSERT INTO support_messages (ticket_id, sender_id, sender_role, content) VALUES (?, ?, 'user', ?)").run(ticketId, id, parsed.data.content);
        getDb().prepare("UPDATE support_tickets SET status='open', updated_at=datetime('now') WHERE id=?").run(ticketId);
    })();
    res.status(201).json({ success: true });
});
supportTicketsRouter.delete('/:id', (req, res) => {
    const ticketId = validId(req.params.id);
    const id = userId(req);
    if (!ticketId) {
        res.status(400).json({ error: { message: '工单编号无效', type: 'validation_error' } });
        return;
    }
    const result = getDb().prepare('DELETE FROM support_tickets WHERE id=? AND user_id=?').run(ticketId, id);
    if (!result.changes) {
        res.status(404).json({ error: { message: '工单不存在', type: 'not_found' } });
        return;
    }
    res.json({ success: true });
});
adminSupportTicketsRouter.get('/', (_req, res) => {
    const tickets = getDb().prepare(`
    SELECT t.id, t.subject, t.status, t.created_at createdAt, t.updated_at updatedAt, u.email,
      (SELECT content FROM support_messages WHERE ticket_id=t.id ORDER BY id DESC LIMIT 1) lastMessage,
      (SELECT COUNT(*) FROM support_messages WHERE ticket_id=t.id AND sender_role='user' AND read_at IS NULL) unreadCount
    FROM support_tickets t JOIN users u ON u.id=t.user_id
    ORDER BY CASE t.status WHEN 'open' THEN 0 WHEN 'admin_replied' THEN 1 ELSE 2 END, t.updated_at DESC
    LIMIT 300
  `).all();
    const unread = getDb().prepare("SELECT COUNT(*) count FROM support_messages WHERE sender_role='user' AND read_at IS NULL").get();
    res.json({ tickets, unreadCount: unread.count });
});
adminSupportTicketsRouter.post('/users/:userId', (req, res) => {
    const targetUserId = validId(req.params.userId);
    const parsed = createSchema.safeParse(req.body);
    const adminId = userId(req);
    const target = targetUserId && getDb().prepare("SELECT id FROM users WHERE id=? AND role='user' AND status='active'").get(targetUserId);
    if (!target) {
        res.status(404).json({ error: { message: '用户不存在或已被禁用', type: 'not_found' } });
        return;
    }
    if (!parsed.success) {
        res.status(400).json({ error: { message: '标题需为 2-120 字，内容需为 2-2000 字', type: 'validation_error' } });
        return;
    }
    const create = getDb().transaction(() => {
        const result = getDb().prepare("INSERT INTO support_tickets (user_id, subject, status) VALUES (?, ?, 'admin_replied')").run(targetUserId, parsed.data.subject);
        const ticketId = Number(result.lastInsertRowid);
        getDb().prepare("INSERT INTO support_messages (ticket_id, sender_id, sender_role, content) VALUES (?, ?, 'admin', ?)").run(ticketId, adminId, parsed.data.content);
        return ticketId;
    });
    res.status(201).json({ id: create() });
});
adminSupportTicketsRouter.get('/:id', (req, res) => {
    const ticketId = validId(req.params.id);
    const ticket = ticketId && getDb().prepare(`SELECT t.id, t.subject, t.status, t.created_at createdAt, t.updated_at updatedAt, u.email FROM support_tickets t JOIN users u ON u.id=t.user_id WHERE t.id=?`).get(ticketId);
    if (!ticket) {
        res.status(404).json({ error: { message: '工单不存在', type: 'not_found' } });
        return;
    }
    getDb().prepare("UPDATE support_messages SET read_at=datetime('now') WHERE ticket_id=? AND sender_role='user' AND read_at IS NULL").run(ticketId);
    const messages = getDb().prepare(`SELECT id, sender_role senderRole, content, created_at createdAt FROM support_messages WHERE ticket_id=? ORDER BY id ASC`).all(ticketId);
    res.json({ ticket, messages });
});
adminSupportTicketsRouter.post('/:id/messages', (req, res) => {
    const ticketId = validId(req.params.id);
    const parsed = messageSchema.safeParse(req.body);
    const id = userId(req);
    if (!ticketId || !getDb().prepare('SELECT 1 FROM support_tickets WHERE id=?').get(ticketId)) {
        res.status(404).json({ error: { message: '工单不存在', type: 'not_found' } });
        return;
    }
    if (!parsed.success) {
        res.status(400).json({ error: { message: '消息需为 1-2000 字', type: 'validation_error' } });
        return;
    }
    if (tooSoon(ticketId, id)) {
        res.status(429).json({ error: { message: '发送过于频繁，请稍后再试', type: 'rate_limit' } });
        return;
    }
    getDb().transaction(() => {
        getDb().prepare("INSERT INTO support_messages (ticket_id, sender_id, sender_role, content) VALUES (?, ?, 'admin', ?)").run(ticketId, id, parsed.data.content);
        getDb().prepare("UPDATE support_tickets SET status='admin_replied', updated_at=datetime('now') WHERE id=?").run(ticketId);
    })();
    res.status(201).json({ success: true });
});
adminSupportTicketsRouter.patch('/:id/status', (req, res) => {
    const ticketId = validId(req.params.id);
    const parsed = statusSchema.safeParse(req.body);
    if (!ticketId || !parsed.success) {
        res.status(400).json({ error: { message: '状态无效', type: 'validation_error' } });
        return;
    }
    const result = getDb().prepare("UPDATE support_tickets SET status=?, updated_at=datetime('now') WHERE id=?").run(parsed.data.status, ticketId);
    if (!result.changes) {
        res.status(404).json({ error: { message: '工单不存在', type: 'not_found' } });
        return;
    }
    res.json({ success: true });
});
adminSupportTicketsRouter.delete('/:id', (req, res) => {
    const ticketId = validId(req.params.id);
    if (!ticketId) {
        res.status(400).json({ error: { message: '工单编号无效', type: 'validation_error' } });
        return;
    }
    const result = getDb().prepare('DELETE FROM support_tickets WHERE id=?').run(ticketId);
    if (!result.changes) {
        res.status(404).json({ error: { message: '工单不存在', type: 'not_found' } });
        return;
    }
    res.json({ success: true });
});
//# sourceMappingURL=support-tickets.js.map