export declare const adminDashboardRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=admin-dashboard.d.ts.map