export declare const userRechargeRouter: import("express-serve-static-core").Router;
export declare const adminRechargeRouter: import("express-serve-static-core").Router;
export declare const alipayNotifyRouter: import("express-serve-static-core").Router;
//# sourceMappingURL=recharge.d.ts.map