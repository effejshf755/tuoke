import type { Db } from '../db/types.js';
/**
 * SQL predicate used anywhere a model row needs an enabled provider key.
 *
 * A custom model keeps one anchor key_id so different custom endpoints can
 * still reuse the same model ids safely.  Every sibling key with the same
 * base_url belongs to that anchor's credential pool and may serve the model.
 */
export declare function customProviderKeyMatchSql(modelAlias?: string, keyAlias?: string): string;
export declare function getCustomEndpointBaseUrl(db: Db, anchorKeyId: number | null): string | null;
export declare function customKeyBelongsToEndpoint(db: Db, anchorKeyId: number | null, candidate: {
    id: number;
    base_url?: string | null;
}): boolean;
//# sourceMappingURL=custom-provider-pool.d.ts.map