type UnknownRecord = Record<string, unknown>;
export declare const CODEX_RELAY_HEADER_TIMEOUT_CODE = "codex_relay_header_timeout";
export declare const CODEX_RELAY_CLIENT_ABORT_CODE = "codex_relay_client_abort";
export interface NativeResponsesPromptCacheIdentity {
    /** A consumer key id or other tenant-unique value. It is hashed, never sent. */
    consumerKey: string | number;
    /** Prefer a client/session id when one is available and stable across turns. */
    sessionId?: string | null;
    /** Stable first-turn/prefix seed used when the client has no session id. */
    stablePrefixSeed: string;
}
/**
 * Derive one stable, opaque affinity seed from a native Responses request.
 * Appending assistant/tool history or later user turns cannot change it: only
 * instructions, tools, leading system/developer items and the first user item
 * define the reusable prompt prefix.
 */
export declare function nativeResponsesStablePrefixSeed(request: UnknownRecord): string;
/**
 * Add the public GPT-5.6+ explicit-cache contract to a certified native
 * Responses request. This helper is deliberately pure and fail-preserving:
 * client-owned keys, options and breakpoints are never replaced.
 *
 * A string `input` is the Responses shorthand for one user input-text item;
 * expanding that shorthand is wire-equivalent and gives the breakpoint a
 * valid content-part attachment point.
 */
export declare function applyNativeResponsesExplicitPromptCache(request: UnknownRecord, identity: NativeResponsesPromptCacheIdentity): UnknownRecord;
/**
 * Add only a deterministic cache-routing key. The ChatGPT Codex OAuth backend
 * accepts this field but can reject the public explicit-cache options and
 * breakpoint markers, so local OAuth requests deliberately use this narrower
 * helper while certified third-party Responses relays use the full contract.
 */
export declare function applyNativeResponsesPromptCacheKey(request: UnknownRecord, identity: NativeResponsesPromptCacheIdentity): UnknownRecord;
/**
 * Build the request sent to a native Responses relay.
 *
 * Shared/unbound traffic stays stateless because it may fail over between
 * independent sources in the same Codex group. An explicitly bound relay (or
 * a compacted conversation pinned to one relay) keeps the upstream-owned state
 * contract intact instead. Encrypted reasoning is requested in both modes so
 * a later portable replay remains possible when the client supplies it.
 */
export declare function prepareNativeResponsesRequestBody(request: UnknownRecord, upstreamModelId: string, stream: boolean, options?: {
    preserveUpstreamState?: boolean;
}): UnknownRecord;
/**
 * Build the minimal stateless body accepted by the standalone Responses
 * compaction endpoint. Unlike /responses, compact does not use stream/store
 * controls or upstream response identifiers; keeping those fields out also
 * prevents older third-party relays from rejecting an otherwise valid compact
 * request as an unknown parameter.
 */
export declare function prepareNativeResponsesCompactRequestBody(request: UnknownRecord, upstreamModelId: string): UnknownRecord;
export interface NativeResponsesRelayErrorDetails {
    message: string;
    code?: unknown;
    type?: unknown;
}
/**
 * Extract an error object embedded in an otherwise successful Responses
 * payload. Some OpenAI-compatible relays return HTTP 200 for failures and put
 * the real error under `error`; treating that as a successful response would
 * make the caller try to wrap invalid compaction state or stream metadata.
 */
export declare function responsePayloadErrorDetails(payload: unknown, fallback?: string): NativeResponsesRelayErrorDetails | null;
export declare function responseErrorDetails(body: string, statusText: string): NativeResponsesRelayErrorDetails;
export declare function requestNativeResponsesRelay(args: {
    baseUrl: string;
    apiKey: string;
    body: UnknownRecord;
    sessionId?: string;
    signal?: AbortSignal;
}): Promise<Response>;
/** Forward a stateless Codex compaction request to a native Responses relay. */
export declare function requestNativeResponsesCompactRelay(args: {
    baseUrl: string;
    apiKey: string;
    body: UnknownRecord;
    sessionId?: string;
    signal?: AbortSignal;
}): Promise<Response>;
/**
 * Replace only response-level model fields. Tool arguments, metadata, nested
 * vendor payloads, item IDs and call IDs are intentionally left untouched.
 */
export declare function rewriteNativeResponsesModel<T>(value: T, publicModelId: string): T;
export interface NativeResponsesTerminalErrorMetadata {
    message: string;
    code?: string;
    type?: string;
    status?: number;
}
/**
 * Incremental native SSE rewriter. It buffers only the unfinished final frame,
 * so arbitrary network chunk boundaries never corrupt JSON event payloads.
 */
export declare class NativeResponsesSseRewriter {
    private buffer;
    private invalidDataFrame;
    private terminalFailure;
    get hasInvalidDataFrame(): boolean;
    /**
     * Kept only inside the gateway so a pre-commit error can retain its retry
     * semantics. It is never part of rewritten client-facing SSE.
     */
    get terminalErrorMessage(): string | undefined;
    get terminalErrorMetadata(): NativeResponsesTerminalErrorMetadata | undefined;
    private rewriteFrame;
    push(chunk: string, publicModelId: string): string;
    flush(publicModelId: string): string;
}
export {};
//# sourceMappingURL=native-responses-relay.d.ts.map