import { type RequestRoutingDiagnostics } from "./client-context.js";
/**
 * Request rows shown as user-facing outcomes. A retry attempt that was later
 * recovered by a normal successful dispatch must not appear as a separate
 * failure, while committed streams, terminal failures, and partial responses
 * remain visible. A committed stream can contain an in-band provider error
 * after bytes were sent, so it is a real final failure rather than a hidden
 * pre-fallback attempt. SQL users must alias the requests table as `r`.
 */
export declare const RECOVERED_FALLBACK_ATTEMPT_SQL = "(\n  r.status = 'error'\n  AND COALESCE(\n    CASE\n      WHEN json_valid(r.routing_diagnostics) = 1\n        THEN json_extract(r.routing_diagnostics, '$.outcome')\n    END,\n    ''\n  ) = 'succeeded'\n)";
/** Any error row that is not yet a terminal user-visible outcome. */
export declare const NON_FINAL_FALLBACK_ATTEMPT_SQL = "(\n  r.status = 'error'\n  AND COALESCE(\n    CASE\n      WHEN json_valid(r.routing_diagnostics) = 1\n        THEN json_extract(r.routing_diagnostics, '$.outcome')\n    END,\n    ''\n  ) IN ('in_progress', 'succeeded')\n)";
/** Rows whose durable attempt counters have not yet been corrected. */
export declare const UNADJUSTED_RECOVERED_FALLBACK_ATTEMPT_SQL = "(\n  (\n  r.status = 'error'\n  AND COALESCE(\n    CASE\n      WHEN json_valid(r.routing_diagnostics) = 1\n        THEN json_extract(r.routing_diagnostics, '$.outcome')\n    END,\n    ''\n  ) = 'succeeded'\n)\n  AND COALESCE(\n    CASE\n      WHEN json_valid(r.routing_diagnostics) = 1\n        THEN json_extract(r.routing_diagnostics, '$.aggregateAdjusted')\n    END,\n    0\n  ) <> 1\n)";
/** Non-final attempts that still contribute to durable aggregate counters. */
export declare const UNADJUSTED_NON_FINAL_FALLBACK_ATTEMPT_SQL = "(\n  (\n  r.status = 'error'\n  AND COALESCE(\n    CASE\n      WHEN json_valid(r.routing_diagnostics) = 1\n        THEN json_extract(r.routing_diagnostics, '$.outcome')\n    END,\n    ''\n  ) IN ('in_progress', 'succeeded')\n)\n  AND COALESCE(\n    CASE\n      WHEN json_valid(r.routing_diagnostics) = 1\n        THEN json_extract(r.routing_diagnostics, '$.aggregateAdjusted')\n    END,\n    0\n  ) <> 1\n)";
export declare const FINAL_REQUEST_RESULT_SQL = "NOT (\n  r.status = 'error'\n  AND COALESCE(\n    CASE\n      WHEN json_valid(r.routing_diagnostics) = 1\n        THEN json_extract(r.routing_diagnostics, '$.outcome')\n    END,\n    ''\n  ) IN ('in_progress', 'succeeded')\n)";
/** Start an isolated routing trace for one fallback loop in this HTTP call. */
export declare function resetRequestRoutingDiagnostics(): void;
/**
 * Publish the newest bounded snapshot and refresh rows already written by
 * earlier failed attempts.  This makes every row in the same fallback chain
 * answer what happened eventually, including a later successful source.
 */
export declare function publishRequestRoutingDiagnostics(diagnostics: RequestRoutingDiagnostics): void;
/**
 * A surface may recover an exhausted upstream chain with a local response
 * after the fallback loop has already persisted its failed attempts.  Treat
 * that local result as the final outcome before replying, so those attempts
 * remain available to administrators in routing diagnostics but are removed
 * from user-facing history and aggregate error counts.
 */
export declare function markExhaustedRequestRoutingRecovered(): void;
export declare function logRequest(platform: string, modelId: string, keyId: number, status: string, inputTokens: number, outputTokens: number, latencyMs: number, error: string | null, ttfbMs?: number | null, requestedModel?: string | null, explicitCachedInputTokens?: number | null, explicitCacheWriteTokens?: number | null): number | undefined;
//# sourceMappingURL=request-log.d.ts.map