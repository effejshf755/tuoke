type UnknownRecord = Record<string, unknown>;
export interface CodexCompactionUpstreamPin {
    sourceType: 'oauth' | 'relay';
    targetId: number;
    /**
     * Native Responses state can be scoped to the credential/account, not only
     * the supplier URL. New Relay envelopes therefore pin the exact vault Key.
     * It is optional solely so envelopes emitted before this field existed keep
     * decoding during the transition; new Relay envelopes must always set it.
     */
    relayApiKeyId?: number;
    publicModelId: string;
    upstreamModelId: string;
}
export declare class CodexCompactionEnvelopeError extends Error {
    readonly status = 400;
    readonly code = "invalid_compaction_envelope";
}
export declare function findCodexCompactionUpstreamPin(input: unknown): CodexCompactionUpstreamPin | null;
export declare function wrapCodexCompactionResponse(response: unknown, pin: CodexCompactionUpstreamPin): UnknownRecord;
export declare function unwrapCodexCompactionRequest(request: UnknownRecord, expectedPin: CodexCompactionUpstreamPin): UnknownRecord;
export declare function isCodexCompactionEnvelope(value: unknown): boolean;
export {};
//# sourceMappingURL=codex-compaction-envelope.d.ts.map