export interface StructuredProviderStreamError extends Error {
    status?: number;
    upstreamCode?: string;
    upstreamType?: string;
    cause?: unknown;
}
/**
 * Convert an OpenAI-compatible HTTP-200 SSE `{ error: ... }` frame into the
 * same structured error shape used for non-2xx responses. Keeping code/type
 * metadata is important for relay policy routing and model-specific cooldowns.
 */
export declare function providerStreamErrorFromChunk(chunk: unknown, displayName: string): StructuredProviderStreamError | null;
export declare function isRetryableError(err: any): boolean;
export declare function isKeyAuthError(err: any): boolean;
export declare function isDailyQuotaExhaustedError(err: any): boolean;
export declare function isProviderBadRequestError(err: any): boolean;
export declare function isPaymentRequiredError(err: any): boolean;
export declare function isModelNotFoundError(err: any): boolean;
export declare function isModelAccessForbiddenError(err: any): boolean;
//# sourceMappingURL=error-classify.d.ts.map