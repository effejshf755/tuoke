export declare const CODEX_PROMPT_CACHE_STATUSES: readonly ["untested", "compatible", "partial", "incompatible"];
export type CodexPromptCacheStatus = typeof CODEX_PROMPT_CACHE_STATUSES[number];
/** Prompt-cache probe results are short-lived signals for enabling optimization. */
export declare const CODEX_PROMPT_CACHE_CERTIFICATION_TTL_MS: number;
/**
 * GPT-5.6 introduced the explicit prompt-cache contract used by the optional
 * Codex relay diagnostic. Later major/minor versions inherit the same cache
 * behavior; older and non-GPT model ids do not expose this diagnostic.
 */
export declare function requiresExplicitPromptCache(modelId: string): boolean;
/** A compatible result enables cache optimization only while it is fresh. */
export declare function isPromptCacheCertificationCurrent(status: CodexPromptCacheStatus | string | null | undefined, checkedAt: string | null | undefined, nowMs?: number): boolean;
/** Public aliases inherit the diagnostic when their mapped upstream is GPT-5.6+. */
export declare function relayMappingRequiresExplicitPromptCache(publicModelId: string, upstreamModelId: string): boolean;
//# sourceMappingURL=codex-prompt-cache.d.ts.map