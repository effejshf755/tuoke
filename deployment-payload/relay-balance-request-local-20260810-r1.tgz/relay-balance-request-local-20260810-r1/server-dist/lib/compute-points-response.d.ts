import type { Response } from 'express';
import type { Db } from '../db/types.js';
/** Convert an OpenAI/Responses/Anthropic-shaped usage object without mutating it. */
export declare function convertUsageToComputePoints<T>(usage: T, pointsPerMillion: number): T;
/** Recursively rewrite only public usage blocks, leaving model content intact. */
export declare function convertResponseUsageToComputePoints<T>(body: T, pointsPerMillion: number): T;
export declare function requestComputePointsPerMillionTokens(db: Db): number | null;
/** Install the account-scoped output contract for one consumer API response. */
export declare function installComputePointUsageResponse(res: Response, db: Db): void;
//# sourceMappingURL=compute-points-response.d.ts.map