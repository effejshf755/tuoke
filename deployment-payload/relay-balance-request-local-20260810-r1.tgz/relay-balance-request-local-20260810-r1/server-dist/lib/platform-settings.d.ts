export declare const defaults: {
    readonly default_consumer_rpm: 60;
    readonly registration_enabled: true;
    readonly new_user_bonus_micro: 0;
    readonly minimum_recharge_micro: 1000000;
    readonly maximum_recharge_micro: 1000000000000;
    readonly platform_notice: "";
    readonly maintenance_mode: false;
    readonly compute_points_per_million_tokens: 1000000;
    readonly codex_account_max_concurrency: 1;
    readonly codex_queue_timeout_seconds: 30;
};
export declare function settingNumber(key: keyof typeof defaults): number;
export declare function settingBool(key: keyof typeof defaults): boolean;
export declare function settingString(key: keyof typeof defaults): string;
//# sourceMappingURL=platform-settings.d.ts.map