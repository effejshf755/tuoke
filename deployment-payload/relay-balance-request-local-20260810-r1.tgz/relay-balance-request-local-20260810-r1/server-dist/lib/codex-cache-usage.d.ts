export type PromptCacheUsageDetailsField = 'input_tokens_details' | 'prompt_tokens_details';
/** Read every cache-read spelling accepted by the relay compatibility probe. */
export declare function codexCachedInputTokensFromUsage(usage: unknown): number | undefined;
/** Read every cache-write/cache-creation spelling accepted by the probe. */
export declare function codexCacheWriteTokensFromUsage(usage: unknown): number | undefined;
/**
 * Convert provider-specific cache counters to canonical OpenAI-compatible
 * nested fields. The upstream object is cloned rather than mutated.
 */
export declare function normalizeCodexPromptCacheUsage<T>(usage: T, preferredDetailsField?: PromptCacheUsageDetailsField): T;
//# sourceMappingURL=codex-cache-usage.d.ts.map