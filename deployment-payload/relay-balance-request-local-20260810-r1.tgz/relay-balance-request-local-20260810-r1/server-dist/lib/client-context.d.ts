import type { NextFunction, Request, Response } from 'express';
export type RoutingDiagnosticsOutcome = 'in_progress' | 'succeeded' | 'committed' | 'fatal' | 'exhausted';
export type RoutingSwitchBlockReason = 'administrator_binding' | 'compaction_upstream_pin' | 'binding_conflicts_with_compaction_pin';
export interface RoutingDiagnosticTarget {
    platform: string;
    modelId: string;
    relaySourceId: number | null;
    relaySourceName: string | null;
    relayApiKeyId: number | null;
    relayKeyLabel: string | null;
}
export interface RoutingDiagnosticAttempt extends RoutingDiagnosticTarget {
    errorClass: string;
}
export interface RequestRoutingDiagnostics {
    version: 1;
    attempts: RoutingDiagnosticAttempt[];
    finalRoute: RoutingDiagnosticTarget | null;
    fallbackOccurred: boolean;
    outcome: RoutingDiagnosticsOutcome;
    switchBlockedReason: RoutingSwitchBlockReason | null;
    /** Internal marker: request aggregates were already corrected for retries. */
    aggregateAdjusted?: boolean;
}
export interface ClientContext {
    ip: string | null;
    userAgent: string | null;
    consumerUserId: number | null;
    consumerApiKeyId: number | null;
    /** Points rate captured when the consumer request was admitted. */
    computePointsPerMillionTokens: number | null;
    consumerApiKeyType: 'universal' | 'codex_pool' | 'resource_subpool' | null;
    consumerCodexGroupId: number | null;
    consumerFreeOnly: boolean;
    walletReservationId: number | null;
    codexUsageRecordId: number | null;
    resourceSubpoolId: number | null;
    resourceMemberId: number | null;
    resourceQuotaReservationId: number | null;
    resourceRequestCorrelationId: string | null;
    resourceDispatchId: number | null;
    resourceUsageObserved: boolean;
    resourceSettlementDeferred: boolean;
    freeModelUsageDate: string | null;
    freeModelUsageCommitted: boolean;
    routingDiagnostics: RequestRoutingDiagnostics | null;
    routingDiagnosticsRequestIds: number[];
}
export declare function clientContextMiddleware(req: Request, _res: Response, next: NextFunction): void;
export declare function getClientContext(): ClientContext;
export declare function setConsumerIdentity(userId: number, keyId: number, keyType?: 'universal' | 'codex_pool' | 'resource_subpool', codexGroupId?: number | null): void;
/** Keep the account's pricing unit stable for the entire request lifecycle. */
export declare function setComputePointsPerMillionTokens(pointsPerMillion: number | null): void;
/**
 * Namespace shared Codex health state by the exact product boundary that owns
 * the upstream capacity. This prevents a failing group or purchased resource
 * pool from suppressing another group's otherwise healthy route.
 */
export declare function getCodexPolicyScope(): string;
export declare function setWalletReservationId(reservationId: number | null): void;
/**
 * Keep the existing `auto` free-model API contract separate from the
 * administrator's full fallback chain.  This flag is request-scoped: it is
 * set only for an external universal consumer key and is read by the router.
 */
export declare function setConsumerFreeOnly(enabled: boolean): void;
/** Attach the provider-side Codex usage row to the next request log entry. */
export declare function setCodexUsageRecordId(recordId: number | null): void;
export declare function setResourceReservation(input: {
    subpoolId: number;
    memberId: number;
    reservationId: number;
    requestCorrelationId: string;
}): void;
export declare function setResourceDispatchId(dispatchId: number | null): void;
export declare function markResourceUsageObserved(): void;
/**
 * A fallback attempt is not the whole consumer request. Keep its analytics and
 * provider-usage log, but leave the request-level resource reservation open so
 * a same-scope sibling can still succeed and settle it exactly once.
 */
export declare function withDeferredResourceSettlement<T>(callback: () => T): T;
export declare function setFreeModelUsage(usageDate: string): void;
export declare function markFreeModelUsageCommitted(): void;
/**
 * Consume the current Codex usage row exactly once. A request can fail over
 * between several Codex accounts; each attempt records and links its own row.
 */
export declare function takeCodexUsageRecordId(): number | null;
//# sourceMappingURL=client-context.d.ts.map