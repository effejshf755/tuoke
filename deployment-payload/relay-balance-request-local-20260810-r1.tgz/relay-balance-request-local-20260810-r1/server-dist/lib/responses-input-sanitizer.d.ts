/**
 * Return an isolated copy of a Responses request whose replayed input items are
 * portable across independent, stateless upstreams.
 *
 * Message item IDs belong to the upstream that created them and can be omitted
 * during replay. Reasoning can only be replayed statelessly when the upstream
 * returned `encrypted_content`; unlike messages, the Responses input schema
 * still requires its original non-empty reasoning `id`. Items missing either
 * field are therefore omitted rather than converted into an invalid shape.
 *
 * Function/custom tool item IDs and every `call_id` are deliberately left
 * untouched. Those identifiers link calls to their outputs, and rewriting them
 * would corrupt the conversation.
 */
export declare function sanitizeResponsesRequestInputIds<T>(request: T): T;
//# sourceMappingURL=responses-input-sanitizer.d.ts.map