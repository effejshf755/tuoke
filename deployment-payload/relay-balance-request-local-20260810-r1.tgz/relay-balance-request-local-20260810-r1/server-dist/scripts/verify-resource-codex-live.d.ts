export {};
//# sourceMappingURL=verify-resource-codex-live.d.ts.map